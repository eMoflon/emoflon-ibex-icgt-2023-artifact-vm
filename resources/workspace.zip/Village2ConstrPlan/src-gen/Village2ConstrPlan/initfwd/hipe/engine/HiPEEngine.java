package Village2ConstrPlan.initfwd.hipe.engine;

import akka.actor.ActorRef;
import akka.actor.Props;

import Village2ConstrPlan.initfwd.hipe.engine.actor.NotificationActor;
import Village2ConstrPlan.initfwd.hipe.engine.actor.DispatchActor;
import Village2ConstrPlan.initfwd.hipe.engine.actor.localsearch.Corner2Constr_h_nextHouse_incoming_SRC__FILTER_NAC_SRC_1_localSearch;
import Village2ConstrPlan.initfwd.hipe.engine.actor.localsearch.Corner2Constr_cst_firstStep_outgoing_TRG__FILTER_NAC_TRG_4_localSearch;
import Village2ConstrPlan.initfwd.hipe.engine.actor.localsearch.Corner2Constr__CONSISTENCY_8_localSearch;
import Village2ConstrPlan.initfwd.hipe.engine.actor.localsearch.Corner2Constr__FWD_18_localSearch;
import Village2ConstrPlan.initfwd.hipe.engine.actor.localsearch.Cube2Constr_nh_streetCorner_incoming_SRC__FILTER_NAC_SRC_23_localSearch;
import Village2ConstrPlan.initfwd.hipe.engine.actor.localsearch.Cube2Constr_ncst_firstStep_outgoing_TRG__FILTER_NAC_TRG_26_localSearch;
import Village2ConstrPlan.initfwd.hipe.engine.actor.localsearch.Cube2Constr__CONSISTENCY_30_localSearch;
import Village2ConstrPlan.initfwd.hipe.engine.actor.localsearch.Cube2Constr__FWD_41_localSearch;
import Village2ConstrPlan.initfwd.hipe.engine.actor.localsearch.Villa2Constr_nh_streetCorner_incoming_SRC__FILTER_NAC_SRC_47_localSearch;
import Village2ConstrPlan.initfwd.hipe.engine.actor.localsearch.Villa2Constr_ncst_firstStep_outgoing_TRG__FILTER_NAC_TRG_50_localSearch;
import Village2ConstrPlan.initfwd.hipe.engine.actor.localsearch.Villa2Constr__CONSISTENCY_54_localSearch;
import Village2ConstrPlan.initfwd.hipe.engine.actor.localsearch.Villa2Constr__FWD_65_localSearch;
import Village2ConstrPlan.initfwd.hipe.engine.actor.localsearch.VillageSquare2PlanCollection__CONSISTENCY_71_localSearch;

import hipe.engine.IHiPEEngine;
import hipe.engine.message.InitGenReferenceActor;

import hipe.generic.actor.GenericObjectActor;
import hipe.generic.actor.GenericReferenceActor;
import hipe.generic.actor.GenericProductionActor;
import hipe.generic.actor.junction.*;

import hipe.network.*;

public class HiPEEngine extends IHiPEEngine{
	
	public HiPEEngine(HiPENetwork network) {
		super(network);
	}
	
	public HiPEEngine() {
		super();
	}
	
	@Override
	public String getClassLocation() {
		return getClass().getProtectionDomain().getCodeSource().getLocation().getPath().toString();
	}
	
	@Override
	public String getPackageName() {
		return getClass().getPackageName();
	}
	
	@Override
	protected ActorRef getDispatchActor() {
		return system.actorOf(
			Props.create(DispatchActor.class, () -> new DispatchActor(name2actor, incUtil)),
			"DispatchActor");
	}
	
	@Override
	protected ActorRef getNotificationActor(boolean cascadingNotifications) {
		return system.actorOf(
			Props.create(NotificationActor.class, () -> new NotificationActor(dispatcher, incUtil, cascadingNotifications)), 
			"NotificationActor");
	}
	
	@Override
	public void createProductionNodes() {
		classes.put("Corner2Constr__CONSISTENCY_production", GenericProductionActor.class);
		productionNodes2pattern.put("Corner2Constr__CONSISTENCY_production", "Corner2Constr__CONSISTENCY");
		classes.put("Corner2Constr__FWD_production", GenericProductionActor.class);
		productionNodes2pattern.put("Corner2Constr__FWD_production", "Corner2Constr__FWD");
		classes.put("Corner2Constr_cst_firstStep_outgoing_TRG__FILTER_NAC_TRG_production", GenericProductionActor.class);
		productionNodes2pattern.put("Corner2Constr_cst_firstStep_outgoing_TRG__FILTER_NAC_TRG_production", "Corner2Constr_cst_firstStep_outgoing_TRG__FILTER_NAC_TRG");
		classes.put("Corner2Constr_h_nextHouse_incoming_SRC__FILTER_NAC_SRC_production", GenericProductionActor.class);
		productionNodes2pattern.put("Corner2Constr_h_nextHouse_incoming_SRC__FILTER_NAC_SRC_production", "Corner2Constr_h_nextHouse_incoming_SRC__FILTER_NAC_SRC");
		classes.put("Cube2Constr__CONSISTENCY_production", GenericProductionActor.class);
		productionNodes2pattern.put("Cube2Constr__CONSISTENCY_production", "Cube2Constr__CONSISTENCY");
		classes.put("Cube2Constr__FWD_production", GenericProductionActor.class);
		productionNodes2pattern.put("Cube2Constr__FWD_production", "Cube2Constr__FWD");
		classes.put("Cube2Constr_ncst_firstStep_outgoing_TRG__FILTER_NAC_TRG_production", GenericProductionActor.class);
		productionNodes2pattern.put("Cube2Constr_ncst_firstStep_outgoing_TRG__FILTER_NAC_TRG_production", "Cube2Constr_ncst_firstStep_outgoing_TRG__FILTER_NAC_TRG");
		classes.put("Cube2Constr_nh_streetCorner_incoming_SRC__FILTER_NAC_SRC_production", GenericProductionActor.class);
		productionNodes2pattern.put("Cube2Constr_nh_streetCorner_incoming_SRC__FILTER_NAC_SRC_production", "Cube2Constr_nh_streetCorner_incoming_SRC__FILTER_NAC_SRC");
		classes.put("Villa2Constr__CONSISTENCY_production", GenericProductionActor.class);
		productionNodes2pattern.put("Villa2Constr__CONSISTENCY_production", "Villa2Constr__CONSISTENCY");
		classes.put("Villa2Constr__FWD_production", GenericProductionActor.class);
		productionNodes2pattern.put("Villa2Constr__FWD_production", "Villa2Constr__FWD");
		classes.put("Villa2Constr_ncst_firstStep_outgoing_TRG__FILTER_NAC_TRG_production", GenericProductionActor.class);
		productionNodes2pattern.put("Villa2Constr_ncst_firstStep_outgoing_TRG__FILTER_NAC_TRG_production", "Villa2Constr_ncst_firstStep_outgoing_TRG__FILTER_NAC_TRG");
		classes.put("Villa2Constr_nh_streetCorner_incoming_SRC__FILTER_NAC_SRC_production", GenericProductionActor.class);
		productionNodes2pattern.put("Villa2Constr_nh_streetCorner_incoming_SRC__FILTER_NAC_SRC_production", "Villa2Constr_nh_streetCorner_incoming_SRC__FILTER_NAC_SRC");
		classes.put("VillageSquare2PlanCollection__CONSISTENCY_production", GenericProductionActor.class);
		productionNodes2pattern.put("VillageSquare2PlanCollection__CONSISTENCY_production", "VillageSquare2PlanCollection__CONSISTENCY");
		classes.put("VillageSquare2PlanCollection__FWD_production", GenericProductionActor.class);
		productionNodes2pattern.put("VillageSquare2PlanCollection__FWD_production", "VillageSquare2PlanCollection__FWD");
		
	}
	
	@Override
	public void createJunctionNodes() {
		classes.put("Corner2Constr_h_nextHouse_incoming_SRC__FILTER_NAC_SRC_1_localSearch", Corner2Constr_h_nextHouse_incoming_SRC__FILTER_NAC_SRC_1_localSearch.class);
		classes.put("Corner2Constr_cst_firstStep_outgoing_TRG__FILTER_NAC_TRG_4_localSearch", Corner2Constr_cst_firstStep_outgoing_TRG__FILTER_NAC_TRG_4_localSearch.class);
		classes.put("Corner2Constr__CONSISTENCY_8_localSearch", Corner2Constr__CONSISTENCY_8_localSearch.class);
		classes.put("Corner2Constr__FWD_18_localSearch", Corner2Constr__FWD_18_localSearch.class);
		classes.put("Cube2Constr_nh_streetCorner_incoming_SRC__FILTER_NAC_SRC_23_localSearch", Cube2Constr_nh_streetCorner_incoming_SRC__FILTER_NAC_SRC_23_localSearch.class);
		classes.put("Cube2Constr_ncst_firstStep_outgoing_TRG__FILTER_NAC_TRG_26_localSearch", Cube2Constr_ncst_firstStep_outgoing_TRG__FILTER_NAC_TRG_26_localSearch.class);
		classes.put("Cube2Constr__CONSISTENCY_30_localSearch", Cube2Constr__CONSISTENCY_30_localSearch.class);
		classes.put("Cube2Constr__FWD_41_localSearch", Cube2Constr__FWD_41_localSearch.class);
		classes.put("Villa2Constr_nh_streetCorner_incoming_SRC__FILTER_NAC_SRC_47_localSearch", Villa2Constr_nh_streetCorner_incoming_SRC__FILTER_NAC_SRC_47_localSearch.class);
		classes.put("Villa2Constr_ncst_firstStep_outgoing_TRG__FILTER_NAC_TRG_50_localSearch", Villa2Constr_ncst_firstStep_outgoing_TRG__FILTER_NAC_TRG_50_localSearch.class);
		classes.put("Villa2Constr__CONSISTENCY_54_localSearch", Villa2Constr__CONSISTENCY_54_localSearch.class);
		classes.put("Villa2Constr__FWD_65_localSearch", Villa2Constr__FWD_65_localSearch.class);
		classes.put("VillageSquare2PlanCollection__CONSISTENCY_71_localSearch", VillageSquare2PlanCollection__CONSISTENCY_71_localSearch.class);
	}
	
	@Override
	public void createReferenceNodes() {
		
	}
	
	@Override
	public void createObjectNodes() {
		classes.put("PlanCollection_object",PlanCollection_object.class);
		classes.put("VillageSquare2PlanCollection_object",VillageSquare2PlanCollection_object.class);
		classes.put("Corner2Constr__Marker_object",Corner2Constr__Marker_object.class);
		classes.put("Component_object",Component_object.class);
		classes.put("Cellar_object",Cellar_object.class);
		classes.put("Cube2Constr__Marker_object",Cube2Constr__Marker_object.class);
		classes.put("SaddleRoof_object",SaddleRoof_object.class);
		classes.put("Villa2Constr__Marker_object",Villa2Constr__Marker_object.class);
		classes.put("VillageSquare2PlanCollection__Marker_object",VillageSquare2PlanCollection__Marker_object.class);
		classes.put("House_object_SP0",House_object_SP0.class);
		classes.put("House_object_SP1",House_object_SP1.class);
		classes.put("House_object_SP2",House_object_SP2.class);
		classes.put("VillageSquare_object_SP0",VillageSquare_object_SP0.class);
		classes.put("VillageSquare_object_SP1",VillageSquare_object_SP1.class);
		classes.put("Basement_object_SP0",Basement_object_SP0.class);
		classes.put("Basement_object_SP1",Basement_object_SP1.class);
		classes.put("Construction_object_SP0",Construction_object_SP0.class);
		classes.put("Construction_object_SP1",Construction_object_SP1.class);
		classes.put("Plan_object_SP0",Plan_object_SP0.class);
		classes.put("Plan_object_SP1",Plan_object_SP1.class);
		classes.put("House2Constr_object_SP0",House2Constr_object_SP0.class);
		classes.put("House2Constr_object_SP1",House2Constr_object_SP1.class);
		
	}
	
	@Override
	public void initializeReferenceNodes() {
	}
}

class PlanCollection_object extends GenericObjectActor<ConstructionPlan.PlanCollection> { }
class VillageSquare2PlanCollection_object extends GenericObjectActor<Village2ConstrPlan.VillageSquare2PlanCollection> { }
class Corner2Constr__Marker_object extends GenericObjectActor<Village2ConstrPlan.Corner2Constr__Marker> { }
class Component_object extends GenericObjectActor<ConstructionPlan.Component> { }
class Cellar_object extends GenericObjectActor<ConstructionPlan.Cellar> { }
class Cube2Constr__Marker_object extends GenericObjectActor<Village2ConstrPlan.Cube2Constr__Marker> { }
class SaddleRoof_object extends GenericObjectActor<ConstructionPlan.SaddleRoof> { }
class Villa2Constr__Marker_object extends GenericObjectActor<Village2ConstrPlan.Villa2Constr__Marker> { }
class VillageSquare2PlanCollection__Marker_object extends GenericObjectActor<Village2ConstrPlan.VillageSquare2PlanCollection__Marker> { }
class House_object_SP0 extends GenericObjectActor<Village.House> { }
class House_object_SP1 extends GenericObjectActor<Village.House> { }
class House_object_SP2 extends GenericObjectActor<Village.House> { }
class VillageSquare_object_SP0 extends GenericObjectActor<Village.VillageSquare> { }
class VillageSquare_object_SP1 extends GenericObjectActor<Village.VillageSquare> { }
class Basement_object_SP0 extends GenericObjectActor<ConstructionPlan.Basement> { }
class Basement_object_SP1 extends GenericObjectActor<ConstructionPlan.Basement> { }
class Construction_object_SP0 extends GenericObjectActor<ConstructionPlan.Construction> { }
class Construction_object_SP1 extends GenericObjectActor<ConstructionPlan.Construction> { }
class Plan_object_SP0 extends GenericObjectActor<ConstructionPlan.Plan> { }
class Plan_object_SP1 extends GenericObjectActor<ConstructionPlan.Plan> { }
class House2Constr_object_SP0 extends GenericObjectActor<Village2ConstrPlan.House2Constr> { }
class House2Constr_object_SP1 extends GenericObjectActor<Village2ConstrPlan.House2Constr> { }


