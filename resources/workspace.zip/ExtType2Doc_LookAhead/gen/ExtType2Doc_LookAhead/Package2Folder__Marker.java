package ExtType2Doc_LookAhead;

import runtime.RuntimePackage;
import ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage;

import org.emoflon.smartemf.runtime.notification.SmartEMFNotification;
import org.emoflon.smartemf.runtime.SmartObject;
import org.emoflon.smartemf.runtime.collections.*;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EStructuralFeature;

public interface Package2Folder__Marker extends EObject, runtime.TGGRuleApplication {
	
    public runtime.Protocol getProtocol();
    
    public void setProtocol(runtime.Protocol value);
    
    public ExtTypeModel.Package getCREATE__SRC__p();
    
    public void setCREATE__SRC__p(ExtTypeModel.Package value);
    
    public ExtDocModel.Folder getCREATE__TRG__f();
    
    public void setCREATE__TRG__f(ExtDocModel.Folder value);
    
    public ExtType2Doc_LookAhead.Package2Folder getCREATE__CORR__p2f();
    
    public void setCREATE__CORR__p2f(ExtType2Doc_LookAhead.Package2Folder value);
    

}
