package Village;

import java.lang.String;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.eclipse.emf.common.util.Enumerator;

public enum HouseType implements Enumerator {
	
	 CORNER(0, "CORNER", "CORNER"), CUBE(1, "CUBE", "CUBE"), VILLA(2, "VILLA", "VILLA");
	
	public static final int CORNER_VALUE = 0;
	public static final int CUBE_VALUE = 1;
	public static final int VILLA_VALUE = 2;
	
	private static final HouseType[] VALUES_ARRAY = new HouseType[] {CORNER,CUBE,VILLA};

	public static final List<HouseType> VALUES = Collections.unmodifiableList(Arrays.asList(VALUES_ARRAY));

	public static HouseType get(String literal) {
	for (int i = 0; i < VALUES_ARRAY.length; ++i) {
		HouseType result = VALUES_ARRAY[i];
		if (result.toString().equals(literal)) {
			return result;
		}
	}
	return null;
	}

	public static HouseType getByName(String name) {
	for (int i = 0; i < VALUES_ARRAY.length; ++i) {
		HouseType result = VALUES_ARRAY[i];
		if (result.getName().equals(name)) {
			return result;
		}
	}
	return null;
	}

	public static HouseType get(int value) {
		switch (value) {
		case CORNER_VALUE:
			return CORNER;
		case CUBE_VALUE:
			return CUBE;
		case VILLA_VALUE:
			return VILLA;
		}
		return null;
	}

	private final int value;

	private final String name;

	private final String literal;

	private HouseType(int value, String name, String literal) {
	this.value = value;
	this.name = name;
	this.literal = literal;
	}

	@Override
	public int getValue() {
		return value;
	}

	@Override
	public String getName() {
	return name;
	}

	@Override
	public String getLiteral() {
		return literal;
	}

	@Override
	public String toString() {
	return literal;
	}

}

