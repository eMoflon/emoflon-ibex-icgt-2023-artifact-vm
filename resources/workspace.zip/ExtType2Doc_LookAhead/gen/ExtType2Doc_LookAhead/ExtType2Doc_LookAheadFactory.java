package ExtType2Doc_LookAhead;

import ExtType2Doc_LookAhead.Package2Folder;
import ExtType2Doc_LookAhead.Type2Doc;
import ExtType2Doc_LookAhead.Method2Entry;
import ExtType2Doc_LookAhead.Param2Entry;
import ExtType2Doc_LookAhead.Field2Entry;
import ExtType2Doc_LookAhead.ExtendingType2Doc__Marker;
import ExtType2Doc_LookAhead.Field2Entry__Marker;
import ExtType2Doc_LookAhead.ImplementingType2Doc__Marker;
import ExtType2Doc_LookAhead.Method2Entry__Marker;
import ExtType2Doc_LookAhead.Package2Folder__Marker;
import ExtType2Doc_LookAhead.Param2Entry__Marker;
import ExtType2Doc_LookAhead.SubPackage2Folder__Marker;
import ExtType2Doc_LookAhead.Type2Doc__Marker;

import org.eclipse.emf.ecore.EFactory;

public interface ExtType2Doc_LookAheadFactory extends EFactory {

	ExtType2Doc_LookAheadFactory eINSTANCE = ExtType2Doc_LookAhead.impl.ExtType2Doc_LookAheadFactoryImpl.init();
	
	Package2Folder createPackage2Folder();
	
	Type2Doc createType2Doc();
	
	Method2Entry createMethod2Entry();
	
	Param2Entry createParam2Entry();
	
	Field2Entry createField2Entry();
	
	ExtendingType2Doc__Marker createExtendingType2Doc__Marker();
	
	Field2Entry__Marker createField2Entry__Marker();
	
	ImplementingType2Doc__Marker createImplementingType2Doc__Marker();
	
	Method2Entry__Marker createMethod2Entry__Marker();
	
	Package2Folder__Marker createPackage2Folder__Marker();
	
	Param2Entry__Marker createParam2Entry__Marker();
	
	SubPackage2Folder__Marker createSubPackage2Folder__Marker();
	
	Type2Doc__Marker createType2Doc__Marker();
	
	
	ExtType2Doc_LookAheadPackage getExtType2Doc_LookAheadPackage();

}
