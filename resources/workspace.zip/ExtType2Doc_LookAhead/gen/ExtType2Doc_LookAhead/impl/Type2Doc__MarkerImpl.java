package ExtType2Doc_LookAhead.impl;

import ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage;
import runtime.RuntimePackage;
import ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage;

import org.emoflon.smartemf.runtime.*;
import org.emoflon.smartemf.runtime.collections.*;
import org.emoflon.smartemf.persistence.SmartEMFResource;
import org.emoflon.smartemf.runtime.notification.SmartEMFNotification;
import org.emoflon.smartemf.runtime.notification.NotifyStatus;

import java.util.function.Consumer;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EcoreFactory;
import org.eclipse.emf.ecore.EcorePackage;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.resource.Resource;

public class Type2Doc__MarkerImpl extends SmartObject implements ExtType2Doc_LookAhead.Type2Doc__Marker {

    protected runtime.Protocol protocol = null;
    protected ExtTypeModel.Package CONTEXT__SRC__p = null;
    protected ExtTypeModel.Type CREATE__SRC__t = null;
    protected ExtDocModel.Doc CREATE__TRG__d = null;
    protected ExtDocModel.Folder CONTEXT__TRG__f = null;
    protected ExtType2Doc_LookAhead.Package2Folder CONTEXT__CORR__p2f = null;
    protected ExtType2Doc_LookAhead.Type2Doc CREATE__CORR__t2d = null;
	
	protected Type2Doc__MarkerImpl() {
		super(ExtType2Doc_LookAheadPackage.Literals.TYPE2_DOC___MARKER);
	}
	
    
    @Override
    public runtime.Protocol getProtocol() {
    	return this.protocol;
    }
    
    @Override
    public void setProtocol(runtime.Protocol value) {
    	
    	Object oldValue = this.protocol;
    	
    	if(value == null && oldValue == null)
    		return;
    		
    	if(value != null && value.equals(oldValue))
    		return;
    		
    	
    	
    		       	if(this.protocol != null && value == null) {
    		       		resetContainmentSilently();
    		       	}
    		        this.protocol = value;
    		        
    	
    	
    	        	sendNotification(SmartEMFNotification.createSetNotification(this, RuntimePackage.Literals.TGG_RULE_APPLICATION__PROTOCOL, oldValue, value, -1));
    	        	
    	
    	        	if(oldValue != null) {
    	        		((SmartObject) oldValue).eInverseRemove(this, RuntimePackage.Literals.PROTOCOL__STEPS);
    	        	}
    	        	if(value != null) {
    	        		((SmartObject) value).eInverseAdd(this, RuntimePackage.Literals.PROTOCOL__STEPS);
    	        	}
    }
    
    private void setProtocolAsInverse(runtime.Protocol value) {
			    
			    Object oldValue = this.protocol;
			    
			    if(value == null && oldValue == null)
			    	return;
			    	
			    if(value != null && value.equals(oldValue))
			    	return;
			    	
			    
			    
			    	       	if(this.protocol != null && value == null) {
			    	       		resetContainmentSilently();
			    	       	}
			    	        this.protocol = value;
			    	        
			    
			    
			            	sendNotification(SmartEMFNotification.createSetNotification(this, RuntimePackage.Literals.TGG_RULE_APPLICATION__PROTOCOL, oldValue, value, -1));
			            	
    }
    
    @Override
    public ExtTypeModel.Package getCONTEXT__SRC__p() {
    	return this.CONTEXT__SRC__p;
    }
    
    @Override
    public void setCONTEXT__SRC__p(ExtTypeModel.Package value) {
    	
    	Object oldValue = this.CONTEXT__SRC__p;
    	
    	if(value == null && oldValue == null)
    		return;
    		
    	if(value != null && value.equals(oldValue))
    		return;
    		
    	
    	
    		        this.CONTEXT__SRC__p = value;
    		        
    	
    	
    	        	sendNotification(SmartEMFNotification.createSetNotification(this, ExtType2Doc_LookAheadPackage.Literals.TYPE2_DOC___MARKER__CONTEX_T__SR_C__P, oldValue, value, -1));
    	        	
    	        	if(ExtType2Doc_LookAheadPackage.Literals.TYPE2_DOC___MARKER__CONTEX_T__SR_C__P.getEOpposite() != null) {
    	        		if(oldValue != null) {
    	        			((SmartObject) oldValue).eInverseRemove(this, ExtType2Doc_LookAheadPackage.Literals.TYPE2_DOC___MARKER__CONTEX_T__SR_C__P.getEOpposite());
    	        		}
    	        		if(value != null) {
    	        		    ((SmartObject) value).eInverseAdd(this, ExtType2Doc_LookAheadPackage.Literals.TYPE2_DOC___MARKER__CONTEX_T__SR_C__P.getEOpposite());
    	        		}
    	        	}
    }
    
    
    @Override
    public ExtTypeModel.Type getCREATE__SRC__t() {
    	return this.CREATE__SRC__t;
    }
    
    @Override
    public void setCREATE__SRC__t(ExtTypeModel.Type value) {
    	
    	Object oldValue = this.CREATE__SRC__t;
    	
    	if(value == null && oldValue == null)
    		return;
    		
    	if(value != null && value.equals(oldValue))
    		return;
    		
    	
    	
    		        this.CREATE__SRC__t = value;
    		        
    	
    	
    	        	sendNotification(SmartEMFNotification.createSetNotification(this, ExtType2Doc_LookAheadPackage.Literals.TYPE2_DOC___MARKER__CREAT_E__SR_C__T, oldValue, value, -1));
    	        	
    	        	if(ExtType2Doc_LookAheadPackage.Literals.TYPE2_DOC___MARKER__CREAT_E__SR_C__T.getEOpposite() != null) {
    	        		if(oldValue != null) {
    	        			((SmartObject) oldValue).eInverseRemove(this, ExtType2Doc_LookAheadPackage.Literals.TYPE2_DOC___MARKER__CREAT_E__SR_C__T.getEOpposite());
    	        		}
    	        		if(value != null) {
    	        		    ((SmartObject) value).eInverseAdd(this, ExtType2Doc_LookAheadPackage.Literals.TYPE2_DOC___MARKER__CREAT_E__SR_C__T.getEOpposite());
    	        		}
    	        	}
    }
    
    
    @Override
    public ExtDocModel.Doc getCREATE__TRG__d() {
    	return this.CREATE__TRG__d;
    }
    
    @Override
    public void setCREATE__TRG__d(ExtDocModel.Doc value) {
    	
    	Object oldValue = this.CREATE__TRG__d;
    	
    	if(value == null && oldValue == null)
    		return;
    		
    	if(value != null && value.equals(oldValue))
    		return;
    		
    	
    	
    		        this.CREATE__TRG__d = value;
    		        
    	
    	
    	        	sendNotification(SmartEMFNotification.createSetNotification(this, ExtType2Doc_LookAheadPackage.Literals.TYPE2_DOC___MARKER__CREAT_E__TR_G__D, oldValue, value, -1));
    	        	
    	        	if(ExtType2Doc_LookAheadPackage.Literals.TYPE2_DOC___MARKER__CREAT_E__TR_G__D.getEOpposite() != null) {
    	        		if(oldValue != null) {
    	        			((SmartObject) oldValue).eInverseRemove(this, ExtType2Doc_LookAheadPackage.Literals.TYPE2_DOC___MARKER__CREAT_E__TR_G__D.getEOpposite());
    	        		}
    	        		if(value != null) {
    	        		    ((SmartObject) value).eInverseAdd(this, ExtType2Doc_LookAheadPackage.Literals.TYPE2_DOC___MARKER__CREAT_E__TR_G__D.getEOpposite());
    	        		}
    	        	}
    }
    
    
    @Override
    public ExtDocModel.Folder getCONTEXT__TRG__f() {
    	return this.CONTEXT__TRG__f;
    }
    
    @Override
    public void setCONTEXT__TRG__f(ExtDocModel.Folder value) {
    	
    	Object oldValue = this.CONTEXT__TRG__f;
    	
    	if(value == null && oldValue == null)
    		return;
    		
    	if(value != null && value.equals(oldValue))
    		return;
    		
    	
    	
    		        this.CONTEXT__TRG__f = value;
    		        
    	
    	
    	        	sendNotification(SmartEMFNotification.createSetNotification(this, ExtType2Doc_LookAheadPackage.Literals.TYPE2_DOC___MARKER__CONTEX_T__TR_G__F, oldValue, value, -1));
    	        	
    	        	if(ExtType2Doc_LookAheadPackage.Literals.TYPE2_DOC___MARKER__CONTEX_T__TR_G__F.getEOpposite() != null) {
    	        		if(oldValue != null) {
    	        			((SmartObject) oldValue).eInverseRemove(this, ExtType2Doc_LookAheadPackage.Literals.TYPE2_DOC___MARKER__CONTEX_T__TR_G__F.getEOpposite());
    	        		}
    	        		if(value != null) {
    	        		    ((SmartObject) value).eInverseAdd(this, ExtType2Doc_LookAheadPackage.Literals.TYPE2_DOC___MARKER__CONTEX_T__TR_G__F.getEOpposite());
    	        		}
    	        	}
    }
    
    
    @Override
    public ExtType2Doc_LookAhead.Package2Folder getCONTEXT__CORR__p2f() {
    	return this.CONTEXT__CORR__p2f;
    }
    
    @Override
    public void setCONTEXT__CORR__p2f(ExtType2Doc_LookAhead.Package2Folder value) {
    	
    	Object oldValue = this.CONTEXT__CORR__p2f;
    	
    	if(value == null && oldValue == null)
    		return;
    		
    	if(value != null && value.equals(oldValue))
    		return;
    		
    	
    	
    		        this.CONTEXT__CORR__p2f = value;
    		        
    	
    	
    	        	sendNotification(SmartEMFNotification.createSetNotification(this, ExtType2Doc_LookAheadPackage.Literals.TYPE2_DOC___MARKER__CONTEX_T__COR_R__P2F, oldValue, value, -1));
    	        	
    	        	if(ExtType2Doc_LookAheadPackage.Literals.TYPE2_DOC___MARKER__CONTEX_T__COR_R__P2F.getEOpposite() != null) {
    	        		if(oldValue != null) {
    	        			((SmartObject) oldValue).eInverseRemove(this, ExtType2Doc_LookAheadPackage.Literals.TYPE2_DOC___MARKER__CONTEX_T__COR_R__P2F.getEOpposite());
    	        		}
    	        		if(value != null) {
    	        		    ((SmartObject) value).eInverseAdd(this, ExtType2Doc_LookAheadPackage.Literals.TYPE2_DOC___MARKER__CONTEX_T__COR_R__P2F.getEOpposite());
    	        		}
    	        	}
    }
    
    
    @Override
    public ExtType2Doc_LookAhead.Type2Doc getCREATE__CORR__t2d() {
    	return this.CREATE__CORR__t2d;
    }
    
    @Override
    public void setCREATE__CORR__t2d(ExtType2Doc_LookAhead.Type2Doc value) {
    	
    	Object oldValue = this.CREATE__CORR__t2d;
    	
    	if(value == null && oldValue == null)
    		return;
    		
    	if(value != null && value.equals(oldValue))
    		return;
    		
    	
    	
    		        this.CREATE__CORR__t2d = value;
    		        
    	
    	
    	        	sendNotification(SmartEMFNotification.createSetNotification(this, ExtType2Doc_LookAheadPackage.Literals.TYPE2_DOC___MARKER__CREAT_E__COR_R__T2D, oldValue, value, -1));
    	        	
    	        	if(ExtType2Doc_LookAheadPackage.Literals.TYPE2_DOC___MARKER__CREAT_E__COR_R__T2D.getEOpposite() != null) {
    	        		if(oldValue != null) {
    	        			((SmartObject) oldValue).eInverseRemove(this, ExtType2Doc_LookAheadPackage.Literals.TYPE2_DOC___MARKER__CREAT_E__COR_R__T2D.getEOpposite());
    	        		}
    	        		if(value != null) {
    	        		    ((SmartObject) value).eInverseAdd(this, ExtType2Doc_LookAheadPackage.Literals.TYPE2_DOC___MARKER__CREAT_E__COR_R__T2D.getEOpposite());
    	        		}
    	        	}
    }
    

    @Override
    public void eSet(EStructuralFeature eFeature, Object newValue){
    	if (RuntimePackage.Literals.TGG_RULE_APPLICATION__PROTOCOL.equals(eFeature)) {
    		setProtocol((runtime.Protocol) newValue); 
    		return;
    	}
    	if (ExtType2Doc_LookAheadPackage.Literals.TYPE2_DOC___MARKER__CONTEX_T__SR_C__P.equals(eFeature)) {
    		setCONTEXT__SRC__p((ExtTypeModel.Package) newValue); 
    		return;
    	}
    	if (ExtType2Doc_LookAheadPackage.Literals.TYPE2_DOC___MARKER__CREAT_E__SR_C__T.equals(eFeature)) {
    		setCREATE__SRC__t((ExtTypeModel.Type) newValue); 
    		return;
    	}
    	if (ExtType2Doc_LookAheadPackage.Literals.TYPE2_DOC___MARKER__CREAT_E__TR_G__D.equals(eFeature)) {
    		setCREATE__TRG__d((ExtDocModel.Doc) newValue); 
    		return;
    	}
    	if (ExtType2Doc_LookAheadPackage.Literals.TYPE2_DOC___MARKER__CONTEX_T__TR_G__F.equals(eFeature)) {
    		setCONTEXT__TRG__f((ExtDocModel.Folder) newValue); 
    		return;
    	}
    	if (ExtType2Doc_LookAheadPackage.Literals.TYPE2_DOC___MARKER__CONTEX_T__COR_R__P2F.equals(eFeature)) {
    		setCONTEXT__CORR__p2f((ExtType2Doc_LookAhead.Package2Folder) newValue); 
    		return;
    	}
    	if (ExtType2Doc_LookAheadPackage.Literals.TYPE2_DOC___MARKER__CREAT_E__COR_R__T2D.equals(eFeature)) {
    		setCREATE__CORR__t2d((ExtType2Doc_LookAhead.Type2Doc) newValue); 
    		return;
    	}
    	eDynamicSet(eFeature, newValue);
    }
    
    @Override
    public void eUnset(EStructuralFeature eFeature){
    	if (RuntimePackage.Literals.TGG_RULE_APPLICATION__PROTOCOL.equals(eFeature)) {
    		setProtocol((runtime.Protocol)null); 
    		return;
    	}
    	if (ExtType2Doc_LookAheadPackage.Literals.TYPE2_DOC___MARKER__CONTEX_T__SR_C__P.equals(eFeature)) {
    		setCONTEXT__SRC__p((ExtTypeModel.Package)null); 
    		return;
    	}
    	if (ExtType2Doc_LookAheadPackage.Literals.TYPE2_DOC___MARKER__CREAT_E__SR_C__T.equals(eFeature)) {
    		setCREATE__SRC__t((ExtTypeModel.Type)null); 
    		return;
    	}
    	if (ExtType2Doc_LookAheadPackage.Literals.TYPE2_DOC___MARKER__CREAT_E__TR_G__D.equals(eFeature)) {
    		setCREATE__TRG__d((ExtDocModel.Doc)null); 
    		return;
    	}
    	if (ExtType2Doc_LookAheadPackage.Literals.TYPE2_DOC___MARKER__CONTEX_T__TR_G__F.equals(eFeature)) {
    		setCONTEXT__TRG__f((ExtDocModel.Folder)null); 
    		return;
    	}
    	if (ExtType2Doc_LookAheadPackage.Literals.TYPE2_DOC___MARKER__CONTEX_T__COR_R__P2F.equals(eFeature)) {
    		setCONTEXT__CORR__p2f((ExtType2Doc_LookAhead.Package2Folder)null); 
    		return;
    	}
    	if (ExtType2Doc_LookAheadPackage.Literals.TYPE2_DOC___MARKER__CREAT_E__COR_R__T2D.equals(eFeature)) {
    		setCREATE__CORR__t2d((ExtType2Doc_LookAhead.Type2Doc)null); 
    		return;
    	}
    	eDynamicUnset(eFeature);
    }

    @Override
    public String toString(){
		return super.toString();
    }

 	@Override
    public Object eGet(EStructuralFeature eFeature){
    	if (RuntimePackage.Literals.TGG_RULE_APPLICATION__PROTOCOL.equals(eFeature))
    		return getProtocol();
    	if (ExtType2Doc_LookAheadPackage.Literals.TYPE2_DOC___MARKER__CONTEX_T__SR_C__P.equals(eFeature))
    		return getCONTEXT__SRC__p();
    	if (ExtType2Doc_LookAheadPackage.Literals.TYPE2_DOC___MARKER__CREAT_E__SR_C__T.equals(eFeature))
    		return getCREATE__SRC__t();
    	if (ExtType2Doc_LookAheadPackage.Literals.TYPE2_DOC___MARKER__CREAT_E__TR_G__D.equals(eFeature))
    		return getCREATE__TRG__d();
    	if (ExtType2Doc_LookAheadPackage.Literals.TYPE2_DOC___MARKER__CONTEX_T__TR_G__F.equals(eFeature))
    		return getCONTEXT__TRG__f();
    	if (ExtType2Doc_LookAheadPackage.Literals.TYPE2_DOC___MARKER__CONTEX_T__COR_R__P2F.equals(eFeature))
    		return getCONTEXT__CORR__p2f();
    	if (ExtType2Doc_LookAheadPackage.Literals.TYPE2_DOC___MARKER__CREAT_E__COR_R__T2D.equals(eFeature))
    		return getCREATE__CORR__t2d();
    	return eDynamicGet(eFeature);
    }

    @Override
    public Object eGet(int featureID, boolean resolve, boolean coreType){
    	throw new UnsupportedOperationException("This method has been deactivated since it is not always safe to use.");
    }
    
    @Override
    public void eInverseAdd(Object otherEnd, EStructuralFeature feature) {
if (RuntimePackage.Literals.TGG_RULE_APPLICATION__PROTOCOL.equals(feature)) {
setProtocolAsInverse((runtime.Protocol) otherEnd); 
 	return;
			        }	
	    if(feature == null)
	    	return;
	    	
    	eDynamicInverseAdd(otherEnd, feature);
	    	}
    	
    @Override
	    	public void eInverseRemove(Object otherEnd, EStructuralFeature feature) {
if (RuntimePackage.Literals.TGG_RULE_APPLICATION__PROTOCOL.equals(feature)) {
setProtocolAsInverse(null); 
 	return;
			        }
	    if(feature == null)
	    	return;
	    		    		
    	eDynamicInverseRemove(otherEnd, feature);
	    	}
    
    @Override
    /**
    * This method sets the resource and generates REMOVING_ADAPTER and ADD notifications
    */
    protected void setResourceOfContainments(Consumer<SmartObject> setResourceCall) {
	    	}
	    	
	    	@Override
	    	/**
	    	* This method sets the resource and only generates REMOVING_ADAPTER notifications (no ADD messages)
	    	*/
    protected void setResourceOfContainmentsSilently(Resource r) { 		
	    	}
}
