package Village2ConstrPlan;

import runtime.RuntimePackage;
import Village2ConstrPlan.Village2ConstrPlanPackage;

import org.emoflon.smartemf.runtime.notification.SmartEMFNotification;
import org.emoflon.smartemf.runtime.SmartObject;
import org.emoflon.smartemf.runtime.collections.*;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EStructuralFeature;

public interface Villa2Constr__Marker extends EObject, runtime.TGGRuleApplication {
	
    public runtime.Protocol getProtocol();
    
    public void setProtocol(runtime.Protocol value);
    
    public Village.House getCONTEXT__SRC__h();
    
    public void setCONTEXT__SRC__h(Village.House value);
    
    public Village.House getCREATE__SRC__nh();
    
    public void setCREATE__SRC__nh(Village.House value);
    
    public ConstructionPlan.Basement getCREATE__TRG__bt();
    
    public void setCREATE__TRG__bt(ConstructionPlan.Basement value);
    
    public ConstructionPlan.Construction getCONTEXT__TRG__cst();
    
    public void setCONTEXT__TRG__cst(ConstructionPlan.Construction value);
    
    public ConstructionPlan.Construction getCREATE__TRG__ncst();
    
    public void setCREATE__TRG__ncst(ConstructionPlan.Construction value);
    
    public ConstructionPlan.Plan getCONTEXT__TRG__p();
    
    public void setCONTEXT__TRG__p(ConstructionPlan.Plan value);
    
    public ConstructionPlan.SaddleRoof getCREATE__TRG__sr();
    
    public void setCREATE__TRG__sr(ConstructionPlan.SaddleRoof value);
    
    public Village2ConstrPlan.House2Constr getCONTEXT__CORR__h2cst();
    
    public void setCONTEXT__CORR__h2cst(Village2ConstrPlan.House2Constr value);
    
    public Village2ConstrPlan.House2Constr getCREATE__CORR__nh2ncst();
    
    public void setCREATE__CORR__nh2ncst(Village2ConstrPlan.House2Constr value);
    

}
