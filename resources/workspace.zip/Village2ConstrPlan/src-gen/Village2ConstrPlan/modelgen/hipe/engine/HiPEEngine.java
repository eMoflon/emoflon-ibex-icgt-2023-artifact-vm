package Village2ConstrPlan.modelgen.hipe.engine;

import akka.actor.ActorRef;
import akka.actor.Props;

import Village2ConstrPlan.modelgen.hipe.engine.actor.NotificationActor;
import Village2ConstrPlan.modelgen.hipe.engine.actor.DispatchActor;
import Village2ConstrPlan.modelgen.hipe.engine.actor.localsearch.Corner2Constr__GEN_1_localSearch;
import Village2ConstrPlan.modelgen.hipe.engine.actor.localsearch.Cube2Constr__GEN_5_localSearch;
import Village2ConstrPlan.modelgen.hipe.engine.actor.localsearch.DoubleCube2Constr__GEN_10_localSearch;
import Village2ConstrPlan.modelgen.hipe.engine.actor.localsearch.Villa2Constr__GEN_15_localSearch;

import hipe.engine.IHiPEEngine;
import hipe.engine.message.InitGenReferenceActor;

import hipe.generic.actor.GenericObjectActor;
import hipe.generic.actor.GenericReferenceActor;
import hipe.generic.actor.GenericProductionActor;
import hipe.generic.actor.junction.*;

import hipe.network.*;

public class HiPEEngine extends IHiPEEngine{
	
	public HiPEEngine(HiPENetwork network) {
		super(network);
	}
	
	public HiPEEngine() {
		super();
	}
	
	@Override
	public String getClassLocation() {
		return getClass().getProtectionDomain().getCodeSource().getLocation().getPath().toString();
	}
	
	@Override
	public String getPackageName() {
		return getClass().getPackageName();
	}
	
	@Override
	protected ActorRef getDispatchActor() {
		return system.actorOf(
			Props.create(DispatchActor.class, () -> new DispatchActor(name2actor, incUtil)),
			"DispatchActor");
	}
	
	@Override
	protected ActorRef getNotificationActor(boolean cascadingNotifications) {
		return system.actorOf(
			Props.create(NotificationActor.class, () -> new NotificationActor(dispatcher, incUtil, cascadingNotifications)), 
			"NotificationActor");
	}
	
	@Override
	public void createProductionNodes() {
		classes.put("Corner2Constr__GEN_production", GenericProductionActor.class);
		productionNodes2pattern.put("Corner2Constr__GEN_production", "Corner2Constr__GEN");
		classes.put("Cube2Constr__GEN_production", GenericProductionActor.class);
		productionNodes2pattern.put("Cube2Constr__GEN_production", "Cube2Constr__GEN");
		classes.put("DoubleCube2Constr__GEN_production", GenericProductionActor.class);
		productionNodes2pattern.put("DoubleCube2Constr__GEN_production", "DoubleCube2Constr__GEN");
		classes.put("Villa2Constr__GEN_production", GenericProductionActor.class);
		productionNodes2pattern.put("Villa2Constr__GEN_production", "Villa2Constr__GEN");
		
	}
	
	@Override
	public void createJunctionNodes() {
		classes.put("Corner2Constr__GEN_1_localSearch", Corner2Constr__GEN_1_localSearch.class);
		classes.put("Cube2Constr__GEN_5_localSearch", Cube2Constr__GEN_5_localSearch.class);
		classes.put("DoubleCube2Constr__GEN_10_localSearch", DoubleCube2Constr__GEN_10_localSearch.class);
		classes.put("Villa2Constr__GEN_15_localSearch", Villa2Constr__GEN_15_localSearch.class);
	}
	
	@Override
	public void createReferenceNodes() {
		
	}
	
	@Override
	public void createObjectNodes() {
		classes.put("PlanCollection_object",PlanCollection_object.class);
		classes.put("VillageSquare_object",VillageSquare_object.class);
		classes.put("VillageSquare2PlanCollection_object",VillageSquare2PlanCollection_object.class);
		classes.put("Construction_object",Construction_object.class);
		classes.put("House_object",House_object.class);
		classes.put("House2Constr_object",House2Constr_object.class);
		classes.put("Plan_object",Plan_object.class);
		
	}
	
	@Override
	public void initializeReferenceNodes() {
	}
}

class PlanCollection_object extends GenericObjectActor<ConstructionPlan.PlanCollection> { }
class VillageSquare_object extends GenericObjectActor<Village.VillageSquare> { }
class VillageSquare2PlanCollection_object extends GenericObjectActor<Village2ConstrPlan.VillageSquare2PlanCollection> { }
class Construction_object extends GenericObjectActor<ConstructionPlan.Construction> { }
class House_object extends GenericObjectActor<Village.House> { }
class House2Constr_object extends GenericObjectActor<Village2ConstrPlan.House2Constr> { }
class Plan_object extends GenericObjectActor<ConstructionPlan.Plan> { }


