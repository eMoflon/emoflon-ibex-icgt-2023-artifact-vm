package ExtType2Doc_ConcSync.impl;

import ExtType2Doc_ConcSync.Project2DocContainer;
import ExtType2Doc_ConcSync.Package2Folder;
import ExtType2Doc_ConcSync.Type2Doc;
import ExtType2Doc_ConcSync.Method2Entry;
import ExtType2Doc_ConcSync.Param2Entry;
import ExtType2Doc_ConcSync.Field2Entry;
import ExtType2Doc_ConcSync.JDoc2Annotation;
import ExtType2Doc_ConcSync.ExtendingType2Doc__Marker;
import ExtType2Doc_ConcSync.Field2Entry__Marker;
import ExtType2Doc_ConcSync.Glossary__Marker;
import ExtType2Doc_ConcSync.GlossaryEntry__Marker;
import ExtType2Doc_ConcSync.GlossaryLink__Marker;
import ExtType2Doc_ConcSync.JDoc2Annotation__Marker;
import ExtType2Doc_ConcSync.Method2Entry__Marker;
import ExtType2Doc_ConcSync.Package2Folder__Marker;
import ExtType2Doc_ConcSync.Param2Entry__Marker;
import ExtType2Doc_ConcSync.Project2DocCont__Marker;
import ExtType2Doc_ConcSync.Type2Doc__Marker;


import ExtType2Doc_ConcSync.ExtType2Doc_ConcSyncFactory;
import ExtType2Doc_ConcSync.ExtType2Doc_ConcSyncPackage;

import ExtDocModel.ExtDocModelPackage;
import runtime.RuntimePackage;
import ExtTypeModel.ExtTypeModelPackage;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.ecore.EcorePackage;

import org.eclipse.emf.ecore.impl.EPackageImpl;

import org.emoflon.smartemf.runtime.SmartPackageImpl;

public class ExtType2Doc_ConcSyncPackageImpl extends SmartPackageImpl
		implements ExtType2Doc_ConcSyncPackage {
			
	private EClass project2DocContainerEClass = null;
	private EReference project2DocContainer_sourceEReference = null;
	private EReference project2DocContainer_targetEReference = null;
	private EClass package2FolderEClass = null;
	private EReference package2Folder_sourceEReference = null;
	private EReference package2Folder_targetEReference = null;
	private EClass type2DocEClass = null;
	private EReference type2Doc_sourceEReference = null;
	private EReference type2Doc_targetEReference = null;
	private EClass method2EntryEClass = null;
	private EReference method2Entry_sourceEReference = null;
	private EReference method2Entry_targetEReference = null;
	private EClass param2EntryEClass = null;
	private EReference param2Entry_sourceEReference = null;
	private EReference param2Entry_targetEReference = null;
	private EClass field2EntryEClass = null;
	private EReference field2Entry_sourceEReference = null;
	private EReference field2Entry_targetEReference = null;
	private EClass jDoc2AnnotationEClass = null;
	private EReference jDoc2Annotation_sourceEReference = null;
	private EReference jDoc2Annotation_targetEReference = null;
	private EClass extendingType2Doc__MarkerEClass = null;
	private EReference extendingType2Doc__Marker_cREATE__SRC__ntEReference = null;
	private EReference extendingType2Doc__Marker_cONTEXT__SRC__pEReference = null;
	private EReference extendingType2Doc__Marker_cONTEXT__SRC__tEReference = null;
	private EReference extendingType2Doc__Marker_cONTEXT__TRG__dEReference = null;
	private EReference extendingType2Doc__Marker_cONTEXT__TRG__fEReference = null;
	private EReference extendingType2Doc__Marker_cREATE__TRG__ndEReference = null;
	private EReference extendingType2Doc__Marker_cREATE__CORR__nt2ndEReference = null;
	private EReference extendingType2Doc__Marker_cONTEXT__CORR__p2fEReference = null;
	private EReference extendingType2Doc__Marker_cONTEXT__CORR__t2dEReference = null;
	private EClass field2Entry__MarkerEClass = null;
	private EReference field2Entry__Marker_cREATE__SRC__fEReference = null;
	private EReference field2Entry__Marker_cONTEXT__SRC__tEReference = null;
	private EReference field2Entry__Marker_cONTEXT__TRG__dEReference = null;
	private EReference field2Entry__Marker_cREATE__TRG__eEReference = null;
	private EReference field2Entry__Marker_cREATE__CORR__f2eEReference = null;
	private EReference field2Entry__Marker_cONTEXT__CORR__t2dEReference = null;
	private EClass glossary__MarkerEClass = null;
	private EReference glossary__Marker_cONTEXT__TRG__dcEReference = null;
	private EReference glossary__Marker_cREATE__TRG__gEReference = null;
	private EClass glossaryEntry__MarkerEClass = null;
	private EReference glossaryEntry__Marker_cONTEXT__TRG__gEReference = null;
	private EReference glossaryEntry__Marker_cREATE__TRG__geEReference = null;
	private EClass glossaryLink__MarkerEClass = null;
	private EReference glossaryLink__Marker_cONTEXT__TRG__eEReference = null;
	private EReference glossaryLink__Marker_cONTEXT__TRG__geEReference = null;
	private EClass jDoc2Annotation__MarkerEClass = null;
	private EReference jDoc2Annotation__Marker_cREATE__SRC__jEReference = null;
	private EReference jDoc2Annotation__Marker_cONTEXT__SRC__mEReference = null;
	private EReference jDoc2Annotation__Marker_cREATE__TRG__aEReference = null;
	private EReference jDoc2Annotation__Marker_cONTEXT__TRG__eEReference = null;
	private EReference jDoc2Annotation__Marker_cREATE__CORR__j2aEReference = null;
	private EReference jDoc2Annotation__Marker_cONTEXT__CORR__m2eEReference = null;
	private EClass method2Entry__MarkerEClass = null;
	private EReference method2Entry__Marker_cREATE__SRC__mEReference = null;
	private EReference method2Entry__Marker_cONTEXT__SRC__tEReference = null;
	private EReference method2Entry__Marker_cONTEXT__TRG__dEReference = null;
	private EReference method2Entry__Marker_cREATE__TRG__eEReference = null;
	private EReference method2Entry__Marker_cREATE__CORR__m2eEReference = null;
	private EReference method2Entry__Marker_cONTEXT__CORR__t2dEReference = null;
	private EClass package2Folder__MarkerEClass = null;
	private EReference package2Folder__Marker_cREATE__SRC__pEReference = null;
	private EReference package2Folder__Marker_cONTEXT__SRC__prEReference = null;
	private EReference package2Folder__Marker_cONTEXT__TRG__dcEReference = null;
	private EReference package2Folder__Marker_cREATE__TRG__fEReference = null;
	private EReference package2Folder__Marker_cREATE__CORR__p2fEReference = null;
	private EReference package2Folder__Marker_cONTEXT__CORR__pr2dcEReference = null;
	private EClass param2Entry__MarkerEClass = null;
	private EReference param2Entry__Marker_cONTEXT__SRC__mEReference = null;
	private EReference param2Entry__Marker_cREATE__SRC__pEReference = null;
	private EReference param2Entry__Marker_cONTEXT__TRG__eEReference = null;
	private EReference param2Entry__Marker_cONTEXT__CORR__m2eEReference = null;
	private EReference param2Entry__Marker_cREATE__CORR__p2eEReference = null;
	private EClass project2DocCont__MarkerEClass = null;
	private EReference project2DocCont__Marker_cREATE__SRC__prEReference = null;
	private EReference project2DocCont__Marker_cREATE__TRG__dcEReference = null;
	private EReference project2DocCont__Marker_cREATE__CORR__pr2dcEReference = null;
	private EClass type2Doc__MarkerEClass = null;
	private EReference type2Doc__Marker_cONTEXT__SRC__pEReference = null;
	private EReference type2Doc__Marker_cREATE__SRC__tEReference = null;
	private EReference type2Doc__Marker_cREATE__TRG__dEReference = null;
	private EReference type2Doc__Marker_cONTEXT__TRG__fEReference = null;
	private EReference type2Doc__Marker_cONTEXT__CORR__p2fEReference = null;
	private EReference type2Doc__Marker_cREATE__CORR__t2dEReference = null;
	
	

	private ExtType2Doc_ConcSyncPackageImpl() {
		super(eNS_URI, ExtType2Doc_ConcSync.ExtType2Doc_ConcSyncFactory.eINSTANCE);
	}

	private static boolean isRegistered = false;
	private boolean isCreated = false;
	private boolean isInitialized = false;

	public static ExtType2Doc_ConcSyncPackage init() {
		if (isRegistered)
			return (ExtType2Doc_ConcSyncPackage) EPackage.Registry.INSTANCE
					.getEPackage(ExtType2Doc_ConcSyncPackage.eNS_URI);

		// Obtain or create and register package
		Object registeredExtType2Doc_ConcSyncPackage = EPackage.Registry.INSTANCE.get(eNS_URI);
		ExtType2Doc_ConcSyncPackageImpl theExtType2Doc_ConcSyncPackage = registeredExtType2Doc_ConcSyncPackage instanceof ExtType2Doc_ConcSyncPackageImpl
				? (ExtType2Doc_ConcSyncPackageImpl) registeredExtType2Doc_ConcSyncPackage
				: new ExtType2Doc_ConcSyncPackageImpl();

		isRegistered = true;

		// Create package meta-data objects
		theExtType2Doc_ConcSyncPackage.createPackageContents();

		// Initialize created meta-data
		theExtType2Doc_ConcSyncPackage.initializePackageContents();
		
		// Inject internal eOpposites to unidirectional references
		theExtType2Doc_ConcSyncPackage.injectDynamicOpposites();
		
		// Inject external references into foreign packages
		theExtType2Doc_ConcSyncPackage.injectExternalReferences();

		// Mark meta-data to indicate it can't be changed
		theExtType2Doc_ConcSyncPackage.freeze();

		// Update the registry and return the package
		EPackage.Registry.INSTANCE.put(ExtType2Doc_ConcSyncPackage.eNS_URI,
				theExtType2Doc_ConcSyncPackage);
				
		theExtType2Doc_ConcSyncPackage.fetchDynamicEStructuralFeaturesOfSuperTypes();
		return theExtType2Doc_ConcSyncPackage;
	}

	@Override
	public EClass getProject2DocContainer() {
		return project2DocContainerEClass;
	}
	@Override
	public EReference getProject2DocContainer_Source() {
		return project2DocContainer_sourceEReference;	
	}
	@Override
	public EReference getProject2DocContainer_Target() {
		return project2DocContainer_targetEReference;	
	}
	@Override
	public EClass getPackage2Folder() {
		return package2FolderEClass;
	}
	@Override
	public EReference getPackage2Folder_Source() {
		return package2Folder_sourceEReference;	
	}
	@Override
	public EReference getPackage2Folder_Target() {
		return package2Folder_targetEReference;	
	}
	@Override
	public EClass getType2Doc() {
		return type2DocEClass;
	}
	@Override
	public EReference getType2Doc_Source() {
		return type2Doc_sourceEReference;	
	}
	@Override
	public EReference getType2Doc_Target() {
		return type2Doc_targetEReference;	
	}
	@Override
	public EClass getMethod2Entry() {
		return method2EntryEClass;
	}
	@Override
	public EReference getMethod2Entry_Source() {
		return method2Entry_sourceEReference;	
	}
	@Override
	public EReference getMethod2Entry_Target() {
		return method2Entry_targetEReference;	
	}
	@Override
	public EClass getParam2Entry() {
		return param2EntryEClass;
	}
	@Override
	public EReference getParam2Entry_Source() {
		return param2Entry_sourceEReference;	
	}
	@Override
	public EReference getParam2Entry_Target() {
		return param2Entry_targetEReference;	
	}
	@Override
	public EClass getField2Entry() {
		return field2EntryEClass;
	}
	@Override
	public EReference getField2Entry_Source() {
		return field2Entry_sourceEReference;	
	}
	@Override
	public EReference getField2Entry_Target() {
		return field2Entry_targetEReference;	
	}
	@Override
	public EClass getJDoc2Annotation() {
		return jDoc2AnnotationEClass;
	}
	@Override
	public EReference getJDoc2Annotation_Source() {
		return jDoc2Annotation_sourceEReference;	
	}
	@Override
	public EReference getJDoc2Annotation_Target() {
		return jDoc2Annotation_targetEReference;	
	}
	@Override
	public EClass getExtendingType2Doc__Marker() {
		return extendingType2Doc__MarkerEClass;
	}
	@Override
	public EReference getExtendingType2Doc__Marker_CREATE__SRC__nt() {
		return extendingType2Doc__Marker_cREATE__SRC__ntEReference;	
	}
	@Override
	public EReference getExtendingType2Doc__Marker_CONTEXT__SRC__p() {
		return extendingType2Doc__Marker_cONTEXT__SRC__pEReference;	
	}
	@Override
	public EReference getExtendingType2Doc__Marker_CONTEXT__SRC__t() {
		return extendingType2Doc__Marker_cONTEXT__SRC__tEReference;	
	}
	@Override
	public EReference getExtendingType2Doc__Marker_CONTEXT__TRG__d() {
		return extendingType2Doc__Marker_cONTEXT__TRG__dEReference;	
	}
	@Override
	public EReference getExtendingType2Doc__Marker_CONTEXT__TRG__f() {
		return extendingType2Doc__Marker_cONTEXT__TRG__fEReference;	
	}
	@Override
	public EReference getExtendingType2Doc__Marker_CREATE__TRG__nd() {
		return extendingType2Doc__Marker_cREATE__TRG__ndEReference;	
	}
	@Override
	public EReference getExtendingType2Doc__Marker_CREATE__CORR__nt2nd() {
		return extendingType2Doc__Marker_cREATE__CORR__nt2ndEReference;	
	}
	@Override
	public EReference getExtendingType2Doc__Marker_CONTEXT__CORR__p2f() {
		return extendingType2Doc__Marker_cONTEXT__CORR__p2fEReference;	
	}
	@Override
	public EReference getExtendingType2Doc__Marker_CONTEXT__CORR__t2d() {
		return extendingType2Doc__Marker_cONTEXT__CORR__t2dEReference;	
	}
	@Override
	public EClass getField2Entry__Marker() {
		return field2Entry__MarkerEClass;
	}
	@Override
	public EReference getField2Entry__Marker_CREATE__SRC__f() {
		return field2Entry__Marker_cREATE__SRC__fEReference;	
	}
	@Override
	public EReference getField2Entry__Marker_CONTEXT__SRC__t() {
		return field2Entry__Marker_cONTEXT__SRC__tEReference;	
	}
	@Override
	public EReference getField2Entry__Marker_CONTEXT__TRG__d() {
		return field2Entry__Marker_cONTEXT__TRG__dEReference;	
	}
	@Override
	public EReference getField2Entry__Marker_CREATE__TRG__e() {
		return field2Entry__Marker_cREATE__TRG__eEReference;	
	}
	@Override
	public EReference getField2Entry__Marker_CREATE__CORR__f2e() {
		return field2Entry__Marker_cREATE__CORR__f2eEReference;	
	}
	@Override
	public EReference getField2Entry__Marker_CONTEXT__CORR__t2d() {
		return field2Entry__Marker_cONTEXT__CORR__t2dEReference;	
	}
	@Override
	public EClass getGlossary__Marker() {
		return glossary__MarkerEClass;
	}
	@Override
	public EReference getGlossary__Marker_CONTEXT__TRG__dc() {
		return glossary__Marker_cONTEXT__TRG__dcEReference;	
	}
	@Override
	public EReference getGlossary__Marker_CREATE__TRG__g() {
		return glossary__Marker_cREATE__TRG__gEReference;	
	}
	@Override
	public EClass getGlossaryEntry__Marker() {
		return glossaryEntry__MarkerEClass;
	}
	@Override
	public EReference getGlossaryEntry__Marker_CONTEXT__TRG__g() {
		return glossaryEntry__Marker_cONTEXT__TRG__gEReference;	
	}
	@Override
	public EReference getGlossaryEntry__Marker_CREATE__TRG__ge() {
		return glossaryEntry__Marker_cREATE__TRG__geEReference;	
	}
	@Override
	public EClass getGlossaryLink__Marker() {
		return glossaryLink__MarkerEClass;
	}
	@Override
	public EReference getGlossaryLink__Marker_CONTEXT__TRG__e() {
		return glossaryLink__Marker_cONTEXT__TRG__eEReference;	
	}
	@Override
	public EReference getGlossaryLink__Marker_CONTEXT__TRG__ge() {
		return glossaryLink__Marker_cONTEXT__TRG__geEReference;	
	}
	@Override
	public EClass getJDoc2Annotation__Marker() {
		return jDoc2Annotation__MarkerEClass;
	}
	@Override
	public EReference getJDoc2Annotation__Marker_CREATE__SRC__j() {
		return jDoc2Annotation__Marker_cREATE__SRC__jEReference;	
	}
	@Override
	public EReference getJDoc2Annotation__Marker_CONTEXT__SRC__m() {
		return jDoc2Annotation__Marker_cONTEXT__SRC__mEReference;	
	}
	@Override
	public EReference getJDoc2Annotation__Marker_CREATE__TRG__a() {
		return jDoc2Annotation__Marker_cREATE__TRG__aEReference;	
	}
	@Override
	public EReference getJDoc2Annotation__Marker_CONTEXT__TRG__e() {
		return jDoc2Annotation__Marker_cONTEXT__TRG__eEReference;	
	}
	@Override
	public EReference getJDoc2Annotation__Marker_CREATE__CORR__j2a() {
		return jDoc2Annotation__Marker_cREATE__CORR__j2aEReference;	
	}
	@Override
	public EReference getJDoc2Annotation__Marker_CONTEXT__CORR__m2e() {
		return jDoc2Annotation__Marker_cONTEXT__CORR__m2eEReference;	
	}
	@Override
	public EClass getMethod2Entry__Marker() {
		return method2Entry__MarkerEClass;
	}
	@Override
	public EReference getMethod2Entry__Marker_CREATE__SRC__m() {
		return method2Entry__Marker_cREATE__SRC__mEReference;	
	}
	@Override
	public EReference getMethod2Entry__Marker_CONTEXT__SRC__t() {
		return method2Entry__Marker_cONTEXT__SRC__tEReference;	
	}
	@Override
	public EReference getMethod2Entry__Marker_CONTEXT__TRG__d() {
		return method2Entry__Marker_cONTEXT__TRG__dEReference;	
	}
	@Override
	public EReference getMethod2Entry__Marker_CREATE__TRG__e() {
		return method2Entry__Marker_cREATE__TRG__eEReference;	
	}
	@Override
	public EReference getMethod2Entry__Marker_CREATE__CORR__m2e() {
		return method2Entry__Marker_cREATE__CORR__m2eEReference;	
	}
	@Override
	public EReference getMethod2Entry__Marker_CONTEXT__CORR__t2d() {
		return method2Entry__Marker_cONTEXT__CORR__t2dEReference;	
	}
	@Override
	public EClass getPackage2Folder__Marker() {
		return package2Folder__MarkerEClass;
	}
	@Override
	public EReference getPackage2Folder__Marker_CREATE__SRC__p() {
		return package2Folder__Marker_cREATE__SRC__pEReference;	
	}
	@Override
	public EReference getPackage2Folder__Marker_CONTEXT__SRC__pr() {
		return package2Folder__Marker_cONTEXT__SRC__prEReference;	
	}
	@Override
	public EReference getPackage2Folder__Marker_CONTEXT__TRG__dc() {
		return package2Folder__Marker_cONTEXT__TRG__dcEReference;	
	}
	@Override
	public EReference getPackage2Folder__Marker_CREATE__TRG__f() {
		return package2Folder__Marker_cREATE__TRG__fEReference;	
	}
	@Override
	public EReference getPackage2Folder__Marker_CREATE__CORR__p2f() {
		return package2Folder__Marker_cREATE__CORR__p2fEReference;	
	}
	@Override
	public EReference getPackage2Folder__Marker_CONTEXT__CORR__pr2dc() {
		return package2Folder__Marker_cONTEXT__CORR__pr2dcEReference;	
	}
	@Override
	public EClass getParam2Entry__Marker() {
		return param2Entry__MarkerEClass;
	}
	@Override
	public EReference getParam2Entry__Marker_CONTEXT__SRC__m() {
		return param2Entry__Marker_cONTEXT__SRC__mEReference;	
	}
	@Override
	public EReference getParam2Entry__Marker_CREATE__SRC__p() {
		return param2Entry__Marker_cREATE__SRC__pEReference;	
	}
	@Override
	public EReference getParam2Entry__Marker_CONTEXT__TRG__e() {
		return param2Entry__Marker_cONTEXT__TRG__eEReference;	
	}
	@Override
	public EReference getParam2Entry__Marker_CONTEXT__CORR__m2e() {
		return param2Entry__Marker_cONTEXT__CORR__m2eEReference;	
	}
	@Override
	public EReference getParam2Entry__Marker_CREATE__CORR__p2e() {
		return param2Entry__Marker_cREATE__CORR__p2eEReference;	
	}
	@Override
	public EClass getProject2DocCont__Marker() {
		return project2DocCont__MarkerEClass;
	}
	@Override
	public EReference getProject2DocCont__Marker_CREATE__SRC__pr() {
		return project2DocCont__Marker_cREATE__SRC__prEReference;	
	}
	@Override
	public EReference getProject2DocCont__Marker_CREATE__TRG__dc() {
		return project2DocCont__Marker_cREATE__TRG__dcEReference;	
	}
	@Override
	public EReference getProject2DocCont__Marker_CREATE__CORR__pr2dc() {
		return project2DocCont__Marker_cREATE__CORR__pr2dcEReference;	
	}
	@Override
	public EClass getType2Doc__Marker() {
		return type2Doc__MarkerEClass;
	}
	@Override
	public EReference getType2Doc__Marker_CONTEXT__SRC__p() {
		return type2Doc__Marker_cONTEXT__SRC__pEReference;	
	}
	@Override
	public EReference getType2Doc__Marker_CREATE__SRC__t() {
		return type2Doc__Marker_cREATE__SRC__tEReference;	
	}
	@Override
	public EReference getType2Doc__Marker_CREATE__TRG__d() {
		return type2Doc__Marker_cREATE__TRG__dEReference;	
	}
	@Override
	public EReference getType2Doc__Marker_CONTEXT__TRG__f() {
		return type2Doc__Marker_cONTEXT__TRG__fEReference;	
	}
	@Override
	public EReference getType2Doc__Marker_CONTEXT__CORR__p2f() {
		return type2Doc__Marker_cONTEXT__CORR__p2fEReference;	
	}
	@Override
	public EReference getType2Doc__Marker_CREATE__CORR__t2d() {
		return type2Doc__Marker_cREATE__CORR__t2dEReference;	
	}
	
	

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ExtType2Doc_ConcSync.ExtType2Doc_ConcSyncFactory getExtType2Doc_ConcSyncFactory() {
		return (ExtType2Doc_ConcSync.ExtType2Doc_ConcSyncFactory) getEFactoryInstance();
	}

	public void createPackageContents() {
		if (isCreated)
			return;
		isCreated = true;

		// Create classes and their features
		project2DocContainerEClass = createEClass(PROJECT2_DOC_CONTAINER);
		createEReference(project2DocContainerEClass, PROJECT2_DOC_CONTAINER__SOURCE);
		project2DocContainer_sourceEReference = (EReference) project2DocContainerEClass.getEStructuralFeatures().get(0);
		createEReference(project2DocContainerEClass, PROJECT2_DOC_CONTAINER__TARGET);
		project2DocContainer_targetEReference = (EReference) project2DocContainerEClass.getEStructuralFeatures().get(1);
		
		package2FolderEClass = createEClass(PACKAGE2_FOLDER);
		createEReference(package2FolderEClass, PACKAGE2_FOLDER__SOURCE);
		package2Folder_sourceEReference = (EReference) package2FolderEClass.getEStructuralFeatures().get(0);
		createEReference(package2FolderEClass, PACKAGE2_FOLDER__TARGET);
		package2Folder_targetEReference = (EReference) package2FolderEClass.getEStructuralFeatures().get(1);
		
		type2DocEClass = createEClass(TYPE2_DOC);
		createEReference(type2DocEClass, TYPE2_DOC__SOURCE);
		type2Doc_sourceEReference = (EReference) type2DocEClass.getEStructuralFeatures().get(0);
		createEReference(type2DocEClass, TYPE2_DOC__TARGET);
		type2Doc_targetEReference = (EReference) type2DocEClass.getEStructuralFeatures().get(1);
		
		method2EntryEClass = createEClass(METHOD2_ENTRY);
		createEReference(method2EntryEClass, METHOD2_ENTRY__SOURCE);
		method2Entry_sourceEReference = (EReference) method2EntryEClass.getEStructuralFeatures().get(0);
		createEReference(method2EntryEClass, METHOD2_ENTRY__TARGET);
		method2Entry_targetEReference = (EReference) method2EntryEClass.getEStructuralFeatures().get(1);
		
		param2EntryEClass = createEClass(PARAM2_ENTRY);
		createEReference(param2EntryEClass, PARAM2_ENTRY__SOURCE);
		param2Entry_sourceEReference = (EReference) param2EntryEClass.getEStructuralFeatures().get(0);
		createEReference(param2EntryEClass, PARAM2_ENTRY__TARGET);
		param2Entry_targetEReference = (EReference) param2EntryEClass.getEStructuralFeatures().get(1);
		
		field2EntryEClass = createEClass(FIELD2_ENTRY);
		createEReference(field2EntryEClass, FIELD2_ENTRY__SOURCE);
		field2Entry_sourceEReference = (EReference) field2EntryEClass.getEStructuralFeatures().get(0);
		createEReference(field2EntryEClass, FIELD2_ENTRY__TARGET);
		field2Entry_targetEReference = (EReference) field2EntryEClass.getEStructuralFeatures().get(1);
		
		jDoc2AnnotationEClass = createEClass(J_DOC2_ANNOTATION);
		createEReference(jDoc2AnnotationEClass, J_DOC2_ANNOTATION__SOURCE);
		jDoc2Annotation_sourceEReference = (EReference) jDoc2AnnotationEClass.getEStructuralFeatures().get(0);
		createEReference(jDoc2AnnotationEClass, J_DOC2_ANNOTATION__TARGET);
		jDoc2Annotation_targetEReference = (EReference) jDoc2AnnotationEClass.getEStructuralFeatures().get(1);
		
		extendingType2Doc__MarkerEClass = createEClass(EXTENDING_TYPE2_DOC___MARKER);
		createEReference(extendingType2Doc__MarkerEClass, EXTENDING_TYPE2_DOC___MARKER__CREAT_E__SR_C__NT);
		extendingType2Doc__Marker_cREATE__SRC__ntEReference = (EReference) extendingType2Doc__MarkerEClass.getEStructuralFeatures().get(0);
		createEReference(extendingType2Doc__MarkerEClass, EXTENDING_TYPE2_DOC___MARKER__CONTEX_T__SR_C__P);
		extendingType2Doc__Marker_cONTEXT__SRC__pEReference = (EReference) extendingType2Doc__MarkerEClass.getEStructuralFeatures().get(1);
		createEReference(extendingType2Doc__MarkerEClass, EXTENDING_TYPE2_DOC___MARKER__CONTEX_T__SR_C__T);
		extendingType2Doc__Marker_cONTEXT__SRC__tEReference = (EReference) extendingType2Doc__MarkerEClass.getEStructuralFeatures().get(2);
		createEReference(extendingType2Doc__MarkerEClass, EXTENDING_TYPE2_DOC___MARKER__CONTEX_T__TR_G__D);
		extendingType2Doc__Marker_cONTEXT__TRG__dEReference = (EReference) extendingType2Doc__MarkerEClass.getEStructuralFeatures().get(3);
		createEReference(extendingType2Doc__MarkerEClass, EXTENDING_TYPE2_DOC___MARKER__CONTEX_T__TR_G__F);
		extendingType2Doc__Marker_cONTEXT__TRG__fEReference = (EReference) extendingType2Doc__MarkerEClass.getEStructuralFeatures().get(4);
		createEReference(extendingType2Doc__MarkerEClass, EXTENDING_TYPE2_DOC___MARKER__CREAT_E__TR_G__ND);
		extendingType2Doc__Marker_cREATE__TRG__ndEReference = (EReference) extendingType2Doc__MarkerEClass.getEStructuralFeatures().get(5);
		createEReference(extendingType2Doc__MarkerEClass, EXTENDING_TYPE2_DOC___MARKER__CREAT_E__COR_R__NT2ND);
		extendingType2Doc__Marker_cREATE__CORR__nt2ndEReference = (EReference) extendingType2Doc__MarkerEClass.getEStructuralFeatures().get(6);
		createEReference(extendingType2Doc__MarkerEClass, EXTENDING_TYPE2_DOC___MARKER__CONTEX_T__COR_R__P2F);
		extendingType2Doc__Marker_cONTEXT__CORR__p2fEReference = (EReference) extendingType2Doc__MarkerEClass.getEStructuralFeatures().get(7);
		createEReference(extendingType2Doc__MarkerEClass, EXTENDING_TYPE2_DOC___MARKER__CONTEX_T__COR_R__T2D);
		extendingType2Doc__Marker_cONTEXT__CORR__t2dEReference = (EReference) extendingType2Doc__MarkerEClass.getEStructuralFeatures().get(8);
		
		field2Entry__MarkerEClass = createEClass(FIELD2_ENTRY___MARKER);
		createEReference(field2Entry__MarkerEClass, FIELD2_ENTRY___MARKER__CREAT_E__SR_C__F);
		field2Entry__Marker_cREATE__SRC__fEReference = (EReference) field2Entry__MarkerEClass.getEStructuralFeatures().get(0);
		createEReference(field2Entry__MarkerEClass, FIELD2_ENTRY___MARKER__CONTEX_T__SR_C__T);
		field2Entry__Marker_cONTEXT__SRC__tEReference = (EReference) field2Entry__MarkerEClass.getEStructuralFeatures().get(1);
		createEReference(field2Entry__MarkerEClass, FIELD2_ENTRY___MARKER__CONTEX_T__TR_G__D);
		field2Entry__Marker_cONTEXT__TRG__dEReference = (EReference) field2Entry__MarkerEClass.getEStructuralFeatures().get(2);
		createEReference(field2Entry__MarkerEClass, FIELD2_ENTRY___MARKER__CREAT_E__TR_G__E);
		field2Entry__Marker_cREATE__TRG__eEReference = (EReference) field2Entry__MarkerEClass.getEStructuralFeatures().get(3);
		createEReference(field2Entry__MarkerEClass, FIELD2_ENTRY___MARKER__CREAT_E__COR_R__F2E);
		field2Entry__Marker_cREATE__CORR__f2eEReference = (EReference) field2Entry__MarkerEClass.getEStructuralFeatures().get(4);
		createEReference(field2Entry__MarkerEClass, FIELD2_ENTRY___MARKER__CONTEX_T__COR_R__T2D);
		field2Entry__Marker_cONTEXT__CORR__t2dEReference = (EReference) field2Entry__MarkerEClass.getEStructuralFeatures().get(5);
		
		glossary__MarkerEClass = createEClass(GLOSSARY___MARKER);
		createEReference(glossary__MarkerEClass, GLOSSARY___MARKER__CONTEX_T__TR_G__DC);
		glossary__Marker_cONTEXT__TRG__dcEReference = (EReference) glossary__MarkerEClass.getEStructuralFeatures().get(0);
		createEReference(glossary__MarkerEClass, GLOSSARY___MARKER__CREAT_E__TR_G__G);
		glossary__Marker_cREATE__TRG__gEReference = (EReference) glossary__MarkerEClass.getEStructuralFeatures().get(1);
		
		glossaryEntry__MarkerEClass = createEClass(GLOSSARY_ENTRY___MARKER);
		createEReference(glossaryEntry__MarkerEClass, GLOSSARY_ENTRY___MARKER__CONTEX_T__TR_G__G);
		glossaryEntry__Marker_cONTEXT__TRG__gEReference = (EReference) glossaryEntry__MarkerEClass.getEStructuralFeatures().get(0);
		createEReference(glossaryEntry__MarkerEClass, GLOSSARY_ENTRY___MARKER__CREAT_E__TR_G__GE);
		glossaryEntry__Marker_cREATE__TRG__geEReference = (EReference) glossaryEntry__MarkerEClass.getEStructuralFeatures().get(1);
		
		glossaryLink__MarkerEClass = createEClass(GLOSSARY_LINK___MARKER);
		createEReference(glossaryLink__MarkerEClass, GLOSSARY_LINK___MARKER__CONTEX_T__TR_G__E);
		glossaryLink__Marker_cONTEXT__TRG__eEReference = (EReference) glossaryLink__MarkerEClass.getEStructuralFeatures().get(0);
		createEReference(glossaryLink__MarkerEClass, GLOSSARY_LINK___MARKER__CONTEX_T__TR_G__GE);
		glossaryLink__Marker_cONTEXT__TRG__geEReference = (EReference) glossaryLink__MarkerEClass.getEStructuralFeatures().get(1);
		
		jDoc2Annotation__MarkerEClass = createEClass(J_DOC2_ANNOTATION___MARKER);
		createEReference(jDoc2Annotation__MarkerEClass, J_DOC2_ANNOTATION___MARKER__CREAT_E__SR_C__J);
		jDoc2Annotation__Marker_cREATE__SRC__jEReference = (EReference) jDoc2Annotation__MarkerEClass.getEStructuralFeatures().get(0);
		createEReference(jDoc2Annotation__MarkerEClass, J_DOC2_ANNOTATION___MARKER__CONTEX_T__SR_C__M);
		jDoc2Annotation__Marker_cONTEXT__SRC__mEReference = (EReference) jDoc2Annotation__MarkerEClass.getEStructuralFeatures().get(1);
		createEReference(jDoc2Annotation__MarkerEClass, J_DOC2_ANNOTATION___MARKER__CREAT_E__TR_G__A);
		jDoc2Annotation__Marker_cREATE__TRG__aEReference = (EReference) jDoc2Annotation__MarkerEClass.getEStructuralFeatures().get(2);
		createEReference(jDoc2Annotation__MarkerEClass, J_DOC2_ANNOTATION___MARKER__CONTEX_T__TR_G__E);
		jDoc2Annotation__Marker_cONTEXT__TRG__eEReference = (EReference) jDoc2Annotation__MarkerEClass.getEStructuralFeatures().get(3);
		createEReference(jDoc2Annotation__MarkerEClass, J_DOC2_ANNOTATION___MARKER__CREAT_E__COR_R__J2A);
		jDoc2Annotation__Marker_cREATE__CORR__j2aEReference = (EReference) jDoc2Annotation__MarkerEClass.getEStructuralFeatures().get(4);
		createEReference(jDoc2Annotation__MarkerEClass, J_DOC2_ANNOTATION___MARKER__CONTEX_T__COR_R__M2E);
		jDoc2Annotation__Marker_cONTEXT__CORR__m2eEReference = (EReference) jDoc2Annotation__MarkerEClass.getEStructuralFeatures().get(5);
		
		method2Entry__MarkerEClass = createEClass(METHOD2_ENTRY___MARKER);
		createEReference(method2Entry__MarkerEClass, METHOD2_ENTRY___MARKER__CREAT_E__SR_C__M);
		method2Entry__Marker_cREATE__SRC__mEReference = (EReference) method2Entry__MarkerEClass.getEStructuralFeatures().get(0);
		createEReference(method2Entry__MarkerEClass, METHOD2_ENTRY___MARKER__CONTEX_T__SR_C__T);
		method2Entry__Marker_cONTEXT__SRC__tEReference = (EReference) method2Entry__MarkerEClass.getEStructuralFeatures().get(1);
		createEReference(method2Entry__MarkerEClass, METHOD2_ENTRY___MARKER__CONTEX_T__TR_G__D);
		method2Entry__Marker_cONTEXT__TRG__dEReference = (EReference) method2Entry__MarkerEClass.getEStructuralFeatures().get(2);
		createEReference(method2Entry__MarkerEClass, METHOD2_ENTRY___MARKER__CREAT_E__TR_G__E);
		method2Entry__Marker_cREATE__TRG__eEReference = (EReference) method2Entry__MarkerEClass.getEStructuralFeatures().get(3);
		createEReference(method2Entry__MarkerEClass, METHOD2_ENTRY___MARKER__CREAT_E__COR_R__M2E);
		method2Entry__Marker_cREATE__CORR__m2eEReference = (EReference) method2Entry__MarkerEClass.getEStructuralFeatures().get(4);
		createEReference(method2Entry__MarkerEClass, METHOD2_ENTRY___MARKER__CONTEX_T__COR_R__T2D);
		method2Entry__Marker_cONTEXT__CORR__t2dEReference = (EReference) method2Entry__MarkerEClass.getEStructuralFeatures().get(5);
		
		package2Folder__MarkerEClass = createEClass(PACKAGE2_FOLDER___MARKER);
		createEReference(package2Folder__MarkerEClass, PACKAGE2_FOLDER___MARKER__CREAT_E__SR_C__P);
		package2Folder__Marker_cREATE__SRC__pEReference = (EReference) package2Folder__MarkerEClass.getEStructuralFeatures().get(0);
		createEReference(package2Folder__MarkerEClass, PACKAGE2_FOLDER___MARKER__CONTEX_T__SR_C__PR);
		package2Folder__Marker_cONTEXT__SRC__prEReference = (EReference) package2Folder__MarkerEClass.getEStructuralFeatures().get(1);
		createEReference(package2Folder__MarkerEClass, PACKAGE2_FOLDER___MARKER__CONTEX_T__TR_G__DC);
		package2Folder__Marker_cONTEXT__TRG__dcEReference = (EReference) package2Folder__MarkerEClass.getEStructuralFeatures().get(2);
		createEReference(package2Folder__MarkerEClass, PACKAGE2_FOLDER___MARKER__CREAT_E__TR_G__F);
		package2Folder__Marker_cREATE__TRG__fEReference = (EReference) package2Folder__MarkerEClass.getEStructuralFeatures().get(3);
		createEReference(package2Folder__MarkerEClass, PACKAGE2_FOLDER___MARKER__CREAT_E__COR_R__P2F);
		package2Folder__Marker_cREATE__CORR__p2fEReference = (EReference) package2Folder__MarkerEClass.getEStructuralFeatures().get(4);
		createEReference(package2Folder__MarkerEClass, PACKAGE2_FOLDER___MARKER__CONTEX_T__COR_R__PR2DC);
		package2Folder__Marker_cONTEXT__CORR__pr2dcEReference = (EReference) package2Folder__MarkerEClass.getEStructuralFeatures().get(5);
		
		param2Entry__MarkerEClass = createEClass(PARAM2_ENTRY___MARKER);
		createEReference(param2Entry__MarkerEClass, PARAM2_ENTRY___MARKER__CONTEX_T__SR_C__M);
		param2Entry__Marker_cONTEXT__SRC__mEReference = (EReference) param2Entry__MarkerEClass.getEStructuralFeatures().get(0);
		createEReference(param2Entry__MarkerEClass, PARAM2_ENTRY___MARKER__CREAT_E__SR_C__P);
		param2Entry__Marker_cREATE__SRC__pEReference = (EReference) param2Entry__MarkerEClass.getEStructuralFeatures().get(1);
		createEReference(param2Entry__MarkerEClass, PARAM2_ENTRY___MARKER__CONTEX_T__TR_G__E);
		param2Entry__Marker_cONTEXT__TRG__eEReference = (EReference) param2Entry__MarkerEClass.getEStructuralFeatures().get(2);
		createEReference(param2Entry__MarkerEClass, PARAM2_ENTRY___MARKER__CONTEX_T__COR_R__M2E);
		param2Entry__Marker_cONTEXT__CORR__m2eEReference = (EReference) param2Entry__MarkerEClass.getEStructuralFeatures().get(3);
		createEReference(param2Entry__MarkerEClass, PARAM2_ENTRY___MARKER__CREAT_E__COR_R__P2E);
		param2Entry__Marker_cREATE__CORR__p2eEReference = (EReference) param2Entry__MarkerEClass.getEStructuralFeatures().get(4);
		
		project2DocCont__MarkerEClass = createEClass(PROJECT2_DOC_CONT___MARKER);
		createEReference(project2DocCont__MarkerEClass, PROJECT2_DOC_CONT___MARKER__CREAT_E__SR_C__PR);
		project2DocCont__Marker_cREATE__SRC__prEReference = (EReference) project2DocCont__MarkerEClass.getEStructuralFeatures().get(0);
		createEReference(project2DocCont__MarkerEClass, PROJECT2_DOC_CONT___MARKER__CREAT_E__TR_G__DC);
		project2DocCont__Marker_cREATE__TRG__dcEReference = (EReference) project2DocCont__MarkerEClass.getEStructuralFeatures().get(1);
		createEReference(project2DocCont__MarkerEClass, PROJECT2_DOC_CONT___MARKER__CREAT_E__COR_R__PR2DC);
		project2DocCont__Marker_cREATE__CORR__pr2dcEReference = (EReference) project2DocCont__MarkerEClass.getEStructuralFeatures().get(2);
		
		type2Doc__MarkerEClass = createEClass(TYPE2_DOC___MARKER);
		createEReference(type2Doc__MarkerEClass, TYPE2_DOC___MARKER__CONTEX_T__SR_C__P);
		type2Doc__Marker_cONTEXT__SRC__pEReference = (EReference) type2Doc__MarkerEClass.getEStructuralFeatures().get(0);
		createEReference(type2Doc__MarkerEClass, TYPE2_DOC___MARKER__CREAT_E__SR_C__T);
		type2Doc__Marker_cREATE__SRC__tEReference = (EReference) type2Doc__MarkerEClass.getEStructuralFeatures().get(1);
		createEReference(type2Doc__MarkerEClass, TYPE2_DOC___MARKER__CREAT_E__TR_G__D);
		type2Doc__Marker_cREATE__TRG__dEReference = (EReference) type2Doc__MarkerEClass.getEStructuralFeatures().get(2);
		createEReference(type2Doc__MarkerEClass, TYPE2_DOC___MARKER__CONTEX_T__TR_G__F);
		type2Doc__Marker_cONTEXT__TRG__fEReference = (EReference) type2Doc__MarkerEClass.getEStructuralFeatures().get(3);
		createEReference(type2Doc__MarkerEClass, TYPE2_DOC___MARKER__CONTEX_T__COR_R__P2F);
		type2Doc__Marker_cONTEXT__CORR__p2fEReference = (EReference) type2Doc__MarkerEClass.getEStructuralFeatures().get(4);
		createEReference(type2Doc__MarkerEClass, TYPE2_DOC___MARKER__CREAT_E__COR_R__T2D);
		type2Doc__Marker_cREATE__CORR__t2dEReference = (EReference) type2Doc__MarkerEClass.getEStructuralFeatures().get(5);
		
		// Create enums
		
		// Create data types
	}

	public void initializePackageContents() {
		if (isInitialized)
			return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);
		
		// Obtain other dependent packages
		ExtDocModelPackage theExtDocModelPackagePackage = ExtDocModelPackage.eINSTANCE;
		RuntimePackage theRuntimePackagePackage = RuntimePackage.eINSTANCE;
		ExtTypeModelPackage theExtTypeModelPackagePackage = ExtTypeModelPackage.eINSTANCE;

		// Create type parameters

		// Set bounds for type parameters

		// Add supertypes to classes
		project2DocContainerEClass.getESuperTypes().add(RuntimePackage.eINSTANCE.getCorrespondenceNode());
		package2FolderEClass.getESuperTypes().add(RuntimePackage.eINSTANCE.getCorrespondenceNode());
		type2DocEClass.getESuperTypes().add(RuntimePackage.eINSTANCE.getCorrespondenceNode());
		method2EntryEClass.getESuperTypes().add(RuntimePackage.eINSTANCE.getCorrespondenceNode());
		param2EntryEClass.getESuperTypes().add(RuntimePackage.eINSTANCE.getCorrespondenceNode());
		field2EntryEClass.getESuperTypes().add(RuntimePackage.eINSTANCE.getCorrespondenceNode());
		jDoc2AnnotationEClass.getESuperTypes().add(RuntimePackage.eINSTANCE.getCorrespondenceNode());
		extendingType2Doc__MarkerEClass.getESuperTypes().add(RuntimePackage.eINSTANCE.getTGGRuleApplication());
		field2Entry__MarkerEClass.getESuperTypes().add(RuntimePackage.eINSTANCE.getTGGRuleApplication());
		glossary__MarkerEClass.getESuperTypes().add(RuntimePackage.eINSTANCE.getTGGRuleApplication());
		glossaryEntry__MarkerEClass.getESuperTypes().add(RuntimePackage.eINSTANCE.getTGGRuleApplication());
		glossaryLink__MarkerEClass.getESuperTypes().add(RuntimePackage.eINSTANCE.getTGGRuleApplication());
		jDoc2Annotation__MarkerEClass.getESuperTypes().add(RuntimePackage.eINSTANCE.getTGGRuleApplication());
		method2Entry__MarkerEClass.getESuperTypes().add(RuntimePackage.eINSTANCE.getTGGRuleApplication());
		package2Folder__MarkerEClass.getESuperTypes().add(RuntimePackage.eINSTANCE.getTGGRuleApplication());
		param2Entry__MarkerEClass.getESuperTypes().add(RuntimePackage.eINSTANCE.getTGGRuleApplication());
		project2DocCont__MarkerEClass.getESuperTypes().add(RuntimePackage.eINSTANCE.getTGGRuleApplication());
		type2Doc__MarkerEClass.getESuperTypes().add(RuntimePackage.eINSTANCE.getTGGRuleApplication());

		// Initialize classes, features, and operations; add parameters
		initEClass(project2DocContainerEClass, Project2DocContainer.class, "Project2DocContainer", !IS_ABSTRACT, !IS_INTERFACE,
			IS_GENERATED_INSTANCE_CLASS);
		initEReference(getProject2DocContainer_Source(), ExtTypeModelPackage.eINSTANCE.getProject(),  null, 
			"source", null, 0, 1, Project2DocContainer.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getProject2DocContainer_Target(), ExtDocModelPackage.eINSTANCE.getDocContainer(),  null, 
			"target", null, 0, 1, Project2DocContainer.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
				
		initEClass(package2FolderEClass, Package2Folder.class, "Package2Folder", !IS_ABSTRACT, !IS_INTERFACE,
			IS_GENERATED_INSTANCE_CLASS);
		initEReference(getPackage2Folder_Source(), ExtTypeModelPackage.eINSTANCE.getPackage(),  null, 
			"source", null, 0, 1, Package2Folder.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getPackage2Folder_Target(), ExtDocModelPackage.eINSTANCE.getFolder(),  null, 
			"target", null, 0, 1, Package2Folder.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
				
		initEClass(type2DocEClass, Type2Doc.class, "Type2Doc", !IS_ABSTRACT, !IS_INTERFACE,
			IS_GENERATED_INSTANCE_CLASS);
		initEReference(getType2Doc_Source(), ExtTypeModelPackage.eINSTANCE.getType(),  null, 
			"source", null, 0, 1, Type2Doc.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getType2Doc_Target(), ExtDocModelPackage.eINSTANCE.getDoc(),  null, 
			"target", null, 0, 1, Type2Doc.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
				
		initEClass(method2EntryEClass, Method2Entry.class, "Method2Entry", !IS_ABSTRACT, !IS_INTERFACE,
			IS_GENERATED_INSTANCE_CLASS);
		initEReference(getMethod2Entry_Source(), ExtTypeModelPackage.eINSTANCE.getMethod(),  null, 
			"source", null, 0, 1, Method2Entry.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getMethod2Entry_Target(), ExtDocModelPackage.eINSTANCE.getEntry(),  null, 
			"target", null, 0, 1, Method2Entry.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
				
		initEClass(param2EntryEClass, Param2Entry.class, "Param2Entry", !IS_ABSTRACT, !IS_INTERFACE,
			IS_GENERATED_INSTANCE_CLASS);
		initEReference(getParam2Entry_Source(), ExtTypeModelPackage.eINSTANCE.getParameter(),  null, 
			"source", null, 0, 1, Param2Entry.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getParam2Entry_Target(), ExtDocModelPackage.eINSTANCE.getEntry(),  null, 
			"target", null, 0, 1, Param2Entry.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
				
		initEClass(field2EntryEClass, Field2Entry.class, "Field2Entry", !IS_ABSTRACT, !IS_INTERFACE,
			IS_GENERATED_INSTANCE_CLASS);
		initEReference(getField2Entry_Source(), ExtTypeModelPackage.eINSTANCE.getField(),  null, 
			"source", null, 0, 1, Field2Entry.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getField2Entry_Target(), ExtDocModelPackage.eINSTANCE.getEntry(),  null, 
			"target", null, 0, 1, Field2Entry.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
				
		initEClass(jDoc2AnnotationEClass, JDoc2Annotation.class, "JDoc2Annotation", !IS_ABSTRACT, !IS_INTERFACE,
			IS_GENERATED_INSTANCE_CLASS);
		initEReference(getJDoc2Annotation_Source(), ExtTypeModelPackage.eINSTANCE.getJavaDoc(),  null, 
			"source", null, 0, 1, JDoc2Annotation.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getJDoc2Annotation_Target(), ExtDocModelPackage.eINSTANCE.getAnnotation(),  null, 
			"target", null, 0, 1, JDoc2Annotation.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
				
		initEClass(extendingType2Doc__MarkerEClass, ExtendingType2Doc__Marker.class, "ExtendingType2Doc__Marker", !IS_ABSTRACT, !IS_INTERFACE,
			IS_GENERATED_INSTANCE_CLASS);
		initEReference(getExtendingType2Doc__Marker_CREATE__SRC__nt(), ExtTypeModelPackage.eINSTANCE.getType(),  null, 
			"CREATE__SRC__nt", null, 1, 1, ExtendingType2Doc__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getExtendingType2Doc__Marker_CONTEXT__SRC__p(), ExtTypeModelPackage.eINSTANCE.getPackage(),  null, 
			"CONTEXT__SRC__p", null, 1, 1, ExtendingType2Doc__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getExtendingType2Doc__Marker_CONTEXT__SRC__t(), ExtTypeModelPackage.eINSTANCE.getType(),  null, 
			"CONTEXT__SRC__t", null, 1, 1, ExtendingType2Doc__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getExtendingType2Doc__Marker_CONTEXT__TRG__d(), ExtDocModelPackage.eINSTANCE.getDoc(),  null, 
			"CONTEXT__TRG__d", null, 1, 1, ExtendingType2Doc__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getExtendingType2Doc__Marker_CONTEXT__TRG__f(), ExtDocModelPackage.eINSTANCE.getFolder(),  null, 
			"CONTEXT__TRG__f", null, 1, 1, ExtendingType2Doc__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getExtendingType2Doc__Marker_CREATE__TRG__nd(), ExtDocModelPackage.eINSTANCE.getDoc(),  null, 
			"CREATE__TRG__nd", null, 1, 1, ExtendingType2Doc__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getExtendingType2Doc__Marker_CREATE__CORR__nt2nd(), this.getType2Doc(),  null, 
			"CREATE__CORR__nt2nd", null, 1, 1, ExtendingType2Doc__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getExtendingType2Doc__Marker_CONTEXT__CORR__p2f(), this.getPackage2Folder(),  null, 
			"CONTEXT__CORR__p2f", null, 1, 1, ExtendingType2Doc__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getExtendingType2Doc__Marker_CONTEXT__CORR__t2d(), this.getType2Doc(),  null, 
			"CONTEXT__CORR__t2d", null, 1, 1, ExtendingType2Doc__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
				
		initEClass(field2Entry__MarkerEClass, Field2Entry__Marker.class, "Field2Entry__Marker", !IS_ABSTRACT, !IS_INTERFACE,
			IS_GENERATED_INSTANCE_CLASS);
		initEReference(getField2Entry__Marker_CREATE__SRC__f(), ExtTypeModelPackage.eINSTANCE.getField(),  null, 
			"CREATE__SRC__f", null, 1, 1, Field2Entry__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getField2Entry__Marker_CONTEXT__SRC__t(), ExtTypeModelPackage.eINSTANCE.getType(),  null, 
			"CONTEXT__SRC__t", null, 1, 1, Field2Entry__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getField2Entry__Marker_CONTEXT__TRG__d(), ExtDocModelPackage.eINSTANCE.getDoc(),  null, 
			"CONTEXT__TRG__d", null, 1, 1, Field2Entry__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getField2Entry__Marker_CREATE__TRG__e(), ExtDocModelPackage.eINSTANCE.getEntry(),  null, 
			"CREATE__TRG__e", null, 1, 1, Field2Entry__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getField2Entry__Marker_CREATE__CORR__f2e(), this.getField2Entry(),  null, 
			"CREATE__CORR__f2e", null, 1, 1, Field2Entry__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getField2Entry__Marker_CONTEXT__CORR__t2d(), this.getType2Doc(),  null, 
			"CONTEXT__CORR__t2d", null, 1, 1, Field2Entry__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
				
		initEClass(glossary__MarkerEClass, Glossary__Marker.class, "Glossary__Marker", !IS_ABSTRACT, !IS_INTERFACE,
			IS_GENERATED_INSTANCE_CLASS);
		initEReference(getGlossary__Marker_CONTEXT__TRG__dc(), ExtDocModelPackage.eINSTANCE.getDocContainer(),  null, 
			"CONTEXT__TRG__dc", null, 1, 1, Glossary__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getGlossary__Marker_CREATE__TRG__g(), ExtDocModelPackage.eINSTANCE.getGlossary(),  null, 
			"CREATE__TRG__g", null, 1, 1, Glossary__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
				
		initEClass(glossaryEntry__MarkerEClass, GlossaryEntry__Marker.class, "GlossaryEntry__Marker", !IS_ABSTRACT, !IS_INTERFACE,
			IS_GENERATED_INSTANCE_CLASS);
		initEReference(getGlossaryEntry__Marker_CONTEXT__TRG__g(), ExtDocModelPackage.eINSTANCE.getGlossary(),  null, 
			"CONTEXT__TRG__g", null, 1, 1, GlossaryEntry__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getGlossaryEntry__Marker_CREATE__TRG__ge(), ExtDocModelPackage.eINSTANCE.getGlossaryEntry(),  null, 
			"CREATE__TRG__ge", null, 1, 1, GlossaryEntry__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
				
		initEClass(glossaryLink__MarkerEClass, GlossaryLink__Marker.class, "GlossaryLink__Marker", !IS_ABSTRACT, !IS_INTERFACE,
			IS_GENERATED_INSTANCE_CLASS);
		initEReference(getGlossaryLink__Marker_CONTEXT__TRG__e(), ExtDocModelPackage.eINSTANCE.getEntry(),  null, 
			"CONTEXT__TRG__e", null, 1, 1, GlossaryLink__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getGlossaryLink__Marker_CONTEXT__TRG__ge(), ExtDocModelPackage.eINSTANCE.getGlossaryEntry(),  null, 
			"CONTEXT__TRG__ge", null, 1, 1, GlossaryLink__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
				
		initEClass(jDoc2Annotation__MarkerEClass, JDoc2Annotation__Marker.class, "JDoc2Annotation__Marker", !IS_ABSTRACT, !IS_INTERFACE,
			IS_GENERATED_INSTANCE_CLASS);
		initEReference(getJDoc2Annotation__Marker_CREATE__SRC__j(), ExtTypeModelPackage.eINSTANCE.getJavaDoc(),  null, 
			"CREATE__SRC__j", null, 1, 1, JDoc2Annotation__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getJDoc2Annotation__Marker_CONTEXT__SRC__m(), ExtTypeModelPackage.eINSTANCE.getMethod(),  null, 
			"CONTEXT__SRC__m", null, 1, 1, JDoc2Annotation__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getJDoc2Annotation__Marker_CREATE__TRG__a(), ExtDocModelPackage.eINSTANCE.getAnnotation(),  null, 
			"CREATE__TRG__a", null, 1, 1, JDoc2Annotation__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getJDoc2Annotation__Marker_CONTEXT__TRG__e(), ExtDocModelPackage.eINSTANCE.getEntry(),  null, 
			"CONTEXT__TRG__e", null, 1, 1, JDoc2Annotation__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getJDoc2Annotation__Marker_CREATE__CORR__j2a(), this.getJDoc2Annotation(),  null, 
			"CREATE__CORR__j2a", null, 1, 1, JDoc2Annotation__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getJDoc2Annotation__Marker_CONTEXT__CORR__m2e(), this.getMethod2Entry(),  null, 
			"CONTEXT__CORR__m2e", null, 1, 1, JDoc2Annotation__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
				
		initEClass(method2Entry__MarkerEClass, Method2Entry__Marker.class, "Method2Entry__Marker", !IS_ABSTRACT, !IS_INTERFACE,
			IS_GENERATED_INSTANCE_CLASS);
		initEReference(getMethod2Entry__Marker_CREATE__SRC__m(), ExtTypeModelPackage.eINSTANCE.getMethod(),  null, 
			"CREATE__SRC__m", null, 1, 1, Method2Entry__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getMethod2Entry__Marker_CONTEXT__SRC__t(), ExtTypeModelPackage.eINSTANCE.getType(),  null, 
			"CONTEXT__SRC__t", null, 1, 1, Method2Entry__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getMethod2Entry__Marker_CONTEXT__TRG__d(), ExtDocModelPackage.eINSTANCE.getDoc(),  null, 
			"CONTEXT__TRG__d", null, 1, 1, Method2Entry__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getMethod2Entry__Marker_CREATE__TRG__e(), ExtDocModelPackage.eINSTANCE.getEntry(),  null, 
			"CREATE__TRG__e", null, 1, 1, Method2Entry__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getMethod2Entry__Marker_CREATE__CORR__m2e(), this.getMethod2Entry(),  null, 
			"CREATE__CORR__m2e", null, 1, 1, Method2Entry__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getMethod2Entry__Marker_CONTEXT__CORR__t2d(), this.getType2Doc(),  null, 
			"CONTEXT__CORR__t2d", null, 1, 1, Method2Entry__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
				
		initEClass(package2Folder__MarkerEClass, Package2Folder__Marker.class, "Package2Folder__Marker", !IS_ABSTRACT, !IS_INTERFACE,
			IS_GENERATED_INSTANCE_CLASS);
		initEReference(getPackage2Folder__Marker_CREATE__SRC__p(), ExtTypeModelPackage.eINSTANCE.getPackage(),  null, 
			"CREATE__SRC__p", null, 1, 1, Package2Folder__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getPackage2Folder__Marker_CONTEXT__SRC__pr(), ExtTypeModelPackage.eINSTANCE.getProject(),  null, 
			"CONTEXT__SRC__pr", null, 1, 1, Package2Folder__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getPackage2Folder__Marker_CONTEXT__TRG__dc(), ExtDocModelPackage.eINSTANCE.getDocContainer(),  null, 
			"CONTEXT__TRG__dc", null, 1, 1, Package2Folder__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getPackage2Folder__Marker_CREATE__TRG__f(), ExtDocModelPackage.eINSTANCE.getFolder(),  null, 
			"CREATE__TRG__f", null, 1, 1, Package2Folder__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getPackage2Folder__Marker_CREATE__CORR__p2f(), this.getPackage2Folder(),  null, 
			"CREATE__CORR__p2f", null, 1, 1, Package2Folder__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getPackage2Folder__Marker_CONTEXT__CORR__pr2dc(), this.getProject2DocContainer(),  null, 
			"CONTEXT__CORR__pr2dc", null, 1, 1, Package2Folder__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
				
		initEClass(param2Entry__MarkerEClass, Param2Entry__Marker.class, "Param2Entry__Marker", !IS_ABSTRACT, !IS_INTERFACE,
			IS_GENERATED_INSTANCE_CLASS);
		initEReference(getParam2Entry__Marker_CONTEXT__SRC__m(), ExtTypeModelPackage.eINSTANCE.getMethod(),  null, 
			"CONTEXT__SRC__m", null, 1, 1, Param2Entry__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getParam2Entry__Marker_CREATE__SRC__p(), ExtTypeModelPackage.eINSTANCE.getParameter(),  null, 
			"CREATE__SRC__p", null, 1, 1, Param2Entry__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getParam2Entry__Marker_CONTEXT__TRG__e(), ExtDocModelPackage.eINSTANCE.getEntry(),  null, 
			"CONTEXT__TRG__e", null, 1, 1, Param2Entry__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getParam2Entry__Marker_CONTEXT__CORR__m2e(), this.getMethod2Entry(),  null, 
			"CONTEXT__CORR__m2e", null, 1, 1, Param2Entry__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getParam2Entry__Marker_CREATE__CORR__p2e(), this.getParam2Entry(),  null, 
			"CREATE__CORR__p2e", null, 1, 1, Param2Entry__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
				
		initEClass(project2DocCont__MarkerEClass, Project2DocCont__Marker.class, "Project2DocCont__Marker", !IS_ABSTRACT, !IS_INTERFACE,
			IS_GENERATED_INSTANCE_CLASS);
		initEReference(getProject2DocCont__Marker_CREATE__SRC__pr(), ExtTypeModelPackage.eINSTANCE.getProject(),  null, 
			"CREATE__SRC__pr", null, 1, 1, Project2DocCont__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getProject2DocCont__Marker_CREATE__TRG__dc(), ExtDocModelPackage.eINSTANCE.getDocContainer(),  null, 
			"CREATE__TRG__dc", null, 1, 1, Project2DocCont__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getProject2DocCont__Marker_CREATE__CORR__pr2dc(), this.getProject2DocContainer(),  null, 
			"CREATE__CORR__pr2dc", null, 1, 1, Project2DocCont__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
				
		initEClass(type2Doc__MarkerEClass, Type2Doc__Marker.class, "Type2Doc__Marker", !IS_ABSTRACT, !IS_INTERFACE,
			IS_GENERATED_INSTANCE_CLASS);
		initEReference(getType2Doc__Marker_CONTEXT__SRC__p(), ExtTypeModelPackage.eINSTANCE.getPackage(),  null, 
			"CONTEXT__SRC__p", null, 1, 1, Type2Doc__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getType2Doc__Marker_CREATE__SRC__t(), ExtTypeModelPackage.eINSTANCE.getType(),  null, 
			"CREATE__SRC__t", null, 1, 1, Type2Doc__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getType2Doc__Marker_CREATE__TRG__d(), ExtDocModelPackage.eINSTANCE.getDoc(),  null, 
			"CREATE__TRG__d", null, 1, 1, Type2Doc__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getType2Doc__Marker_CONTEXT__TRG__f(), ExtDocModelPackage.eINSTANCE.getFolder(),  null, 
			"CONTEXT__TRG__f", null, 1, 1, Type2Doc__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getType2Doc__Marker_CONTEXT__CORR__p2f(), this.getPackage2Folder(),  null, 
			"CONTEXT__CORR__p2f", null, 1, 1, Type2Doc__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getType2Doc__Marker_CREATE__CORR__t2d(), this.getType2Doc(),  null, 
			"CREATE__CORR__t2d", null, 1, 1, Type2Doc__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
				
		
		// Initialize enums and add enum literals
		
		// Initialize data types
		
		// Create resource
		createResource(eNS_URI);
	}

} 

