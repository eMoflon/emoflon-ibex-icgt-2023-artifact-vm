package ExtDocModel;

import ExtDocModel.ExtDocModelPackage;

import org.emoflon.smartemf.runtime.notification.SmartEMFNotification;
import org.emoflon.smartemf.runtime.SmartObject;
import org.emoflon.smartemf.runtime.collections.*;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EStructuralFeature;

public interface Folder extends EObject, ExtDocModel.NamedElement {
	
    public java.lang.String getName();
    
    public void setName(java.lang.String value);
    
    public LinkedSmartESet<ExtDocModel.Doc> getDocs();
    
    public void setDocs(LinkedSmartESet<ExtDocModel.Doc> value);
    
    public ExtDocModel.DocContainer getContainer();
    
    public void setContainer(ExtDocModel.DocContainer value);
    
    public LinkedSmartESet<ExtDocModel.Folder> getSubFolder();
    
    public void setSubFolder(LinkedSmartESet<ExtDocModel.Folder> value);
    
    public ExtDocModel.Folder getSuperFolder();
    
    public void setSuperFolder(ExtDocModel.Folder value);
    

}
