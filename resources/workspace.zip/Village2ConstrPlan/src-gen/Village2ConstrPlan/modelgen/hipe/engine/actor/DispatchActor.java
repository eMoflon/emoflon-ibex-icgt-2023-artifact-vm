package Village2ConstrPlan.modelgen.hipe.engine.actor;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EObject;

import java.text.DecimalFormat;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.time.Duration;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.function.Consumer;

import akka.actor.AbstractActor;
import akka.actor.ActorRef;
import akka.stream.ActorMaterializer;
import akka.stream.javadsl.*;
import static akka.pattern.Patterns.ask;

import hipe.engine.util.HiPEMultiUtil;
import hipe.engine.util.IncUtil;
import hipe.engine.message.NewInput;
import hipe.engine.message.NoMoreInput;
import hipe.engine.message.input.ObjectAdded;
import hipe.engine.message.input.ObjectDeleted;
import hipe.engine.message.input.ReferenceAdded;
import hipe.engine.message.input.ReferenceDeleted;		
import hipe.engine.message.input.AttributeChanged;
import hipe.engine.message.input.NotificationContainer;

import hipe.generic.actor.junction.util.HiPEConfig;

public class DispatchActor extends AbstractActor {
	
	private int counter = 0;
	public long time = 0;
				
	private Map<String, ActorRef> name2actor;
	
	private Map<Object, Consumer<Object>> type2addConsumer = HiPEMultiUtil.createMap();
	private Map<Object, Consumer<Notification>> feature2setConsumer = HiPEMultiUtil.createMap();
	private Map<Object, Consumer<Notification>> feature2addEdgeConsumer = HiPEMultiUtil.createMap();
	private Map<Object, Consumer<Notification>> feature2removeEdgeConsumer = HiPEMultiUtil.createMap();
	
	private IncUtil incUtil;
	
	private ActorMaterializer materializer;
	
	public DispatchActor(Map<String, ActorRef> name2actor, IncUtil incUtil) {
		this.name2actor = name2actor;
		this.incUtil = incUtil;
		
		initializeAdd();
		initializeSet();
		initializeAddEdge();
		initializeRemoveEdge();
	
		materializer = ActorMaterializer.create(getContext());
	}
	
	private void initializeAdd() {
		type2addConsumer.put(ConstructionPlan.ConstructionPlanPackage.eINSTANCE.getPlanCollection(), obj -> {
			ConstructionPlan.PlanCollection _plancollection = (ConstructionPlan.PlanCollection) obj;
			incUtil.newMessage();
			name2actor.get("PlanCollection_object").tell(new ObjectAdded<ConstructionPlan.PlanCollection>(incUtil, _plancollection), getSelf());
		});
		type2addConsumer.put(ConstructionPlan.ConstructionPlanPackage.eINSTANCE.getPlan(), obj -> {
			ConstructionPlan.Plan _plan = (ConstructionPlan.Plan) obj;
			incUtil.newMessage();
			name2actor.get("Plan_object").tell(new ObjectAdded<ConstructionPlan.Plan>(incUtil, _plan), getSelf());
		});
		type2addConsumer.put(Village.VillagePackage.eINSTANCE.getHouse(), obj -> {
			Village.House _house = (Village.House) obj;
			incUtil.newMessage();
			name2actor.get("House_object").tell(new ObjectAdded<Village.House>(incUtil, _house), getSelf());
		});
		type2addConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getHouse2Constr(), obj -> {
			Village2ConstrPlan.House2Constr _house2constr = (Village2ConstrPlan.House2Constr) obj;
			incUtil.newMessage();
			name2actor.get("House2Constr_object").tell(new ObjectAdded<Village2ConstrPlan.House2Constr>(incUtil, _house2constr), getSelf());
		});
		type2addConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getVillageSquare2PlanCollection(), obj -> {
			Village2ConstrPlan.VillageSquare2PlanCollection _villagesquare2plancollection = (Village2ConstrPlan.VillageSquare2PlanCollection) obj;
			incUtil.newMessage();
			name2actor.get("VillageSquare2PlanCollection_object").tell(new ObjectAdded<Village2ConstrPlan.VillageSquare2PlanCollection>(incUtil, _villagesquare2plancollection), getSelf());
		});
		type2addConsumer.put(ConstructionPlan.ConstructionPlanPackage.eINSTANCE.getConstruction(), obj -> {
			ConstructionPlan.Construction _construction = (ConstructionPlan.Construction) obj;
			incUtil.newMessage();
			name2actor.get("Construction_object").tell(new ObjectAdded<ConstructionPlan.Construction>(incUtil, _construction), getSelf());
		});
		type2addConsumer.put(Village.VillagePackage.eINSTANCE.getVillageSquare(), obj -> {
			Village.VillageSquare _villagesquare = (Village.VillageSquare) obj;
			incUtil.newMessage();
			name2actor.get("VillageSquare_object").tell(new ObjectAdded<Village.VillageSquare>(incUtil, _villagesquare), getSelf());
		});
	}
	
	private void initializeSet() {
	}
	
	private void initializeAddEdge() {
		feature2addEdgeConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getVillageSquare2PlanCollection_Source(), notification -> {
			incUtil.newMessage();
			name2actor.get("Corner2Constr__GEN_1_localSearch").tell(new ReferenceAdded<Village2ConstrPlan.VillageSquare2PlanCollection, Village.VillageSquare>(incUtil,(Village2ConstrPlan.VillageSquare2PlanCollection) notification.getNotifier(), (Village.VillageSquare) notification.getNewValue(), "Village2ConstrPlan.VillageSquare2PlanCollection_source_VillageSquare"), getSelf());
		});
		feature2addEdgeConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getHouse2Constr_Source(), notification -> {
			incUtil.newMessage();
			name2actor.get("Cube2Constr__GEN_5_localSearch").tell(new ReferenceAdded<Village2ConstrPlan.House2Constr, Village.House>(incUtil,(Village2ConstrPlan.House2Constr) notification.getNotifier(), (Village.House) notification.getNewValue(), "Village2ConstrPlan.House2Constr_source_House"), getSelf());
			incUtil.newMessage();
			name2actor.get("Villa2Constr__GEN_10_localSearch").tell(new ReferenceAdded<Village2ConstrPlan.House2Constr, Village.House>(incUtil,(Village2ConstrPlan.House2Constr) notification.getNotifier(), (Village.House) notification.getNewValue(), "Village2ConstrPlan.House2Constr_source_House"), getSelf());
		});
		feature2addEdgeConsumer.put(ConstructionPlan.ConstructionPlanPackage.eINSTANCE.getPlan_Constructions(), notification -> {
			incUtil.newMessage();
			name2actor.get("Cube2Constr__GEN_5_localSearch").tell(new ReferenceAdded<ConstructionPlan.Plan, ConstructionPlan.Construction>(incUtil,(ConstructionPlan.Plan) notification.getNotifier(), (ConstructionPlan.Construction) notification.getNewValue(), "ConstructionPlan.Plan_constructions_Construction"), getSelf());
			incUtil.newMessage();
			name2actor.get("Villa2Constr__GEN_10_localSearch").tell(new ReferenceAdded<ConstructionPlan.Plan, ConstructionPlan.Construction>(incUtil,(ConstructionPlan.Plan) notification.getNotifier(), (ConstructionPlan.Construction) notification.getNewValue(), "ConstructionPlan.Plan_constructions_Construction"), getSelf());
		});
		feature2addEdgeConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getHouse2Constr_Target(), notification -> {
			incUtil.newMessage();
			name2actor.get("Cube2Constr__GEN_5_localSearch").tell(new ReferenceAdded<Village2ConstrPlan.House2Constr, ConstructionPlan.Construction>(incUtil,(Village2ConstrPlan.House2Constr) notification.getNotifier(), (ConstructionPlan.Construction) notification.getNewValue(), "Village2ConstrPlan.House2Constr_target_Construction"), getSelf());
			incUtil.newMessage();
			name2actor.get("Villa2Constr__GEN_10_localSearch").tell(new ReferenceAdded<Village2ConstrPlan.House2Constr, ConstructionPlan.Construction>(incUtil,(Village2ConstrPlan.House2Constr) notification.getNotifier(), (ConstructionPlan.Construction) notification.getNewValue(), "Village2ConstrPlan.House2Constr_target_Construction"), getSelf());
		});
		feature2addEdgeConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getVillageSquare2PlanCollection_Target(), notification -> {
			incUtil.newMessage();
			name2actor.get("Corner2Constr__GEN_1_localSearch").tell(new ReferenceAdded<Village2ConstrPlan.VillageSquare2PlanCollection, ConstructionPlan.PlanCollection>(incUtil,(Village2ConstrPlan.VillageSquare2PlanCollection) notification.getNotifier(), (ConstructionPlan.PlanCollection) notification.getNewValue(), "Village2ConstrPlan.VillageSquare2PlanCollection_target_PlanCollection"), getSelf());
		});
	}
	
	private void initializeRemoveEdge() {
		feature2removeEdgeConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getVillageSquare2PlanCollection_Source(), notification -> {
			incUtil.newMessage();
			name2actor.get("Corner2Constr__GEN_1_localSearch").tell(new ReferenceDeleted<Village2ConstrPlan.VillageSquare2PlanCollection, Village.VillageSquare>(incUtil, (Village2ConstrPlan.VillageSquare2PlanCollection) notification.getNotifier(), (Village.VillageSquare) notification.getOldValue(), "Village2ConstrPlan.VillageSquare2PlanCollection_source_VillageSquare"), getSelf());
		});
		feature2removeEdgeConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getHouse2Constr_Source(), notification -> {
			incUtil.newMessage();
			name2actor.get("Cube2Constr__GEN_5_localSearch").tell(new ReferenceDeleted<Village2ConstrPlan.House2Constr, Village.House>(incUtil, (Village2ConstrPlan.House2Constr) notification.getNotifier(), (Village.House) notification.getOldValue(), "Village2ConstrPlan.House2Constr_source_House"), getSelf());
			incUtil.newMessage();
			name2actor.get("Villa2Constr__GEN_10_localSearch").tell(new ReferenceDeleted<Village2ConstrPlan.House2Constr, Village.House>(incUtil, (Village2ConstrPlan.House2Constr) notification.getNotifier(), (Village.House) notification.getOldValue(), "Village2ConstrPlan.House2Constr_source_House"), getSelf());
		});
		feature2removeEdgeConsumer.put(ConstructionPlan.ConstructionPlanPackage.eINSTANCE.getPlan_Constructions(), notification -> {
			incUtil.newMessage();
			name2actor.get("Cube2Constr__GEN_5_localSearch").tell(new ReferenceDeleted<ConstructionPlan.Plan, ConstructionPlan.Construction>(incUtil, (ConstructionPlan.Plan) notification.getNotifier(), (ConstructionPlan.Construction) notification.getOldValue(), "ConstructionPlan.Plan_constructions_Construction"), getSelf());
			incUtil.newMessage();
			name2actor.get("Villa2Constr__GEN_10_localSearch").tell(new ReferenceDeleted<ConstructionPlan.Plan, ConstructionPlan.Construction>(incUtil, (ConstructionPlan.Plan) notification.getNotifier(), (ConstructionPlan.Construction) notification.getOldValue(), "ConstructionPlan.Plan_constructions_Construction"), getSelf());
		});
		feature2removeEdgeConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getHouse2Constr_Target(), notification -> {
			incUtil.newMessage();
			name2actor.get("Cube2Constr__GEN_5_localSearch").tell(new ReferenceDeleted<Village2ConstrPlan.House2Constr, ConstructionPlan.Construction>(incUtil, (Village2ConstrPlan.House2Constr) notification.getNotifier(), (ConstructionPlan.Construction) notification.getOldValue(), "Village2ConstrPlan.House2Constr_target_Construction"), getSelf());
			incUtil.newMessage();
			name2actor.get("Villa2Constr__GEN_10_localSearch").tell(new ReferenceDeleted<Village2ConstrPlan.House2Constr, ConstructionPlan.Construction>(incUtil, (Village2ConstrPlan.House2Constr) notification.getNotifier(), (ConstructionPlan.Construction) notification.getOldValue(), "Village2ConstrPlan.House2Constr_target_Construction"), getSelf());
		});
		feature2removeEdgeConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getVillageSquare2PlanCollection_Target(), notification -> {
			incUtil.newMessage();
			name2actor.get("Corner2Constr__GEN_1_localSearch").tell(new ReferenceDeleted<Village2ConstrPlan.VillageSquare2PlanCollection, ConstructionPlan.PlanCollection>(incUtil, (Village2ConstrPlan.VillageSquare2PlanCollection) notification.getNotifier(), (ConstructionPlan.PlanCollection) notification.getOldValue(), "Village2ConstrPlan.VillageSquare2PlanCollection_target_PlanCollection"), getSelf());
		});
	}

	@Override
	public void preStart() throws Exception {
		super.preStart();
	}

	@Override
	public void postStop() throws Exception {
		if(HiPEConfig.logWorkloadActivated) {
			DecimalFormat df = new DecimalFormat("0.#####");
	        df.setMaximumFractionDigits(5);
			System.err.println("DispatchNode" + ";"  + counter + ";" + df.format((double) time / (double) (1000 * 1000 * 1000)));
		}
	}

	@Override
	public Receive createReceive() {
		return receiveBuilder() //
				.match(NotificationContainer.class, this::handleNotificationContainer)
				.match(NoMoreInput.class, this::sendFinished) //
				.build();
	}

	private void sendFinished(NoMoreInput m) {
		incUtil.allMessagesInserted();
	}
	
	private void handleNotificationContainer(NotificationContainer nc) {
		counter++;
		long tic = System.nanoTime();
		nc.notifications.parallelStream().forEach(this::handleNotification);
		time += System.nanoTime() - tic;
	}
	
	private void handleNotification(Notification notification) {
		switch (notification.getEventType()) {
		case Notification.ADD:
			handleAdd(notification);
			break;
		case Notification.REMOVE:
			handleRemove(notification);
			break;
		case Notification.REMOVING_ADAPTER:
			handleRemoveAdapter(notification);
			break;	
		case Notification.SET:
			handleSet(notification);
			break;
		}
	}

	private void handleAdd(Notification notification) {
		if(notification.getFeature() == null) 
			handleAddedNode(notification.getNewValue());
		else
			handleAddedEdge(notification);
	}

	private void handleAddedNode(Object node) {
		if(node == null) 
			return;
			
		EObject obj = (EObject) node;
		if(type2addConsumer.containsKey(obj.eClass())) {
			type2addConsumer.get(obj.eClass()).accept(node);
		}
	}
	
	private void handleSet(Notification notification) {
		Object feature = notification.getFeature();
		if(feature2setConsumer.containsKey(feature)) {
			feature2setConsumer.get(feature).accept(notification);
		}
	}

	private void handleAddedEdge(Notification notification) {
		//check for self-edges
		if(notification.getNotifier().equals(notification.getNewValue()))
			handleAddedNode(notification.getNewValue());
					
		Object feature = notification.getFeature();
		if(feature2addEdgeConsumer.containsKey(feature)) {
			feature2addEdgeConsumer.get(feature).accept(notification);
		}
	}

	private void handleRemove(Notification notification) {
		Object feature = notification.getFeature();
		if(feature2removeEdgeConsumer.containsKey(feature)) {
			feature2removeEdgeConsumer.get(feature).accept(notification);
		}
	}
	
	private void handleRemoveAdapter(Notification notification) {
		Object node = notification.getNotifier();
		if (node instanceof Village2ConstrPlan.VillageSquare2PlanCollection) {
			incUtil.newMessage();
			name2actor.get("VillageSquare2PlanCollection_object").tell(new ObjectDeleted<Village2ConstrPlan.VillageSquare2PlanCollection>(incUtil, (Village2ConstrPlan.VillageSquare2PlanCollection) node), getSelf());
		}
		if (node instanceof Village2ConstrPlan.House2Constr) {
			incUtil.newMessage();
			name2actor.get("House2Constr_object").tell(new ObjectDeleted<Village2ConstrPlan.House2Constr>(incUtil, (Village2ConstrPlan.House2Constr) node), getSelf());
		}
		if (node instanceof ConstructionPlan.PlanCollection) {
			incUtil.newMessage();
			name2actor.get("PlanCollection_object").tell(new ObjectDeleted<ConstructionPlan.PlanCollection>(incUtil, (ConstructionPlan.PlanCollection) node), getSelf());
		}
		if (node instanceof ConstructionPlan.Construction) {
			incUtil.newMessage();
			name2actor.get("Construction_object").tell(new ObjectDeleted<ConstructionPlan.Construction>(incUtil, (ConstructionPlan.Construction) node), getSelf());
		}
		if (node instanceof ConstructionPlan.Plan) {
			incUtil.newMessage();
			name2actor.get("Plan_object").tell(new ObjectDeleted<ConstructionPlan.Plan>(incUtil, (ConstructionPlan.Plan) node), getSelf());
		}
		if (node instanceof Village.VillageSquare) {
			incUtil.newMessage();
			name2actor.get("VillageSquare_object").tell(new ObjectDeleted<Village.VillageSquare>(incUtil, (Village.VillageSquare) node), getSelf());
		}
		if (node instanceof Village.House) {
			incUtil.newMessage();
			name2actor.get("House_object").tell(new ObjectDeleted<Village.House>(incUtil, (Village.House) node), getSelf());
		}
	}
}

