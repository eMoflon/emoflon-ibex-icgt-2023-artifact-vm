package ExtType2Doc_LookAhead;

import runtime.RuntimePackage;
import ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage;

import org.emoflon.smartemf.runtime.notification.SmartEMFNotification;
import org.emoflon.smartemf.runtime.SmartObject;
import org.emoflon.smartemf.runtime.collections.*;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EStructuralFeature;

public interface Param2Entry__Marker extends EObject, runtime.TGGRuleApplication {
	
    public runtime.Protocol getProtocol();
    
    public void setProtocol(runtime.Protocol value);
    
    public ExtTypeModel.Method getCONTEXT__SRC__m();
    
    public void setCONTEXT__SRC__m(ExtTypeModel.Method value);
    
    public ExtTypeModel.Parameter getCREATE__SRC__p();
    
    public void setCREATE__SRC__p(ExtTypeModel.Parameter value);
    
    public ExtDocModel.Entry getCONTEXT__TRG__e();
    
    public void setCONTEXT__TRG__e(ExtDocModel.Entry value);
    
    public ExtType2Doc_LookAhead.Method2Entry getCONTEXT__CORR__m2e();
    
    public void setCONTEXT__CORR__m2e(ExtType2Doc_LookAhead.Method2Entry value);
    
    public ExtType2Doc_LookAhead.Param2Entry getCREATE__CORR__p2e();
    
    public void setCREATE__CORR__p2e(ExtType2Doc_LookAhead.Param2Entry value);
    

}
