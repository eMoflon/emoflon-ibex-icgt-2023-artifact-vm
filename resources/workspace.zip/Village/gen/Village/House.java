package Village;

import Village.VillagePackage;

import org.emoflon.smartemf.runtime.notification.SmartEMFNotification;
import org.emoflon.smartemf.runtime.SmartObject;
import org.emoflon.smartemf.runtime.collections.*;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EStructuralFeature;

public interface House extends EObject {
	
    public Village.House getNextHouse();
    
    public void setNextHouse(Village.House value);
    
    public java.lang.String getName();
    
    public void setName(java.lang.String value);
    
    public Village.HouseType getType();
    
    public void setType(Village.HouseType value);
    
    public java.lang.String getAddress();
    
    public void setAddress(java.lang.String value);
    

}
