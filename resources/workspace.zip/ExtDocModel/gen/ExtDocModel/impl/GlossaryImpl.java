package ExtDocModel.impl;

import ExtDocModel.ExtDocModelPackage;
import ExtDocModel.ExtDocModelPackage;

import org.emoflon.smartemf.runtime.*;
import org.emoflon.smartemf.runtime.collections.*;
import org.emoflon.smartemf.persistence.SmartEMFResource;
import org.emoflon.smartemf.runtime.notification.SmartEMFNotification;
import org.emoflon.smartemf.runtime.notification.NotifyStatus;

import java.util.function.Consumer;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EcoreFactory;
import org.eclipse.emf.ecore.EcorePackage;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.resource.Resource;

public class GlossaryImpl extends SmartObject implements ExtDocModel.Glossary {

    protected LinkedSmartESet<ExtDocModel.GlossaryEntry> entries = new LinkedSmartESet<ExtDocModel.GlossaryEntry>(this, ExtDocModelPackage.Literals.GLOSSARY__ENTRIES);
    protected ExtDocModel.DocContainer container = null;
	
	protected GlossaryImpl() {
		super(ExtDocModelPackage.Literals.GLOSSARY);
	}
	
    
    @Override
    public LinkedSmartESet<ExtDocModel.GlossaryEntry> getEntries() {
    	return this.entries;
    }
    
    @Override
    public void setEntries(LinkedSmartESet<ExtDocModel.GlossaryEntry> value) {
    	throw new UnsupportedOperationException("Set methods for SmartEMF collections are not supported.");
    }
    
    private void addEntriesAsInverse(ExtDocModel.GlossaryEntry value) {
    	if(this.entries.addInternal(value, false) == NotifyStatus.SUCCESS_NO_NOTIFICATION) {
    sendNotification(SmartEMFNotification.createAddNotification(this, ExtDocModelPackage.Literals.GLOSSARY__ENTRIES, value, -1));
    	} 
    }
    
    private void removeEntriesAsInverse(ExtDocModel.GlossaryEntry value) {
    	entries.removeInternal(value, false, true);
    }
    
    @Override
    public ExtDocModel.DocContainer getContainer() {
    	return this.container;
    }
    
    @Override
    public void setContainer(ExtDocModel.DocContainer value) {
    	
    	Object oldValue = this.container;
    	
    	if(value == null && oldValue == null)
    		return;
    		
    	if(value != null && value.equals(oldValue))
    		return;
    		
    	
    	
    		       	if(this.container != null && value == null) {
    		       		resetContainmentSilently();
    		       	}
    		        this.container = value;
    		        
    	
    	
    	        	sendNotification(SmartEMFNotification.createSetNotification(this, ExtDocModelPackage.Literals.GLOSSARY__CONTAINER, oldValue, value, -1));
    	        	
    	
    	        	if(oldValue != null) {
    	        		((SmartObject) oldValue).eInverseRemove(this, ExtDocModelPackage.Literals.DOC_CONTAINER__GLOSSARY);
    	        	}
    	        	if(value != null) {
    	        		((SmartObject) value).eInverseAdd(this, ExtDocModelPackage.Literals.DOC_CONTAINER__GLOSSARY);
    	        	}
    }
    
    private void setContainerAsInverse(ExtDocModel.DocContainer value) {
			    
			    Object oldValue = this.container;
			    
			    if(value == null && oldValue == null)
			    	return;
			    	
			    if(value != null && value.equals(oldValue))
			    	return;
			    	
			    
			    
			    	       	if(this.container != null && value == null) {
			    	       		resetContainmentSilently();
			    	       	}
			    	        this.container = value;
			    	        
			    
			    
			            	sendNotification(SmartEMFNotification.createSetNotification(this, ExtDocModelPackage.Literals.GLOSSARY__CONTAINER, oldValue, value, -1));
			            	
    }

    @Override
    public void eSet(EStructuralFeature eFeature, Object newValue){
    	if (ExtDocModelPackage.Literals.GLOSSARY__ENTRIES.equals(eFeature)) {
    		setEntries((LinkedSmartESet<ExtDocModel.GlossaryEntry>) newValue); 
    		return;
    	}
    	if (ExtDocModelPackage.Literals.GLOSSARY__CONTAINER.equals(eFeature)) {
    		setContainer((ExtDocModel.DocContainer) newValue); 
    		return;
    	}
    	eDynamicSet(eFeature, newValue);
    }
    
    @Override
    public void eUnset(EStructuralFeature eFeature){
    	if (ExtDocModelPackage.Literals.GLOSSARY__ENTRIES.equals(eFeature)) {
    		getEntries().clear(); 
    		return;
    	}
    	if (ExtDocModelPackage.Literals.GLOSSARY__CONTAINER.equals(eFeature)) {
    		setContainer((ExtDocModel.DocContainer)null); 
    		return;
    	}
    	eDynamicUnset(eFeature);
    }

    @Override
    public String toString(){
		return super.toString();
    }

 	@Override
    public Object eGet(EStructuralFeature eFeature){
    	if (ExtDocModelPackage.Literals.GLOSSARY__ENTRIES.equals(eFeature))
    		return getEntries();
    	if (ExtDocModelPackage.Literals.GLOSSARY__CONTAINER.equals(eFeature))
    		return getContainer();
    	return eDynamicGet(eFeature);
    }

    @Override
    public Object eGet(int featureID, boolean resolve, boolean coreType){
    	throw new UnsupportedOperationException("This method has been deactivated since it is not always safe to use.");
    }
    
    @Override
    public void eInverseAdd(Object otherEnd, EStructuralFeature feature) {
if (ExtDocModelPackage.Literals.GLOSSARY__ENTRIES.equals(feature)) {
	addEntriesAsInverse((ExtDocModel.GlossaryEntry) otherEnd);
 	return;
			        }	
if (ExtDocModelPackage.Literals.GLOSSARY__CONTAINER.equals(feature)) {
setContainerAsInverse((ExtDocModel.DocContainer) otherEnd); 
 	return;
			        }	
	    if(feature == null)
	    	return;
	    	
    	eDynamicInverseAdd(otherEnd, feature);
	    	}
    	
    @Override
	    	public void eInverseRemove(Object otherEnd, EStructuralFeature feature) {
if (ExtDocModelPackage.Literals.GLOSSARY__ENTRIES.equals(feature)) {
	removeEntriesAsInverse((ExtDocModel.GlossaryEntry) otherEnd);
 	return;
			        }
if (ExtDocModelPackage.Literals.GLOSSARY__CONTAINER.equals(feature)) {
setContainerAsInverse(null); 
 	return;
			        }
	    if(feature == null)
	    	return;
	    		    		
    	eDynamicInverseRemove(otherEnd, feature);
	    	}
    
    @Override
    /**
    * This method sets the resource and generates REMOVING_ADAPTER and ADD notifications
    */
    protected void setResourceOfContainments(Consumer<SmartObject> setResourceCall) {
    	for(Object obj : getEntries()) {
    		setResourceCall.accept(((SmartObject) obj));
	    		}
	    	}
	    	
	    	@Override
	    	/**
	    	* This method sets the resource and only generates REMOVING_ADAPTER notifications (no ADD messages)
	    	*/
    protected void setResourceOfContainmentsSilently(Resource r) { 		
    	for(Object obj : getEntries()) {
    		((SmartObject) obj).setResourceSilently(r);
	    		}
	    	}
}
