package ExtType2Doc_LookAhead.co.hipe.engine;

import akka.actor.ActorRef;
import akka.actor.Props;

import ExtType2Doc_LookAhead.co.hipe.engine.actor.NotificationActor;
import ExtType2Doc_LookAhead.co.hipe.engine.actor.DispatchActor;
import ExtType2Doc_LookAhead.co.hipe.engine.actor.localsearch.ExtendingType2Doc__CC_1_localSearch;
import ExtType2Doc_LookAhead.co.hipe.engine.actor.localsearch.Field2Entry__CC_10_localSearch;
import ExtType2Doc_LookAhead.co.hipe.engine.actor.localsearch.ImplementingType2Doc__CC_16_localSearch;
import ExtType2Doc_LookAhead.co.hipe.engine.actor.localsearch.Method2Entry__CC_23_localSearch;
import ExtType2Doc_LookAhead.co.hipe.engine.actor.localsearch.Package2Folder_f_superFolder_outgoing_TRG__FILTER_NAC_TRG_32_localSearch;
import ExtType2Doc_LookAhead.co.hipe.engine.actor.localsearch.Package2Folder_p_superPackage_outgoing_SRC__FILTER_NAC_SRC_29_localSearch;
import ExtType2Doc_LookAhead.co.hipe.engine.actor.junction.Package2Folder__CC_35_junction;
import ExtType2Doc_LookAhead.co.hipe.engine.actor.localsearch.Param2Entry__CC_40_localSearch;
import ExtType2Doc_LookAhead.co.hipe.engine.actor.localsearch.SubPackage2Folder__CC_45_localSearch;
import ExtType2Doc_LookAhead.co.hipe.engine.actor.localsearch.Type2Doc__CC_51_localSearch;

import hipe.engine.IHiPEEngine;
import hipe.engine.message.InitGenReferenceActor;

import hipe.generic.actor.GenericObjectActor;
import hipe.generic.actor.GenericReferenceActor;
import hipe.generic.actor.GenericProductionActor;
import hipe.generic.actor.junction.*;

import hipe.network.*;

public class HiPEEngine extends IHiPEEngine{
	
	public HiPEEngine(HiPENetwork network) {
		super(network);
	}
	
	public HiPEEngine() {
		super();
	}
	
	@Override
	public String getClassLocation() {
		return getClass().getProtectionDomain().getCodeSource().getLocation().getPath().toString();
	}
	
	@Override
	public String getPackageName() {
		return getClass().getPackageName();
	}
	
	@Override
	protected ActorRef getDispatchActor() {
		return system.actorOf(
			Props.create(DispatchActor.class, () -> new DispatchActor(name2actor, incUtil)),
			"DispatchActor");
	}
	
	@Override
	protected ActorRef getNotificationActor(boolean cascadingNotifications) {
		return system.actorOf(
			Props.create(NotificationActor.class, () -> new NotificationActor(dispatcher, incUtil, cascadingNotifications)), 
			"NotificationActor");
	}
	
	@Override
	public void createProductionNodes() {
		classes.put("ExtendingType2Doc__CC_production", GenericProductionActor.class);
		productionNodes2pattern.put("ExtendingType2Doc__CC_production", "ExtendingType2Doc__CC");
		classes.put("Field2Entry__CC_production", GenericProductionActor.class);
		productionNodes2pattern.put("Field2Entry__CC_production", "Field2Entry__CC");
		classes.put("ImplementingType2Doc__CC_production", GenericProductionActor.class);
		productionNodes2pattern.put("ImplementingType2Doc__CC_production", "ImplementingType2Doc__CC");
		classes.put("Method2Entry__CC_production", GenericProductionActor.class);
		productionNodes2pattern.put("Method2Entry__CC_production", "Method2Entry__CC");
		classes.put("Package2Folder__CC_production", GenericProductionActor.class);
		productionNodes2pattern.put("Package2Folder__CC_production", "Package2Folder__CC");
		classes.put("Package2Folder_f_superFolder_outgoing_TRG__FILTER_NAC_TRG_production", GenericProductionActor.class);
		productionNodes2pattern.put("Package2Folder_f_superFolder_outgoing_TRG__FILTER_NAC_TRG_production", "Package2Folder_f_superFolder_outgoing_TRG__FILTER_NAC_TRG");
		classes.put("Package2Folder_p_superPackage_outgoing_SRC__FILTER_NAC_SRC_production", GenericProductionActor.class);
		productionNodes2pattern.put("Package2Folder_p_superPackage_outgoing_SRC__FILTER_NAC_SRC_production", "Package2Folder_p_superPackage_outgoing_SRC__FILTER_NAC_SRC");
		classes.put("Param2Entry__CC_production", GenericProductionActor.class);
		productionNodes2pattern.put("Param2Entry__CC_production", "Param2Entry__CC");
		classes.put("SubPackage2Folder__CC_production", GenericProductionActor.class);
		productionNodes2pattern.put("SubPackage2Folder__CC_production", "SubPackage2Folder__CC");
		classes.put("Type2Doc__CC_production", GenericProductionActor.class);
		productionNodes2pattern.put("Type2Doc__CC_production", "Type2Doc__CC");
		
	}
	
	@Override
	public void createJunctionNodes() {
		classes.put("ExtendingType2Doc__CC_1_localSearch", ExtendingType2Doc__CC_1_localSearch.class);
		classes.put("Field2Entry__CC_10_localSearch", Field2Entry__CC_10_localSearch.class);
		classes.put("ImplementingType2Doc__CC_16_localSearch", ImplementingType2Doc__CC_16_localSearch.class);
		classes.put("Method2Entry__CC_23_localSearch", Method2Entry__CC_23_localSearch.class);
		classes.put("Package2Folder_f_superFolder_outgoing_TRG__FILTER_NAC_TRG_32_localSearch", Package2Folder_f_superFolder_outgoing_TRG__FILTER_NAC_TRG_32_localSearch.class);
		classes.put("Package2Folder__CC_36_nacjunction", GenericNACJunctionActor.class);
		classes.put("Package2Folder_p_superPackage_outgoing_SRC__FILTER_NAC_SRC_29_localSearch", Package2Folder_p_superPackage_outgoing_SRC__FILTER_NAC_SRC_29_localSearch.class);
		classes.put("Package2Folder__CC_37_nacjunction", GenericNACJunctionActor.class);
		classes.put("Package2Folder__CC_35_junction", Package2Folder__CC_35_junction.class);
		classes.put("Param2Entry__CC_40_localSearch", Param2Entry__CC_40_localSearch.class);
		classes.put("SubPackage2Folder__CC_45_localSearch", SubPackage2Folder__CC_45_localSearch.class);
		classes.put("Type2Doc__CC_51_localSearch", Type2Doc__CC_51_localSearch.class);
	}
	
	@Override
	public void createReferenceNodes() {
		
	}
	
	@Override
	public void createObjectNodes() {
		classes.put("Package2Folder_object",Package2Folder_object.class);
		classes.put("Type2Doc_object",Type2Doc_object.class);
		classes.put("Field_object",Field_object.class);
		classes.put("Entry_object",Entry_object.class);
		classes.put("Method_object",Method_object.class);
		classes.put("Method2Entry_object",Method2Entry_object.class);
		classes.put("Parameter_object",Parameter_object.class);
		classes.put("Doc_object_SP0",Doc_object_SP0.class);
		classes.put("Doc_object_SP1",Doc_object_SP1.class);
		classes.put("Folder_object_SP0",Folder_object_SP0.class);
		classes.put("Folder_object_SP1",Folder_object_SP1.class);
		classes.put("Package_object_SP0",Package_object_SP0.class);
		classes.put("Package_object_SP1",Package_object_SP1.class);
		classes.put("Type_object_SP0",Type_object_SP0.class);
		classes.put("Type_object_SP1",Type_object_SP1.class);
		
	}
	
	@Override
	public void initializeReferenceNodes() {
	}
}

class Package2Folder_object extends GenericObjectActor<ExtType2Doc_LookAhead.Package2Folder> { }
class Type2Doc_object extends GenericObjectActor<ExtType2Doc_LookAhead.Type2Doc> { }
class Field_object extends GenericObjectActor<ExtTypeModel.Field> { }
class Entry_object extends GenericObjectActor<ExtDocModel.Entry> { }
class Method_object extends GenericObjectActor<ExtTypeModel.Method> { }
class Method2Entry_object extends GenericObjectActor<ExtType2Doc_LookAhead.Method2Entry> { }
class Parameter_object extends GenericObjectActor<ExtTypeModel.Parameter> { }
class Doc_object_SP0 extends GenericObjectActor<ExtDocModel.Doc> { }
class Doc_object_SP1 extends GenericObjectActor<ExtDocModel.Doc> { }
class Folder_object_SP0 extends GenericObjectActor<ExtDocModel.Folder> { }
class Folder_object_SP1 extends GenericObjectActor<ExtDocModel.Folder> { }
class Package_object_SP0 extends GenericObjectActor<ExtTypeModel.Package> { }
class Package_object_SP1 extends GenericObjectActor<ExtTypeModel.Package> { }
class Type_object_SP0 extends GenericObjectActor<ExtTypeModel.Type> { }
class Type_object_SP1 extends GenericObjectActor<ExtTypeModel.Type> { }


