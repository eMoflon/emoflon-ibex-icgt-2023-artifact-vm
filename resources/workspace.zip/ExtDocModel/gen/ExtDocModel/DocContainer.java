package ExtDocModel;

import ExtDocModel.ExtDocModelPackage;

import org.emoflon.smartemf.runtime.notification.SmartEMFNotification;
import org.emoflon.smartemf.runtime.SmartObject;
import org.emoflon.smartemf.runtime.collections.*;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EStructuralFeature;

public interface DocContainer extends EObject {
	
    public LinkedSmartESet<ExtDocModel.Folder> getFolders();
    
    public void setFolders(LinkedSmartESet<ExtDocModel.Folder> value);
    
    public ExtDocModel.Glossary getGlossary();
    
    public void setGlossary(ExtDocModel.Glossary value);
    

}
