package ConstructionPlan.impl;

import ConstructionPlan.PlanCollection;
import ConstructionPlan.Plan;
import ConstructionPlan.Construction;
import ConstructionPlan.Component;
import ConstructionPlan.Cellar;
import ConstructionPlan.Basement;
import ConstructionPlan.SaddleRoof;


import ConstructionPlan.ConstructionPlanFactory;
import ConstructionPlan.ConstructionPlanPackage;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

public class ConstructionPlanFactoryImpl extends EFactoryImpl implements ConstructionPlan.ConstructionPlanFactory {

	public static ConstructionPlan.ConstructionPlanFactory init() {
		try {
			ConstructionPlanFactory theConstructionPlanFactory = (ConstructionPlanFactory) EPackage.Registry.INSTANCE
					.getEFactory(ConstructionPlanPackage.eNS_URI);
			if (theConstructionPlanFactory != null) {
				return theConstructionPlanFactory;
			}
		} catch (java.lang.Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new ConstructionPlanFactoryImpl();
	}

	public ConstructionPlanFactoryImpl() {
		super();
	}

	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
		case ConstructionPlanPackage.PLAN_COLLECTION:
			return createPlanCollection();
		case ConstructionPlanPackage.PLAN:
			return createPlan();
		case ConstructionPlanPackage.CONSTRUCTION:
			return createConstruction();
		case ConstructionPlanPackage.CELLAR:
			return createCellar();
		case ConstructionPlanPackage.BASEMENT:
			return createBasement();
		case ConstructionPlanPackage.SADDLE_ROOF:
			return createSaddleRoof();
		default:
			throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}
	
	
	@Override
	public ConstructionPlan.PlanCollection createPlanCollection() {
		PlanCollectionImpl planCollection = new PlanCollectionImpl();
		return planCollection;
	}
	@Override
	public ConstructionPlan.Plan createPlan() {
		PlanImpl plan = new PlanImpl();
		return plan;
	}
	@Override
	public ConstructionPlan.Construction createConstruction() {
		ConstructionImpl construction = new ConstructionImpl();
		return construction;
	}
	@Override
	public ConstructionPlan.Cellar createCellar() {
		CellarImpl cellar = new CellarImpl();
		return cellar;
	}
	@Override
	public ConstructionPlan.Basement createBasement() {
		BasementImpl basement = new BasementImpl();
		return basement;
	}
	@Override
	public ConstructionPlan.SaddleRoof createSaddleRoof() {
		SaddleRoofImpl saddleRoof = new SaddleRoofImpl();
		return saddleRoof;
	}
	

	@Override
	public ConstructionPlanPackage getConstructionPlanPackage() {
	return (ConstructionPlanPackage) getEPackage();
	}
} 
