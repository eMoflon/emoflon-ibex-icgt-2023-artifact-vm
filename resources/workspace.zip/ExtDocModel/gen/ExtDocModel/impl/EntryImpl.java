package ExtDocModel.impl;

import ExtDocModel.ExtDocModelPackage;
import ExtDocModel.ExtDocModelPackage;

import org.emoflon.smartemf.runtime.*;
import org.emoflon.smartemf.runtime.collections.*;
import org.emoflon.smartemf.persistence.SmartEMFResource;
import org.emoflon.smartemf.runtime.notification.SmartEMFNotification;
import org.emoflon.smartemf.runtime.notification.NotifyStatus;

import java.util.function.Consumer;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EcoreFactory;
import org.eclipse.emf.ecore.EcorePackage;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.resource.Resource;

public class EntryImpl extends SmartObject implements ExtDocModel.Entry {

    protected java.lang.String name = null;
    protected ExtDocModel.Doc doc = null;
    protected LinkedSmartESet<ExtDocModel.Annotation> annotations = new LinkedSmartESet<ExtDocModel.Annotation>(this, ExtDocModelPackage.Literals.ENTRY__ANNOTATIONS);
    protected LinkedSmartESet<ExtDocModel.GlossaryEntry> glossaryEntries = new LinkedSmartESet<ExtDocModel.GlossaryEntry>(this, ExtDocModelPackage.Literals.ENTRY__GLOSSARY_ENTRIES);
    protected ExtDocModel.EntryType type = ExtDocModel.EntryType.FIELD;
	
	protected EntryImpl() {
		super(ExtDocModelPackage.Literals.ENTRY);
	}
	
    
    @Override
    public java.lang.String getName() {
    	return this.name;
    }
    
    @Override
    public void setName(java.lang.String value) {
    	Object oldValue = this.name;
    	this.name = value;
    	
    	        	sendNotification(SmartEMFNotification.createSetNotification(this, ExtDocModelPackage.Literals.NAMED_ELEMENT__NAME, oldValue, value, -1));
    }
    
    
    @Override
    public ExtDocModel.Doc getDoc() {
    	return this.doc;
    }
    
    @Override
    public void setDoc(ExtDocModel.Doc value) {
    	
    	Object oldValue = this.doc;
    	
    	if(value == null && oldValue == null)
    		return;
    		
    	if(value != null && value.equals(oldValue))
    		return;
    		
    	
    	
    		       	if(this.doc != null && value == null) {
    		       		resetContainmentSilently();
    		       	}
    		        this.doc = value;
    		        
    	
    	
    	        	sendNotification(SmartEMFNotification.createSetNotification(this, ExtDocModelPackage.Literals.ENTRY__DOC, oldValue, value, -1));
    	        	
    	
    	        	if(oldValue != null) {
    	        		((SmartObject) oldValue).eInverseRemove(this, ExtDocModelPackage.Literals.DOC__ENTRIES);
    	        	}
    	        	if(value != null) {
    	        		((SmartObject) value).eInverseAdd(this, ExtDocModelPackage.Literals.DOC__ENTRIES);
    	        	}
    }
    
    private void setDocAsInverse(ExtDocModel.Doc value) {
			    
			    Object oldValue = this.doc;
			    
			    if(value == null && oldValue == null)
			    	return;
			    	
			    if(value != null && value.equals(oldValue))
			    	return;
			    	
			    
			    
			    	       	if(this.doc != null && value == null) {
			    	       		resetContainmentSilently();
			    	       	}
			    	        this.doc = value;
			    	        
			    
			    
			            	sendNotification(SmartEMFNotification.createSetNotification(this, ExtDocModelPackage.Literals.ENTRY__DOC, oldValue, value, -1));
			            	
    }
    
    @Override
    public LinkedSmartESet<ExtDocModel.Annotation> getAnnotations() {
    	return this.annotations;
    }
    
    @Override
    public void setAnnotations(LinkedSmartESet<ExtDocModel.Annotation> value) {
    	throw new UnsupportedOperationException("Set methods for SmartEMF collections are not supported.");
    }
    
    private void addAnnotationsAsInverse(ExtDocModel.Annotation value) {
    	if(this.annotations.addInternal(value, false) == NotifyStatus.SUCCESS_NO_NOTIFICATION) {
    sendNotification(SmartEMFNotification.createAddNotification(this, ExtDocModelPackage.Literals.ENTRY__ANNOTATIONS, value, -1));
    	} 
    }
    
    private void removeAnnotationsAsInverse(ExtDocModel.Annotation value) {
    	annotations.removeInternal(value, false, true);
    }
    
    @Override
    public LinkedSmartESet<ExtDocModel.GlossaryEntry> getGlossaryEntries() {
    	return this.glossaryEntries;
    }
    
    @Override
    public void setGlossaryEntries(LinkedSmartESet<ExtDocModel.GlossaryEntry> value) {
    	throw new UnsupportedOperationException("Set methods for SmartEMF collections are not supported.");
    }
    
    private void addGlossaryEntriesAsInverse(ExtDocModel.GlossaryEntry value) {
    	if(this.glossaryEntries.addInternal(value, false) == NotifyStatus.SUCCESS_NO_NOTIFICATION) {
    sendNotification(SmartEMFNotification.createAddNotification(this, ExtDocModelPackage.Literals.ENTRY__GLOSSARY_ENTRIES, value, -1));
    	} 
    }
    
    private void removeGlossaryEntriesAsInverse(ExtDocModel.GlossaryEntry value) {
    	glossaryEntries.removeInternal(value, false, true);
    }
    
    @Override
    public ExtDocModel.EntryType getType() {
    	return this.type;
    }
    
    @Override
    public void setType(ExtDocModel.EntryType value) {
    	Object oldValue = this.type;
    	this.type = value;
    	
    	        	sendNotification(SmartEMFNotification.createSetNotification(this, ExtDocModelPackage.Literals.ENTRY__TYPE, oldValue, value, -1));
    }
    

    @Override
    public void eSet(EStructuralFeature eFeature, Object newValue){
    	if (ExtDocModelPackage.Literals.NAMED_ELEMENT__NAME.equals(eFeature)) {
    		setName((java.lang.String) newValue); 
    		return;
    	}
    	if (ExtDocModelPackage.Literals.ENTRY__DOC.equals(eFeature)) {
    		setDoc((ExtDocModel.Doc) newValue); 
    		return;
    	}
    	if (ExtDocModelPackage.Literals.ENTRY__ANNOTATIONS.equals(eFeature)) {
    		setAnnotations((LinkedSmartESet<ExtDocModel.Annotation>) newValue); 
    		return;
    	}
    	if (ExtDocModelPackage.Literals.ENTRY__GLOSSARY_ENTRIES.equals(eFeature)) {
    		setGlossaryEntries((LinkedSmartESet<ExtDocModel.GlossaryEntry>) newValue); 
    		return;
    	}
    	if (ExtDocModelPackage.Literals.ENTRY__TYPE.equals(eFeature)) {
    		setType((ExtDocModel.EntryType) newValue); 
    		return;
    	}
    	eDynamicSet(eFeature, newValue);
    }
    
    @Override
    public void eUnset(EStructuralFeature eFeature){
    	if (ExtDocModelPackage.Literals.NAMED_ELEMENT__NAME.equals(eFeature)) {
    		setName((java.lang.String)null); 
    		return;
    	}
    	if (ExtDocModelPackage.Literals.ENTRY__DOC.equals(eFeature)) {
    		setDoc((ExtDocModel.Doc)null); 
    		return;
    	}
    	if (ExtDocModelPackage.Literals.ENTRY__ANNOTATIONS.equals(eFeature)) {
    		getAnnotations().clear(); 
    		return;
    	}
    	if (ExtDocModelPackage.Literals.ENTRY__GLOSSARY_ENTRIES.equals(eFeature)) {
    		getGlossaryEntries().clear(); 
    		return;
    	}
    	if (ExtDocModelPackage.Literals.ENTRY__TYPE.equals(eFeature)) {
    		setType((ExtDocModel.EntryType)ExtDocModel.EntryType.FIELD); 
    		return;
    	}
    	eDynamicUnset(eFeature);
    }

    @Override
    public String toString(){
		StringBuilder b = new StringBuilder();
		b.append(super.toString());
		b.append(" (");
		if (SmartEMFConfig.simpleStringRepresentations()) {
			b.append(getName());
		} else {
			b.append("name: ");
			b.append(getName());
			b.append(", ");
			b.append("type: ");
			b.append(getType());
		}
		b.append(")");
		return b.toString();
    }

 	@Override
    public Object eGet(EStructuralFeature eFeature){
    	if (ExtDocModelPackage.Literals.NAMED_ELEMENT__NAME.equals(eFeature))
    		return getName();
    	if (ExtDocModelPackage.Literals.ENTRY__DOC.equals(eFeature))
    		return getDoc();
    	if (ExtDocModelPackage.Literals.ENTRY__ANNOTATIONS.equals(eFeature))
    		return getAnnotations();
    	if (ExtDocModelPackage.Literals.ENTRY__GLOSSARY_ENTRIES.equals(eFeature))
    		return getGlossaryEntries();
    	if (ExtDocModelPackage.Literals.ENTRY__TYPE.equals(eFeature))
    		return getType();
    	return eDynamicGet(eFeature);
    }

    @Override
    public Object eGet(int featureID, boolean resolve, boolean coreType){
    	throw new UnsupportedOperationException("This method has been deactivated since it is not always safe to use.");
    }
    
    @Override
    public void eInverseAdd(Object otherEnd, EStructuralFeature feature) {
if (ExtDocModelPackage.Literals.ENTRY__DOC.equals(feature)) {
setDocAsInverse((ExtDocModel.Doc) otherEnd); 
 	return;
			        }	
if (ExtDocModelPackage.Literals.ENTRY__ANNOTATIONS.equals(feature)) {
	addAnnotationsAsInverse((ExtDocModel.Annotation) otherEnd);
 	return;
			        }	
if (ExtDocModelPackage.Literals.ENTRY__GLOSSARY_ENTRIES.equals(feature)) {
	addGlossaryEntriesAsInverse((ExtDocModel.GlossaryEntry) otherEnd);
 	return;
			        }	
	    if(feature == null)
	    	return;
	    	
    	eDynamicInverseAdd(otherEnd, feature);
	    	}
    	
    @Override
	    	public void eInverseRemove(Object otherEnd, EStructuralFeature feature) {
if (ExtDocModelPackage.Literals.ENTRY__DOC.equals(feature)) {
setDocAsInverse(null); 
 	return;
			        }
if (ExtDocModelPackage.Literals.ENTRY__ANNOTATIONS.equals(feature)) {
	removeAnnotationsAsInverse((ExtDocModel.Annotation) otherEnd);
 	return;
			        }
if (ExtDocModelPackage.Literals.ENTRY__GLOSSARY_ENTRIES.equals(feature)) {
	removeGlossaryEntriesAsInverse((ExtDocModel.GlossaryEntry) otherEnd);
 	return;
			        }
	    if(feature == null)
	    	return;
	    		    		
    	eDynamicInverseRemove(otherEnd, feature);
	    	}
    
    @Override
    /**
    * This method sets the resource and generates REMOVING_ADAPTER and ADD notifications
    */
    protected void setResourceOfContainments(Consumer<SmartObject> setResourceCall) {
    	for(Object obj : getAnnotations()) {
    		setResourceCall.accept(((SmartObject) obj));
	    		}
	    	}
	    	
	    	@Override
	    	/**
	    	* This method sets the resource and only generates REMOVING_ADAPTER notifications (no ADD messages)
	    	*/
    protected void setResourceOfContainmentsSilently(Resource r) { 		
    	for(Object obj : getAnnotations()) {
    		((SmartObject) obj).setResourceSilently(r);
	    		}
	    	}
}
