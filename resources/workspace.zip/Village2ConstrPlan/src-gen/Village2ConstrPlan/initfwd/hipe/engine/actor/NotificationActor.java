package Village2ConstrPlan.initfwd.hipe.engine.actor;

import java.util.Collection;
import java.util.LinkedList;

import org.eclipse.emf.ecore.EObject;

import akka.actor.ActorRef;

import hipe.engine.actor.GenericNotificationActor;
import hipe.engine.util.IncUtil;

public class NotificationActor extends GenericNotificationActor {
	
	public NotificationActor(ActorRef dispatchActor, IncUtil incUtil, boolean cascadingNotifications) {
		super(dispatchActor, incUtil, cascadingNotifications);
	}
	
	@Override
	protected void initializeExploration() {
		explorationConsumer.put(ConstructionPlan.ConstructionPlanPackage.eINSTANCE.getSaddleRoof(), obj -> {
			Collection<EObject> children = new LinkedList<>();
			ConstructionPlan.SaddleRoof _saddleroof = (ConstructionPlan.SaddleRoof) obj;
			if(_saddleroof.getNextStep() != null)
				children.add(_saddleroof.getNextStep());
			return children;
		});
		explorationConsumer.put(ConstructionPlan.ConstructionPlanPackage.eINSTANCE.getComponent(), obj -> {
			Collection<EObject> children = new LinkedList<>();
			ConstructionPlan.Component _component = (ConstructionPlan.Component) obj;
			if(_component.getNextStep() != null)
				children.add(_component.getNextStep());
			return children;
		});
		explorationConsumer.put(ConstructionPlan.ConstructionPlanPackage.eINSTANCE.getCellar(), obj -> {
			Collection<EObject> children = new LinkedList<>();
			ConstructionPlan.Cellar _cellar = (ConstructionPlan.Cellar) obj;
			if(_cellar.getNextStep() != null)
				children.add(_cellar.getNextStep());
			return children;
		});
		explorationConsumer.put(ConstructionPlan.ConstructionPlanPackage.eINSTANCE.getConstruction(), obj -> {
			Collection<EObject> children = new LinkedList<>();
			ConstructionPlan.Construction _construction = (ConstructionPlan.Construction) obj;
			if(_construction.getFirstStep() != null)
				children.add(_construction.getFirstStep());
			return children;
		});
		explorationConsumer.put(runtime.impl.RuntimePackageImpl.eINSTANCE.getProtocol(), obj -> {
			Collection<EObject> children = new LinkedList<>();
			runtime.Protocol _protocol = (runtime.Protocol) obj;
			children.addAll(_protocol.getSteps());
			return children;
		});
		explorationConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getVilla2Constr__Marker(), obj -> {
			Collection<EObject> children = new LinkedList<>();
			return children;
		});
		explorationConsumer.put(runtime.impl.RuntimePackageImpl.eINSTANCE.getCorrespondenceNode(), obj -> {
			Collection<EObject> children = new LinkedList<>();
			return children;
		});
		explorationConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getHouse2Constr(), obj -> {
			Collection<EObject> children = new LinkedList<>();
			return children;
		});
		explorationConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getCorner2Constr__Marker(), obj -> {
			Collection<EObject> children = new LinkedList<>();
			return children;
		});
		explorationConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getCube2Constr__Marker(), obj -> {
			Collection<EObject> children = new LinkedList<>();
			return children;
		});
		explorationConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getVillageSquare2PlanCollection(), obj -> {
			Collection<EObject> children = new LinkedList<>();
			return children;
		});
		explorationConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getVillageSquare2PlanCollection__Marker(), obj -> {
			Collection<EObject> children = new LinkedList<>();
			return children;
		});
		explorationConsumer.put(ConstructionPlan.ConstructionPlanPackage.eINSTANCE.getPlan(), obj -> {
			Collection<EObject> children = new LinkedList<>();
			ConstructionPlan.Plan _plan = (ConstructionPlan.Plan) obj;
			children.addAll(_plan.getConstructions());
			return children;
		});
		explorationConsumer.put(Village.VillagePackage.eINSTANCE.getVillageSquare(), obj -> {
			Collection<EObject> children = new LinkedList<>();
			Village.VillageSquare _villagesquare = (Village.VillageSquare) obj;
			children.addAll(_villagesquare.getStreetCorner());
			return children;
		});
		explorationConsumer.put(ConstructionPlan.ConstructionPlanPackage.eINSTANCE.getBasement(), obj -> {
			Collection<EObject> children = new LinkedList<>();
			ConstructionPlan.Basement _basement = (ConstructionPlan.Basement) obj;
			if(_basement.getNextStep() != null)
				children.add(_basement.getNextStep());
			return children;
		});
		explorationConsumer.put(runtime.impl.RuntimePackageImpl.eINSTANCE.getTempContainer(), obj -> {
			Collection<EObject> children = new LinkedList<>();
			runtime.TempContainer _tempcontainer = (runtime.TempContainer) obj;
			children.addAll(_tempcontainer.getObjects());
			return children;
		});
		explorationConsumer.put(runtime.impl.RuntimePackageImpl.eINSTANCE.getTGGRuleApplication(), obj -> {
			Collection<EObject> children = new LinkedList<>();
			return children;
		});
		explorationConsumer.put(Village.VillagePackage.eINSTANCE.getHouse(), obj -> {
			Collection<EObject> children = new LinkedList<>();
			Village.House _house = (Village.House) obj;
			if(_house.getNextHouse() != null)
				children.add(_house.getNextHouse());
			return children;
		});
		explorationConsumer.put(ConstructionPlan.ConstructionPlanPackage.eINSTANCE.getPlanCollection(), obj -> {
			Collection<EObject> children = new LinkedList<>();
			ConstructionPlan.PlanCollection _plancollection = (ConstructionPlan.PlanCollection) obj;
			children.addAll(_plancollection.getPlans());
			return children;
		});
	}
}

