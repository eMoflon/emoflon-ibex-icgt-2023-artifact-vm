package ConstructionPlan;

import ConstructionPlan.ConstructionPlanPackage;

import org.emoflon.smartemf.runtime.notification.SmartEMFNotification;
import org.emoflon.smartemf.runtime.SmartObject;
import org.emoflon.smartemf.runtime.collections.*;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EStructuralFeature;

public interface Basement extends EObject, ConstructionPlan.Component {
	
    public ConstructionPlan.Component getNextStep();
    
    public void setNextStep(ConstructionPlan.Component value);
    
    public java.lang.String getDescription();
    
    public void setDescription(java.lang.String value);
    

}
