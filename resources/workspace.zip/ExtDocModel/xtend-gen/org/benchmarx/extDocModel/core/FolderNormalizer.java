package org.benchmarx.extDocModel.core;

import ExtDocModel.Folder;
import org.benchmarx.util.Normalizer;

@SuppressWarnings("all")
public class FolderNormalizer extends Normalizer<Folder> {
  @Override
  public int compare(final Folder o1, final Folder o2) {
    return o1.getName().compareTo(o2.getName());
  }
}
