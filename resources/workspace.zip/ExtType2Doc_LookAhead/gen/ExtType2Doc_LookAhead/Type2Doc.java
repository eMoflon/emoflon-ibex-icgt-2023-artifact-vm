package ExtType2Doc_LookAhead;

import runtime.RuntimePackage;
import ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage;

import org.emoflon.smartemf.runtime.notification.SmartEMFNotification;
import org.emoflon.smartemf.runtime.SmartObject;
import org.emoflon.smartemf.runtime.collections.*;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EStructuralFeature;

public interface Type2Doc extends EObject, runtime.CorrespondenceNode {
	
    public ExtTypeModel.Type getSource();
    
    public void setSource(ExtTypeModel.Type value);
    
    public ExtDocModel.Doc getTarget();
    
    public void setTarget(ExtDocModel.Doc value);
    

}
