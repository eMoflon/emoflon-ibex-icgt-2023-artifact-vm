package Village2ConstrPlan;

import runtime.RuntimePackage;
import Village2ConstrPlan.Village2ConstrPlanPackage;

import org.emoflon.smartemf.runtime.notification.SmartEMFNotification;
import org.emoflon.smartemf.runtime.SmartObject;
import org.emoflon.smartemf.runtime.collections.*;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EStructuralFeature;

public interface Corner2Constr__Marker extends EObject, runtime.TGGRuleApplication {
	
    public runtime.Protocol getProtocol();
    
    public void setProtocol(runtime.Protocol value);
    
    public Village.House getCREATE__SRC__h();
    
    public void setCREATE__SRC__h(Village.House value);
    
    public Village.VillageSquare getCONTEXT__SRC__vs();
    
    public void setCONTEXT__SRC__vs(Village.VillageSquare value);
    
    public ConstructionPlan.Basement getCREATE__TRG__bt();
    
    public void setCREATE__TRG__bt(ConstructionPlan.Basement value);
    
    public ConstructionPlan.Construction getCREATE__TRG__cst();
    
    public void setCREATE__TRG__cst(ConstructionPlan.Construction value);
    
    public ConstructionPlan.Plan getCREATE__TRG__p();
    
    public void setCREATE__TRG__p(ConstructionPlan.Plan value);
    
    public ConstructionPlan.PlanCollection getCONTEXT__TRG__pc();
    
    public void setCONTEXT__TRG__pc(ConstructionPlan.PlanCollection value);
    
    public Village2ConstrPlan.House2Constr getCREATE__CORR__h2cst();
    
    public void setCREATE__CORR__h2cst(Village2ConstrPlan.House2Constr value);
    
    public Village2ConstrPlan.VillageSquare2PlanCollection getCONTEXT__CORR__vs2pc();
    
    public void setCONTEXT__CORR__vs2pc(Village2ConstrPlan.VillageSquare2PlanCollection value);
    

}
