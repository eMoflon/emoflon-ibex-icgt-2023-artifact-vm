package Village2ConstrPlan.co.hipe.engine.actor;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EObject;

import java.text.DecimalFormat;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.time.Duration;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.function.Consumer;

import akka.actor.AbstractActor;
import akka.actor.ActorRef;
import akka.stream.ActorMaterializer;
import akka.stream.javadsl.*;
import static akka.pattern.Patterns.ask;

import hipe.engine.util.HiPEMultiUtil;
import hipe.engine.util.IncUtil;
import hipe.engine.message.NewInput;
import hipe.engine.message.NoMoreInput;
import hipe.engine.message.input.ObjectAdded;
import hipe.engine.message.input.ObjectDeleted;
import hipe.engine.message.input.ReferenceAdded;
import hipe.engine.message.input.ReferenceDeleted;		
import hipe.engine.message.input.AttributeChanged;
import hipe.engine.message.input.NotificationContainer;

import hipe.generic.actor.junction.util.HiPEConfig;

public class DispatchActor extends AbstractActor {
	
	private int counter = 0;
	public long time = 0;
				
	private Map<String, ActorRef> name2actor;
	
	private Map<Object, Consumer<Object>> type2addConsumer = HiPEMultiUtil.createMap();
	private Map<Object, Consumer<Notification>> feature2setConsumer = HiPEMultiUtil.createMap();
	private Map<Object, Consumer<Notification>> feature2addEdgeConsumer = HiPEMultiUtil.createMap();
	private Map<Object, Consumer<Notification>> feature2removeEdgeConsumer = HiPEMultiUtil.createMap();
	
	private IncUtil incUtil;
	
	private ActorMaterializer materializer;
	
	public DispatchActor(Map<String, ActorRef> name2actor, IncUtil incUtil) {
		this.name2actor = name2actor;
		this.incUtil = incUtil;
		
		initializeAdd();
		initializeSet();
		initializeAddEdge();
		initializeRemoveEdge();
	
		materializer = ActorMaterializer.create(getContext());
	}
	
	private void initializeAdd() {
		type2addConsumer.put(ConstructionPlan.ConstructionPlanPackage.eINSTANCE.getPlanCollection(), obj -> {
			ConstructionPlan.PlanCollection _plancollection = (ConstructionPlan.PlanCollection) obj;
			incUtil.newMessage();
			name2actor.get("PlanCollection_object").tell(new ObjectAdded<ConstructionPlan.PlanCollection>(incUtil, _plancollection), getSelf());
		});
		type2addConsumer.put(ConstructionPlan.ConstructionPlanPackage.eINSTANCE.getCellar(), obj -> {
			ConstructionPlan.Cellar _cellar = (ConstructionPlan.Cellar) obj;
			incUtil.newMessage();
			name2actor.get("Cellar_object").tell(new ObjectAdded<ConstructionPlan.Cellar>(incUtil, _cellar), getSelf());
			incUtil.newMessage();
			name2actor.get("Component_object").tell(new ObjectAdded<ConstructionPlan.Component>(incUtil, _cellar), getSelf());
		});
		type2addConsumer.put(ConstructionPlan.ConstructionPlanPackage.eINSTANCE.getComponent(), obj -> {
			ConstructionPlan.Component _component = (ConstructionPlan.Component) obj;
			incUtil.newMessage();
			name2actor.get("Component_object").tell(new ObjectAdded<ConstructionPlan.Component>(incUtil, _component), getSelf());
		});
		type2addConsumer.put(ConstructionPlan.ConstructionPlanPackage.eINSTANCE.getBasement(), obj -> {
			ConstructionPlan.Basement _basement = (ConstructionPlan.Basement) obj;
			incUtil.newMessage();
			name2actor.get("Basement_object_SP0").tell(new ObjectAdded<ConstructionPlan.Basement>(incUtil, _basement), getSelf());
			incUtil.newMessage();
			name2actor.get("Basement_object_SP1").tell(new ObjectAdded<ConstructionPlan.Basement>(incUtil, _basement), getSelf());
			incUtil.newMessage();
			name2actor.get("Component_object").tell(new ObjectAdded<ConstructionPlan.Component>(incUtil, _basement), getSelf());
		});
		type2addConsumer.put(Village.VillagePackage.eINSTANCE.getHouse(), obj -> {
			Village.House _house = (Village.House) obj;
			incUtil.newMessage();
			name2actor.get("House_object_SP0").tell(new ObjectAdded<Village.House>(incUtil, _house), getSelf());
			incUtil.newMessage();
			name2actor.get("House_object_SP1").tell(new ObjectAdded<Village.House>(incUtil, _house), getSelf());
		});
		type2addConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getHouse2Constr(), obj -> {
			Village2ConstrPlan.House2Constr _house2constr = (Village2ConstrPlan.House2Constr) obj;
			incUtil.newMessage();
			name2actor.get("House2Constr_object").tell(new ObjectAdded<Village2ConstrPlan.House2Constr>(incUtil, _house2constr), getSelf());
		});
		type2addConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getVillageSquare2PlanCollection(), obj -> {
			Village2ConstrPlan.VillageSquare2PlanCollection _villagesquare2plancollection = (Village2ConstrPlan.VillageSquare2PlanCollection) obj;
			incUtil.newMessage();
			name2actor.get("VillageSquare2PlanCollection_object").tell(new ObjectAdded<Village2ConstrPlan.VillageSquare2PlanCollection>(incUtil, _villagesquare2plancollection), getSelf());
		});
		type2addConsumer.put(ConstructionPlan.ConstructionPlanPackage.eINSTANCE.getConstruction(), obj -> {
			ConstructionPlan.Construction _construction = (ConstructionPlan.Construction) obj;
			incUtil.newMessage();
			name2actor.get("Construction_object_SP0").tell(new ObjectAdded<ConstructionPlan.Construction>(incUtil, _construction), getSelf());
			incUtil.newMessage();
			name2actor.get("Construction_object_SP1").tell(new ObjectAdded<ConstructionPlan.Construction>(incUtil, _construction), getSelf());
		});
		type2addConsumer.put(Village.VillagePackage.eINSTANCE.getVillageSquare(), obj -> {
			Village.VillageSquare _villagesquare = (Village.VillageSquare) obj;
			incUtil.newMessage();
			name2actor.get("VillageSquare_object").tell(new ObjectAdded<Village.VillageSquare>(incUtil, _villagesquare), getSelf());
		});
		type2addConsumer.put(ConstructionPlan.ConstructionPlanPackage.eINSTANCE.getPlan(), obj -> {
			ConstructionPlan.Plan _plan = (ConstructionPlan.Plan) obj;
			incUtil.newMessage();
			name2actor.get("Plan_object").tell(new ObjectAdded<ConstructionPlan.Plan>(incUtil, _plan), getSelf());
		});
		type2addConsumer.put(ConstructionPlan.ConstructionPlanPackage.eINSTANCE.getSaddleRoof(), obj -> {
			ConstructionPlan.SaddleRoof _saddleroof = (ConstructionPlan.SaddleRoof) obj;
			incUtil.newMessage();
			name2actor.get("SaddleRoof_object").tell(new ObjectAdded<ConstructionPlan.SaddleRoof>(incUtil, _saddleroof), getSelf());
			incUtil.newMessage();
			name2actor.get("Component_object").tell(new ObjectAdded<ConstructionPlan.Component>(incUtil, _saddleroof), getSelf());
		});
	}
	
	private void initializeSet() {
		feature2setConsumer.put(Village.VillagePackage.eINSTANCE.getHouse_Name(), notification -> {
			if(notification.getNotifier() instanceof Village.House) {
				incUtil.newMessage();
				name2actor.get("House_object_SP1").tell(new AttributeChanged<Village.House>(incUtil, (Village.House) notification.getNotifier(), notification.getOldValue()), getSelf());
			}
			if(notification.getNotifier() instanceof Village.House) {
				incUtil.newMessage();
				name2actor.get("House_object_SP0").tell(new AttributeChanged<Village.House>(incUtil, (Village.House) notification.getNotifier(), notification.getOldValue()), getSelf());
			}
		});
		
		feature2setConsumer.put(ConstructionPlan.ConstructionPlanPackage.eINSTANCE.getConstruction_Name(), notification -> {
			if(notification.getNotifier() instanceof ConstructionPlan.Construction) {
				incUtil.newMessage();
				name2actor.get("Construction_object_SP0").tell(new AttributeChanged<ConstructionPlan.Construction>(incUtil, (ConstructionPlan.Construction) notification.getNotifier(), notification.getOldValue()), getSelf());
			}
			if(notification.getNotifier() instanceof ConstructionPlan.Construction) {
				incUtil.newMessage();
				name2actor.get("Construction_object_SP1").tell(new AttributeChanged<ConstructionPlan.Construction>(incUtil, (ConstructionPlan.Construction) notification.getNotifier(), notification.getOldValue()), getSelf());
			}
		});
		
		feature2setConsumer.put(Village.VillagePackage.eINSTANCE.getHouse_Type(), notification -> {
			if(notification.getNotifier() instanceof Village.House) {
				incUtil.newMessage();
				name2actor.get("House_object_SP1").tell(new AttributeChanged<Village.House>(incUtil, (Village.House) notification.getNotifier(), notification.getOldValue()), getSelf());
			}
			if(notification.getNotifier() instanceof Village.House) {
				incUtil.newMessage();
				name2actor.get("House_object_SP0").tell(new AttributeChanged<Village.House>(incUtil, (Village.House) notification.getNotifier(), notification.getOldValue()), getSelf());
			}
		});
		
	}
	
	private void initializeAddEdge() {
		feature2addEdgeConsumer.put(ConstructionPlan.ConstructionPlanPackage.eINSTANCE.getPlan_Constructions(), notification -> {
			incUtil.newMessage();
			name2actor.get("Corner2Constr__CC_8_localSearch").tell(new ReferenceAdded<ConstructionPlan.Plan, ConstructionPlan.Construction>(incUtil,(ConstructionPlan.Plan) notification.getNotifier(), (ConstructionPlan.Construction) notification.getNewValue(), "ConstructionPlan.Plan_constructions_Construction"), getSelf());
			incUtil.newMessage();
			name2actor.get("Cube2Constr__CC_23_localSearch").tell(new ReferenceAdded<ConstructionPlan.Plan, ConstructionPlan.Construction>(incUtil,(ConstructionPlan.Plan) notification.getNotifier(), (ConstructionPlan.Construction) notification.getNewValue(), "ConstructionPlan.Plan_constructions_Construction"), getSelf());
			incUtil.newMessage();
			name2actor.get("Cube2Constr__CC_23_localSearch").tell(new ReferenceAdded<ConstructionPlan.Plan, ConstructionPlan.Construction>(incUtil,(ConstructionPlan.Plan) notification.getNotifier(), (ConstructionPlan.Construction) notification.getNewValue(), "ConstructionPlan.Plan_constructions_Construction"), getSelf());
			incUtil.newMessage();
			name2actor.get("Villa2Constr__CC_39_localSearch").tell(new ReferenceAdded<ConstructionPlan.Plan, ConstructionPlan.Construction>(incUtil,(ConstructionPlan.Plan) notification.getNotifier(), (ConstructionPlan.Construction) notification.getNewValue(), "ConstructionPlan.Plan_constructions_Construction"), getSelf());
			incUtil.newMessage();
			name2actor.get("Villa2Constr__CC_39_localSearch").tell(new ReferenceAdded<ConstructionPlan.Plan, ConstructionPlan.Construction>(incUtil,(ConstructionPlan.Plan) notification.getNotifier(), (ConstructionPlan.Construction) notification.getNewValue(), "ConstructionPlan.Plan_constructions_Construction"), getSelf());
		});
		feature2addEdgeConsumer.put(Village.VillagePackage.eINSTANCE.getVillageSquare_StreetCorner(), notification -> {
			incUtil.newMessage();
			name2actor.get("Corner2Constr__CC_8_localSearch").tell(new ReferenceAdded<Village.VillageSquare, Village.House>(incUtil,(Village.VillageSquare) notification.getNotifier(), (Village.House) notification.getNewValue(), "Village.VillageSquare_streetCorner_House"), getSelf());
			incUtil.newMessage();
			name2actor.get("Cube2Constr_nh_streetCorner_incoming_SRC__FILTER_NAC_SRC_16_localSearch").tell(new ReferenceAdded<Village.VillageSquare, Village.House>(incUtil,(Village.VillageSquare) notification.getNotifier(), (Village.House) notification.getNewValue(), "Village.VillageSquare_streetCorner_House"), getSelf());
			incUtil.newMessage();
			name2actor.get("Villa2Constr_nh_streetCorner_incoming_SRC__FILTER_NAC_SRC_32_localSearch").tell(new ReferenceAdded<Village.VillageSquare, Village.House>(incUtil,(Village.VillageSquare) notification.getNotifier(), (Village.House) notification.getNewValue(), "Village.VillageSquare_streetCorner_House"), getSelf());
		});
		feature2addEdgeConsumer.put(ConstructionPlan.ConstructionPlanPackage.eINSTANCE.getConstruction_FirstStep(), notification -> {
			incUtil.newMessage();
			name2actor.get("Corner2Constr_cst_firstStep_outgoing_TRG__FILTER_NAC_TRG_4_localSearch").tell(new ReferenceAdded<ConstructionPlan.Construction, ConstructionPlan.Component>(incUtil,(ConstructionPlan.Construction) notification.getNotifier(), (ConstructionPlan.Component) notification.getNewValue(), "ConstructionPlan.Construction_firstStep_Component"), getSelf());
			incUtil.newMessage();
			name2actor.get("Corner2Constr_cst_firstStep_outgoing_TRG__FILTER_NAC_TRG_4_localSearch").tell(new ReferenceAdded<ConstructionPlan.Construction, ConstructionPlan.Component>(incUtil,(ConstructionPlan.Construction) notification.getNotifier(), (ConstructionPlan.Component) notification.getNewValue(), "ConstructionPlan.Construction_firstStep_Component"), getSelf());
			incUtil.newMessage();
			name2actor.get("Corner2Constr__CC_8_localSearch").tell(new ReferenceAdded<ConstructionPlan.Construction, ConstructionPlan.Component>(incUtil,(ConstructionPlan.Construction) notification.getNotifier(), (ConstructionPlan.Component) notification.getNewValue(), "ConstructionPlan.Construction_firstStep_Component"), getSelf());
			incUtil.newMessage();
			name2actor.get("Cube2Constr_ncst_firstStep_outgoing_TRG__FILTER_NAC_TRG_19_localSearch").tell(new ReferenceAdded<ConstructionPlan.Construction, ConstructionPlan.Component>(incUtil,(ConstructionPlan.Construction) notification.getNotifier(), (ConstructionPlan.Component) notification.getNewValue(), "ConstructionPlan.Construction_firstStep_Component"), getSelf());
			incUtil.newMessage();
			name2actor.get("Cube2Constr_ncst_firstStep_outgoing_TRG__FILTER_NAC_TRG_19_localSearch").tell(new ReferenceAdded<ConstructionPlan.Construction, ConstructionPlan.Component>(incUtil,(ConstructionPlan.Construction) notification.getNotifier(), (ConstructionPlan.Component) notification.getNewValue(), "ConstructionPlan.Construction_firstStep_Component"), getSelf());
			incUtil.newMessage();
			name2actor.get("Cube2Constr__CC_23_localSearch").tell(new ReferenceAdded<ConstructionPlan.Construction, ConstructionPlan.Component>(incUtil,(ConstructionPlan.Construction) notification.getNotifier(), (ConstructionPlan.Component) notification.getNewValue(), "ConstructionPlan.Construction_firstStep_Component"), getSelf());
			incUtil.newMessage();
			name2actor.get("Villa2Constr_ncst_firstStep_outgoing_TRG__FILTER_NAC_TRG_35_localSearch").tell(new ReferenceAdded<ConstructionPlan.Construction, ConstructionPlan.Component>(incUtil,(ConstructionPlan.Construction) notification.getNotifier(), (ConstructionPlan.Component) notification.getNewValue(), "ConstructionPlan.Construction_firstStep_Component"), getSelf());
			incUtil.newMessage();
			name2actor.get("Villa2Constr_ncst_firstStep_outgoing_TRG__FILTER_NAC_TRG_35_localSearch").tell(new ReferenceAdded<ConstructionPlan.Construction, ConstructionPlan.Component>(incUtil,(ConstructionPlan.Construction) notification.getNotifier(), (ConstructionPlan.Component) notification.getNewValue(), "ConstructionPlan.Construction_firstStep_Component"), getSelf());
			incUtil.newMessage();
			name2actor.get("Villa2Constr__CC_39_localSearch").tell(new ReferenceAdded<ConstructionPlan.Construction, ConstructionPlan.Component>(incUtil,(ConstructionPlan.Construction) notification.getNotifier(), (ConstructionPlan.Component) notification.getNewValue(), "ConstructionPlan.Construction_firstStep_Component"), getSelf());
		});
		feature2addEdgeConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getVillageSquare2PlanCollection_Source(), notification -> {
			incUtil.newMessage();
			name2actor.get("Corner2Constr__CC_8_localSearch").tell(new ReferenceAdded<Village2ConstrPlan.VillageSquare2PlanCollection, Village.VillageSquare>(incUtil,(Village2ConstrPlan.VillageSquare2PlanCollection) notification.getNotifier(), (Village.VillageSquare) notification.getNewValue(), "Village2ConstrPlan.VillageSquare2PlanCollection_source_VillageSquare"), getSelf());
		});
		feature2addEdgeConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getHouse2Constr_Source(), notification -> {
			incUtil.newMessage();
			name2actor.get("Cube2Constr__CC_23_localSearch").tell(new ReferenceAdded<Village2ConstrPlan.House2Constr, Village.House>(incUtil,(Village2ConstrPlan.House2Constr) notification.getNotifier(), (Village.House) notification.getNewValue(), "Village2ConstrPlan.House2Constr_source_House"), getSelf());
			incUtil.newMessage();
			name2actor.get("Villa2Constr__CC_39_localSearch").tell(new ReferenceAdded<Village2ConstrPlan.House2Constr, Village.House>(incUtil,(Village2ConstrPlan.House2Constr) notification.getNotifier(), (Village.House) notification.getNewValue(), "Village2ConstrPlan.House2Constr_source_House"), getSelf());
		});
		feature2addEdgeConsumer.put(Village.VillagePackage.eINSTANCE.getHouse_NextHouse(), notification -> {
			incUtil.newMessage();
			name2actor.get("Corner2Constr_h_nextHouse_incoming_SRC__FILTER_NAC_SRC_1_localSearch").tell(new ReferenceAdded<Village.House, Village.House>(incUtil,(Village.House) notification.getNotifier(), (Village.House) notification.getNewValue(), "Village.House_nextHouse_House"), getSelf());
			incUtil.newMessage();
			name2actor.get("Cube2Constr__CC_23_localSearch").tell(new ReferenceAdded<Village.House, Village.House>(incUtil,(Village.House) notification.getNotifier(), (Village.House) notification.getNewValue(), "Village.House_nextHouse_House"), getSelf());
			incUtil.newMessage();
			name2actor.get("Villa2Constr__CC_39_localSearch").tell(new ReferenceAdded<Village.House, Village.House>(incUtil,(Village.House) notification.getNotifier(), (Village.House) notification.getNewValue(), "Village.House_nextHouse_House"), getSelf());
		});
		feature2addEdgeConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getHouse2Constr_Target(), notification -> {
			incUtil.newMessage();
			name2actor.get("Cube2Constr__CC_23_localSearch").tell(new ReferenceAdded<Village2ConstrPlan.House2Constr, ConstructionPlan.Construction>(incUtil,(Village2ConstrPlan.House2Constr) notification.getNotifier(), (ConstructionPlan.Construction) notification.getNewValue(), "Village2ConstrPlan.House2Constr_target_Construction"), getSelf());
			incUtil.newMessage();
			name2actor.get("Villa2Constr__CC_39_localSearch").tell(new ReferenceAdded<Village2ConstrPlan.House2Constr, ConstructionPlan.Construction>(incUtil,(Village2ConstrPlan.House2Constr) notification.getNotifier(), (ConstructionPlan.Construction) notification.getNewValue(), "Village2ConstrPlan.House2Constr_target_Construction"), getSelf());
		});
		feature2addEdgeConsumer.put(ConstructionPlan.ConstructionPlanPackage.eINSTANCE.getComponent_NextStep(), notification -> {
			incUtil.newMessage();
			name2actor.get("Cube2Constr__CC_23_localSearch").tell(new ReferenceAdded<ConstructionPlan.Component, ConstructionPlan.Component>(incUtil,(ConstructionPlan.Component) notification.getNotifier(), (ConstructionPlan.Component) notification.getNewValue(), "ConstructionPlan.Component_nextStep_Component"), getSelf());
			incUtil.newMessage();
			name2actor.get("Villa2Constr__CC_39_localSearch").tell(new ReferenceAdded<ConstructionPlan.Component, ConstructionPlan.Component>(incUtil,(ConstructionPlan.Component) notification.getNotifier(), (ConstructionPlan.Component) notification.getNewValue(), "ConstructionPlan.Component_nextStep_Component"), getSelf());
		});
		feature2addEdgeConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getVillageSquare2PlanCollection_Target(), notification -> {
			incUtil.newMessage();
			name2actor.get("Corner2Constr__CC_8_localSearch").tell(new ReferenceAdded<Village2ConstrPlan.VillageSquare2PlanCollection, ConstructionPlan.PlanCollection>(incUtil,(Village2ConstrPlan.VillageSquare2PlanCollection) notification.getNotifier(), (ConstructionPlan.PlanCollection) notification.getNewValue(), "Village2ConstrPlan.VillageSquare2PlanCollection_target_PlanCollection"), getSelf());
		});
		feature2addEdgeConsumer.put(ConstructionPlan.ConstructionPlanPackage.eINSTANCE.getPlanCollection_Plans(), notification -> {
			incUtil.newMessage();
			name2actor.get("Corner2Constr__CC_8_localSearch").tell(new ReferenceAdded<ConstructionPlan.PlanCollection, ConstructionPlan.Plan>(incUtil,(ConstructionPlan.PlanCollection) notification.getNotifier(), (ConstructionPlan.Plan) notification.getNewValue(), "ConstructionPlan.PlanCollection_plans_Plan"), getSelf());
		});
	}
	
	private void initializeRemoveEdge() {
		feature2removeEdgeConsumer.put(ConstructionPlan.ConstructionPlanPackage.eINSTANCE.getPlan_Constructions(), notification -> {
			incUtil.newMessage();
			name2actor.get("Corner2Constr__CC_8_localSearch").tell(new ReferenceDeleted<ConstructionPlan.Plan, ConstructionPlan.Construction>(incUtil, (ConstructionPlan.Plan) notification.getNotifier(), (ConstructionPlan.Construction) notification.getOldValue(), "ConstructionPlan.Plan_constructions_Construction"), getSelf());
			incUtil.newMessage();
			name2actor.get("Cube2Constr__CC_23_localSearch").tell(new ReferenceDeleted<ConstructionPlan.Plan, ConstructionPlan.Construction>(incUtil, (ConstructionPlan.Plan) notification.getNotifier(), (ConstructionPlan.Construction) notification.getOldValue(), "ConstructionPlan.Plan_constructions_Construction"), getSelf());
			incUtil.newMessage();
			name2actor.get("Cube2Constr__CC_23_localSearch").tell(new ReferenceDeleted<ConstructionPlan.Plan, ConstructionPlan.Construction>(incUtil, (ConstructionPlan.Plan) notification.getNotifier(), (ConstructionPlan.Construction) notification.getOldValue(), "ConstructionPlan.Plan_constructions_Construction"), getSelf());
			incUtil.newMessage();
			name2actor.get("Villa2Constr__CC_39_localSearch").tell(new ReferenceDeleted<ConstructionPlan.Plan, ConstructionPlan.Construction>(incUtil, (ConstructionPlan.Plan) notification.getNotifier(), (ConstructionPlan.Construction) notification.getOldValue(), "ConstructionPlan.Plan_constructions_Construction"), getSelf());
			incUtil.newMessage();
			name2actor.get("Villa2Constr__CC_39_localSearch").tell(new ReferenceDeleted<ConstructionPlan.Plan, ConstructionPlan.Construction>(incUtil, (ConstructionPlan.Plan) notification.getNotifier(), (ConstructionPlan.Construction) notification.getOldValue(), "ConstructionPlan.Plan_constructions_Construction"), getSelf());
		});
		feature2removeEdgeConsumer.put(Village.VillagePackage.eINSTANCE.getVillageSquare_StreetCorner(), notification -> {
			incUtil.newMessage();
			name2actor.get("Corner2Constr__CC_8_localSearch").tell(new ReferenceDeleted<Village.VillageSquare, Village.House>(incUtil, (Village.VillageSquare) notification.getNotifier(), (Village.House) notification.getOldValue(), "Village.VillageSquare_streetCorner_House"), getSelf());
			incUtil.newMessage();
			name2actor.get("Cube2Constr_nh_streetCorner_incoming_SRC__FILTER_NAC_SRC_16_localSearch").tell(new ReferenceDeleted<Village.VillageSquare, Village.House>(incUtil, (Village.VillageSquare) notification.getNotifier(), (Village.House) notification.getOldValue(), "Village.VillageSquare_streetCorner_House"), getSelf());
			incUtil.newMessage();
			name2actor.get("Villa2Constr_nh_streetCorner_incoming_SRC__FILTER_NAC_SRC_32_localSearch").tell(new ReferenceDeleted<Village.VillageSquare, Village.House>(incUtil, (Village.VillageSquare) notification.getNotifier(), (Village.House) notification.getOldValue(), "Village.VillageSquare_streetCorner_House"), getSelf());
		});
		feature2removeEdgeConsumer.put(ConstructionPlan.ConstructionPlanPackage.eINSTANCE.getConstruction_FirstStep(), notification -> {
			incUtil.newMessage();
			name2actor.get("Corner2Constr_cst_firstStep_outgoing_TRG__FILTER_NAC_TRG_4_localSearch").tell(new ReferenceDeleted<ConstructionPlan.Construction, ConstructionPlan.Component>(incUtil, (ConstructionPlan.Construction) notification.getNotifier(), (ConstructionPlan.Component) notification.getOldValue(), "ConstructionPlan.Construction_firstStep_Component"), getSelf());
			incUtil.newMessage();
			name2actor.get("Corner2Constr_cst_firstStep_outgoing_TRG__FILTER_NAC_TRG_4_localSearch").tell(new ReferenceDeleted<ConstructionPlan.Construction, ConstructionPlan.Component>(incUtil, (ConstructionPlan.Construction) notification.getNotifier(), (ConstructionPlan.Component) notification.getOldValue(), "ConstructionPlan.Construction_firstStep_Component"), getSelf());
			incUtil.newMessage();
			name2actor.get("Corner2Constr__CC_8_localSearch").tell(new ReferenceDeleted<ConstructionPlan.Construction, ConstructionPlan.Component>(incUtil, (ConstructionPlan.Construction) notification.getNotifier(), (ConstructionPlan.Component) notification.getOldValue(), "ConstructionPlan.Construction_firstStep_Component"), getSelf());
			incUtil.newMessage();
			name2actor.get("Cube2Constr_ncst_firstStep_outgoing_TRG__FILTER_NAC_TRG_19_localSearch").tell(new ReferenceDeleted<ConstructionPlan.Construction, ConstructionPlan.Component>(incUtil, (ConstructionPlan.Construction) notification.getNotifier(), (ConstructionPlan.Component) notification.getOldValue(), "ConstructionPlan.Construction_firstStep_Component"), getSelf());
			incUtil.newMessage();
			name2actor.get("Cube2Constr_ncst_firstStep_outgoing_TRG__FILTER_NAC_TRG_19_localSearch").tell(new ReferenceDeleted<ConstructionPlan.Construction, ConstructionPlan.Component>(incUtil, (ConstructionPlan.Construction) notification.getNotifier(), (ConstructionPlan.Component) notification.getOldValue(), "ConstructionPlan.Construction_firstStep_Component"), getSelf());
			incUtil.newMessage();
			name2actor.get("Cube2Constr__CC_23_localSearch").tell(new ReferenceDeleted<ConstructionPlan.Construction, ConstructionPlan.Component>(incUtil, (ConstructionPlan.Construction) notification.getNotifier(), (ConstructionPlan.Component) notification.getOldValue(), "ConstructionPlan.Construction_firstStep_Component"), getSelf());
			incUtil.newMessage();
			name2actor.get("Villa2Constr_ncst_firstStep_outgoing_TRG__FILTER_NAC_TRG_35_localSearch").tell(new ReferenceDeleted<ConstructionPlan.Construction, ConstructionPlan.Component>(incUtil, (ConstructionPlan.Construction) notification.getNotifier(), (ConstructionPlan.Component) notification.getOldValue(), "ConstructionPlan.Construction_firstStep_Component"), getSelf());
			incUtil.newMessage();
			name2actor.get("Villa2Constr_ncst_firstStep_outgoing_TRG__FILTER_NAC_TRG_35_localSearch").tell(new ReferenceDeleted<ConstructionPlan.Construction, ConstructionPlan.Component>(incUtil, (ConstructionPlan.Construction) notification.getNotifier(), (ConstructionPlan.Component) notification.getOldValue(), "ConstructionPlan.Construction_firstStep_Component"), getSelf());
			incUtil.newMessage();
			name2actor.get("Villa2Constr__CC_39_localSearch").tell(new ReferenceDeleted<ConstructionPlan.Construction, ConstructionPlan.Component>(incUtil, (ConstructionPlan.Construction) notification.getNotifier(), (ConstructionPlan.Component) notification.getOldValue(), "ConstructionPlan.Construction_firstStep_Component"), getSelf());
		});
		feature2removeEdgeConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getVillageSquare2PlanCollection_Source(), notification -> {
			incUtil.newMessage();
			name2actor.get("Corner2Constr__CC_8_localSearch").tell(new ReferenceDeleted<Village2ConstrPlan.VillageSquare2PlanCollection, Village.VillageSquare>(incUtil, (Village2ConstrPlan.VillageSquare2PlanCollection) notification.getNotifier(), (Village.VillageSquare) notification.getOldValue(), "Village2ConstrPlan.VillageSquare2PlanCollection_source_VillageSquare"), getSelf());
		});
		feature2removeEdgeConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getHouse2Constr_Source(), notification -> {
			incUtil.newMessage();
			name2actor.get("Cube2Constr__CC_23_localSearch").tell(new ReferenceDeleted<Village2ConstrPlan.House2Constr, Village.House>(incUtil, (Village2ConstrPlan.House2Constr) notification.getNotifier(), (Village.House) notification.getOldValue(), "Village2ConstrPlan.House2Constr_source_House"), getSelf());
			incUtil.newMessage();
			name2actor.get("Villa2Constr__CC_39_localSearch").tell(new ReferenceDeleted<Village2ConstrPlan.House2Constr, Village.House>(incUtil, (Village2ConstrPlan.House2Constr) notification.getNotifier(), (Village.House) notification.getOldValue(), "Village2ConstrPlan.House2Constr_source_House"), getSelf());
		});
		feature2removeEdgeConsumer.put(Village.VillagePackage.eINSTANCE.getHouse_NextHouse(), notification -> {
			incUtil.newMessage();
			name2actor.get("Corner2Constr_h_nextHouse_incoming_SRC__FILTER_NAC_SRC_1_localSearch").tell(new ReferenceDeleted<Village.House, Village.House>(incUtil, (Village.House) notification.getNotifier(), (Village.House) notification.getOldValue(), "Village.House_nextHouse_House"), getSelf());
			incUtil.newMessage();
			name2actor.get("Cube2Constr__CC_23_localSearch").tell(new ReferenceDeleted<Village.House, Village.House>(incUtil, (Village.House) notification.getNotifier(), (Village.House) notification.getOldValue(), "Village.House_nextHouse_House"), getSelf());
			incUtil.newMessage();
			name2actor.get("Villa2Constr__CC_39_localSearch").tell(new ReferenceDeleted<Village.House, Village.House>(incUtil, (Village.House) notification.getNotifier(), (Village.House) notification.getOldValue(), "Village.House_nextHouse_House"), getSelf());
		});
		feature2removeEdgeConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getHouse2Constr_Target(), notification -> {
			incUtil.newMessage();
			name2actor.get("Cube2Constr__CC_23_localSearch").tell(new ReferenceDeleted<Village2ConstrPlan.House2Constr, ConstructionPlan.Construction>(incUtil, (Village2ConstrPlan.House2Constr) notification.getNotifier(), (ConstructionPlan.Construction) notification.getOldValue(), "Village2ConstrPlan.House2Constr_target_Construction"), getSelf());
			incUtil.newMessage();
			name2actor.get("Villa2Constr__CC_39_localSearch").tell(new ReferenceDeleted<Village2ConstrPlan.House2Constr, ConstructionPlan.Construction>(incUtil, (Village2ConstrPlan.House2Constr) notification.getNotifier(), (ConstructionPlan.Construction) notification.getOldValue(), "Village2ConstrPlan.House2Constr_target_Construction"), getSelf());
		});
		feature2removeEdgeConsumer.put(ConstructionPlan.ConstructionPlanPackage.eINSTANCE.getComponent_NextStep(), notification -> {
			incUtil.newMessage();
			name2actor.get("Cube2Constr__CC_23_localSearch").tell(new ReferenceDeleted<ConstructionPlan.Component, ConstructionPlan.Component>(incUtil, (ConstructionPlan.Component) notification.getNotifier(), (ConstructionPlan.Component) notification.getOldValue(), "ConstructionPlan.Component_nextStep_Component"), getSelf());
			incUtil.newMessage();
			name2actor.get("Villa2Constr__CC_39_localSearch").tell(new ReferenceDeleted<ConstructionPlan.Component, ConstructionPlan.Component>(incUtil, (ConstructionPlan.Component) notification.getNotifier(), (ConstructionPlan.Component) notification.getOldValue(), "ConstructionPlan.Component_nextStep_Component"), getSelf());
		});
		feature2removeEdgeConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getVillageSquare2PlanCollection_Target(), notification -> {
			incUtil.newMessage();
			name2actor.get("Corner2Constr__CC_8_localSearch").tell(new ReferenceDeleted<Village2ConstrPlan.VillageSquare2PlanCollection, ConstructionPlan.PlanCollection>(incUtil, (Village2ConstrPlan.VillageSquare2PlanCollection) notification.getNotifier(), (ConstructionPlan.PlanCollection) notification.getOldValue(), "Village2ConstrPlan.VillageSquare2PlanCollection_target_PlanCollection"), getSelf());
		});
		feature2removeEdgeConsumer.put(ConstructionPlan.ConstructionPlanPackage.eINSTANCE.getPlanCollection_Plans(), notification -> {
			incUtil.newMessage();
			name2actor.get("Corner2Constr__CC_8_localSearch").tell(new ReferenceDeleted<ConstructionPlan.PlanCollection, ConstructionPlan.Plan>(incUtil, (ConstructionPlan.PlanCollection) notification.getNotifier(), (ConstructionPlan.Plan) notification.getOldValue(), "ConstructionPlan.PlanCollection_plans_Plan"), getSelf());
		});
	}

	@Override
	public void preStart() throws Exception {
		super.preStart();
	}

	@Override
	public void postStop() throws Exception {
		if(HiPEConfig.logWorkloadActivated) {
			DecimalFormat df = new DecimalFormat("0.#####");
	        df.setMaximumFractionDigits(5);
			System.err.println("DispatchNode" + ";"  + counter + ";" + df.format((double) time / (double) (1000 * 1000 * 1000)));
		}
	}

	@Override
	public Receive createReceive() {
		return receiveBuilder() //
				.match(NotificationContainer.class, this::handleNotificationContainer)
				.match(NoMoreInput.class, this::sendFinished) //
				.build();
	}

	private void sendFinished(NoMoreInput m) {
		incUtil.allMessagesInserted();
	}
	
	private void handleNotificationContainer(NotificationContainer nc) {
		counter++;
		long tic = System.nanoTime();
		nc.notifications.parallelStream().forEach(this::handleNotification);
		time += System.nanoTime() - tic;
	}
	
	private void handleNotification(Notification notification) {
		switch (notification.getEventType()) {
		case Notification.ADD:
			handleAdd(notification);
			break;
		case Notification.REMOVE:
			handleRemove(notification);
			break;
		case Notification.REMOVING_ADAPTER:
			handleRemoveAdapter(notification);
			break;	
		case Notification.SET:
			handleSet(notification);
			break;
		}
	}

	private void handleAdd(Notification notification) {
		if(notification.getFeature() == null) 
			handleAddedNode(notification.getNewValue());
		else
			handleAddedEdge(notification);
	}

	private void handleAddedNode(Object node) {
		if(node == null) 
			return;
			
		EObject obj = (EObject) node;
		if(type2addConsumer.containsKey(obj.eClass())) {
			type2addConsumer.get(obj.eClass()).accept(node);
		}
	}
	
	private void handleSet(Notification notification) {
		Object feature = notification.getFeature();
		if(feature2setConsumer.containsKey(feature)) {
			feature2setConsumer.get(feature).accept(notification);
		}
	}

	private void handleAddedEdge(Notification notification) {
		//check for self-edges
		if(notification.getNotifier().equals(notification.getNewValue()))
			handleAddedNode(notification.getNewValue());
					
		Object feature = notification.getFeature();
		if(feature2addEdgeConsumer.containsKey(feature)) {
			feature2addEdgeConsumer.get(feature).accept(notification);
		}
	}

	private void handleRemove(Notification notification) {
		Object feature = notification.getFeature();
		if(feature2removeEdgeConsumer.containsKey(feature)) {
			feature2removeEdgeConsumer.get(feature).accept(notification);
		}
	}
	
	private void handleRemoveAdapter(Notification notification) {
		Object node = notification.getNotifier();
		if (node instanceof Village2ConstrPlan.VillageSquare2PlanCollection) {
			incUtil.newMessage();
			name2actor.get("VillageSquare2PlanCollection_object").tell(new ObjectDeleted<Village2ConstrPlan.VillageSquare2PlanCollection>(incUtil, (Village2ConstrPlan.VillageSquare2PlanCollection) node), getSelf());
		}
		if (node instanceof Village2ConstrPlan.House2Constr) {
			incUtil.newMessage();
			name2actor.get("House2Constr_object").tell(new ObjectDeleted<Village2ConstrPlan.House2Constr>(incUtil, (Village2ConstrPlan.House2Constr) node), getSelf());
		}
		if (node instanceof Village.VillageSquare) {
			incUtil.newMessage();
			name2actor.get("VillageSquare_object").tell(new ObjectDeleted<Village.VillageSquare>(incUtil, (Village.VillageSquare) node), getSelf());
		}
		if (node instanceof Village.House) {
			incUtil.newMessage();
			name2actor.get("House_object_SP0").tell(new ObjectDeleted<Village.House>(incUtil, (Village.House) node), getSelf());
		}
		if (node instanceof Village.House) {
			incUtil.newMessage();
			name2actor.get("House_object_SP1").tell(new ObjectDeleted<Village.House>(incUtil, (Village.House) node), getSelf());
		}
		if (node instanceof ConstructionPlan.PlanCollection) {
			incUtil.newMessage();
			name2actor.get("PlanCollection_object").tell(new ObjectDeleted<ConstructionPlan.PlanCollection>(incUtil, (ConstructionPlan.PlanCollection) node), getSelf());
		}
		if (node instanceof ConstructionPlan.Plan) {
			incUtil.newMessage();
			name2actor.get("Plan_object").tell(new ObjectDeleted<ConstructionPlan.Plan>(incUtil, (ConstructionPlan.Plan) node), getSelf());
		}
		if (node instanceof ConstructionPlan.Component) {
			incUtil.newMessage();
			name2actor.get("Component_object").tell(new ObjectDeleted<ConstructionPlan.Component>(incUtil, (ConstructionPlan.Component) node), getSelf());
		}
		if (node instanceof ConstructionPlan.Cellar) {
			incUtil.newMessage();
			name2actor.get("Cellar_object").tell(new ObjectDeleted<ConstructionPlan.Cellar>(incUtil, (ConstructionPlan.Cellar) node), getSelf());
		}
		if (node instanceof ConstructionPlan.SaddleRoof) {
			incUtil.newMessage();
			name2actor.get("SaddleRoof_object").tell(new ObjectDeleted<ConstructionPlan.SaddleRoof>(incUtil, (ConstructionPlan.SaddleRoof) node), getSelf());
		}
		if (node instanceof ConstructionPlan.Basement) {
			incUtil.newMessage();
			name2actor.get("Basement_object_SP0").tell(new ObjectDeleted<ConstructionPlan.Basement>(incUtil, (ConstructionPlan.Basement) node), getSelf());
		}
		if (node instanceof ConstructionPlan.Basement) {
			incUtil.newMessage();
			name2actor.get("Basement_object_SP1").tell(new ObjectDeleted<ConstructionPlan.Basement>(incUtil, (ConstructionPlan.Basement) node), getSelf());
		}
		if (node instanceof ConstructionPlan.Construction) {
			incUtil.newMessage();
			name2actor.get("Construction_object_SP0").tell(new ObjectDeleted<ConstructionPlan.Construction>(incUtil, (ConstructionPlan.Construction) node), getSelf());
		}
		if (node instanceof ConstructionPlan.Construction) {
			incUtil.newMessage();
			name2actor.get("Construction_object_SP1").tell(new ObjectDeleted<ConstructionPlan.Construction>(incUtil, (ConstructionPlan.Construction) node), getSelf());
		}
	}
}

