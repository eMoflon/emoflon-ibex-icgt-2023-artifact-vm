package Village2ConstrPlan.impl;

import Village2ConstrPlan.VillageSquare2PlanCollection;
import Village2ConstrPlan.House2Constr;
import Village2ConstrPlan.Corner2Constr__Marker;
import Village2ConstrPlan.Cube2Constr__Marker;
import Village2ConstrPlan.Villa2Constr__Marker;
import Village2ConstrPlan.VillageSquare2PlanCollection__Marker;


import Village2ConstrPlan.Village2ConstrPlanFactory;
import Village2ConstrPlan.Village2ConstrPlanPackage;

import ConstructionPlan.ConstructionPlanPackage;
import runtime.RuntimePackage;
import Village.VillagePackage;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.ecore.EcorePackage;

import org.eclipse.emf.ecore.impl.EPackageImpl;

import org.emoflon.smartemf.runtime.SmartPackageImpl;

public class Village2ConstrPlanPackageImpl extends SmartPackageImpl
		implements Village2ConstrPlanPackage {
			
	private EClass villageSquare2PlanCollectionEClass = null;
	private EReference villageSquare2PlanCollection_sourceEReference = null;
	private EReference villageSquare2PlanCollection_targetEReference = null;
	private EClass house2ConstrEClass = null;
	private EReference house2Constr_sourceEReference = null;
	private EReference house2Constr_targetEReference = null;
	private EClass corner2Constr__MarkerEClass = null;
	private EReference corner2Constr__Marker_cREATE__SRC__hEReference = null;
	private EReference corner2Constr__Marker_cONTEXT__SRC__vsEReference = null;
	private EReference corner2Constr__Marker_cREATE__TRG__btEReference = null;
	private EReference corner2Constr__Marker_cREATE__TRG__cstEReference = null;
	private EReference corner2Constr__Marker_cREATE__TRG__pEReference = null;
	private EReference corner2Constr__Marker_cONTEXT__TRG__pcEReference = null;
	private EReference corner2Constr__Marker_cREATE__CORR__h2cstEReference = null;
	private EReference corner2Constr__Marker_cONTEXT__CORR__vs2pcEReference = null;
	private EClass cube2Constr__MarkerEClass = null;
	private EReference cube2Constr__Marker_cONTEXT__SRC__hEReference = null;
	private EReference cube2Constr__Marker_cREATE__SRC__nhEReference = null;
	private EReference cube2Constr__Marker_cREATE__TRG__btEReference = null;
	private EReference cube2Constr__Marker_cREATE__TRG__clEReference = null;
	private EReference cube2Constr__Marker_cONTEXT__TRG__cstEReference = null;
	private EReference cube2Constr__Marker_cREATE__TRG__ncstEReference = null;
	private EReference cube2Constr__Marker_cONTEXT__TRG__pEReference = null;
	private EReference cube2Constr__Marker_cONTEXT__CORR__h2cstEReference = null;
	private EReference cube2Constr__Marker_cREATE__CORR__nh2ncstEReference = null;
	private EClass villa2Constr__MarkerEClass = null;
	private EReference villa2Constr__Marker_cONTEXT__SRC__hEReference = null;
	private EReference villa2Constr__Marker_cREATE__SRC__nhEReference = null;
	private EReference villa2Constr__Marker_cREATE__TRG__btEReference = null;
	private EReference villa2Constr__Marker_cONTEXT__TRG__cstEReference = null;
	private EReference villa2Constr__Marker_cREATE__TRG__ncstEReference = null;
	private EReference villa2Constr__Marker_cONTEXT__TRG__pEReference = null;
	private EReference villa2Constr__Marker_cREATE__TRG__srEReference = null;
	private EReference villa2Constr__Marker_cONTEXT__CORR__h2cstEReference = null;
	private EReference villa2Constr__Marker_cREATE__CORR__nh2ncstEReference = null;
	private EClass villageSquare2PlanCollection__MarkerEClass = null;
	private EReference villageSquare2PlanCollection__Marker_cREATE__SRC__vsEReference = null;
	private EReference villageSquare2PlanCollection__Marker_cREATE__TRG__pcEReference = null;
	private EReference villageSquare2PlanCollection__Marker_cREATE__CORR__vs2plEReference = null;
	
	

	private Village2ConstrPlanPackageImpl() {
		super(eNS_URI, Village2ConstrPlan.Village2ConstrPlanFactory.eINSTANCE);
	}

	private static boolean isRegistered = false;
	private boolean isCreated = false;
	private boolean isInitialized = false;

	public static Village2ConstrPlanPackage init() {
		if (isRegistered)
			return (Village2ConstrPlanPackage) EPackage.Registry.INSTANCE
					.getEPackage(Village2ConstrPlanPackage.eNS_URI);

		// Obtain or create and register package
		Object registeredVillage2ConstrPlanPackage = EPackage.Registry.INSTANCE.get(eNS_URI);
		Village2ConstrPlanPackageImpl theVillage2ConstrPlanPackage = registeredVillage2ConstrPlanPackage instanceof Village2ConstrPlanPackageImpl
				? (Village2ConstrPlanPackageImpl) registeredVillage2ConstrPlanPackage
				: new Village2ConstrPlanPackageImpl();

		isRegistered = true;

		// Create package meta-data objects
		theVillage2ConstrPlanPackage.createPackageContents();

		// Initialize created meta-data
		theVillage2ConstrPlanPackage.initializePackageContents();
		
		// Inject internal eOpposites to unidirectional references
		theVillage2ConstrPlanPackage.injectDynamicOpposites();
		
		// Inject external references into foreign packages
		theVillage2ConstrPlanPackage.injectExternalReferences();

		// Mark meta-data to indicate it can't be changed
		theVillage2ConstrPlanPackage.freeze();

		// Update the registry and return the package
		EPackage.Registry.INSTANCE.put(Village2ConstrPlanPackage.eNS_URI,
				theVillage2ConstrPlanPackage);
				
		theVillage2ConstrPlanPackage.fetchDynamicEStructuralFeaturesOfSuperTypes();
		return theVillage2ConstrPlanPackage;
	}

	@Override
	public EClass getVillageSquare2PlanCollection() {
		return villageSquare2PlanCollectionEClass;
	}
	@Override
	public EReference getVillageSquare2PlanCollection_Source() {
		return villageSquare2PlanCollection_sourceEReference;	
	}
	@Override
	public EReference getVillageSquare2PlanCollection_Target() {
		return villageSquare2PlanCollection_targetEReference;	
	}
	@Override
	public EClass getHouse2Constr() {
		return house2ConstrEClass;
	}
	@Override
	public EReference getHouse2Constr_Source() {
		return house2Constr_sourceEReference;	
	}
	@Override
	public EReference getHouse2Constr_Target() {
		return house2Constr_targetEReference;	
	}
	@Override
	public EClass getCorner2Constr__Marker() {
		return corner2Constr__MarkerEClass;
	}
	@Override
	public EReference getCorner2Constr__Marker_CREATE__SRC__h() {
		return corner2Constr__Marker_cREATE__SRC__hEReference;	
	}
	@Override
	public EReference getCorner2Constr__Marker_CONTEXT__SRC__vs() {
		return corner2Constr__Marker_cONTEXT__SRC__vsEReference;	
	}
	@Override
	public EReference getCorner2Constr__Marker_CREATE__TRG__bt() {
		return corner2Constr__Marker_cREATE__TRG__btEReference;	
	}
	@Override
	public EReference getCorner2Constr__Marker_CREATE__TRG__cst() {
		return corner2Constr__Marker_cREATE__TRG__cstEReference;	
	}
	@Override
	public EReference getCorner2Constr__Marker_CREATE__TRG__p() {
		return corner2Constr__Marker_cREATE__TRG__pEReference;	
	}
	@Override
	public EReference getCorner2Constr__Marker_CONTEXT__TRG__pc() {
		return corner2Constr__Marker_cONTEXT__TRG__pcEReference;	
	}
	@Override
	public EReference getCorner2Constr__Marker_CREATE__CORR__h2cst() {
		return corner2Constr__Marker_cREATE__CORR__h2cstEReference;	
	}
	@Override
	public EReference getCorner2Constr__Marker_CONTEXT__CORR__vs2pc() {
		return corner2Constr__Marker_cONTEXT__CORR__vs2pcEReference;	
	}
	@Override
	public EClass getCube2Constr__Marker() {
		return cube2Constr__MarkerEClass;
	}
	@Override
	public EReference getCube2Constr__Marker_CONTEXT__SRC__h() {
		return cube2Constr__Marker_cONTEXT__SRC__hEReference;	
	}
	@Override
	public EReference getCube2Constr__Marker_CREATE__SRC__nh() {
		return cube2Constr__Marker_cREATE__SRC__nhEReference;	
	}
	@Override
	public EReference getCube2Constr__Marker_CREATE__TRG__bt() {
		return cube2Constr__Marker_cREATE__TRG__btEReference;	
	}
	@Override
	public EReference getCube2Constr__Marker_CREATE__TRG__cl() {
		return cube2Constr__Marker_cREATE__TRG__clEReference;	
	}
	@Override
	public EReference getCube2Constr__Marker_CONTEXT__TRG__cst() {
		return cube2Constr__Marker_cONTEXT__TRG__cstEReference;	
	}
	@Override
	public EReference getCube2Constr__Marker_CREATE__TRG__ncst() {
		return cube2Constr__Marker_cREATE__TRG__ncstEReference;	
	}
	@Override
	public EReference getCube2Constr__Marker_CONTEXT__TRG__p() {
		return cube2Constr__Marker_cONTEXT__TRG__pEReference;	
	}
	@Override
	public EReference getCube2Constr__Marker_CONTEXT__CORR__h2cst() {
		return cube2Constr__Marker_cONTEXT__CORR__h2cstEReference;	
	}
	@Override
	public EReference getCube2Constr__Marker_CREATE__CORR__nh2ncst() {
		return cube2Constr__Marker_cREATE__CORR__nh2ncstEReference;	
	}
	@Override
	public EClass getVilla2Constr__Marker() {
		return villa2Constr__MarkerEClass;
	}
	@Override
	public EReference getVilla2Constr__Marker_CONTEXT__SRC__h() {
		return villa2Constr__Marker_cONTEXT__SRC__hEReference;	
	}
	@Override
	public EReference getVilla2Constr__Marker_CREATE__SRC__nh() {
		return villa2Constr__Marker_cREATE__SRC__nhEReference;	
	}
	@Override
	public EReference getVilla2Constr__Marker_CREATE__TRG__bt() {
		return villa2Constr__Marker_cREATE__TRG__btEReference;	
	}
	@Override
	public EReference getVilla2Constr__Marker_CONTEXT__TRG__cst() {
		return villa2Constr__Marker_cONTEXT__TRG__cstEReference;	
	}
	@Override
	public EReference getVilla2Constr__Marker_CREATE__TRG__ncst() {
		return villa2Constr__Marker_cREATE__TRG__ncstEReference;	
	}
	@Override
	public EReference getVilla2Constr__Marker_CONTEXT__TRG__p() {
		return villa2Constr__Marker_cONTEXT__TRG__pEReference;	
	}
	@Override
	public EReference getVilla2Constr__Marker_CREATE__TRG__sr() {
		return villa2Constr__Marker_cREATE__TRG__srEReference;	
	}
	@Override
	public EReference getVilla2Constr__Marker_CONTEXT__CORR__h2cst() {
		return villa2Constr__Marker_cONTEXT__CORR__h2cstEReference;	
	}
	@Override
	public EReference getVilla2Constr__Marker_CREATE__CORR__nh2ncst() {
		return villa2Constr__Marker_cREATE__CORR__nh2ncstEReference;	
	}
	@Override
	public EClass getVillageSquare2PlanCollection__Marker() {
		return villageSquare2PlanCollection__MarkerEClass;
	}
	@Override
	public EReference getVillageSquare2PlanCollection__Marker_CREATE__SRC__vs() {
		return villageSquare2PlanCollection__Marker_cREATE__SRC__vsEReference;	
	}
	@Override
	public EReference getVillageSquare2PlanCollection__Marker_CREATE__TRG__pc() {
		return villageSquare2PlanCollection__Marker_cREATE__TRG__pcEReference;	
	}
	@Override
	public EReference getVillageSquare2PlanCollection__Marker_CREATE__CORR__vs2pl() {
		return villageSquare2PlanCollection__Marker_cREATE__CORR__vs2plEReference;	
	}
	
	

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Village2ConstrPlan.Village2ConstrPlanFactory getVillage2ConstrPlanFactory() {
		return (Village2ConstrPlan.Village2ConstrPlanFactory) getEFactoryInstance();
	}

	public void createPackageContents() {
		if (isCreated)
			return;
		isCreated = true;

		// Create classes and their features
		villageSquare2PlanCollectionEClass = createEClass(VILLAGE_SQUARE2_PLAN_COLLECTION);
		createEReference(villageSquare2PlanCollectionEClass, VILLAGE_SQUARE2_PLAN_COLLECTION__SOURCE);
		villageSquare2PlanCollection_sourceEReference = (EReference) villageSquare2PlanCollectionEClass.getEStructuralFeatures().get(0);
		createEReference(villageSquare2PlanCollectionEClass, VILLAGE_SQUARE2_PLAN_COLLECTION__TARGET);
		villageSquare2PlanCollection_targetEReference = (EReference) villageSquare2PlanCollectionEClass.getEStructuralFeatures().get(1);
		
		house2ConstrEClass = createEClass(HOUSE2_CONSTR);
		createEReference(house2ConstrEClass, HOUSE2_CONSTR__SOURCE);
		house2Constr_sourceEReference = (EReference) house2ConstrEClass.getEStructuralFeatures().get(0);
		createEReference(house2ConstrEClass, HOUSE2_CONSTR__TARGET);
		house2Constr_targetEReference = (EReference) house2ConstrEClass.getEStructuralFeatures().get(1);
		
		corner2Constr__MarkerEClass = createEClass(CORNER2_CONSTR___MARKER);
		createEReference(corner2Constr__MarkerEClass, CORNER2_CONSTR___MARKER__CREAT_E__SR_C__H);
		corner2Constr__Marker_cREATE__SRC__hEReference = (EReference) corner2Constr__MarkerEClass.getEStructuralFeatures().get(0);
		createEReference(corner2Constr__MarkerEClass, CORNER2_CONSTR___MARKER__CONTEX_T__SR_C__VS);
		corner2Constr__Marker_cONTEXT__SRC__vsEReference = (EReference) corner2Constr__MarkerEClass.getEStructuralFeatures().get(1);
		createEReference(corner2Constr__MarkerEClass, CORNER2_CONSTR___MARKER__CREAT_E__TR_G__BT);
		corner2Constr__Marker_cREATE__TRG__btEReference = (EReference) corner2Constr__MarkerEClass.getEStructuralFeatures().get(2);
		createEReference(corner2Constr__MarkerEClass, CORNER2_CONSTR___MARKER__CREAT_E__TR_G__CST);
		corner2Constr__Marker_cREATE__TRG__cstEReference = (EReference) corner2Constr__MarkerEClass.getEStructuralFeatures().get(3);
		createEReference(corner2Constr__MarkerEClass, CORNER2_CONSTR___MARKER__CREAT_E__TR_G__P);
		corner2Constr__Marker_cREATE__TRG__pEReference = (EReference) corner2Constr__MarkerEClass.getEStructuralFeatures().get(4);
		createEReference(corner2Constr__MarkerEClass, CORNER2_CONSTR___MARKER__CONTEX_T__TR_G__PC);
		corner2Constr__Marker_cONTEXT__TRG__pcEReference = (EReference) corner2Constr__MarkerEClass.getEStructuralFeatures().get(5);
		createEReference(corner2Constr__MarkerEClass, CORNER2_CONSTR___MARKER__CREAT_E__COR_R__H2CST);
		corner2Constr__Marker_cREATE__CORR__h2cstEReference = (EReference) corner2Constr__MarkerEClass.getEStructuralFeatures().get(6);
		createEReference(corner2Constr__MarkerEClass, CORNER2_CONSTR___MARKER__CONTEX_T__COR_R__VS2PC);
		corner2Constr__Marker_cONTEXT__CORR__vs2pcEReference = (EReference) corner2Constr__MarkerEClass.getEStructuralFeatures().get(7);
		
		cube2Constr__MarkerEClass = createEClass(CUBE2_CONSTR___MARKER);
		createEReference(cube2Constr__MarkerEClass, CUBE2_CONSTR___MARKER__CONTEX_T__SR_C__H);
		cube2Constr__Marker_cONTEXT__SRC__hEReference = (EReference) cube2Constr__MarkerEClass.getEStructuralFeatures().get(0);
		createEReference(cube2Constr__MarkerEClass, CUBE2_CONSTR___MARKER__CREAT_E__SR_C__NH);
		cube2Constr__Marker_cREATE__SRC__nhEReference = (EReference) cube2Constr__MarkerEClass.getEStructuralFeatures().get(1);
		createEReference(cube2Constr__MarkerEClass, CUBE2_CONSTR___MARKER__CREAT_E__TR_G__BT);
		cube2Constr__Marker_cREATE__TRG__btEReference = (EReference) cube2Constr__MarkerEClass.getEStructuralFeatures().get(2);
		createEReference(cube2Constr__MarkerEClass, CUBE2_CONSTR___MARKER__CREAT_E__TR_G__CL);
		cube2Constr__Marker_cREATE__TRG__clEReference = (EReference) cube2Constr__MarkerEClass.getEStructuralFeatures().get(3);
		createEReference(cube2Constr__MarkerEClass, CUBE2_CONSTR___MARKER__CONTEX_T__TR_G__CST);
		cube2Constr__Marker_cONTEXT__TRG__cstEReference = (EReference) cube2Constr__MarkerEClass.getEStructuralFeatures().get(4);
		createEReference(cube2Constr__MarkerEClass, CUBE2_CONSTR___MARKER__CREAT_E__TR_G__NCST);
		cube2Constr__Marker_cREATE__TRG__ncstEReference = (EReference) cube2Constr__MarkerEClass.getEStructuralFeatures().get(5);
		createEReference(cube2Constr__MarkerEClass, CUBE2_CONSTR___MARKER__CONTEX_T__TR_G__P);
		cube2Constr__Marker_cONTEXT__TRG__pEReference = (EReference) cube2Constr__MarkerEClass.getEStructuralFeatures().get(6);
		createEReference(cube2Constr__MarkerEClass, CUBE2_CONSTR___MARKER__CONTEX_T__COR_R__H2CST);
		cube2Constr__Marker_cONTEXT__CORR__h2cstEReference = (EReference) cube2Constr__MarkerEClass.getEStructuralFeatures().get(7);
		createEReference(cube2Constr__MarkerEClass, CUBE2_CONSTR___MARKER__CREAT_E__COR_R__NH2NCST);
		cube2Constr__Marker_cREATE__CORR__nh2ncstEReference = (EReference) cube2Constr__MarkerEClass.getEStructuralFeatures().get(8);
		
		villa2Constr__MarkerEClass = createEClass(VILLA2_CONSTR___MARKER);
		createEReference(villa2Constr__MarkerEClass, VILLA2_CONSTR___MARKER__CONTEX_T__SR_C__H);
		villa2Constr__Marker_cONTEXT__SRC__hEReference = (EReference) villa2Constr__MarkerEClass.getEStructuralFeatures().get(0);
		createEReference(villa2Constr__MarkerEClass, VILLA2_CONSTR___MARKER__CREAT_E__SR_C__NH);
		villa2Constr__Marker_cREATE__SRC__nhEReference = (EReference) villa2Constr__MarkerEClass.getEStructuralFeatures().get(1);
		createEReference(villa2Constr__MarkerEClass, VILLA2_CONSTR___MARKER__CREAT_E__TR_G__BT);
		villa2Constr__Marker_cREATE__TRG__btEReference = (EReference) villa2Constr__MarkerEClass.getEStructuralFeatures().get(2);
		createEReference(villa2Constr__MarkerEClass, VILLA2_CONSTR___MARKER__CONTEX_T__TR_G__CST);
		villa2Constr__Marker_cONTEXT__TRG__cstEReference = (EReference) villa2Constr__MarkerEClass.getEStructuralFeatures().get(3);
		createEReference(villa2Constr__MarkerEClass, VILLA2_CONSTR___MARKER__CREAT_E__TR_G__NCST);
		villa2Constr__Marker_cREATE__TRG__ncstEReference = (EReference) villa2Constr__MarkerEClass.getEStructuralFeatures().get(4);
		createEReference(villa2Constr__MarkerEClass, VILLA2_CONSTR___MARKER__CONTEX_T__TR_G__P);
		villa2Constr__Marker_cONTEXT__TRG__pEReference = (EReference) villa2Constr__MarkerEClass.getEStructuralFeatures().get(5);
		createEReference(villa2Constr__MarkerEClass, VILLA2_CONSTR___MARKER__CREAT_E__TR_G__SR);
		villa2Constr__Marker_cREATE__TRG__srEReference = (EReference) villa2Constr__MarkerEClass.getEStructuralFeatures().get(6);
		createEReference(villa2Constr__MarkerEClass, VILLA2_CONSTR___MARKER__CONTEX_T__COR_R__H2CST);
		villa2Constr__Marker_cONTEXT__CORR__h2cstEReference = (EReference) villa2Constr__MarkerEClass.getEStructuralFeatures().get(7);
		createEReference(villa2Constr__MarkerEClass, VILLA2_CONSTR___MARKER__CREAT_E__COR_R__NH2NCST);
		villa2Constr__Marker_cREATE__CORR__nh2ncstEReference = (EReference) villa2Constr__MarkerEClass.getEStructuralFeatures().get(8);
		
		villageSquare2PlanCollection__MarkerEClass = createEClass(VILLAGE_SQUARE2_PLAN_COLLECTION___MARKER);
		createEReference(villageSquare2PlanCollection__MarkerEClass, VILLAGE_SQUARE2_PLAN_COLLECTION___MARKER__CREAT_E__SR_C__VS);
		villageSquare2PlanCollection__Marker_cREATE__SRC__vsEReference = (EReference) villageSquare2PlanCollection__MarkerEClass.getEStructuralFeatures().get(0);
		createEReference(villageSquare2PlanCollection__MarkerEClass, VILLAGE_SQUARE2_PLAN_COLLECTION___MARKER__CREAT_E__TR_G__PC);
		villageSquare2PlanCollection__Marker_cREATE__TRG__pcEReference = (EReference) villageSquare2PlanCollection__MarkerEClass.getEStructuralFeatures().get(1);
		createEReference(villageSquare2PlanCollection__MarkerEClass, VILLAGE_SQUARE2_PLAN_COLLECTION___MARKER__CREAT_E__COR_R__VS2PL);
		villageSquare2PlanCollection__Marker_cREATE__CORR__vs2plEReference = (EReference) villageSquare2PlanCollection__MarkerEClass.getEStructuralFeatures().get(2);
		
		// Create enums
		
		// Create data types
	}

	public void initializePackageContents() {
		if (isInitialized)
			return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);
		
		// Obtain other dependent packages
		ConstructionPlanPackage theConstructionPlanPackagePackage = ConstructionPlanPackage.eINSTANCE;
		RuntimePackage theRuntimePackagePackage = RuntimePackage.eINSTANCE;
		VillagePackage theVillagePackagePackage = VillagePackage.eINSTANCE;

		// Create type parameters

		// Set bounds for type parameters

		// Add supertypes to classes
		villageSquare2PlanCollectionEClass.getESuperTypes().add(RuntimePackage.eINSTANCE.getCorrespondenceNode());
		house2ConstrEClass.getESuperTypes().add(RuntimePackage.eINSTANCE.getCorrespondenceNode());
		corner2Constr__MarkerEClass.getESuperTypes().add(RuntimePackage.eINSTANCE.getTGGRuleApplication());
		cube2Constr__MarkerEClass.getESuperTypes().add(RuntimePackage.eINSTANCE.getTGGRuleApplication());
		villa2Constr__MarkerEClass.getESuperTypes().add(RuntimePackage.eINSTANCE.getTGGRuleApplication());
		villageSquare2PlanCollection__MarkerEClass.getESuperTypes().add(RuntimePackage.eINSTANCE.getTGGRuleApplication());

		// Initialize classes, features, and operations; add parameters
		initEClass(villageSquare2PlanCollectionEClass, VillageSquare2PlanCollection.class, "VillageSquare2PlanCollection", !IS_ABSTRACT, !IS_INTERFACE,
			IS_GENERATED_INSTANCE_CLASS);
		initEReference(getVillageSquare2PlanCollection_Source(), VillagePackage.eINSTANCE.getVillageSquare(),  null, 
			"source", null, 0, 1, VillageSquare2PlanCollection.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getVillageSquare2PlanCollection_Target(), ConstructionPlanPackage.eINSTANCE.getPlanCollection(),  null, 
			"target", null, 0, 1, VillageSquare2PlanCollection.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
				
		initEClass(house2ConstrEClass, House2Constr.class, "House2Constr", !IS_ABSTRACT, !IS_INTERFACE,
			IS_GENERATED_INSTANCE_CLASS);
		initEReference(getHouse2Constr_Source(), VillagePackage.eINSTANCE.getHouse(),  null, 
			"source", null, 0, 1, House2Constr.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getHouse2Constr_Target(), ConstructionPlanPackage.eINSTANCE.getConstruction(),  null, 
			"target", null, 0, 1, House2Constr.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
				
		initEClass(corner2Constr__MarkerEClass, Corner2Constr__Marker.class, "Corner2Constr__Marker", !IS_ABSTRACT, !IS_INTERFACE,
			IS_GENERATED_INSTANCE_CLASS);
		initEReference(getCorner2Constr__Marker_CREATE__SRC__h(), VillagePackage.eINSTANCE.getHouse(),  null, 
			"CREATE__SRC__h", null, 1, 1, Corner2Constr__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCorner2Constr__Marker_CONTEXT__SRC__vs(), VillagePackage.eINSTANCE.getVillageSquare(),  null, 
			"CONTEXT__SRC__vs", null, 1, 1, Corner2Constr__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCorner2Constr__Marker_CREATE__TRG__bt(), ConstructionPlanPackage.eINSTANCE.getBasement(),  null, 
			"CREATE__TRG__bt", null, 1, 1, Corner2Constr__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCorner2Constr__Marker_CREATE__TRG__cst(), ConstructionPlanPackage.eINSTANCE.getConstruction(),  null, 
			"CREATE__TRG__cst", null, 1, 1, Corner2Constr__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCorner2Constr__Marker_CREATE__TRG__p(), ConstructionPlanPackage.eINSTANCE.getPlan(),  null, 
			"CREATE__TRG__p", null, 1, 1, Corner2Constr__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCorner2Constr__Marker_CONTEXT__TRG__pc(), ConstructionPlanPackage.eINSTANCE.getPlanCollection(),  null, 
			"CONTEXT__TRG__pc", null, 1, 1, Corner2Constr__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCorner2Constr__Marker_CREATE__CORR__h2cst(), this.getHouse2Constr(),  null, 
			"CREATE__CORR__h2cst", null, 1, 1, Corner2Constr__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCorner2Constr__Marker_CONTEXT__CORR__vs2pc(), this.getVillageSquare2PlanCollection(),  null, 
			"CONTEXT__CORR__vs2pc", null, 1, 1, Corner2Constr__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
				
		initEClass(cube2Constr__MarkerEClass, Cube2Constr__Marker.class, "Cube2Constr__Marker", !IS_ABSTRACT, !IS_INTERFACE,
			IS_GENERATED_INSTANCE_CLASS);
		initEReference(getCube2Constr__Marker_CONTEXT__SRC__h(), VillagePackage.eINSTANCE.getHouse(),  null, 
			"CONTEXT__SRC__h", null, 1, 1, Cube2Constr__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCube2Constr__Marker_CREATE__SRC__nh(), VillagePackage.eINSTANCE.getHouse(),  null, 
			"CREATE__SRC__nh", null, 1, 1, Cube2Constr__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCube2Constr__Marker_CREATE__TRG__bt(), ConstructionPlanPackage.eINSTANCE.getBasement(),  null, 
			"CREATE__TRG__bt", null, 1, 1, Cube2Constr__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCube2Constr__Marker_CREATE__TRG__cl(), ConstructionPlanPackage.eINSTANCE.getCellar(),  null, 
			"CREATE__TRG__cl", null, 1, 1, Cube2Constr__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCube2Constr__Marker_CONTEXT__TRG__cst(), ConstructionPlanPackage.eINSTANCE.getConstruction(),  null, 
			"CONTEXT__TRG__cst", null, 1, 1, Cube2Constr__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCube2Constr__Marker_CREATE__TRG__ncst(), ConstructionPlanPackage.eINSTANCE.getConstruction(),  null, 
			"CREATE__TRG__ncst", null, 1, 1, Cube2Constr__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCube2Constr__Marker_CONTEXT__TRG__p(), ConstructionPlanPackage.eINSTANCE.getPlan(),  null, 
			"CONTEXT__TRG__p", null, 1, 1, Cube2Constr__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCube2Constr__Marker_CONTEXT__CORR__h2cst(), this.getHouse2Constr(),  null, 
			"CONTEXT__CORR__h2cst", null, 1, 1, Cube2Constr__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCube2Constr__Marker_CREATE__CORR__nh2ncst(), this.getHouse2Constr(),  null, 
			"CREATE__CORR__nh2ncst", null, 1, 1, Cube2Constr__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
				
		initEClass(villa2Constr__MarkerEClass, Villa2Constr__Marker.class, "Villa2Constr__Marker", !IS_ABSTRACT, !IS_INTERFACE,
			IS_GENERATED_INSTANCE_CLASS);
		initEReference(getVilla2Constr__Marker_CONTEXT__SRC__h(), VillagePackage.eINSTANCE.getHouse(),  null, 
			"CONTEXT__SRC__h", null, 1, 1, Villa2Constr__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getVilla2Constr__Marker_CREATE__SRC__nh(), VillagePackage.eINSTANCE.getHouse(),  null, 
			"CREATE__SRC__nh", null, 1, 1, Villa2Constr__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getVilla2Constr__Marker_CREATE__TRG__bt(), ConstructionPlanPackage.eINSTANCE.getBasement(),  null, 
			"CREATE__TRG__bt", null, 1, 1, Villa2Constr__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getVilla2Constr__Marker_CONTEXT__TRG__cst(), ConstructionPlanPackage.eINSTANCE.getConstruction(),  null, 
			"CONTEXT__TRG__cst", null, 1, 1, Villa2Constr__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getVilla2Constr__Marker_CREATE__TRG__ncst(), ConstructionPlanPackage.eINSTANCE.getConstruction(),  null, 
			"CREATE__TRG__ncst", null, 1, 1, Villa2Constr__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getVilla2Constr__Marker_CONTEXT__TRG__p(), ConstructionPlanPackage.eINSTANCE.getPlan(),  null, 
			"CONTEXT__TRG__p", null, 1, 1, Villa2Constr__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getVilla2Constr__Marker_CREATE__TRG__sr(), ConstructionPlanPackage.eINSTANCE.getSaddleRoof(),  null, 
			"CREATE__TRG__sr", null, 1, 1, Villa2Constr__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getVilla2Constr__Marker_CONTEXT__CORR__h2cst(), this.getHouse2Constr(),  null, 
			"CONTEXT__CORR__h2cst", null, 1, 1, Villa2Constr__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getVilla2Constr__Marker_CREATE__CORR__nh2ncst(), this.getHouse2Constr(),  null, 
			"CREATE__CORR__nh2ncst", null, 1, 1, Villa2Constr__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
				
		initEClass(villageSquare2PlanCollection__MarkerEClass, VillageSquare2PlanCollection__Marker.class, "VillageSquare2PlanCollection__Marker", !IS_ABSTRACT, !IS_INTERFACE,
			IS_GENERATED_INSTANCE_CLASS);
		initEReference(getVillageSquare2PlanCollection__Marker_CREATE__SRC__vs(), VillagePackage.eINSTANCE.getVillageSquare(),  null, 
			"CREATE__SRC__vs", null, 1, 1, VillageSquare2PlanCollection__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getVillageSquare2PlanCollection__Marker_CREATE__TRG__pc(), ConstructionPlanPackage.eINSTANCE.getPlanCollection(),  null, 
			"CREATE__TRG__pc", null, 1, 1, VillageSquare2PlanCollection__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getVillageSquare2PlanCollection__Marker_CREATE__CORR__vs2pl(), this.getVillageSquare2PlanCollection(),  null, 
			"CREATE__CORR__vs2pl", null, 1, 1, VillageSquare2PlanCollection__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
				
		
		// Initialize enums and add enum literals
		
		// Initialize data types
		
		// Create resource
		createResource(eNS_URI);
	}

} 

