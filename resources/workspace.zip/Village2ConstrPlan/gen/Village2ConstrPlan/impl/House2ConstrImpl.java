package Village2ConstrPlan.impl;

import Village2ConstrPlan.Village2ConstrPlanPackage;
import runtime.RuntimePackage;
import Village2ConstrPlan.Village2ConstrPlanPackage;

import org.emoflon.smartemf.runtime.*;
import org.emoflon.smartemf.runtime.collections.*;
import org.emoflon.smartemf.persistence.SmartEMFResource;
import org.emoflon.smartemf.runtime.notification.SmartEMFNotification;
import org.emoflon.smartemf.runtime.notification.NotifyStatus;

import java.util.function.Consumer;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EcoreFactory;
import org.eclipse.emf.ecore.EcorePackage;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.resource.Resource;

public class House2ConstrImpl extends SmartObject implements Village2ConstrPlan.House2Constr {

    protected Village.House source = null;
    protected ConstructionPlan.Construction target = null;
	
	protected House2ConstrImpl() {
		super(Village2ConstrPlanPackage.Literals.HOUSE2_CONSTR);
	}
	
    
    @Override
    public Village.House getSource() {
    	return this.source;
    }
    
    @Override
    public void setSource(Village.House value) {
    	
    	Object oldValue = this.source;
    	
    	if(value == null && oldValue == null)
    		return;
    		
    	if(value != null && value.equals(oldValue))
    		return;
    		
    	
    	
    		        this.source = value;
    	
    	
    	        	sendNotification(SmartEMFNotification.createSetNotification(this, Village2ConstrPlanPackage.Literals.HOUSE2_CONSTR__SOURCE, oldValue, value, -1));
    	        	
    	        	if(Village2ConstrPlanPackage.Literals.HOUSE2_CONSTR__SOURCE.getEOpposite() != null) {
    	        		if(oldValue != null) {
    	        			((SmartObject) oldValue).eInverseRemove(this, Village2ConstrPlanPackage.Literals.HOUSE2_CONSTR__SOURCE.getEOpposite());
    	        		}
    	        		if(value != null) {
    	        		    ((SmartObject) value).eInverseAdd(this, Village2ConstrPlanPackage.Literals.HOUSE2_CONSTR__SOURCE.getEOpposite());
    	        		}
    	        	}
    }
    
    
    @Override
    public ConstructionPlan.Construction getTarget() {
    	return this.target;
    }
    
    @Override
    public void setTarget(ConstructionPlan.Construction value) {
    	
    	Object oldValue = this.target;
    	
    	if(value == null && oldValue == null)
    		return;
    		
    	if(value != null && value.equals(oldValue))
    		return;
    		
    	
    	
    		        this.target = value;
    	
    	
    	        	sendNotification(SmartEMFNotification.createSetNotification(this, Village2ConstrPlanPackage.Literals.HOUSE2_CONSTR__TARGET, oldValue, value, -1));
    	        	
    	        	if(Village2ConstrPlanPackage.Literals.HOUSE2_CONSTR__TARGET.getEOpposite() != null) {
    	        		if(oldValue != null) {
    	        			((SmartObject) oldValue).eInverseRemove(this, Village2ConstrPlanPackage.Literals.HOUSE2_CONSTR__TARGET.getEOpposite());
    	        		}
    	        		if(value != null) {
    	        		    ((SmartObject) value).eInverseAdd(this, Village2ConstrPlanPackage.Literals.HOUSE2_CONSTR__TARGET.getEOpposite());
    	        		}
    	        	}
    }
    

    @Override
    public void eSet(EStructuralFeature eFeature, Object newValue){
    	if (Village2ConstrPlanPackage.Literals.HOUSE2_CONSTR__SOURCE.equals(eFeature)) {
    		setSource((Village.House) newValue); 
    		return;
    	}
    	if (Village2ConstrPlanPackage.Literals.HOUSE2_CONSTR__TARGET.equals(eFeature)) {
    		setTarget((ConstructionPlan.Construction) newValue); 
    		return;
    	}
    	eDynamicSet(eFeature, newValue);
    }
    
    @Override
    public void eUnset(EStructuralFeature eFeature){
    	if (Village2ConstrPlanPackage.Literals.HOUSE2_CONSTR__SOURCE.equals(eFeature)) {
    		setSource((Village.House)null); 
    		return;
    	}
    	if (Village2ConstrPlanPackage.Literals.HOUSE2_CONSTR__TARGET.equals(eFeature)) {
    		setTarget((ConstructionPlan.Construction)null); 
    		return;
    	}
    	eDynamicUnset(eFeature);
    }

    @Override
    public String toString(){
		return super.toString();
    }

 	@Override
    public Object eGet(EStructuralFeature eFeature){
    	if (Village2ConstrPlanPackage.Literals.HOUSE2_CONSTR__SOURCE.equals(eFeature))
    		return getSource();
    	if (Village2ConstrPlanPackage.Literals.HOUSE2_CONSTR__TARGET.equals(eFeature))
    		return getTarget();
    	return eDynamicGet(eFeature);
    }

    @Override
    public Object eGet(int featureID, boolean resolve, boolean coreType){
    	throw new UnsupportedOperationException("This method has been deactivated since it is not always safe to use.");
    }
    
    @Override
    public void eInverseAdd(Object otherEnd, EStructuralFeature feature) {
	    if(feature == null)
	    	return;
	    	
    	eDynamicInverseAdd(otherEnd, feature);
	    	}
    	
    @Override
	    	public void eInverseRemove(Object otherEnd, EStructuralFeature feature) {
	    if(feature == null)
	    	return;
	    		    		
    	eDynamicInverseRemove(otherEnd, feature);
	    	}
    
    @Override
    /**
    * This method sets the resource and generates REMOVING_ADAPTER and ADD notifications
    */
    protected void setResourceOfContainments(Consumer<SmartObject> setResourceCall) {
	    	}
	    	
	    	@Override
	    	/**
	    	* This method sets the resource and only generates REMOVING_ADAPTER notifications (no ADD messages)
	    	*/
    protected void setResourceOfContainmentsSilently(Resource r) { 		
	    	}
}
