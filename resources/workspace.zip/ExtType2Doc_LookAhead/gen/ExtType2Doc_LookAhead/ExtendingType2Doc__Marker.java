package ExtType2Doc_LookAhead;

import runtime.RuntimePackage;
import ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage;

import org.emoflon.smartemf.runtime.notification.SmartEMFNotification;
import org.emoflon.smartemf.runtime.SmartObject;
import org.emoflon.smartemf.runtime.collections.*;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EStructuralFeature;

public interface ExtendingType2Doc__Marker extends EObject, runtime.TGGRuleApplication {
	
    public runtime.Protocol getProtocol();
    
    public void setProtocol(runtime.Protocol value);
    
    public ExtTypeModel.Type getCREATE__SRC__nt();
    
    public void setCREATE__SRC__nt(ExtTypeModel.Type value);
    
    public ExtTypeModel.Package getCONTEXT__SRC__p();
    
    public void setCONTEXT__SRC__p(ExtTypeModel.Package value);
    
    public ExtTypeModel.Type getCONTEXT__SRC__t();
    
    public void setCONTEXT__SRC__t(ExtTypeModel.Type value);
    
    public ExtDocModel.Doc getCONTEXT__TRG__d();
    
    public void setCONTEXT__TRG__d(ExtDocModel.Doc value);
    
    public ExtDocModel.Folder getCONTEXT__TRG__f();
    
    public void setCONTEXT__TRG__f(ExtDocModel.Folder value);
    
    public ExtDocModel.Doc getCREATE__TRG__nd();
    
    public void setCREATE__TRG__nd(ExtDocModel.Doc value);
    
    public ExtType2Doc_LookAhead.Type2Doc getCREATE__CORR__nt2nd();
    
    public void setCREATE__CORR__nt2nd(ExtType2Doc_LookAhead.Type2Doc value);
    
    public ExtType2Doc_LookAhead.Package2Folder getCONTEXT__CORR__p2f();
    
    public void setCONTEXT__CORR__p2f(ExtType2Doc_LookAhead.Package2Folder value);
    
    public ExtType2Doc_LookAhead.Type2Doc getCONTEXT__CORR__t2d();
    
    public void setCONTEXT__CORR__t2d(ExtType2Doc_LookAhead.Type2Doc value);
    

}
