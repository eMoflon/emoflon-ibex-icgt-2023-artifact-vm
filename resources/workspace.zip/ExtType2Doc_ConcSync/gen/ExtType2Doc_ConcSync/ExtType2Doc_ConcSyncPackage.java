package ExtType2Doc_ConcSync;

import java.lang.String;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.ecore.EEnum;


import org.emoflon.smartemf.runtime.SmartPackage;

public interface ExtType2Doc_ConcSyncPackage extends SmartPackage {

	String eNAME = "ExtType2Doc_ConcSync";
	String eNS_URI = "platform:/resource/ExtType2Doc_ConcSync/model/ExtType2Doc_ConcSync.ecore";
	String eNS_PREFIX = "ExtType2Doc_ConcSync";

	ExtType2Doc_ConcSyncPackage eINSTANCE = ExtType2Doc_ConcSync.impl.ExtType2Doc_ConcSyncPackageImpl.init();

	int PROJECT2_DOC_CONTAINER = 0;
	int PROJECT2_DOC_CONTAINER__SOURCE = 0;
	int PROJECT2_DOC_CONTAINER__TARGET = 1;
	int PROJECT2_DOC_CONTAINER_FEATURE_COUNT = 2;
	int PROJECT2_DOC_CONTAINER_OPERATION_COUNT = 0;
	
	int PACKAGE2_FOLDER = 1;
	int PACKAGE2_FOLDER__SOURCE = 2;
	int PACKAGE2_FOLDER__TARGET = 3;
	int PACKAGE2_FOLDER_FEATURE_COUNT = 2;
	int PACKAGE2_FOLDER_OPERATION_COUNT = 0;
	
	int TYPE2_DOC = 2;
	int TYPE2_DOC__SOURCE = 4;
	int TYPE2_DOC__TARGET = 5;
	int TYPE2_DOC_FEATURE_COUNT = 2;
	int TYPE2_DOC_OPERATION_COUNT = 0;
	
	int METHOD2_ENTRY = 3;
	int METHOD2_ENTRY__SOURCE = 6;
	int METHOD2_ENTRY__TARGET = 7;
	int METHOD2_ENTRY_FEATURE_COUNT = 2;
	int METHOD2_ENTRY_OPERATION_COUNT = 0;
	
	int PARAM2_ENTRY = 4;
	int PARAM2_ENTRY__SOURCE = 8;
	int PARAM2_ENTRY__TARGET = 9;
	int PARAM2_ENTRY_FEATURE_COUNT = 2;
	int PARAM2_ENTRY_OPERATION_COUNT = 0;
	
	int FIELD2_ENTRY = 5;
	int FIELD2_ENTRY__SOURCE = 10;
	int FIELD2_ENTRY__TARGET = 11;
	int FIELD2_ENTRY_FEATURE_COUNT = 2;
	int FIELD2_ENTRY_OPERATION_COUNT = 0;
	
	int J_DOC2_ANNOTATION = 6;
	int J_DOC2_ANNOTATION__SOURCE = 12;
	int J_DOC2_ANNOTATION__TARGET = 13;
	int J_DOC2_ANNOTATION_FEATURE_COUNT = 2;
	int J_DOC2_ANNOTATION_OPERATION_COUNT = 0;
	
	int EXTENDING_TYPE2_DOC___MARKER = 7;
	int EXTENDING_TYPE2_DOC___MARKER__CREAT_E__SR_C__NT = 14;
	int EXTENDING_TYPE2_DOC___MARKER__CONTEX_T__SR_C__P = 15;
	int EXTENDING_TYPE2_DOC___MARKER__CONTEX_T__SR_C__T = 16;
	int EXTENDING_TYPE2_DOC___MARKER__CONTEX_T__TR_G__D = 17;
	int EXTENDING_TYPE2_DOC___MARKER__CONTEX_T__TR_G__F = 18;
	int EXTENDING_TYPE2_DOC___MARKER__CREAT_E__TR_G__ND = 19;
	int EXTENDING_TYPE2_DOC___MARKER__CREAT_E__COR_R__NT2ND = 20;
	int EXTENDING_TYPE2_DOC___MARKER__CONTEX_T__COR_R__P2F = 21;
	int EXTENDING_TYPE2_DOC___MARKER__CONTEX_T__COR_R__T2D = 22;
	int EXTENDING_TYPE2_DOC___MARKER_FEATURE_COUNT = 10;
	int EXTENDING_TYPE2_DOC___MARKER_OPERATION_COUNT = 0;
	
	int FIELD2_ENTRY___MARKER = 8;
	int FIELD2_ENTRY___MARKER__CREAT_E__SR_C__F = 23;
	int FIELD2_ENTRY___MARKER__CONTEX_T__SR_C__T = 24;
	int FIELD2_ENTRY___MARKER__CONTEX_T__TR_G__D = 25;
	int FIELD2_ENTRY___MARKER__CREAT_E__TR_G__E = 26;
	int FIELD2_ENTRY___MARKER__CREAT_E__COR_R__F2E = 27;
	int FIELD2_ENTRY___MARKER__CONTEX_T__COR_R__T2D = 28;
	int FIELD2_ENTRY___MARKER_FEATURE_COUNT = 7;
	int FIELD2_ENTRY___MARKER_OPERATION_COUNT = 0;
	
	int GLOSSARY___MARKER = 9;
	int GLOSSARY___MARKER__CONTEX_T__TR_G__DC = 29;
	int GLOSSARY___MARKER__CREAT_E__TR_G__G = 30;
	int GLOSSARY___MARKER_FEATURE_COUNT = 3;
	int GLOSSARY___MARKER_OPERATION_COUNT = 0;
	
	int GLOSSARY_ENTRY___MARKER = 10;
	int GLOSSARY_ENTRY___MARKER__CONTEX_T__TR_G__G = 31;
	int GLOSSARY_ENTRY___MARKER__CREAT_E__TR_G__GE = 32;
	int GLOSSARY_ENTRY___MARKER_FEATURE_COUNT = 3;
	int GLOSSARY_ENTRY___MARKER_OPERATION_COUNT = 0;
	
	int GLOSSARY_LINK___MARKER = 11;
	int GLOSSARY_LINK___MARKER__CONTEX_T__TR_G__E = 33;
	int GLOSSARY_LINK___MARKER__CONTEX_T__TR_G__GE = 34;
	int GLOSSARY_LINK___MARKER_FEATURE_COUNT = 3;
	int GLOSSARY_LINK___MARKER_OPERATION_COUNT = 0;
	
	int J_DOC2_ANNOTATION___MARKER = 12;
	int J_DOC2_ANNOTATION___MARKER__CREAT_E__SR_C__J = 35;
	int J_DOC2_ANNOTATION___MARKER__CONTEX_T__SR_C__M = 36;
	int J_DOC2_ANNOTATION___MARKER__CREAT_E__TR_G__A = 37;
	int J_DOC2_ANNOTATION___MARKER__CONTEX_T__TR_G__E = 38;
	int J_DOC2_ANNOTATION___MARKER__CREAT_E__COR_R__J2A = 39;
	int J_DOC2_ANNOTATION___MARKER__CONTEX_T__COR_R__M2E = 40;
	int J_DOC2_ANNOTATION___MARKER_FEATURE_COUNT = 7;
	int J_DOC2_ANNOTATION___MARKER_OPERATION_COUNT = 0;
	
	int METHOD2_ENTRY___MARKER = 13;
	int METHOD2_ENTRY___MARKER__CREAT_E__SR_C__M = 41;
	int METHOD2_ENTRY___MARKER__CONTEX_T__SR_C__T = 42;
	int METHOD2_ENTRY___MARKER__CONTEX_T__TR_G__D = 43;
	int METHOD2_ENTRY___MARKER__CREAT_E__TR_G__E = 44;
	int METHOD2_ENTRY___MARKER__CREAT_E__COR_R__M2E = 45;
	int METHOD2_ENTRY___MARKER__CONTEX_T__COR_R__T2D = 46;
	int METHOD2_ENTRY___MARKER_FEATURE_COUNT = 7;
	int METHOD2_ENTRY___MARKER_OPERATION_COUNT = 0;
	
	int PACKAGE2_FOLDER___MARKER = 14;
	int PACKAGE2_FOLDER___MARKER__CREAT_E__SR_C__P = 47;
	int PACKAGE2_FOLDER___MARKER__CONTEX_T__SR_C__PR = 48;
	int PACKAGE2_FOLDER___MARKER__CONTEX_T__TR_G__DC = 49;
	int PACKAGE2_FOLDER___MARKER__CREAT_E__TR_G__F = 50;
	int PACKAGE2_FOLDER___MARKER__CREAT_E__COR_R__P2F = 51;
	int PACKAGE2_FOLDER___MARKER__CONTEX_T__COR_R__PR2DC = 52;
	int PACKAGE2_FOLDER___MARKER_FEATURE_COUNT = 7;
	int PACKAGE2_FOLDER___MARKER_OPERATION_COUNT = 0;
	
	int PARAM2_ENTRY___MARKER = 15;
	int PARAM2_ENTRY___MARKER__CONTEX_T__SR_C__M = 53;
	int PARAM2_ENTRY___MARKER__CREAT_E__SR_C__P = 54;
	int PARAM2_ENTRY___MARKER__CONTEX_T__TR_G__E = 55;
	int PARAM2_ENTRY___MARKER__CONTEX_T__COR_R__M2E = 56;
	int PARAM2_ENTRY___MARKER__CREAT_E__COR_R__P2E = 57;
	int PARAM2_ENTRY___MARKER_FEATURE_COUNT = 6;
	int PARAM2_ENTRY___MARKER_OPERATION_COUNT = 0;
	
	int PROJECT2_DOC_CONT___MARKER = 16;
	int PROJECT2_DOC_CONT___MARKER__CREAT_E__SR_C__PR = 58;
	int PROJECT2_DOC_CONT___MARKER__CREAT_E__TR_G__DC = 59;
	int PROJECT2_DOC_CONT___MARKER__CREAT_E__COR_R__PR2DC = 60;
	int PROJECT2_DOC_CONT___MARKER_FEATURE_COUNT = 4;
	int PROJECT2_DOC_CONT___MARKER_OPERATION_COUNT = 0;
	
	int TYPE2_DOC___MARKER = 17;
	int TYPE2_DOC___MARKER__CONTEX_T__SR_C__P = 61;
	int TYPE2_DOC___MARKER__CREAT_E__SR_C__T = 62;
	int TYPE2_DOC___MARKER__CREAT_E__TR_G__D = 63;
	int TYPE2_DOC___MARKER__CONTEX_T__TR_G__F = 64;
	int TYPE2_DOC___MARKER__CONTEX_T__COR_R__P2F = 65;
	int TYPE2_DOC___MARKER__CREAT_E__COR_R__T2D = 66;
	int TYPE2_DOC___MARKER_FEATURE_COUNT = 7;
	int TYPE2_DOC___MARKER_OPERATION_COUNT = 0;
	
	

	EClass getProject2DocContainer();
	EReference getProject2DocContainer_Source();
	EReference getProject2DocContainer_Target();
	
	EClass getPackage2Folder();
	EReference getPackage2Folder_Source();
	EReference getPackage2Folder_Target();
	
	EClass getType2Doc();
	EReference getType2Doc_Source();
	EReference getType2Doc_Target();
	
	EClass getMethod2Entry();
	EReference getMethod2Entry_Source();
	EReference getMethod2Entry_Target();
	
	EClass getParam2Entry();
	EReference getParam2Entry_Source();
	EReference getParam2Entry_Target();
	
	EClass getField2Entry();
	EReference getField2Entry_Source();
	EReference getField2Entry_Target();
	
	EClass getJDoc2Annotation();
	EReference getJDoc2Annotation_Source();
	EReference getJDoc2Annotation_Target();
	
	EClass getExtendingType2Doc__Marker();
	EReference getExtendingType2Doc__Marker_CREATE__SRC__nt();
	EReference getExtendingType2Doc__Marker_CONTEXT__SRC__p();
	EReference getExtendingType2Doc__Marker_CONTEXT__SRC__t();
	EReference getExtendingType2Doc__Marker_CONTEXT__TRG__d();
	EReference getExtendingType2Doc__Marker_CONTEXT__TRG__f();
	EReference getExtendingType2Doc__Marker_CREATE__TRG__nd();
	EReference getExtendingType2Doc__Marker_CREATE__CORR__nt2nd();
	EReference getExtendingType2Doc__Marker_CONTEXT__CORR__p2f();
	EReference getExtendingType2Doc__Marker_CONTEXT__CORR__t2d();
	
	EClass getField2Entry__Marker();
	EReference getField2Entry__Marker_CREATE__SRC__f();
	EReference getField2Entry__Marker_CONTEXT__SRC__t();
	EReference getField2Entry__Marker_CONTEXT__TRG__d();
	EReference getField2Entry__Marker_CREATE__TRG__e();
	EReference getField2Entry__Marker_CREATE__CORR__f2e();
	EReference getField2Entry__Marker_CONTEXT__CORR__t2d();
	
	EClass getGlossary__Marker();
	EReference getGlossary__Marker_CONTEXT__TRG__dc();
	EReference getGlossary__Marker_CREATE__TRG__g();
	
	EClass getGlossaryEntry__Marker();
	EReference getGlossaryEntry__Marker_CONTEXT__TRG__g();
	EReference getGlossaryEntry__Marker_CREATE__TRG__ge();
	
	EClass getGlossaryLink__Marker();
	EReference getGlossaryLink__Marker_CONTEXT__TRG__e();
	EReference getGlossaryLink__Marker_CONTEXT__TRG__ge();
	
	EClass getJDoc2Annotation__Marker();
	EReference getJDoc2Annotation__Marker_CREATE__SRC__j();
	EReference getJDoc2Annotation__Marker_CONTEXT__SRC__m();
	EReference getJDoc2Annotation__Marker_CREATE__TRG__a();
	EReference getJDoc2Annotation__Marker_CONTEXT__TRG__e();
	EReference getJDoc2Annotation__Marker_CREATE__CORR__j2a();
	EReference getJDoc2Annotation__Marker_CONTEXT__CORR__m2e();
	
	EClass getMethod2Entry__Marker();
	EReference getMethod2Entry__Marker_CREATE__SRC__m();
	EReference getMethod2Entry__Marker_CONTEXT__SRC__t();
	EReference getMethod2Entry__Marker_CONTEXT__TRG__d();
	EReference getMethod2Entry__Marker_CREATE__TRG__e();
	EReference getMethod2Entry__Marker_CREATE__CORR__m2e();
	EReference getMethod2Entry__Marker_CONTEXT__CORR__t2d();
	
	EClass getPackage2Folder__Marker();
	EReference getPackage2Folder__Marker_CREATE__SRC__p();
	EReference getPackage2Folder__Marker_CONTEXT__SRC__pr();
	EReference getPackage2Folder__Marker_CONTEXT__TRG__dc();
	EReference getPackage2Folder__Marker_CREATE__TRG__f();
	EReference getPackage2Folder__Marker_CREATE__CORR__p2f();
	EReference getPackage2Folder__Marker_CONTEXT__CORR__pr2dc();
	
	EClass getParam2Entry__Marker();
	EReference getParam2Entry__Marker_CONTEXT__SRC__m();
	EReference getParam2Entry__Marker_CREATE__SRC__p();
	EReference getParam2Entry__Marker_CONTEXT__TRG__e();
	EReference getParam2Entry__Marker_CONTEXT__CORR__m2e();
	EReference getParam2Entry__Marker_CREATE__CORR__p2e();
	
	EClass getProject2DocCont__Marker();
	EReference getProject2DocCont__Marker_CREATE__SRC__pr();
	EReference getProject2DocCont__Marker_CREATE__TRG__dc();
	EReference getProject2DocCont__Marker_CREATE__CORR__pr2dc();
	
	EClass getType2Doc__Marker();
	EReference getType2Doc__Marker_CONTEXT__SRC__p();
	EReference getType2Doc__Marker_CREATE__SRC__t();
	EReference getType2Doc__Marker_CREATE__TRG__d();
	EReference getType2Doc__Marker_CONTEXT__TRG__f();
	EReference getType2Doc__Marker_CONTEXT__CORR__p2f();
	EReference getType2Doc__Marker_CREATE__CORR__t2d();
	
	
	ExtType2Doc_ConcSync.ExtType2Doc_ConcSyncFactory getExtType2Doc_ConcSyncFactory();

	interface Literals {
		
		EClass PROJECT2_DOC_CONTAINER = eINSTANCE.getProject2DocContainer();
		
		EReference PROJECT2_DOC_CONTAINER__SOURCE = eINSTANCE.getProject2DocContainer_Source();
		
		EReference PROJECT2_DOC_CONTAINER__TARGET = eINSTANCE.getProject2DocContainer_Target();
		
		EClass PACKAGE2_FOLDER = eINSTANCE.getPackage2Folder();
		
		EReference PACKAGE2_FOLDER__SOURCE = eINSTANCE.getPackage2Folder_Source();
		
		EReference PACKAGE2_FOLDER__TARGET = eINSTANCE.getPackage2Folder_Target();
		
		EClass TYPE2_DOC = eINSTANCE.getType2Doc();
		
		EReference TYPE2_DOC__SOURCE = eINSTANCE.getType2Doc_Source();
		
		EReference TYPE2_DOC__TARGET = eINSTANCE.getType2Doc_Target();
		
		EClass METHOD2_ENTRY = eINSTANCE.getMethod2Entry();
		
		EReference METHOD2_ENTRY__SOURCE = eINSTANCE.getMethod2Entry_Source();
		
		EReference METHOD2_ENTRY__TARGET = eINSTANCE.getMethod2Entry_Target();
		
		EClass PARAM2_ENTRY = eINSTANCE.getParam2Entry();
		
		EReference PARAM2_ENTRY__SOURCE = eINSTANCE.getParam2Entry_Source();
		
		EReference PARAM2_ENTRY__TARGET = eINSTANCE.getParam2Entry_Target();
		
		EClass FIELD2_ENTRY = eINSTANCE.getField2Entry();
		
		EReference FIELD2_ENTRY__SOURCE = eINSTANCE.getField2Entry_Source();
		
		EReference FIELD2_ENTRY__TARGET = eINSTANCE.getField2Entry_Target();
		
		EClass J_DOC2_ANNOTATION = eINSTANCE.getJDoc2Annotation();
		
		EReference J_DOC2_ANNOTATION__SOURCE = eINSTANCE.getJDoc2Annotation_Source();
		
		EReference J_DOC2_ANNOTATION__TARGET = eINSTANCE.getJDoc2Annotation_Target();
		
		EClass EXTENDING_TYPE2_DOC___MARKER = eINSTANCE.getExtendingType2Doc__Marker();
		
		EReference EXTENDING_TYPE2_DOC___MARKER__CREAT_E__SR_C__NT = eINSTANCE.getExtendingType2Doc__Marker_CREATE__SRC__nt();
		
		EReference EXTENDING_TYPE2_DOC___MARKER__CONTEX_T__SR_C__P = eINSTANCE.getExtendingType2Doc__Marker_CONTEXT__SRC__p();
		
		EReference EXTENDING_TYPE2_DOC___MARKER__CONTEX_T__SR_C__T = eINSTANCE.getExtendingType2Doc__Marker_CONTEXT__SRC__t();
		
		EReference EXTENDING_TYPE2_DOC___MARKER__CONTEX_T__TR_G__D = eINSTANCE.getExtendingType2Doc__Marker_CONTEXT__TRG__d();
		
		EReference EXTENDING_TYPE2_DOC___MARKER__CONTEX_T__TR_G__F = eINSTANCE.getExtendingType2Doc__Marker_CONTEXT__TRG__f();
		
		EReference EXTENDING_TYPE2_DOC___MARKER__CREAT_E__TR_G__ND = eINSTANCE.getExtendingType2Doc__Marker_CREATE__TRG__nd();
		
		EReference EXTENDING_TYPE2_DOC___MARKER__CREAT_E__COR_R__NT2ND = eINSTANCE.getExtendingType2Doc__Marker_CREATE__CORR__nt2nd();
		
		EReference EXTENDING_TYPE2_DOC___MARKER__CONTEX_T__COR_R__P2F = eINSTANCE.getExtendingType2Doc__Marker_CONTEXT__CORR__p2f();
		
		EReference EXTENDING_TYPE2_DOC___MARKER__CONTEX_T__COR_R__T2D = eINSTANCE.getExtendingType2Doc__Marker_CONTEXT__CORR__t2d();
		
		EClass FIELD2_ENTRY___MARKER = eINSTANCE.getField2Entry__Marker();
		
		EReference FIELD2_ENTRY___MARKER__CREAT_E__SR_C__F = eINSTANCE.getField2Entry__Marker_CREATE__SRC__f();
		
		EReference FIELD2_ENTRY___MARKER__CONTEX_T__SR_C__T = eINSTANCE.getField2Entry__Marker_CONTEXT__SRC__t();
		
		EReference FIELD2_ENTRY___MARKER__CONTEX_T__TR_G__D = eINSTANCE.getField2Entry__Marker_CONTEXT__TRG__d();
		
		EReference FIELD2_ENTRY___MARKER__CREAT_E__TR_G__E = eINSTANCE.getField2Entry__Marker_CREATE__TRG__e();
		
		EReference FIELD2_ENTRY___MARKER__CREAT_E__COR_R__F2E = eINSTANCE.getField2Entry__Marker_CREATE__CORR__f2e();
		
		EReference FIELD2_ENTRY___MARKER__CONTEX_T__COR_R__T2D = eINSTANCE.getField2Entry__Marker_CONTEXT__CORR__t2d();
		
		EClass GLOSSARY___MARKER = eINSTANCE.getGlossary__Marker();
		
		EReference GLOSSARY___MARKER__CONTEX_T__TR_G__DC = eINSTANCE.getGlossary__Marker_CONTEXT__TRG__dc();
		
		EReference GLOSSARY___MARKER__CREAT_E__TR_G__G = eINSTANCE.getGlossary__Marker_CREATE__TRG__g();
		
		EClass GLOSSARY_ENTRY___MARKER = eINSTANCE.getGlossaryEntry__Marker();
		
		EReference GLOSSARY_ENTRY___MARKER__CONTEX_T__TR_G__G = eINSTANCE.getGlossaryEntry__Marker_CONTEXT__TRG__g();
		
		EReference GLOSSARY_ENTRY___MARKER__CREAT_E__TR_G__GE = eINSTANCE.getGlossaryEntry__Marker_CREATE__TRG__ge();
		
		EClass GLOSSARY_LINK___MARKER = eINSTANCE.getGlossaryLink__Marker();
		
		EReference GLOSSARY_LINK___MARKER__CONTEX_T__TR_G__E = eINSTANCE.getGlossaryLink__Marker_CONTEXT__TRG__e();
		
		EReference GLOSSARY_LINK___MARKER__CONTEX_T__TR_G__GE = eINSTANCE.getGlossaryLink__Marker_CONTEXT__TRG__ge();
		
		EClass J_DOC2_ANNOTATION___MARKER = eINSTANCE.getJDoc2Annotation__Marker();
		
		EReference J_DOC2_ANNOTATION___MARKER__CREAT_E__SR_C__J = eINSTANCE.getJDoc2Annotation__Marker_CREATE__SRC__j();
		
		EReference J_DOC2_ANNOTATION___MARKER__CONTEX_T__SR_C__M = eINSTANCE.getJDoc2Annotation__Marker_CONTEXT__SRC__m();
		
		EReference J_DOC2_ANNOTATION___MARKER__CREAT_E__TR_G__A = eINSTANCE.getJDoc2Annotation__Marker_CREATE__TRG__a();
		
		EReference J_DOC2_ANNOTATION___MARKER__CONTEX_T__TR_G__E = eINSTANCE.getJDoc2Annotation__Marker_CONTEXT__TRG__e();
		
		EReference J_DOC2_ANNOTATION___MARKER__CREAT_E__COR_R__J2A = eINSTANCE.getJDoc2Annotation__Marker_CREATE__CORR__j2a();
		
		EReference J_DOC2_ANNOTATION___MARKER__CONTEX_T__COR_R__M2E = eINSTANCE.getJDoc2Annotation__Marker_CONTEXT__CORR__m2e();
		
		EClass METHOD2_ENTRY___MARKER = eINSTANCE.getMethod2Entry__Marker();
		
		EReference METHOD2_ENTRY___MARKER__CREAT_E__SR_C__M = eINSTANCE.getMethod2Entry__Marker_CREATE__SRC__m();
		
		EReference METHOD2_ENTRY___MARKER__CONTEX_T__SR_C__T = eINSTANCE.getMethod2Entry__Marker_CONTEXT__SRC__t();
		
		EReference METHOD2_ENTRY___MARKER__CONTEX_T__TR_G__D = eINSTANCE.getMethod2Entry__Marker_CONTEXT__TRG__d();
		
		EReference METHOD2_ENTRY___MARKER__CREAT_E__TR_G__E = eINSTANCE.getMethod2Entry__Marker_CREATE__TRG__e();
		
		EReference METHOD2_ENTRY___MARKER__CREAT_E__COR_R__M2E = eINSTANCE.getMethod2Entry__Marker_CREATE__CORR__m2e();
		
		EReference METHOD2_ENTRY___MARKER__CONTEX_T__COR_R__T2D = eINSTANCE.getMethod2Entry__Marker_CONTEXT__CORR__t2d();
		
		EClass PACKAGE2_FOLDER___MARKER = eINSTANCE.getPackage2Folder__Marker();
		
		EReference PACKAGE2_FOLDER___MARKER__CREAT_E__SR_C__P = eINSTANCE.getPackage2Folder__Marker_CREATE__SRC__p();
		
		EReference PACKAGE2_FOLDER___MARKER__CONTEX_T__SR_C__PR = eINSTANCE.getPackage2Folder__Marker_CONTEXT__SRC__pr();
		
		EReference PACKAGE2_FOLDER___MARKER__CONTEX_T__TR_G__DC = eINSTANCE.getPackage2Folder__Marker_CONTEXT__TRG__dc();
		
		EReference PACKAGE2_FOLDER___MARKER__CREAT_E__TR_G__F = eINSTANCE.getPackage2Folder__Marker_CREATE__TRG__f();
		
		EReference PACKAGE2_FOLDER___MARKER__CREAT_E__COR_R__P2F = eINSTANCE.getPackage2Folder__Marker_CREATE__CORR__p2f();
		
		EReference PACKAGE2_FOLDER___MARKER__CONTEX_T__COR_R__PR2DC = eINSTANCE.getPackage2Folder__Marker_CONTEXT__CORR__pr2dc();
		
		EClass PARAM2_ENTRY___MARKER = eINSTANCE.getParam2Entry__Marker();
		
		EReference PARAM2_ENTRY___MARKER__CONTEX_T__SR_C__M = eINSTANCE.getParam2Entry__Marker_CONTEXT__SRC__m();
		
		EReference PARAM2_ENTRY___MARKER__CREAT_E__SR_C__P = eINSTANCE.getParam2Entry__Marker_CREATE__SRC__p();
		
		EReference PARAM2_ENTRY___MARKER__CONTEX_T__TR_G__E = eINSTANCE.getParam2Entry__Marker_CONTEXT__TRG__e();
		
		EReference PARAM2_ENTRY___MARKER__CONTEX_T__COR_R__M2E = eINSTANCE.getParam2Entry__Marker_CONTEXT__CORR__m2e();
		
		EReference PARAM2_ENTRY___MARKER__CREAT_E__COR_R__P2E = eINSTANCE.getParam2Entry__Marker_CREATE__CORR__p2e();
		
		EClass PROJECT2_DOC_CONT___MARKER = eINSTANCE.getProject2DocCont__Marker();
		
		EReference PROJECT2_DOC_CONT___MARKER__CREAT_E__SR_C__PR = eINSTANCE.getProject2DocCont__Marker_CREATE__SRC__pr();
		
		EReference PROJECT2_DOC_CONT___MARKER__CREAT_E__TR_G__DC = eINSTANCE.getProject2DocCont__Marker_CREATE__TRG__dc();
		
		EReference PROJECT2_DOC_CONT___MARKER__CREAT_E__COR_R__PR2DC = eINSTANCE.getProject2DocCont__Marker_CREATE__CORR__pr2dc();
		
		EClass TYPE2_DOC___MARKER = eINSTANCE.getType2Doc__Marker();
		
		EReference TYPE2_DOC___MARKER__CONTEX_T__SR_C__P = eINSTANCE.getType2Doc__Marker_CONTEXT__SRC__p();
		
		EReference TYPE2_DOC___MARKER__CREAT_E__SR_C__T = eINSTANCE.getType2Doc__Marker_CREATE__SRC__t();
		
		EReference TYPE2_DOC___MARKER__CREAT_E__TR_G__D = eINSTANCE.getType2Doc__Marker_CREATE__TRG__d();
		
		EReference TYPE2_DOC___MARKER__CONTEX_T__TR_G__F = eINSTANCE.getType2Doc__Marker_CONTEXT__TRG__f();
		
		EReference TYPE2_DOC___MARKER__CONTEX_T__COR_R__P2F = eINSTANCE.getType2Doc__Marker_CONTEXT__CORR__p2f();
		
		EReference TYPE2_DOC___MARKER__CREAT_E__COR_R__T2D = eINSTANCE.getType2Doc__Marker_CREATE__CORR__t2d();
		
		
		
		
	}

} 
