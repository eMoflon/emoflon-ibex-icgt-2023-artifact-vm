package ExtType2Doc_LookAhead.modelgen.hipe.engine.actor.junction;

import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import java.util.Set;

import akka.actor.AbstractActor;
import akka.actor.ActorRef;

import hipe.engine.actor.Port;
import hipe.engine.util.HiPESet;
import hipe.engine.match.EdgeMatch;
import hipe.engine.match.HMatch;
import hipe.engine.actor.junction.PortJunction;
import hipe.engine.actor.junction.PortJunctionLeft;
import hipe.engine.actor.junction.PortJunctionRight;
import hipe.engine.message.input.AttributeChanged;
import hipe.engine.util.HiPEMultiUtil;

import hipe.generic.match.GenericJunctionMatch;
import hipe.generic.actor.junction.GenericJunctionActor;

import hipe.network.JunctionNode;

public class ImplementingType2Doc__GEN_12_junction extends GenericJunctionActor{
	
	@Override
	protected void initializePorts(Map<String, ActorRef> name2actor, JunctionNode node) {
		constraints.add(this::check_constraint_3);
		
		ports = new LinkedList<>();
		ports.add(new PortJunction(node.getPorts().getPort().get(0), getSelf(), name2actor.get("ImplementingType2Doc__GEN_production"), this::returnTrue , 0  , false ));
	}
	
	@Override
	protected void registerMatchForAttributeChanges(HMatch match) {
	}
	
	@Override
	protected void deregisterMatchForAttributeChanges(Set<HMatch> matches, HMatch match) {
	}
	
	@Override
	protected void changeAttribute(AttributeChanged<HMatch> message) {
		for(Port<?> port : ports) {
			message.initialMessage.increment();
			port.forwardMessage(message);
		}
		
		message.initialMessage.decrement();
	}
	
	public boolean check_constraint_3(HMatch match, int index) {
		ExtDocModel.Doc id = (ExtDocModel.Doc) match.getNodes()[2];
		ExtTypeModel.Type t = (ExtTypeModel.Type) match.getNodes()[4];
		ExtType2Doc_LookAhead.Type2Doc t2d = (ExtType2Doc_LookAhead.Type2Doc) match.getNodes()[3];
		ExtTypeModel.Type it = (ExtTypeModel.Type) match.getNodes()[1];
		ExtType2Doc_LookAhead.Type2Doc it2id = (ExtType2Doc_LookAhead.Type2Doc) match.getNodes()[0];
		ExtDocModel.Doc d = (ExtDocModel.Doc) match.getNodes()[5];
		boolean predicate = !it.equals(t) && !d.equals(id) && !it2id.equals(t2d);
		match.setConstraintSatisfied(index, predicate);
		return predicate;
	}
	
}

