package ExtType2Doc_LookAhead;

import runtime.RuntimePackage;
import ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage;

import org.emoflon.smartemf.runtime.notification.SmartEMFNotification;
import org.emoflon.smartemf.runtime.SmartObject;
import org.emoflon.smartemf.runtime.collections.*;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EStructuralFeature;

public interface Field2Entry__Marker extends EObject, runtime.TGGRuleApplication {
	
    public runtime.Protocol getProtocol();
    
    public void setProtocol(runtime.Protocol value);
    
    public ExtTypeModel.Field getCREATE__SRC__f();
    
    public void setCREATE__SRC__f(ExtTypeModel.Field value);
    
    public ExtTypeModel.Type getCONTEXT__SRC__t();
    
    public void setCONTEXT__SRC__t(ExtTypeModel.Type value);
    
    public ExtDocModel.Doc getCONTEXT__TRG__d();
    
    public void setCONTEXT__TRG__d(ExtDocModel.Doc value);
    
    public ExtDocModel.Entry getCREATE__TRG__e();
    
    public void setCREATE__TRG__e(ExtDocModel.Entry value);
    
    public ExtType2Doc_LookAhead.Field2Entry getCREATE__CORR__f2e();
    
    public void setCREATE__CORR__f2e(ExtType2Doc_LookAhead.Field2Entry value);
    
    public ExtType2Doc_LookAhead.Type2Doc getCONTEXT__CORR__t2d();
    
    public void setCONTEXT__CORR__t2d(ExtType2Doc_LookAhead.Type2Doc value);
    

}
