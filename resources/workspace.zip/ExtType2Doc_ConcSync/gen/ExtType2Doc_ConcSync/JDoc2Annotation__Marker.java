package ExtType2Doc_ConcSync;

import runtime.RuntimePackage;
import ExtType2Doc_ConcSync.ExtType2Doc_ConcSyncPackage;

import org.emoflon.smartemf.runtime.notification.SmartEMFNotification;
import org.emoflon.smartemf.runtime.SmartObject;
import org.emoflon.smartemf.runtime.collections.*;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EStructuralFeature;

public interface JDoc2Annotation__Marker extends EObject, runtime.TGGRuleApplication {
	
    public runtime.Protocol getProtocol();
    
    public void setProtocol(runtime.Protocol value);
    
    public ExtTypeModel.JavaDoc getCREATE__SRC__j();
    
    public void setCREATE__SRC__j(ExtTypeModel.JavaDoc value);
    
    public ExtTypeModel.Method getCONTEXT__SRC__m();
    
    public void setCONTEXT__SRC__m(ExtTypeModel.Method value);
    
    public ExtDocModel.Annotation getCREATE__TRG__a();
    
    public void setCREATE__TRG__a(ExtDocModel.Annotation value);
    
    public ExtDocModel.Entry getCONTEXT__TRG__e();
    
    public void setCONTEXT__TRG__e(ExtDocModel.Entry value);
    
    public ExtType2Doc_ConcSync.JDoc2Annotation getCREATE__CORR__j2a();
    
    public void setCREATE__CORR__j2a(ExtType2Doc_ConcSync.JDoc2Annotation value);
    
    public ExtType2Doc_ConcSync.Method2Entry getCONTEXT__CORR__m2e();
    
    public void setCONTEXT__CORR__m2e(ExtType2Doc_ConcSync.Method2Entry value);
    

}
