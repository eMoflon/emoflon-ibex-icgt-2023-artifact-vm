package ExtType2Doc_ConcSync;

import runtime.RuntimePackage;
import ExtType2Doc_ConcSync.ExtType2Doc_ConcSyncPackage;

import org.emoflon.smartemf.runtime.notification.SmartEMFNotification;
import org.emoflon.smartemf.runtime.SmartObject;
import org.emoflon.smartemf.runtime.collections.*;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EStructuralFeature;

public interface Glossary__Marker extends EObject, runtime.TGGRuleApplication {
	
    public runtime.Protocol getProtocol();
    
    public void setProtocol(runtime.Protocol value);
    
    public ExtDocModel.DocContainer getCONTEXT__TRG__dc();
    
    public void setCONTEXT__TRG__dc(ExtDocModel.DocContainer value);
    
    public ExtDocModel.Glossary getCREATE__TRG__g();
    
    public void setCREATE__TRG__g(ExtDocModel.Glossary value);
    

}
