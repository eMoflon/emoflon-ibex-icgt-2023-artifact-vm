package ConstructionPlan.impl;

import ConstructionPlan.ConstructionPlanPackage;
import ConstructionPlan.ConstructionPlanPackage;

import org.emoflon.smartemf.runtime.*;
import org.emoflon.smartemf.runtime.collections.*;
import org.emoflon.smartemf.persistence.SmartEMFResource;
import org.emoflon.smartemf.runtime.notification.SmartEMFNotification;
import org.emoflon.smartemf.runtime.notification.NotifyStatus;

import java.util.function.Consumer;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EcoreFactory;
import org.eclipse.emf.ecore.EcorePackage;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.resource.Resource;

public class ConstructionImpl extends SmartObject implements ConstructionPlan.Construction {

    protected ConstructionPlan.Component firstStep = null;
    protected java.lang.String name = null;
    protected ConstructionPlan.Construction next = null;
	
	protected ConstructionImpl() {
		super(ConstructionPlanPackage.Literals.CONSTRUCTION);
	}
	
    
    @Override
    public ConstructionPlan.Component getFirstStep() {
    	return this.firstStep;
    }
    
    @Override
    public void setFirstStep(ConstructionPlan.Component value) {
    	
    	Object oldValue = this.firstStep;
    	
    	if(value == null && oldValue == null)
    		return;
    		
    	if(value != null && value.equals(oldValue))
    		return;
    		
    	
    	Resource.Internal resource = (Resource.Internal) eResource();
    		        if(oldValue != null && value != null) {
    		        	setResourceWithoutChecks(null);
    		        }
    		        
    		        NotifyStatus status = NotifyStatus.SUCCESS_NO_NOTIFICATION;
    	if(oldValue != null) {
    	        		status = ((MinimalSObjectContainer) oldValue).resetContainment();
    	}	
    	
    		        this.firstStep = value;
    		        
    	
    	
    			 	if(oldValue != null && value != null) {
    		        	setResourceWithoutChecks(resource);
    		        }
    	
    	if(value != null)
    		status = ((MinimalSObjectContainer) this.firstStep).setContainment(this, ConstructionPlanPackage.Literals.CONSTRUCTION__FIRST_STEP);
    	
    	
    	if(status == NotifyStatus.SUCCESS_NO_NOTIFICATION || oldValue != null && value != null)
    	        	sendNotification(SmartEMFNotification.createSetNotification(this, ConstructionPlanPackage.Literals.CONSTRUCTION__FIRST_STEP, oldValue, value, -1));
    	        	
    	        	if(ConstructionPlanPackage.Literals.CONSTRUCTION__FIRST_STEP.getEOpposite() != null) {
    	        		if(oldValue != null) {
    	        			((SmartObject) oldValue).eInverseRemove(this, ConstructionPlanPackage.Literals.CONSTRUCTION__FIRST_STEP.getEOpposite());
    	        		}
    	        		if(value != null) {
    	        		    ((SmartObject) value).eInverseAdd(this, ConstructionPlanPackage.Literals.CONSTRUCTION__FIRST_STEP.getEOpposite());
    	        		}
    	        	}
    }
    
    
    @Override
    public java.lang.String getName() {
    	return this.name;
    }
    
    @Override
    public void setName(java.lang.String value) {
    	Object oldValue = this.name;
    	this.name = value;
    	
    	        	sendNotification(SmartEMFNotification.createSetNotification(this, ConstructionPlanPackage.Literals.CONSTRUCTION__NAME, oldValue, value, -1));
    }
    
    
    @Override
    public ConstructionPlan.Construction getNext() {
    	return this.next;
    }
    
    @Override
    public void setNext(ConstructionPlan.Construction value) {
    	
    	Object oldValue = this.next;
    	
    	if(value == null && oldValue == null)
    		return;
    		
    	if(value != null && value.equals(oldValue))
    		return;
    		
    	
    	
    		        this.next = value;
    		        
    	
    	
    	        	sendNotification(SmartEMFNotification.createSetNotification(this, ConstructionPlanPackage.Literals.CONSTRUCTION__NEXT, oldValue, value, -1));
    	        	
    	        	if(ConstructionPlanPackage.Literals.CONSTRUCTION__NEXT.getEOpposite() != null) {
    	        		if(oldValue != null) {
    	        			((SmartObject) oldValue).eInverseRemove(this, ConstructionPlanPackage.Literals.CONSTRUCTION__NEXT.getEOpposite());
    	        		}
    	        		if(value != null) {
    	        		    ((SmartObject) value).eInverseAdd(this, ConstructionPlanPackage.Literals.CONSTRUCTION__NEXT.getEOpposite());
    	        		}
    	        	}
    }
    

    @Override
    public void eSet(EStructuralFeature eFeature, Object newValue){
    	if (ConstructionPlanPackage.Literals.CONSTRUCTION__FIRST_STEP.equals(eFeature)) {
    		setFirstStep((ConstructionPlan.Component) newValue); 
    		return;
    	}
    	if (ConstructionPlanPackage.Literals.CONSTRUCTION__NAME.equals(eFeature)) {
    		setName((java.lang.String) newValue); 
    		return;
    	}
    	if (ConstructionPlanPackage.Literals.CONSTRUCTION__NEXT.equals(eFeature)) {
    		setNext((ConstructionPlan.Construction) newValue); 
    		return;
    	}
    	eDynamicSet(eFeature, newValue);
    }
    
    @Override
    public void eUnset(EStructuralFeature eFeature){
    	if (ConstructionPlanPackage.Literals.CONSTRUCTION__FIRST_STEP.equals(eFeature)) {
    		setFirstStep((ConstructionPlan.Component)null); 
    		return;
    	}
    	if (ConstructionPlanPackage.Literals.CONSTRUCTION__NAME.equals(eFeature)) {
    		setName((java.lang.String)null); 
    		return;
    	}
    	if (ConstructionPlanPackage.Literals.CONSTRUCTION__NEXT.equals(eFeature)) {
    		setNext((ConstructionPlan.Construction)null); 
    		return;
    	}
    	eDynamicUnset(eFeature);
    }

    @Override
    public String toString(){
		StringBuilder b = new StringBuilder();
		b.append(super.toString());
		b.append(" (");
		if (SmartEMFConfig.simpleStringRepresentations()) {
			b.append(getName());
		} else {
			b.append("name: ");
			b.append(getName());
		}
		b.append(")");
		return b.toString();
    }

 	@Override
    public Object eGet(EStructuralFeature eFeature){
    	if (ConstructionPlanPackage.Literals.CONSTRUCTION__FIRST_STEP.equals(eFeature))
    		return getFirstStep();
    	if (ConstructionPlanPackage.Literals.CONSTRUCTION__NAME.equals(eFeature))
    		return getName();
    	if (ConstructionPlanPackage.Literals.CONSTRUCTION__NEXT.equals(eFeature))
    		return getNext();
    	return eDynamicGet(eFeature);
    }

    @Override
    public Object eGet(int featureID, boolean resolve, boolean coreType){
    	throw new UnsupportedOperationException("This method has been deactivated since it is not always safe to use.");
    }
    
    @Override
    public void eInverseAdd(Object otherEnd, EStructuralFeature feature) {
	    if(feature == null)
	    	return;
	    	
    	eDynamicInverseAdd(otherEnd, feature);
	    	}
    	
    @Override
	    	public void eInverseRemove(Object otherEnd, EStructuralFeature feature) {
	    if(feature == null)
	    	return;
	    		    		
    	eDynamicInverseRemove(otherEnd, feature);
	    	}
    
    @Override
    /**
    * This method sets the resource and generates REMOVING_ADAPTER and ADD notifications
    */
    protected void setResourceOfContainments(Consumer<SmartObject> setResourceCall) {
if(getFirstStep() != null)
	setResourceCall.accept((SmartObject) getFirstStep());
	    	}
	    	
	    	@Override
	    	/**
	    	* This method sets the resource and only generates REMOVING_ADAPTER notifications (no ADD messages)
	    	*/
    protected void setResourceOfContainmentsSilently(Resource r) { 		
if(getFirstStep() != null)
    ((SmartObject) getFirstStep()).setResourceSilently(r);
	    	}
}
