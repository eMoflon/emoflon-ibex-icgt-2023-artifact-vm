package ExtDocModel;

import ExtDocModel.ExtDocModelPackage;

import org.emoflon.smartemf.runtime.notification.SmartEMFNotification;
import org.emoflon.smartemf.runtime.SmartObject;
import org.emoflon.smartemf.runtime.collections.*;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EStructuralFeature;

public interface Doc extends EObject, ExtDocModel.NamedElement {
	
    public java.lang.String getName();
    
    public void setName(java.lang.String value);
    
    public ExtDocModel.Folder getFolder();
    
    public void setFolder(ExtDocModel.Folder value);
    
    public LinkedSmartESet<ExtDocModel.Entry> getEntries();
    
    public void setEntries(LinkedSmartESet<ExtDocModel.Entry> value);
    
    public LinkedSmartESet<ExtDocModel.Doc> getSubDocs();
    
    public void setSubDocs(LinkedSmartESet<ExtDocModel.Doc> value);
    
    public LinkedSmartESet<ExtDocModel.Doc> getSuperDocs();
    
    public void setSuperDocs(LinkedSmartESet<ExtDocModel.Doc> value);
    

}
