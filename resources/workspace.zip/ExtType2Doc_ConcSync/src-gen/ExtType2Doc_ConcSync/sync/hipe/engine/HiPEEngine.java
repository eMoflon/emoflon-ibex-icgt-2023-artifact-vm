package ExtType2Doc_ConcSync.sync.hipe.engine;

import akka.actor.ActorRef;
import akka.actor.Props;

import ExtType2Doc_ConcSync.sync.hipe.engine.actor.NotificationActor;
import ExtType2Doc_ConcSync.sync.hipe.engine.actor.DispatchActor;
import ExtType2Doc_ConcSync.sync.hipe.engine.actor.localsearch.ExtendingType2Doc_nd_superDocs_outgoing_TRG__FILTER_NAC_TRG_1_localSearch;
import ExtType2Doc_ConcSync.sync.hipe.engine.actor.localsearch.ExtendingType2Doc__BWD_5_localSearch;
import ExtType2Doc_ConcSync.sync.hipe.engine.actor.localsearch.ExtendingType2Doc_nt_inheritsFrom_outgoing_SRC__FILTER_NAC_SRC_13_localSearch;
import ExtType2Doc_ConcSync.sync.hipe.engine.actor.localsearch.ExtendingType2Doc__CONSISTENCY_17_localSearch;
import ExtType2Doc_ConcSync.sync.hipe.engine.actor.localsearch.ExtendingType2Doc__FWD_28_localSearch;
import ExtType2Doc_ConcSync.sync.hipe.engine.actor.localsearch.Field2Entry__BWD_36_localSearch;
import ExtType2Doc_ConcSync.sync.hipe.engine.actor.localsearch.Field2Entry__CONSISTENCY_41_localSearch;
import ExtType2Doc_ConcSync.sync.hipe.engine.actor.localsearch.Field2Entry__FWD_49_localSearch;
import ExtType2Doc_ConcSync.sync.hipe.engine.actor.localsearch.GlossaryEntry__BWD_54_localSearch;
import ExtType2Doc_ConcSync.sync.hipe.engine.actor.localsearch.GlossaryEntry__CONSISTENCY_57_localSearch;
import ExtType2Doc_ConcSync.sync.hipe.engine.actor.localsearch.GlossaryLink__BWD_61_localSearch;
import ExtType2Doc_ConcSync.sync.hipe.engine.actor.localsearch.GlossaryLink__CONSISTENCY_64_localSearch;
import ExtType2Doc_ConcSync.sync.hipe.engine.actor.localsearch.Glossary__BWD_68_localSearch;
import ExtType2Doc_ConcSync.sync.hipe.engine.actor.localsearch.Glossary__CONSISTENCY_71_localSearch;
import ExtType2Doc_ConcSync.sync.hipe.engine.actor.localsearch.JDoc2Annotation__BWD_75_localSearch;
import ExtType2Doc_ConcSync.sync.hipe.engine.actor.localsearch.JDoc2Annotation__CONSISTENCY_80_localSearch;
import ExtType2Doc_ConcSync.sync.hipe.engine.actor.localsearch.JDoc2Annotation__FWD_88_localSearch;
import ExtType2Doc_ConcSync.sync.hipe.engine.actor.localsearch.Method2Entry__BWD_93_localSearch;
import ExtType2Doc_ConcSync.sync.hipe.engine.actor.localsearch.Method2Entry__CONSISTENCY_98_localSearch;
import ExtType2Doc_ConcSync.sync.hipe.engine.actor.localsearch.Method2Entry__FWD_106_localSearch;
import ExtType2Doc_ConcSync.sync.hipe.engine.actor.localsearch.Package2Folder__BWD_111_localSearch;
import ExtType2Doc_ConcSync.sync.hipe.engine.actor.localsearch.Package2Folder__CONSISTENCY_116_localSearch;
import ExtType2Doc_ConcSync.sync.hipe.engine.actor.localsearch.Package2Folder__FWD_124_localSearch;
import ExtType2Doc_ConcSync.sync.hipe.engine.actor.localsearch.Param2Entry__CONSISTENCY_129_localSearch;
import ExtType2Doc_ConcSync.sync.hipe.engine.actor.localsearch.Param2Entry__FWD_136_localSearch;
import ExtType2Doc_ConcSync.sync.hipe.engine.actor.localsearch.Project2DocCont__CONSISTENCY_142_localSearch;
import ExtType2Doc_ConcSync.sync.hipe.engine.actor.localsearch.Type2Doc_d_superDocs_outgoing_TRG__FILTER_NAC_TRG_148_localSearch;
import ExtType2Doc_ConcSync.sync.hipe.engine.actor.localsearch.Type2Doc__BWD_151_localSearch;
import ExtType2Doc_ConcSync.sync.hipe.engine.actor.localsearch.Type2Doc_t_inheritsFrom_outgoing_SRC__FILTER_NAC_SRC_156_localSearch;
import ExtType2Doc_ConcSync.sync.hipe.engine.actor.localsearch.Type2Doc__CONSISTENCY_159_localSearch;
import ExtType2Doc_ConcSync.sync.hipe.engine.actor.localsearch.Type2Doc__FWD_167_localSearch;

import hipe.engine.IHiPEEngine;
import hipe.engine.message.InitGenReferenceActor;

import hipe.generic.actor.GenericObjectActor;
import hipe.generic.actor.GenericReferenceActor;
import hipe.generic.actor.GenericProductionActor;
import hipe.generic.actor.junction.*;

import hipe.network.*;

public class HiPEEngine extends IHiPEEngine{
	
	public HiPEEngine(HiPENetwork network) {
		super(network);
	}
	
	public HiPEEngine() {
		super();
	}
	
	@Override
	public String getClassLocation() {
		return getClass().getProtectionDomain().getCodeSource().getLocation().getPath().toString();
	}
	
	@Override
	public String getPackageName() {
		return getClass().getPackageName();
	}
	
	@Override
	protected ActorRef getDispatchActor() {
		return system.actorOf(
			Props.create(DispatchActor.class, () -> new DispatchActor(name2actor, incUtil)),
			"DispatchActor");
	}
	
	@Override
	protected ActorRef getNotificationActor(boolean cascadingNotifications) {
		return system.actorOf(
			Props.create(NotificationActor.class, () -> new NotificationActor(dispatcher, incUtil, cascadingNotifications)), 
			"NotificationActor");
	}
	
	@Override
	public void createProductionNodes() {
		classes.put("ExtendingType2Doc__BWD_production", GenericProductionActor.class);
		productionNodes2pattern.put("ExtendingType2Doc__BWD_production", "ExtendingType2Doc__BWD");
		classes.put("ExtendingType2Doc__CONSISTENCY_production", GenericProductionActor.class);
		productionNodes2pattern.put("ExtendingType2Doc__CONSISTENCY_production", "ExtendingType2Doc__CONSISTENCY");
		classes.put("ExtendingType2Doc__FWD_production", GenericProductionActor.class);
		productionNodes2pattern.put("ExtendingType2Doc__FWD_production", "ExtendingType2Doc__FWD");
		classes.put("ExtendingType2Doc_nd_superDocs_outgoing_TRG__FILTER_NAC_TRG_production", GenericProductionActor.class);
		productionNodes2pattern.put("ExtendingType2Doc_nd_superDocs_outgoing_TRG__FILTER_NAC_TRG_production", "ExtendingType2Doc_nd_superDocs_outgoing_TRG__FILTER_NAC_TRG");
		classes.put("ExtendingType2Doc_nt_inheritsFrom_outgoing_SRC__FILTER_NAC_SRC_production", GenericProductionActor.class);
		productionNodes2pattern.put("ExtendingType2Doc_nt_inheritsFrom_outgoing_SRC__FILTER_NAC_SRC_production", "ExtendingType2Doc_nt_inheritsFrom_outgoing_SRC__FILTER_NAC_SRC");
		classes.put("Field2Entry__BWD_production", GenericProductionActor.class);
		productionNodes2pattern.put("Field2Entry__BWD_production", "Field2Entry__BWD");
		classes.put("Field2Entry__CONSISTENCY_production", GenericProductionActor.class);
		productionNodes2pattern.put("Field2Entry__CONSISTENCY_production", "Field2Entry__CONSISTENCY");
		classes.put("Field2Entry__FWD_production", GenericProductionActor.class);
		productionNodes2pattern.put("Field2Entry__FWD_production", "Field2Entry__FWD");
		classes.put("GlossaryEntry__BWD_production", GenericProductionActor.class);
		productionNodes2pattern.put("GlossaryEntry__BWD_production", "GlossaryEntry__BWD");
		classes.put("GlossaryEntry__CONSISTENCY_production", GenericProductionActor.class);
		productionNodes2pattern.put("GlossaryEntry__CONSISTENCY_production", "GlossaryEntry__CONSISTENCY");
		classes.put("GlossaryLink__BWD_production", GenericProductionActor.class);
		productionNodes2pattern.put("GlossaryLink__BWD_production", "GlossaryLink__BWD");
		classes.put("GlossaryLink__CONSISTENCY_production", GenericProductionActor.class);
		productionNodes2pattern.put("GlossaryLink__CONSISTENCY_production", "GlossaryLink__CONSISTENCY");
		classes.put("Glossary__BWD_production", GenericProductionActor.class);
		productionNodes2pattern.put("Glossary__BWD_production", "Glossary__BWD");
		classes.put("Glossary__CONSISTENCY_production", GenericProductionActor.class);
		productionNodes2pattern.put("Glossary__CONSISTENCY_production", "Glossary__CONSISTENCY");
		classes.put("JDoc2Annotation__BWD_production", GenericProductionActor.class);
		productionNodes2pattern.put("JDoc2Annotation__BWD_production", "JDoc2Annotation__BWD");
		classes.put("JDoc2Annotation__CONSISTENCY_production", GenericProductionActor.class);
		productionNodes2pattern.put("JDoc2Annotation__CONSISTENCY_production", "JDoc2Annotation__CONSISTENCY");
		classes.put("JDoc2Annotation__FWD_production", GenericProductionActor.class);
		productionNodes2pattern.put("JDoc2Annotation__FWD_production", "JDoc2Annotation__FWD");
		classes.put("Method2Entry__BWD_production", GenericProductionActor.class);
		productionNodes2pattern.put("Method2Entry__BWD_production", "Method2Entry__BWD");
		classes.put("Method2Entry__CONSISTENCY_production", GenericProductionActor.class);
		productionNodes2pattern.put("Method2Entry__CONSISTENCY_production", "Method2Entry__CONSISTENCY");
		classes.put("Method2Entry__FWD_production", GenericProductionActor.class);
		productionNodes2pattern.put("Method2Entry__FWD_production", "Method2Entry__FWD");
		classes.put("Package2Folder__BWD_production", GenericProductionActor.class);
		productionNodes2pattern.put("Package2Folder__BWD_production", "Package2Folder__BWD");
		classes.put("Package2Folder__CONSISTENCY_production", GenericProductionActor.class);
		productionNodes2pattern.put("Package2Folder__CONSISTENCY_production", "Package2Folder__CONSISTENCY");
		classes.put("Package2Folder__FWD_production", GenericProductionActor.class);
		productionNodes2pattern.put("Package2Folder__FWD_production", "Package2Folder__FWD");
		classes.put("Param2Entry__CONSISTENCY_production", GenericProductionActor.class);
		productionNodes2pattern.put("Param2Entry__CONSISTENCY_production", "Param2Entry__CONSISTENCY");
		classes.put("Param2Entry__FWD_production", GenericProductionActor.class);
		productionNodes2pattern.put("Param2Entry__FWD_production", "Param2Entry__FWD");
		classes.put("Project2DocCont__BWD_production", GenericProductionActor.class);
		productionNodes2pattern.put("Project2DocCont__BWD_production", "Project2DocCont__BWD");
		classes.put("Project2DocCont__CONSISTENCY_production", GenericProductionActor.class);
		productionNodes2pattern.put("Project2DocCont__CONSISTENCY_production", "Project2DocCont__CONSISTENCY");
		classes.put("Project2DocCont__FWD_production", GenericProductionActor.class);
		productionNodes2pattern.put("Project2DocCont__FWD_production", "Project2DocCont__FWD");
		classes.put("Type2Doc__BWD_production", GenericProductionActor.class);
		productionNodes2pattern.put("Type2Doc__BWD_production", "Type2Doc__BWD");
		classes.put("Type2Doc__CONSISTENCY_production", GenericProductionActor.class);
		productionNodes2pattern.put("Type2Doc__CONSISTENCY_production", "Type2Doc__CONSISTENCY");
		classes.put("Type2Doc__FWD_production", GenericProductionActor.class);
		productionNodes2pattern.put("Type2Doc__FWD_production", "Type2Doc__FWD");
		classes.put("Type2Doc_d_superDocs_outgoing_TRG__FILTER_NAC_TRG_production", GenericProductionActor.class);
		productionNodes2pattern.put("Type2Doc_d_superDocs_outgoing_TRG__FILTER_NAC_TRG_production", "Type2Doc_d_superDocs_outgoing_TRG__FILTER_NAC_TRG");
		classes.put("Type2Doc_t_inheritsFrom_outgoing_SRC__FILTER_NAC_SRC_production", GenericProductionActor.class);
		productionNodes2pattern.put("Type2Doc_t_inheritsFrom_outgoing_SRC__FILTER_NAC_SRC_production", "Type2Doc_t_inheritsFrom_outgoing_SRC__FILTER_NAC_SRC");
		
	}
	
	@Override
	public void createJunctionNodes() {
		classes.put("ExtendingType2Doc_nd_superDocs_outgoing_TRG__FILTER_NAC_TRG_1_localSearch", ExtendingType2Doc_nd_superDocs_outgoing_TRG__FILTER_NAC_TRG_1_localSearch.class);
		classes.put("ExtendingType2Doc__BWD_5_localSearch", ExtendingType2Doc__BWD_5_localSearch.class);
		classes.put("ExtendingType2Doc_nt_inheritsFrom_outgoing_SRC__FILTER_NAC_SRC_13_localSearch", ExtendingType2Doc_nt_inheritsFrom_outgoing_SRC__FILTER_NAC_SRC_13_localSearch.class);
		classes.put("ExtendingType2Doc__CONSISTENCY_17_localSearch", ExtendingType2Doc__CONSISTENCY_17_localSearch.class);
		classes.put("ExtendingType2Doc__FWD_28_localSearch", ExtendingType2Doc__FWD_28_localSearch.class);
		classes.put("Field2Entry__BWD_36_localSearch", Field2Entry__BWD_36_localSearch.class);
		classes.put("Field2Entry__CONSISTENCY_41_localSearch", Field2Entry__CONSISTENCY_41_localSearch.class);
		classes.put("Field2Entry__FWD_49_localSearch", Field2Entry__FWD_49_localSearch.class);
		classes.put("GlossaryEntry__BWD_54_localSearch", GlossaryEntry__BWD_54_localSearch.class);
		classes.put("GlossaryEntry__CONSISTENCY_57_localSearch", GlossaryEntry__CONSISTENCY_57_localSearch.class);
		classes.put("GlossaryLink__BWD_61_localSearch", GlossaryLink__BWD_61_localSearch.class);
		classes.put("GlossaryLink__CONSISTENCY_64_localSearch", GlossaryLink__CONSISTENCY_64_localSearch.class);
		classes.put("Glossary__BWD_68_localSearch", Glossary__BWD_68_localSearch.class);
		classes.put("Glossary__CONSISTENCY_71_localSearch", Glossary__CONSISTENCY_71_localSearch.class);
		classes.put("JDoc2Annotation__BWD_75_localSearch", JDoc2Annotation__BWD_75_localSearch.class);
		classes.put("JDoc2Annotation__CONSISTENCY_80_localSearch", JDoc2Annotation__CONSISTENCY_80_localSearch.class);
		classes.put("JDoc2Annotation__FWD_88_localSearch", JDoc2Annotation__FWD_88_localSearch.class);
		classes.put("Method2Entry__BWD_93_localSearch", Method2Entry__BWD_93_localSearch.class);
		classes.put("Method2Entry__CONSISTENCY_98_localSearch", Method2Entry__CONSISTENCY_98_localSearch.class);
		classes.put("Method2Entry__FWD_106_localSearch", Method2Entry__FWD_106_localSearch.class);
		classes.put("Package2Folder__BWD_111_localSearch", Package2Folder__BWD_111_localSearch.class);
		classes.put("Package2Folder__CONSISTENCY_116_localSearch", Package2Folder__CONSISTENCY_116_localSearch.class);
		classes.put("Package2Folder__FWD_124_localSearch", Package2Folder__FWD_124_localSearch.class);
		classes.put("Param2Entry__CONSISTENCY_129_localSearch", Param2Entry__CONSISTENCY_129_localSearch.class);
		classes.put("Param2Entry__FWD_136_localSearch", Param2Entry__FWD_136_localSearch.class);
		classes.put("Project2DocCont__CONSISTENCY_142_localSearch", Project2DocCont__CONSISTENCY_142_localSearch.class);
		classes.put("Type2Doc_d_superDocs_outgoing_TRG__FILTER_NAC_TRG_148_localSearch", Type2Doc_d_superDocs_outgoing_TRG__FILTER_NAC_TRG_148_localSearch.class);
		classes.put("Type2Doc__BWD_151_localSearch", Type2Doc__BWD_151_localSearch.class);
		classes.put("Type2Doc_t_inheritsFrom_outgoing_SRC__FILTER_NAC_SRC_156_localSearch", Type2Doc_t_inheritsFrom_outgoing_SRC__FILTER_NAC_SRC_156_localSearch.class);
		classes.put("Type2Doc__CONSISTENCY_159_localSearch", Type2Doc__CONSISTENCY_159_localSearch.class);
		classes.put("Type2Doc__FWD_167_localSearch", Type2Doc__FWD_167_localSearch.class);
	}
	
	@Override
	public void createReferenceNodes() {
		
	}
	
	@Override
	public void createObjectNodes() {
		classes.put("ExtendingType2Doc__Marker_object",ExtendingType2Doc__Marker_object.class);
		classes.put("Field_object",Field_object.class);
		classes.put("Field2Entry_object",Field2Entry_object.class);
		classes.put("Field2Entry__Marker_object",Field2Entry__Marker_object.class);
		classes.put("GlossaryEntry_object",GlossaryEntry_object.class);
		classes.put("Glossary_object",Glossary_object.class);
		classes.put("GlossaryEntry__Marker_object",GlossaryEntry__Marker_object.class);
		classes.put("GlossaryLink__Marker_object",GlossaryLink__Marker_object.class);
		classes.put("Glossary__Marker_object",Glossary__Marker_object.class);
		classes.put("Annotation_object",Annotation_object.class);
		classes.put("JavaDoc_object",JavaDoc_object.class);
		classes.put("JDoc2Annotation_object",JDoc2Annotation_object.class);
		classes.put("JDoc2Annotation__Marker_object",JDoc2Annotation__Marker_object.class);
		classes.put("Method2Entry__Marker_object",Method2Entry__Marker_object.class);
		classes.put("Project2DocContainer_object",Project2DocContainer_object.class);
		classes.put("Package2Folder__Marker_object",Package2Folder__Marker_object.class);
		classes.put("Parameter_object",Parameter_object.class);
		classes.put("Param2Entry_object",Param2Entry_object.class);
		classes.put("Param2Entry__Marker_object",Param2Entry__Marker_object.class);
		classes.put("Project2DocCont__Marker_object",Project2DocCont__Marker_object.class);
		classes.put("Type2Doc__Marker_object",Type2Doc__Marker_object.class);
		classes.put("Doc_object_SP0",Doc_object_SP0.class);
		classes.put("Doc_object_SP1",Doc_object_SP1.class);
		classes.put("Doc_object_SP2",Doc_object_SP2.class);
		classes.put("Doc_object_SP3",Doc_object_SP3.class);
		classes.put("Folder_object_SP0",Folder_object_SP0.class);
		classes.put("Folder_object_SP1",Folder_object_SP1.class);
		classes.put("Package_object_SP0",Package_object_SP0.class);
		classes.put("Package_object_SP1",Package_object_SP1.class);
		classes.put("Package2Folder_object_SP0",Package2Folder_object_SP0.class);
		classes.put("Package2Folder_object_SP1",Package2Folder_object_SP1.class);
		classes.put("Type_object_SP0",Type_object_SP0.class);
		classes.put("Type_object_SP1",Type_object_SP1.class);
		classes.put("Type_object_SP2",Type_object_SP2.class);
		classes.put("Type_object_SP3",Type_object_SP3.class);
		classes.put("Type2Doc_object_SP0",Type2Doc_object_SP0.class);
		classes.put("Type2Doc_object_SP1",Type2Doc_object_SP1.class);
		classes.put("Type2Doc_object_SP2",Type2Doc_object_SP2.class);
		classes.put("Entry_object_SP0",Entry_object_SP0.class);
		classes.put("Entry_object_SP1",Entry_object_SP1.class);
		classes.put("Entry_object_SP2",Entry_object_SP2.class);
		classes.put("DocContainer_object_SP0",DocContainer_object_SP0.class);
		classes.put("DocContainer_object_SP1",DocContainer_object_SP1.class);
		classes.put("Method_object_SP0",Method_object_SP0.class);
		classes.put("Method_object_SP1",Method_object_SP1.class);
		classes.put("Method2Entry_object_SP0",Method2Entry_object_SP0.class);
		classes.put("Method2Entry_object_SP1",Method2Entry_object_SP1.class);
		classes.put("Project_object_SP0",Project_object_SP0.class);
		classes.put("Project_object_SP1",Project_object_SP1.class);
		
	}
	
	@Override
	public void initializeReferenceNodes() {
	}
}

class ExtendingType2Doc__Marker_object extends GenericObjectActor<ExtType2Doc_ConcSync.ExtendingType2Doc__Marker> { }
class Field_object extends GenericObjectActor<ExtTypeModel.Field> { }
class Field2Entry_object extends GenericObjectActor<ExtType2Doc_ConcSync.Field2Entry> { }
class Field2Entry__Marker_object extends GenericObjectActor<ExtType2Doc_ConcSync.Field2Entry__Marker> { }
class GlossaryEntry_object extends GenericObjectActor<ExtDocModel.GlossaryEntry> { }
class Glossary_object extends GenericObjectActor<ExtDocModel.Glossary> { }
class GlossaryEntry__Marker_object extends GenericObjectActor<ExtType2Doc_ConcSync.GlossaryEntry__Marker> { }
class GlossaryLink__Marker_object extends GenericObjectActor<ExtType2Doc_ConcSync.GlossaryLink__Marker> { }
class Glossary__Marker_object extends GenericObjectActor<ExtType2Doc_ConcSync.Glossary__Marker> { }
class Annotation_object extends GenericObjectActor<ExtDocModel.Annotation> { }
class JavaDoc_object extends GenericObjectActor<ExtTypeModel.JavaDoc> { }
class JDoc2Annotation_object extends GenericObjectActor<ExtType2Doc_ConcSync.JDoc2Annotation> { }
class JDoc2Annotation__Marker_object extends GenericObjectActor<ExtType2Doc_ConcSync.JDoc2Annotation__Marker> { }
class Method2Entry__Marker_object extends GenericObjectActor<ExtType2Doc_ConcSync.Method2Entry__Marker> { }
class Project2DocContainer_object extends GenericObjectActor<ExtType2Doc_ConcSync.Project2DocContainer> { }
class Package2Folder__Marker_object extends GenericObjectActor<ExtType2Doc_ConcSync.Package2Folder__Marker> { }
class Parameter_object extends GenericObjectActor<ExtTypeModel.Parameter> { }
class Param2Entry_object extends GenericObjectActor<ExtType2Doc_ConcSync.Param2Entry> { }
class Param2Entry__Marker_object extends GenericObjectActor<ExtType2Doc_ConcSync.Param2Entry__Marker> { }
class Project2DocCont__Marker_object extends GenericObjectActor<ExtType2Doc_ConcSync.Project2DocCont__Marker> { }
class Type2Doc__Marker_object extends GenericObjectActor<ExtType2Doc_ConcSync.Type2Doc__Marker> { }
class Doc_object_SP0 extends GenericObjectActor<ExtDocModel.Doc> { }
class Doc_object_SP1 extends GenericObjectActor<ExtDocModel.Doc> { }
class Doc_object_SP2 extends GenericObjectActor<ExtDocModel.Doc> { }
class Doc_object_SP3 extends GenericObjectActor<ExtDocModel.Doc> { }
class Folder_object_SP0 extends GenericObjectActor<ExtDocModel.Folder> { }
class Folder_object_SP1 extends GenericObjectActor<ExtDocModel.Folder> { }
class Package_object_SP0 extends GenericObjectActor<ExtTypeModel.Package> { }
class Package_object_SP1 extends GenericObjectActor<ExtTypeModel.Package> { }
class Package2Folder_object_SP0 extends GenericObjectActor<ExtType2Doc_ConcSync.Package2Folder> { }
class Package2Folder_object_SP1 extends GenericObjectActor<ExtType2Doc_ConcSync.Package2Folder> { }
class Type_object_SP0 extends GenericObjectActor<ExtTypeModel.Type> { }
class Type_object_SP1 extends GenericObjectActor<ExtTypeModel.Type> { }
class Type_object_SP2 extends GenericObjectActor<ExtTypeModel.Type> { }
class Type_object_SP3 extends GenericObjectActor<ExtTypeModel.Type> { }
class Type2Doc_object_SP0 extends GenericObjectActor<ExtType2Doc_ConcSync.Type2Doc> { }
class Type2Doc_object_SP1 extends GenericObjectActor<ExtType2Doc_ConcSync.Type2Doc> { }
class Type2Doc_object_SP2 extends GenericObjectActor<ExtType2Doc_ConcSync.Type2Doc> { }
class Entry_object_SP0 extends GenericObjectActor<ExtDocModel.Entry> { }
class Entry_object_SP1 extends GenericObjectActor<ExtDocModel.Entry> { }
class Entry_object_SP2 extends GenericObjectActor<ExtDocModel.Entry> { }
class DocContainer_object_SP0 extends GenericObjectActor<ExtDocModel.DocContainer> { }
class DocContainer_object_SP1 extends GenericObjectActor<ExtDocModel.DocContainer> { }
class Method_object_SP0 extends GenericObjectActor<ExtTypeModel.Method> { }
class Method_object_SP1 extends GenericObjectActor<ExtTypeModel.Method> { }
class Method2Entry_object_SP0 extends GenericObjectActor<ExtType2Doc_ConcSync.Method2Entry> { }
class Method2Entry_object_SP1 extends GenericObjectActor<ExtType2Doc_ConcSync.Method2Entry> { }
class Project_object_SP0 extends GenericObjectActor<ExtTypeModel.Project> { }
class Project_object_SP1 extends GenericObjectActor<ExtTypeModel.Project> { }


