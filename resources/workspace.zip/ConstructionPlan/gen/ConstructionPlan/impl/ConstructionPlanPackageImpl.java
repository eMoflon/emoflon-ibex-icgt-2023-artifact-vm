package ConstructionPlan.impl;

import ConstructionPlan.PlanCollection;
import ConstructionPlan.Plan;
import ConstructionPlan.Construction;
import ConstructionPlan.Component;
import ConstructionPlan.Cellar;
import ConstructionPlan.Basement;
import ConstructionPlan.SaddleRoof;


import ConstructionPlan.ConstructionPlanFactory;
import ConstructionPlan.ConstructionPlanPackage;


import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.ecore.EcorePackage;

import org.eclipse.emf.ecore.impl.EPackageImpl;

import org.emoflon.smartemf.runtime.SmartPackageImpl;

public class ConstructionPlanPackageImpl extends SmartPackageImpl
		implements ConstructionPlanPackage {
			
	private EClass planCollectionEClass = null;
	private EReference planCollection_plansEReference = null;
	private EClass planEClass = null;
	private EReference plan_constructionsEReference = null;
	private EAttribute plan_nameEAttribute = null;
	private EClass constructionEClass = null;
	private EReference construction_firstStepEReference = null;
	private EAttribute construction_nameEAttribute = null;
	private EReference construction_nextEReference = null;
	private EClass componentEClass = null;
	private EReference component_nextStepEReference = null;
	private EAttribute component_descriptionEAttribute = null;
	private EClass cellarEClass = null;
	private EClass basementEClass = null;
	private EClass saddleRoofEClass = null;
	
	

	private ConstructionPlanPackageImpl() {
		super(eNS_URI, ConstructionPlan.ConstructionPlanFactory.eINSTANCE);
	}

	private static boolean isRegistered = false;
	private boolean isCreated = false;
	private boolean isInitialized = false;

	public static ConstructionPlanPackage init() {
		if (isRegistered)
			return (ConstructionPlanPackage) EPackage.Registry.INSTANCE
					.getEPackage(ConstructionPlanPackage.eNS_URI);

		// Obtain or create and register package
		Object registeredConstructionPlanPackage = EPackage.Registry.INSTANCE.get(eNS_URI);
		ConstructionPlanPackageImpl theConstructionPlanPackage = registeredConstructionPlanPackage instanceof ConstructionPlanPackageImpl
				? (ConstructionPlanPackageImpl) registeredConstructionPlanPackage
				: new ConstructionPlanPackageImpl();

		isRegistered = true;

		// Create package meta-data objects
		theConstructionPlanPackage.createPackageContents();

		// Initialize created meta-data
		theConstructionPlanPackage.initializePackageContents();
		
		// Inject internal eOpposites to unidirectional references
		theConstructionPlanPackage.injectDynamicOpposites();
		
		// Inject external references into foreign packages
		theConstructionPlanPackage.injectExternalReferences();

		// Mark meta-data to indicate it can't be changed
		theConstructionPlanPackage.freeze();

		// Update the registry and return the package
		EPackage.Registry.INSTANCE.put(ConstructionPlanPackage.eNS_URI,
				theConstructionPlanPackage);
				
		theConstructionPlanPackage.fetchDynamicEStructuralFeaturesOfSuperTypes();
		return theConstructionPlanPackage;
	}

	@Override
	public EClass getPlanCollection() {
		return planCollectionEClass;
	}
	@Override
	public EReference getPlanCollection_Plans() {
		return planCollection_plansEReference;	
	}
	@Override
	public EClass getPlan() {
		return planEClass;
	}
	@Override
	public EReference getPlan_Constructions() {
		return plan_constructionsEReference;	
	}
	@Override
	public EAttribute getPlan_Name() {
		return plan_nameEAttribute;	
	}
	@Override
	public EClass getConstruction() {
		return constructionEClass;
	}
	@Override
	public EReference getConstruction_FirstStep() {
		return construction_firstStepEReference;	
	}
	@Override
	public EAttribute getConstruction_Name() {
		return construction_nameEAttribute;	
	}
	@Override
	public EReference getConstruction_Next() {
		return construction_nextEReference;	
	}
	@Override
	public EClass getComponent() {
		return componentEClass;
	}
	@Override
	public EReference getComponent_NextStep() {
		return component_nextStepEReference;	
	}
	@Override
	public EAttribute getComponent_Description() {
		return component_descriptionEAttribute;	
	}
	@Override
	public EClass getCellar() {
		return cellarEClass;
	}
	@Override
	public EClass getBasement() {
		return basementEClass;
	}
	@Override
	public EClass getSaddleRoof() {
		return saddleRoofEClass;
	}
	
	

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ConstructionPlan.ConstructionPlanFactory getConstructionPlanFactory() {
		return (ConstructionPlan.ConstructionPlanFactory) getEFactoryInstance();
	}

	public void createPackageContents() {
		if (isCreated)
			return;
		isCreated = true;

		// Create classes and their features
		planCollectionEClass = createEClass(PLAN_COLLECTION);
		createEReference(planCollectionEClass, PLAN_COLLECTION__PLANS);
		planCollection_plansEReference = (EReference) planCollectionEClass.getEStructuralFeatures().get(0);
		
		planEClass = createEClass(PLAN);
		createEReference(planEClass, PLAN__CONSTRUCTIONS);
		plan_constructionsEReference = (EReference) planEClass.getEStructuralFeatures().get(0);
		createEAttribute(planEClass, PLAN__NAME);
		plan_nameEAttribute = (EAttribute) planEClass.getEStructuralFeatures().get(1);
		
		constructionEClass = createEClass(CONSTRUCTION);
		createEReference(constructionEClass, CONSTRUCTION__FIRST_STEP);
		construction_firstStepEReference = (EReference) constructionEClass.getEStructuralFeatures().get(0);
		createEAttribute(constructionEClass, CONSTRUCTION__NAME);
		construction_nameEAttribute = (EAttribute) constructionEClass.getEStructuralFeatures().get(1);
		createEReference(constructionEClass, CONSTRUCTION__NEXT);
		construction_nextEReference = (EReference) constructionEClass.getEStructuralFeatures().get(2);
		
		componentEClass = createEClass(COMPONENT);
		createEReference(componentEClass, COMPONENT__NEXT_STEP);
		component_nextStepEReference = (EReference) componentEClass.getEStructuralFeatures().get(0);
		createEAttribute(componentEClass, COMPONENT__DESCRIPTION);
		component_descriptionEAttribute = (EAttribute) componentEClass.getEStructuralFeatures().get(1);
		
		cellarEClass = createEClass(CELLAR);
		
		basementEClass = createEClass(BASEMENT);
		
		saddleRoofEClass = createEClass(SADDLE_ROOF);
		
		// Create enums
		
		// Create data types
	}

	public void initializePackageContents() {
		if (isInitialized)
			return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);
		
		// Obtain other dependent packages

		// Create type parameters

		// Set bounds for type parameters

		// Add supertypes to classes
		cellarEClass.getESuperTypes().add(this.getComponent());
		basementEClass.getESuperTypes().add(this.getComponent());
		saddleRoofEClass.getESuperTypes().add(this.getComponent());

		// Initialize classes, features, and operations; add parameters
		initEClass(planCollectionEClass, PlanCollection.class, "PlanCollection", !IS_ABSTRACT, !IS_INTERFACE,
			IS_GENERATED_INSTANCE_CLASS);
		initEReference(getPlanCollection_Plans(), this.getPlan(),  null, 
			"plans", null, 0, -1, PlanCollection.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
				
		initEClass(planEClass, Plan.class, "Plan", !IS_ABSTRACT, !IS_INTERFACE,
			IS_GENERATED_INSTANCE_CLASS);
		initEReference(getPlan_Constructions(), this.getConstruction(),  null, 
			"constructions", null, 0, -1, Plan.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getPlan_Name(), ecorePackage.getEString(),
			"name", null, 0, 1, Plan.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, IS_ID, IS_UNIQUE,
			!IS_DERIVED, IS_ORDERED);
		
		initEClass(constructionEClass, Construction.class, "Construction", !IS_ABSTRACT, !IS_INTERFACE,
			IS_GENERATED_INSTANCE_CLASS);
		initEReference(getConstruction_FirstStep(), this.getComponent(),  null, 
			"firstStep", null, 0, 1, Construction.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getConstruction_Name(), ecorePackage.getEString(),
			"name", null, 0, 1, Construction.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, IS_ID, IS_UNIQUE,
			!IS_DERIVED, IS_ORDERED);
		initEReference(getConstruction_Next(), this.getConstruction(),  null, 
			"next", null, 0, 1, Construction.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
				
		initEClass(componentEClass, Component.class, "Component", IS_ABSTRACT, !IS_INTERFACE,
			IS_GENERATED_INSTANCE_CLASS);
		initEReference(getComponent_NextStep(), this.getComponent(),  null, 
			"nextStep", null, 0, 1, Component.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getComponent_Description(), ecorePackage.getEString(),
			"description", null, 0, 1, Component.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, IS_ID, IS_UNIQUE,
			!IS_DERIVED, IS_ORDERED);
		
		initEClass(cellarEClass, Cellar.class, "Cellar", !IS_ABSTRACT, !IS_INTERFACE,
			IS_GENERATED_INSTANCE_CLASS);
		
		initEClass(basementEClass, Basement.class, "Basement", !IS_ABSTRACT, !IS_INTERFACE,
			IS_GENERATED_INSTANCE_CLASS);
		
		initEClass(saddleRoofEClass, SaddleRoof.class, "SaddleRoof", !IS_ABSTRACT, !IS_INTERFACE,
			IS_GENERATED_INSTANCE_CLASS);
		
		
		// Initialize enums and add enum literals
		
		// Initialize data types
		
		// Create resource
		createResource(eNS_URI);
	}

} 

