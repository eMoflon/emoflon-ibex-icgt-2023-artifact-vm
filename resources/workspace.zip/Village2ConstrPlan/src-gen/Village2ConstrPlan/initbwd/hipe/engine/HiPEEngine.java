package Village2ConstrPlan.initbwd.hipe.engine;

import akka.actor.ActorRef;
import akka.actor.Props;

import Village2ConstrPlan.initbwd.hipe.engine.actor.NotificationActor;
import Village2ConstrPlan.initbwd.hipe.engine.actor.DispatchActor;
import Village2ConstrPlan.initbwd.hipe.engine.actor.localsearch.Corner2Constr_cst_firstStep_outgoing_TRG__FILTER_NAC_TRG_1_localSearch;
import Village2ConstrPlan.initbwd.hipe.engine.actor.localsearch.Corner2Constr__BWD_5_localSearch;
import Village2ConstrPlan.initbwd.hipe.engine.actor.localsearch.Corner2Constr_h_nextHouse_incoming_SRC__FILTER_NAC_SRC_12_localSearch;
import Village2ConstrPlan.initbwd.hipe.engine.actor.localsearch.Corner2Constr__CONSISTENCY_15_localSearch;
import Village2ConstrPlan.initbwd.hipe.engine.actor.localsearch.Cube2Constr_ncst_firstStep_outgoing_TRG__FILTER_NAC_TRG_25_localSearch;
import Village2ConstrPlan.initbwd.hipe.engine.actor.localsearch.Cube2Constr__BWD_29_localSearch;
import Village2ConstrPlan.initbwd.hipe.engine.actor.localsearch.Cube2Constr_nh_streetCorner_incoming_SRC__FILTER_NAC_SRC_37_localSearch;
import Village2ConstrPlan.initbwd.hipe.engine.actor.localsearch.Cube2Constr__CONSISTENCY_40_localSearch;
import Village2ConstrPlan.initbwd.hipe.engine.actor.localsearch.Villa2Constr_ncst_firstStep_outgoing_TRG__FILTER_NAC_TRG_51_localSearch;
import Village2ConstrPlan.initbwd.hipe.engine.actor.localsearch.Villa2Constr__BWD_55_localSearch;
import Village2ConstrPlan.initbwd.hipe.engine.actor.localsearch.Villa2Constr_nh_streetCorner_incoming_SRC__FILTER_NAC_SRC_63_localSearch;
import Village2ConstrPlan.initbwd.hipe.engine.actor.localsearch.Villa2Constr__CONSISTENCY_66_localSearch;
import Village2ConstrPlan.initbwd.hipe.engine.actor.localsearch.VillageSquare2PlanCollection__CONSISTENCY_78_localSearch;

import hipe.engine.IHiPEEngine;
import hipe.engine.message.InitGenReferenceActor;

import hipe.generic.actor.GenericObjectActor;
import hipe.generic.actor.GenericReferenceActor;
import hipe.generic.actor.GenericProductionActor;
import hipe.generic.actor.junction.*;

import hipe.network.*;

public class HiPEEngine extends IHiPEEngine{
	
	public HiPEEngine(HiPENetwork network) {
		super(network);
	}
	
	public HiPEEngine() {
		super();
	}
	
	@Override
	public String getClassLocation() {
		return getClass().getProtectionDomain().getCodeSource().getLocation().getPath().toString();
	}
	
	@Override
	public String getPackageName() {
		return getClass().getPackageName();
	}
	
	@Override
	protected ActorRef getDispatchActor() {
		return system.actorOf(
			Props.create(DispatchActor.class, () -> new DispatchActor(name2actor, incUtil)),
			"DispatchActor");
	}
	
	@Override
	protected ActorRef getNotificationActor(boolean cascadingNotifications) {
		return system.actorOf(
			Props.create(NotificationActor.class, () -> new NotificationActor(dispatcher, incUtil, cascadingNotifications)), 
			"NotificationActor");
	}
	
	@Override
	public void createProductionNodes() {
		classes.put("Corner2Constr__BWD_production", GenericProductionActor.class);
		productionNodes2pattern.put("Corner2Constr__BWD_production", "Corner2Constr__BWD");
		classes.put("Corner2Constr__CONSISTENCY_production", GenericProductionActor.class);
		productionNodes2pattern.put("Corner2Constr__CONSISTENCY_production", "Corner2Constr__CONSISTENCY");
		classes.put("Corner2Constr_cst_firstStep_outgoing_TRG__FILTER_NAC_TRG_production", GenericProductionActor.class);
		productionNodes2pattern.put("Corner2Constr_cst_firstStep_outgoing_TRG__FILTER_NAC_TRG_production", "Corner2Constr_cst_firstStep_outgoing_TRG__FILTER_NAC_TRG");
		classes.put("Corner2Constr_h_nextHouse_incoming_SRC__FILTER_NAC_SRC_production", GenericProductionActor.class);
		productionNodes2pattern.put("Corner2Constr_h_nextHouse_incoming_SRC__FILTER_NAC_SRC_production", "Corner2Constr_h_nextHouse_incoming_SRC__FILTER_NAC_SRC");
		classes.put("Cube2Constr__BWD_production", GenericProductionActor.class);
		productionNodes2pattern.put("Cube2Constr__BWD_production", "Cube2Constr__BWD");
		classes.put("Cube2Constr__CONSISTENCY_production", GenericProductionActor.class);
		productionNodes2pattern.put("Cube2Constr__CONSISTENCY_production", "Cube2Constr__CONSISTENCY");
		classes.put("Cube2Constr_ncst_firstStep_outgoing_TRG__FILTER_NAC_TRG_production", GenericProductionActor.class);
		productionNodes2pattern.put("Cube2Constr_ncst_firstStep_outgoing_TRG__FILTER_NAC_TRG_production", "Cube2Constr_ncst_firstStep_outgoing_TRG__FILTER_NAC_TRG");
		classes.put("Cube2Constr_nh_streetCorner_incoming_SRC__FILTER_NAC_SRC_production", GenericProductionActor.class);
		productionNodes2pattern.put("Cube2Constr_nh_streetCorner_incoming_SRC__FILTER_NAC_SRC_production", "Cube2Constr_nh_streetCorner_incoming_SRC__FILTER_NAC_SRC");
		classes.put("Villa2Constr__BWD_production", GenericProductionActor.class);
		productionNodes2pattern.put("Villa2Constr__BWD_production", "Villa2Constr__BWD");
		classes.put("Villa2Constr__CONSISTENCY_production", GenericProductionActor.class);
		productionNodes2pattern.put("Villa2Constr__CONSISTENCY_production", "Villa2Constr__CONSISTENCY");
		classes.put("Villa2Constr_ncst_firstStep_outgoing_TRG__FILTER_NAC_TRG_production", GenericProductionActor.class);
		productionNodes2pattern.put("Villa2Constr_ncst_firstStep_outgoing_TRG__FILTER_NAC_TRG_production", "Villa2Constr_ncst_firstStep_outgoing_TRG__FILTER_NAC_TRG");
		classes.put("Villa2Constr_nh_streetCorner_incoming_SRC__FILTER_NAC_SRC_production", GenericProductionActor.class);
		productionNodes2pattern.put("Villa2Constr_nh_streetCorner_incoming_SRC__FILTER_NAC_SRC_production", "Villa2Constr_nh_streetCorner_incoming_SRC__FILTER_NAC_SRC");
		classes.put("VillageSquare2PlanCollection__BWD_production", GenericProductionActor.class);
		productionNodes2pattern.put("VillageSquare2PlanCollection__BWD_production", "VillageSquare2PlanCollection__BWD");
		classes.put("VillageSquare2PlanCollection__CONSISTENCY_production", GenericProductionActor.class);
		productionNodes2pattern.put("VillageSquare2PlanCollection__CONSISTENCY_production", "VillageSquare2PlanCollection__CONSISTENCY");
		
	}
	
	@Override
	public void createJunctionNodes() {
		classes.put("Corner2Constr_cst_firstStep_outgoing_TRG__FILTER_NAC_TRG_1_localSearch", Corner2Constr_cst_firstStep_outgoing_TRG__FILTER_NAC_TRG_1_localSearch.class);
		classes.put("Corner2Constr__BWD_5_localSearch", Corner2Constr__BWD_5_localSearch.class);
		classes.put("Corner2Constr_h_nextHouse_incoming_SRC__FILTER_NAC_SRC_12_localSearch", Corner2Constr_h_nextHouse_incoming_SRC__FILTER_NAC_SRC_12_localSearch.class);
		classes.put("Corner2Constr__CONSISTENCY_15_localSearch", Corner2Constr__CONSISTENCY_15_localSearch.class);
		classes.put("Cube2Constr_ncst_firstStep_outgoing_TRG__FILTER_NAC_TRG_25_localSearch", Cube2Constr_ncst_firstStep_outgoing_TRG__FILTER_NAC_TRG_25_localSearch.class);
		classes.put("Cube2Constr__BWD_29_localSearch", Cube2Constr__BWD_29_localSearch.class);
		classes.put("Cube2Constr_nh_streetCorner_incoming_SRC__FILTER_NAC_SRC_37_localSearch", Cube2Constr_nh_streetCorner_incoming_SRC__FILTER_NAC_SRC_37_localSearch.class);
		classes.put("Cube2Constr__CONSISTENCY_40_localSearch", Cube2Constr__CONSISTENCY_40_localSearch.class);
		classes.put("Villa2Constr_ncst_firstStep_outgoing_TRG__FILTER_NAC_TRG_51_localSearch", Villa2Constr_ncst_firstStep_outgoing_TRG__FILTER_NAC_TRG_51_localSearch.class);
		classes.put("Villa2Constr__BWD_55_localSearch", Villa2Constr__BWD_55_localSearch.class);
		classes.put("Villa2Constr_nh_streetCorner_incoming_SRC__FILTER_NAC_SRC_63_localSearch", Villa2Constr_nh_streetCorner_incoming_SRC__FILTER_NAC_SRC_63_localSearch.class);
		classes.put("Villa2Constr__CONSISTENCY_66_localSearch", Villa2Constr__CONSISTENCY_66_localSearch.class);
		classes.put("VillageSquare2PlanCollection__CONSISTENCY_78_localSearch", VillageSquare2PlanCollection__CONSISTENCY_78_localSearch.class);
	}
	
	@Override
	public void createReferenceNodes() {
		
	}
	
	@Override
	public void createObjectNodes() {
		classes.put("PlanCollection_object",PlanCollection_object.class);
		classes.put("VillageSquare2PlanCollection_object",VillageSquare2PlanCollection_object.class);
		classes.put("Component_object",Component_object.class);
		classes.put("Corner2Constr__Marker_object",Corner2Constr__Marker_object.class);
		classes.put("Cellar_object",Cellar_object.class);
		classes.put("Cube2Constr__Marker_object",Cube2Constr__Marker_object.class);
		classes.put("SaddleRoof_object",SaddleRoof_object.class);
		classes.put("Villa2Constr__Marker_object",Villa2Constr__Marker_object.class);
		classes.put("VillageSquare2PlanCollection__Marker_object",VillageSquare2PlanCollection__Marker_object.class);
		classes.put("VillageSquare_object_SP0",VillageSquare_object_SP0.class);
		classes.put("VillageSquare_object_SP1",VillageSquare_object_SP1.class);
		classes.put("Basement_object_SP0",Basement_object_SP0.class);
		classes.put("Basement_object_SP1",Basement_object_SP1.class);
		classes.put("Construction_object_SP0",Construction_object_SP0.class);
		classes.put("Construction_object_SP1",Construction_object_SP1.class);
		classes.put("Construction_object_SP2",Construction_object_SP2.class);
		classes.put("Plan_object_SP0",Plan_object_SP0.class);
		classes.put("Plan_object_SP1",Plan_object_SP1.class);
		classes.put("House_object_SP0",House_object_SP0.class);
		classes.put("House_object_SP1",House_object_SP1.class);
		classes.put("House2Constr_object_SP0",House2Constr_object_SP0.class);
		classes.put("House2Constr_object_SP1",House2Constr_object_SP1.class);
		
	}
	
	@Override
	public void initializeReferenceNodes() {
	}
}

class PlanCollection_object extends GenericObjectActor<ConstructionPlan.PlanCollection> { }
class VillageSquare2PlanCollection_object extends GenericObjectActor<Village2ConstrPlan.VillageSquare2PlanCollection> { }
class Component_object extends GenericObjectActor<ConstructionPlan.Component> { }
class Corner2Constr__Marker_object extends GenericObjectActor<Village2ConstrPlan.Corner2Constr__Marker> { }
class Cellar_object extends GenericObjectActor<ConstructionPlan.Cellar> { }
class Cube2Constr__Marker_object extends GenericObjectActor<Village2ConstrPlan.Cube2Constr__Marker> { }
class SaddleRoof_object extends GenericObjectActor<ConstructionPlan.SaddleRoof> { }
class Villa2Constr__Marker_object extends GenericObjectActor<Village2ConstrPlan.Villa2Constr__Marker> { }
class VillageSquare2PlanCollection__Marker_object extends GenericObjectActor<Village2ConstrPlan.VillageSquare2PlanCollection__Marker> { }
class VillageSquare_object_SP0 extends GenericObjectActor<Village.VillageSquare> { }
class VillageSquare_object_SP1 extends GenericObjectActor<Village.VillageSquare> { }
class Basement_object_SP0 extends GenericObjectActor<ConstructionPlan.Basement> { }
class Basement_object_SP1 extends GenericObjectActor<ConstructionPlan.Basement> { }
class Construction_object_SP0 extends GenericObjectActor<ConstructionPlan.Construction> { }
class Construction_object_SP1 extends GenericObjectActor<ConstructionPlan.Construction> { }
class Construction_object_SP2 extends GenericObjectActor<ConstructionPlan.Construction> { }
class Plan_object_SP0 extends GenericObjectActor<ConstructionPlan.Plan> { }
class Plan_object_SP1 extends GenericObjectActor<ConstructionPlan.Plan> { }
class House_object_SP0 extends GenericObjectActor<Village.House> { }
class House_object_SP1 extends GenericObjectActor<Village.House> { }
class House2Constr_object_SP0 extends GenericObjectActor<Village2ConstrPlan.House2Constr> { }
class House2Constr_object_SP1 extends GenericObjectActor<Village2ConstrPlan.House2Constr> { }


