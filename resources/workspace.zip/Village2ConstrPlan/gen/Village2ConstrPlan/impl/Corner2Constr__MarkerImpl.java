package Village2ConstrPlan.impl;

import Village2ConstrPlan.Village2ConstrPlanPackage;
import runtime.RuntimePackage;
import Village2ConstrPlan.Village2ConstrPlanPackage;

import org.emoflon.smartemf.runtime.*;
import org.emoflon.smartemf.runtime.collections.*;
import org.emoflon.smartemf.persistence.SmartEMFResource;
import org.emoflon.smartemf.runtime.notification.SmartEMFNotification;
import org.emoflon.smartemf.runtime.notification.NotifyStatus;

import java.util.function.Consumer;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EcoreFactory;
import org.eclipse.emf.ecore.EcorePackage;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.resource.Resource;

public class Corner2Constr__MarkerImpl extends SmartObject implements Village2ConstrPlan.Corner2Constr__Marker {

    protected runtime.Protocol protocol = null;
    protected Village.House CREATE__SRC__h = null;
    protected Village.VillageSquare CONTEXT__SRC__vs = null;
    protected ConstructionPlan.Basement CREATE__TRG__bt = null;
    protected ConstructionPlan.Construction CREATE__TRG__cst = null;
    protected ConstructionPlan.Plan CREATE__TRG__p = null;
    protected ConstructionPlan.PlanCollection CONTEXT__TRG__pc = null;
    protected Village2ConstrPlan.House2Constr CREATE__CORR__h2cst = null;
    protected Village2ConstrPlan.VillageSquare2PlanCollection CONTEXT__CORR__vs2pc = null;
	
	protected Corner2Constr__MarkerImpl() {
		super(Village2ConstrPlanPackage.Literals.CORNER2_CONSTR___MARKER);
	}
	
    
    @Override
    public runtime.Protocol getProtocol() {
    	return this.protocol;
    }
    
    @Override
    public void setProtocol(runtime.Protocol value) {
    	
    	Object oldValue = this.protocol;
    	
    	if(value == null && oldValue == null)
    		return;
    		
    	if(value != null && value.equals(oldValue))
    		return;
    		
    	
    	
    		        this.protocol = value;
    	
    	
    	        	sendNotification(SmartEMFNotification.createSetNotification(this, RuntimePackage.Literals.TGG_RULE_APPLICATION__PROTOCOL, oldValue, value, -1));
    	        	
    	
    	        	if(oldValue != null) {
    	        		((SmartObject) oldValue).eInverseRemove(this, RuntimePackage.Literals.PROTOCOL__STEPS);
    	        	}
    	        	if(value != null) {
    	        		((SmartObject) value).eInverseAdd(this, RuntimePackage.Literals.PROTOCOL__STEPS);
    	        	}
    }
    
    private void setProtocolAsInverse(runtime.Protocol value) {
			    
			    Object oldValue = this.protocol;
			    
			    if(value == null && oldValue == null)
			    	return;
			    	
			    if(value != null && value.equals(oldValue))
			    	return;
			    	
			    
			    
			    	        this.protocol = value;
			    
			    
			            	sendNotification(SmartEMFNotification.createSetNotification(this, RuntimePackage.Literals.TGG_RULE_APPLICATION__PROTOCOL, oldValue, value, -1));
			            	
    }
    
    @Override
    public Village.House getCREATE__SRC__h() {
    	return this.CREATE__SRC__h;
    }
    
    @Override
    public void setCREATE__SRC__h(Village.House value) {
    	
    	Object oldValue = this.CREATE__SRC__h;
    	
    	if(value == null && oldValue == null)
    		return;
    		
    	if(value != null && value.equals(oldValue))
    		return;
    		
    	
    	
    		        this.CREATE__SRC__h = value;
    	
    	
    	        	sendNotification(SmartEMFNotification.createSetNotification(this, Village2ConstrPlanPackage.Literals.CORNER2_CONSTR___MARKER__CREAT_E__SR_C__H, oldValue, value, -1));
    	        	
    	        	if(Village2ConstrPlanPackage.Literals.CORNER2_CONSTR___MARKER__CREAT_E__SR_C__H.getEOpposite() != null) {
    	        		if(oldValue != null) {
    	        			((SmartObject) oldValue).eInverseRemove(this, Village2ConstrPlanPackage.Literals.CORNER2_CONSTR___MARKER__CREAT_E__SR_C__H.getEOpposite());
    	        		}
    	        		if(value != null) {
    	        		    ((SmartObject) value).eInverseAdd(this, Village2ConstrPlanPackage.Literals.CORNER2_CONSTR___MARKER__CREAT_E__SR_C__H.getEOpposite());
    	        		}
    	        	}
    }
    
    
    @Override
    public Village.VillageSquare getCONTEXT__SRC__vs() {
    	return this.CONTEXT__SRC__vs;
    }
    
    @Override
    public void setCONTEXT__SRC__vs(Village.VillageSquare value) {
    	
    	Object oldValue = this.CONTEXT__SRC__vs;
    	
    	if(value == null && oldValue == null)
    		return;
    		
    	if(value != null && value.equals(oldValue))
    		return;
    		
    	
    	
    		        this.CONTEXT__SRC__vs = value;
    	
    	
    	        	sendNotification(SmartEMFNotification.createSetNotification(this, Village2ConstrPlanPackage.Literals.CORNER2_CONSTR___MARKER__CONTEX_T__SR_C__VS, oldValue, value, -1));
    	        	
    	        	if(Village2ConstrPlanPackage.Literals.CORNER2_CONSTR___MARKER__CONTEX_T__SR_C__VS.getEOpposite() != null) {
    	        		if(oldValue != null) {
    	        			((SmartObject) oldValue).eInverseRemove(this, Village2ConstrPlanPackage.Literals.CORNER2_CONSTR___MARKER__CONTEX_T__SR_C__VS.getEOpposite());
    	        		}
    	        		if(value != null) {
    	        		    ((SmartObject) value).eInverseAdd(this, Village2ConstrPlanPackage.Literals.CORNER2_CONSTR___MARKER__CONTEX_T__SR_C__VS.getEOpposite());
    	        		}
    	        	}
    }
    
    
    @Override
    public ConstructionPlan.Basement getCREATE__TRG__bt() {
    	return this.CREATE__TRG__bt;
    }
    
    @Override
    public void setCREATE__TRG__bt(ConstructionPlan.Basement value) {
    	
    	Object oldValue = this.CREATE__TRG__bt;
    	
    	if(value == null && oldValue == null)
    		return;
    		
    	if(value != null && value.equals(oldValue))
    		return;
    		
    	
    	
    		        this.CREATE__TRG__bt = value;
    	
    	
    	        	sendNotification(SmartEMFNotification.createSetNotification(this, Village2ConstrPlanPackage.Literals.CORNER2_CONSTR___MARKER__CREAT_E__TR_G__BT, oldValue, value, -1));
    	        	
    	        	if(Village2ConstrPlanPackage.Literals.CORNER2_CONSTR___MARKER__CREAT_E__TR_G__BT.getEOpposite() != null) {
    	        		if(oldValue != null) {
    	        			((SmartObject) oldValue).eInverseRemove(this, Village2ConstrPlanPackage.Literals.CORNER2_CONSTR___MARKER__CREAT_E__TR_G__BT.getEOpposite());
    	        		}
    	        		if(value != null) {
    	        		    ((SmartObject) value).eInverseAdd(this, Village2ConstrPlanPackage.Literals.CORNER2_CONSTR___MARKER__CREAT_E__TR_G__BT.getEOpposite());
    	        		}
    	        	}
    }
    
    
    @Override
    public ConstructionPlan.Construction getCREATE__TRG__cst() {
    	return this.CREATE__TRG__cst;
    }
    
    @Override
    public void setCREATE__TRG__cst(ConstructionPlan.Construction value) {
    	
    	Object oldValue = this.CREATE__TRG__cst;
    	
    	if(value == null && oldValue == null)
    		return;
    		
    	if(value != null && value.equals(oldValue))
    		return;
    		
    	
    	
    		        this.CREATE__TRG__cst = value;
    	
    	
    	        	sendNotification(SmartEMFNotification.createSetNotification(this, Village2ConstrPlanPackage.Literals.CORNER2_CONSTR___MARKER__CREAT_E__TR_G__CST, oldValue, value, -1));
    	        	
    	        	if(Village2ConstrPlanPackage.Literals.CORNER2_CONSTR___MARKER__CREAT_E__TR_G__CST.getEOpposite() != null) {
    	        		if(oldValue != null) {
    	        			((SmartObject) oldValue).eInverseRemove(this, Village2ConstrPlanPackage.Literals.CORNER2_CONSTR___MARKER__CREAT_E__TR_G__CST.getEOpposite());
    	        		}
    	        		if(value != null) {
    	        		    ((SmartObject) value).eInverseAdd(this, Village2ConstrPlanPackage.Literals.CORNER2_CONSTR___MARKER__CREAT_E__TR_G__CST.getEOpposite());
    	        		}
    	        	}
    }
    
    
    @Override
    public ConstructionPlan.Plan getCREATE__TRG__p() {
    	return this.CREATE__TRG__p;
    }
    
    @Override
    public void setCREATE__TRG__p(ConstructionPlan.Plan value) {
    	
    	Object oldValue = this.CREATE__TRG__p;
    	
    	if(value == null && oldValue == null)
    		return;
    		
    	if(value != null && value.equals(oldValue))
    		return;
    		
    	
    	
    		        this.CREATE__TRG__p = value;
    	
    	
    	        	sendNotification(SmartEMFNotification.createSetNotification(this, Village2ConstrPlanPackage.Literals.CORNER2_CONSTR___MARKER__CREAT_E__TR_G__P, oldValue, value, -1));
    	        	
    	        	if(Village2ConstrPlanPackage.Literals.CORNER2_CONSTR___MARKER__CREAT_E__TR_G__P.getEOpposite() != null) {
    	        		if(oldValue != null) {
    	        			((SmartObject) oldValue).eInverseRemove(this, Village2ConstrPlanPackage.Literals.CORNER2_CONSTR___MARKER__CREAT_E__TR_G__P.getEOpposite());
    	        		}
    	        		if(value != null) {
    	        		    ((SmartObject) value).eInverseAdd(this, Village2ConstrPlanPackage.Literals.CORNER2_CONSTR___MARKER__CREAT_E__TR_G__P.getEOpposite());
    	        		}
    	        	}
    }
    
    
    @Override
    public ConstructionPlan.PlanCollection getCONTEXT__TRG__pc() {
    	return this.CONTEXT__TRG__pc;
    }
    
    @Override
    public void setCONTEXT__TRG__pc(ConstructionPlan.PlanCollection value) {
    	
    	Object oldValue = this.CONTEXT__TRG__pc;
    	
    	if(value == null && oldValue == null)
    		return;
    		
    	if(value != null && value.equals(oldValue))
    		return;
    		
    	
    	
    		        this.CONTEXT__TRG__pc = value;
    	
    	
    	        	sendNotification(SmartEMFNotification.createSetNotification(this, Village2ConstrPlanPackage.Literals.CORNER2_CONSTR___MARKER__CONTEX_T__TR_G__PC, oldValue, value, -1));
    	        	
    	        	if(Village2ConstrPlanPackage.Literals.CORNER2_CONSTR___MARKER__CONTEX_T__TR_G__PC.getEOpposite() != null) {
    	        		if(oldValue != null) {
    	        			((SmartObject) oldValue).eInverseRemove(this, Village2ConstrPlanPackage.Literals.CORNER2_CONSTR___MARKER__CONTEX_T__TR_G__PC.getEOpposite());
    	        		}
    	        		if(value != null) {
    	        		    ((SmartObject) value).eInverseAdd(this, Village2ConstrPlanPackage.Literals.CORNER2_CONSTR___MARKER__CONTEX_T__TR_G__PC.getEOpposite());
    	        		}
    	        	}
    }
    
    
    @Override
    public Village2ConstrPlan.House2Constr getCREATE__CORR__h2cst() {
    	return this.CREATE__CORR__h2cst;
    }
    
    @Override
    public void setCREATE__CORR__h2cst(Village2ConstrPlan.House2Constr value) {
    	
    	Object oldValue = this.CREATE__CORR__h2cst;
    	
    	if(value == null && oldValue == null)
    		return;
    		
    	if(value != null && value.equals(oldValue))
    		return;
    		
    	
    	
    		        this.CREATE__CORR__h2cst = value;
    	
    	
    	        	sendNotification(SmartEMFNotification.createSetNotification(this, Village2ConstrPlanPackage.Literals.CORNER2_CONSTR___MARKER__CREAT_E__COR_R__H2CST, oldValue, value, -1));
    	        	
    	        	if(Village2ConstrPlanPackage.Literals.CORNER2_CONSTR___MARKER__CREAT_E__COR_R__H2CST.getEOpposite() != null) {
    	        		if(oldValue != null) {
    	        			((SmartObject) oldValue).eInverseRemove(this, Village2ConstrPlanPackage.Literals.CORNER2_CONSTR___MARKER__CREAT_E__COR_R__H2CST.getEOpposite());
    	        		}
    	        		if(value != null) {
    	        		    ((SmartObject) value).eInverseAdd(this, Village2ConstrPlanPackage.Literals.CORNER2_CONSTR___MARKER__CREAT_E__COR_R__H2CST.getEOpposite());
    	        		}
    	        	}
    }
    
    
    @Override
    public Village2ConstrPlan.VillageSquare2PlanCollection getCONTEXT__CORR__vs2pc() {
    	return this.CONTEXT__CORR__vs2pc;
    }
    
    @Override
    public void setCONTEXT__CORR__vs2pc(Village2ConstrPlan.VillageSquare2PlanCollection value) {
    	
    	Object oldValue = this.CONTEXT__CORR__vs2pc;
    	
    	if(value == null && oldValue == null)
    		return;
    		
    	if(value != null && value.equals(oldValue))
    		return;
    		
    	
    	
    		        this.CONTEXT__CORR__vs2pc = value;
    	
    	
    	        	sendNotification(SmartEMFNotification.createSetNotification(this, Village2ConstrPlanPackage.Literals.CORNER2_CONSTR___MARKER__CONTEX_T__COR_R__VS2PC, oldValue, value, -1));
    	        	
    	        	if(Village2ConstrPlanPackage.Literals.CORNER2_CONSTR___MARKER__CONTEX_T__COR_R__VS2PC.getEOpposite() != null) {
    	        		if(oldValue != null) {
    	        			((SmartObject) oldValue).eInverseRemove(this, Village2ConstrPlanPackage.Literals.CORNER2_CONSTR___MARKER__CONTEX_T__COR_R__VS2PC.getEOpposite());
    	        		}
    	        		if(value != null) {
    	        		    ((SmartObject) value).eInverseAdd(this, Village2ConstrPlanPackage.Literals.CORNER2_CONSTR___MARKER__CONTEX_T__COR_R__VS2PC.getEOpposite());
    	        		}
    	        	}
    }
    

    @Override
    public void eSet(EStructuralFeature eFeature, Object newValue){
    	if (RuntimePackage.Literals.TGG_RULE_APPLICATION__PROTOCOL.equals(eFeature)) {
    		setProtocol((runtime.Protocol) newValue); 
    		return;
    	}
    	if (Village2ConstrPlanPackage.Literals.CORNER2_CONSTR___MARKER__CREAT_E__SR_C__H.equals(eFeature)) {
    		setCREATE__SRC__h((Village.House) newValue); 
    		return;
    	}
    	if (Village2ConstrPlanPackage.Literals.CORNER2_CONSTR___MARKER__CONTEX_T__SR_C__VS.equals(eFeature)) {
    		setCONTEXT__SRC__vs((Village.VillageSquare) newValue); 
    		return;
    	}
    	if (Village2ConstrPlanPackage.Literals.CORNER2_CONSTR___MARKER__CREAT_E__TR_G__BT.equals(eFeature)) {
    		setCREATE__TRG__bt((ConstructionPlan.Basement) newValue); 
    		return;
    	}
    	if (Village2ConstrPlanPackage.Literals.CORNER2_CONSTR___MARKER__CREAT_E__TR_G__CST.equals(eFeature)) {
    		setCREATE__TRG__cst((ConstructionPlan.Construction) newValue); 
    		return;
    	}
    	if (Village2ConstrPlanPackage.Literals.CORNER2_CONSTR___MARKER__CREAT_E__TR_G__P.equals(eFeature)) {
    		setCREATE__TRG__p((ConstructionPlan.Plan) newValue); 
    		return;
    	}
    	if (Village2ConstrPlanPackage.Literals.CORNER2_CONSTR___MARKER__CONTEX_T__TR_G__PC.equals(eFeature)) {
    		setCONTEXT__TRG__pc((ConstructionPlan.PlanCollection) newValue); 
    		return;
    	}
    	if (Village2ConstrPlanPackage.Literals.CORNER2_CONSTR___MARKER__CREAT_E__COR_R__H2CST.equals(eFeature)) {
    		setCREATE__CORR__h2cst((Village2ConstrPlan.House2Constr) newValue); 
    		return;
    	}
    	if (Village2ConstrPlanPackage.Literals.CORNER2_CONSTR___MARKER__CONTEX_T__COR_R__VS2PC.equals(eFeature)) {
    		setCONTEXT__CORR__vs2pc((Village2ConstrPlan.VillageSquare2PlanCollection) newValue); 
    		return;
    	}
    	eDynamicSet(eFeature, newValue);
    }
    
    @Override
    public void eUnset(EStructuralFeature eFeature){
    	if (RuntimePackage.Literals.TGG_RULE_APPLICATION__PROTOCOL.equals(eFeature)) {
    		setProtocol((runtime.Protocol)null); 
    		return;
    	}
    	if (Village2ConstrPlanPackage.Literals.CORNER2_CONSTR___MARKER__CREAT_E__SR_C__H.equals(eFeature)) {
    		setCREATE__SRC__h((Village.House)null); 
    		return;
    	}
    	if (Village2ConstrPlanPackage.Literals.CORNER2_CONSTR___MARKER__CONTEX_T__SR_C__VS.equals(eFeature)) {
    		setCONTEXT__SRC__vs((Village.VillageSquare)null); 
    		return;
    	}
    	if (Village2ConstrPlanPackage.Literals.CORNER2_CONSTR___MARKER__CREAT_E__TR_G__BT.equals(eFeature)) {
    		setCREATE__TRG__bt((ConstructionPlan.Basement)null); 
    		return;
    	}
    	if (Village2ConstrPlanPackage.Literals.CORNER2_CONSTR___MARKER__CREAT_E__TR_G__CST.equals(eFeature)) {
    		setCREATE__TRG__cst((ConstructionPlan.Construction)null); 
    		return;
    	}
    	if (Village2ConstrPlanPackage.Literals.CORNER2_CONSTR___MARKER__CREAT_E__TR_G__P.equals(eFeature)) {
    		setCREATE__TRG__p((ConstructionPlan.Plan)null); 
    		return;
    	}
    	if (Village2ConstrPlanPackage.Literals.CORNER2_CONSTR___MARKER__CONTEX_T__TR_G__PC.equals(eFeature)) {
    		setCONTEXT__TRG__pc((ConstructionPlan.PlanCollection)null); 
    		return;
    	}
    	if (Village2ConstrPlanPackage.Literals.CORNER2_CONSTR___MARKER__CREAT_E__COR_R__H2CST.equals(eFeature)) {
    		setCREATE__CORR__h2cst((Village2ConstrPlan.House2Constr)null); 
    		return;
    	}
    	if (Village2ConstrPlanPackage.Literals.CORNER2_CONSTR___MARKER__CONTEX_T__COR_R__VS2PC.equals(eFeature)) {
    		setCONTEXT__CORR__vs2pc((Village2ConstrPlan.VillageSquare2PlanCollection)null); 
    		return;
    	}
    	eDynamicUnset(eFeature);
    }

    @Override
    public String toString(){
		return super.toString();
    }

 	@Override
    public Object eGet(EStructuralFeature eFeature){
    	if (RuntimePackage.Literals.TGG_RULE_APPLICATION__PROTOCOL.equals(eFeature))
    		return getProtocol();
    	if (Village2ConstrPlanPackage.Literals.CORNER2_CONSTR___MARKER__CREAT_E__SR_C__H.equals(eFeature))
    		return getCREATE__SRC__h();
    	if (Village2ConstrPlanPackage.Literals.CORNER2_CONSTR___MARKER__CONTEX_T__SR_C__VS.equals(eFeature))
    		return getCONTEXT__SRC__vs();
    	if (Village2ConstrPlanPackage.Literals.CORNER2_CONSTR___MARKER__CREAT_E__TR_G__BT.equals(eFeature))
    		return getCREATE__TRG__bt();
    	if (Village2ConstrPlanPackage.Literals.CORNER2_CONSTR___MARKER__CREAT_E__TR_G__CST.equals(eFeature))
    		return getCREATE__TRG__cst();
    	if (Village2ConstrPlanPackage.Literals.CORNER2_CONSTR___MARKER__CREAT_E__TR_G__P.equals(eFeature))
    		return getCREATE__TRG__p();
    	if (Village2ConstrPlanPackage.Literals.CORNER2_CONSTR___MARKER__CONTEX_T__TR_G__PC.equals(eFeature))
    		return getCONTEXT__TRG__pc();
    	if (Village2ConstrPlanPackage.Literals.CORNER2_CONSTR___MARKER__CREAT_E__COR_R__H2CST.equals(eFeature))
    		return getCREATE__CORR__h2cst();
    	if (Village2ConstrPlanPackage.Literals.CORNER2_CONSTR___MARKER__CONTEX_T__COR_R__VS2PC.equals(eFeature))
    		return getCONTEXT__CORR__vs2pc();
    	return eDynamicGet(eFeature);
    }

    @Override
    public Object eGet(int featureID, boolean resolve, boolean coreType){
    	throw new UnsupportedOperationException("This method has been deactivated since it is not always safe to use.");
    }
    
    @Override
    public void eInverseAdd(Object otherEnd, EStructuralFeature feature) {
if (RuntimePackage.Literals.TGG_RULE_APPLICATION__PROTOCOL.equals(feature)) {
setProtocolAsInverse((runtime.Protocol) otherEnd); 
 	return;
			        }	
	    if(feature == null)
	    	return;
	    	
    	eDynamicInverseAdd(otherEnd, feature);
	    	}
    	
    @Override
	    	public void eInverseRemove(Object otherEnd, EStructuralFeature feature) {
if (RuntimePackage.Literals.TGG_RULE_APPLICATION__PROTOCOL.equals(feature)) {
setProtocolAsInverse(null); 
 	return;
			        }
	    if(feature == null)
	    	return;
	    		    		
    	eDynamicInverseRemove(otherEnd, feature);
	    	}
    
    @Override
    /**
    * This method sets the resource and generates REMOVING_ADAPTER and ADD notifications
    */
    protected void setResourceOfContainments(Consumer<SmartObject> setResourceCall) {
	    	}
	    	
	    	@Override
	    	/**
	    	* This method sets the resource and only generates REMOVING_ADAPTER notifications (no ADD messages)
	    	*/
    protected void setResourceOfContainmentsSilently(Resource r) { 		
	    	}
}
