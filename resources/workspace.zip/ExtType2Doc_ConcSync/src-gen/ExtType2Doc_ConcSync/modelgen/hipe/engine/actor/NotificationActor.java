package ExtType2Doc_ConcSync.modelgen.hipe.engine.actor;

import java.util.Collection;
import java.util.LinkedList;

import org.eclipse.emf.ecore.EObject;

import akka.actor.ActorRef;

import hipe.engine.actor.GenericNotificationActor;
import hipe.engine.util.IncUtil;

public class NotificationActor extends GenericNotificationActor {
	
	public NotificationActor(ActorRef dispatchActor, IncUtil incUtil, boolean cascadingNotifications) {
		super(dispatchActor, incUtil, cascadingNotifications);
	}
	
	@Override
	protected void initializeExploration() {
		explorationConsumer.put(ExtType2Doc_ConcSync.ExtType2Doc_ConcSyncPackage.eINSTANCE.getType2Doc__Marker(), obj -> {
			Collection<EObject> children = new LinkedList<>();
			return children;
		});
		explorationConsumer.put(ExtType2Doc_ConcSync.ExtType2Doc_ConcSyncPackage.eINSTANCE.getGlossaryEntry__Marker(), obj -> {
			Collection<EObject> children = new LinkedList<>();
			return children;
		});
		explorationConsumer.put(ExtTypeModel.ExtTypeModelPackage.eINSTANCE.getType(), obj -> {
			Collection<EObject> children = new LinkedList<>();
			ExtTypeModel.Type _type = (ExtTypeModel.Type) obj;
			children.addAll(_type.getMethods());
			children.addAll(_type.getFields());
			return children;
		});
		explorationConsumer.put(ExtTypeModel.ExtTypeModelPackage.eINSTANCE.getMethod(), obj -> {
			Collection<EObject> children = new LinkedList<>();
			ExtTypeModel.Method _method = (ExtTypeModel.Method) obj;
			children.addAll(_method.getParams());
			children.addAll(_method.getDocs());
			return children;
		});
		explorationConsumer.put(ExtType2Doc_ConcSync.ExtType2Doc_ConcSyncPackage.eINSTANCE.getField2Entry__Marker(), obj -> {
			Collection<EObject> children = new LinkedList<>();
			return children;
		});
		explorationConsumer.put(ExtDocModel.ExtDocModelPackage.eINSTANCE.getFolder(), obj -> {
			Collection<EObject> children = new LinkedList<>();
			ExtDocModel.Folder _folder = (ExtDocModel.Folder) obj;
			children.addAll(_folder.getDocs());
			children.addAll(_folder.getSubFolder());
			return children;
		});
		explorationConsumer.put(ExtTypeModel.ExtTypeModelPackage.eINSTANCE.getField(), obj -> {
			Collection<EObject> children = new LinkedList<>();
			return children;
		});
		explorationConsumer.put(ExtType2Doc_ConcSync.ExtType2Doc_ConcSyncPackage.eINSTANCE.getPackage2Folder(), obj -> {
			Collection<EObject> children = new LinkedList<>();
			return children;
		});
		explorationConsumer.put(ExtType2Doc_ConcSync.ExtType2Doc_ConcSyncPackage.eINSTANCE.getParam2Entry__Marker(), obj -> {
			Collection<EObject> children = new LinkedList<>();
			return children;
		});
		explorationConsumer.put(ExtType2Doc_ConcSync.ExtType2Doc_ConcSyncPackage.eINSTANCE.getParam2Entry(), obj -> {
			Collection<EObject> children = new LinkedList<>();
			return children;
		});
		explorationConsumer.put(ExtType2Doc_ConcSync.ExtType2Doc_ConcSyncPackage.eINSTANCE.getProject2DocContainer(), obj -> {
			Collection<EObject> children = new LinkedList<>();
			return children;
		});
		explorationConsumer.put(ExtType2Doc_ConcSync.ExtType2Doc_ConcSyncPackage.eINSTANCE.getMethod2Entry__Marker(), obj -> {
			Collection<EObject> children = new LinkedList<>();
			return children;
		});
		explorationConsumer.put(ExtDocModel.ExtDocModelPackage.eINSTANCE.getGlossary(), obj -> {
			Collection<EObject> children = new LinkedList<>();
			ExtDocModel.Glossary _glossary = (ExtDocModel.Glossary) obj;
			children.addAll(_glossary.getEntries());
			return children;
		});
		explorationConsumer.put(ExtType2Doc_ConcSync.ExtType2Doc_ConcSyncPackage.eINSTANCE.getMethod2Entry(), obj -> {
			Collection<EObject> children = new LinkedList<>();
			return children;
		});
		explorationConsumer.put(ExtType2Doc_ConcSync.ExtType2Doc_ConcSyncPackage.eINSTANCE.getField2Entry(), obj -> {
			Collection<EObject> children = new LinkedList<>();
			return children;
		});
		explorationConsumer.put(ExtDocModel.ExtDocModelPackage.eINSTANCE.getDocContainer(), obj -> {
			Collection<EObject> children = new LinkedList<>();
			ExtDocModel.DocContainer _doccontainer = (ExtDocModel.DocContainer) obj;
			children.addAll(_doccontainer.getFolders());
			if(_doccontainer.getGlossary() != null)
				children.add(_doccontainer.getGlossary());
			return children;
		});
		explorationConsumer.put(ExtTypeModel.ExtTypeModelPackage.eINSTANCE.getParameter(), obj -> {
			Collection<EObject> children = new LinkedList<>();
			return children;
		});
		explorationConsumer.put(ExtTypeModel.ExtTypeModelPackage.eINSTANCE.getJavaDoc(), obj -> {
			Collection<EObject> children = new LinkedList<>();
			return children;
		});
		explorationConsumer.put(ExtType2Doc_ConcSync.ExtType2Doc_ConcSyncPackage.eINSTANCE.getGlossaryLink__Marker(), obj -> {
			Collection<EObject> children = new LinkedList<>();
			return children;
		});
		explorationConsumer.put(ExtDocModel.ExtDocModelPackage.eINSTANCE.getAnnotation(), obj -> {
			Collection<EObject> children = new LinkedList<>();
			return children;
		});
		explorationConsumer.put(runtime.impl.RuntimePackageImpl.eINSTANCE.getTempContainer(), obj -> {
			Collection<EObject> children = new LinkedList<>();
			runtime.TempContainer _tempcontainer = (runtime.TempContainer) obj;
			children.addAll(_tempcontainer.getObjects());
			return children;
		});
		explorationConsumer.put(ExtType2Doc_ConcSync.ExtType2Doc_ConcSyncPackage.eINSTANCE.getType2Doc(), obj -> {
			Collection<EObject> children = new LinkedList<>();
			return children;
		});
		explorationConsumer.put(ExtDocModel.ExtDocModelPackage.eINSTANCE.getGlossaryEntry(), obj -> {
			Collection<EObject> children = new LinkedList<>();
			return children;
		});
		explorationConsumer.put(runtime.impl.RuntimePackageImpl.eINSTANCE.getProtocol(), obj -> {
			Collection<EObject> children = new LinkedList<>();
			runtime.Protocol _protocol = (runtime.Protocol) obj;
			children.addAll(_protocol.getSteps());
			return children;
		});
		explorationConsumer.put(ExtType2Doc_ConcSync.ExtType2Doc_ConcSyncPackage.eINSTANCE.getGlossary__Marker(), obj -> {
			Collection<EObject> children = new LinkedList<>();
			return children;
		});
		explorationConsumer.put(ExtType2Doc_ConcSync.ExtType2Doc_ConcSyncPackage.eINSTANCE.getJDoc2Annotation__Marker(), obj -> {
			Collection<EObject> children = new LinkedList<>();
			return children;
		});
		explorationConsumer.put(ExtType2Doc_ConcSync.ExtType2Doc_ConcSyncPackage.eINSTANCE.getProject2DocCont__Marker(), obj -> {
			Collection<EObject> children = new LinkedList<>();
			return children;
		});
		explorationConsumer.put(runtime.impl.RuntimePackageImpl.eINSTANCE.getCorrespondenceNode(), obj -> {
			Collection<EObject> children = new LinkedList<>();
			return children;
		});
		explorationConsumer.put(ExtDocModel.ExtDocModelPackage.eINSTANCE.getEntry(), obj -> {
			Collection<EObject> children = new LinkedList<>();
			ExtDocModel.Entry _entry = (ExtDocModel.Entry) obj;
			children.addAll(_entry.getAnnotations());
			return children;
		});
		explorationConsumer.put(ExtType2Doc_ConcSync.ExtType2Doc_ConcSyncPackage.eINSTANCE.getExtendingType2Doc__Marker(), obj -> {
			Collection<EObject> children = new LinkedList<>();
			return children;
		});
		explorationConsumer.put(ExtDocModel.ExtDocModelPackage.eINSTANCE.getNamedElement(), obj -> {
			Collection<EObject> children = new LinkedList<>();
			return children;
		});
		explorationConsumer.put(ExtTypeModel.ExtTypeModelPackage.eINSTANCE.getProject(), obj -> {
			Collection<EObject> children = new LinkedList<>();
			ExtTypeModel.Project _project = (ExtTypeModel.Project) obj;
			children.addAll(_project.getRootPackages());
			return children;
		});
		explorationConsumer.put(ExtType2Doc_ConcSync.ExtType2Doc_ConcSyncPackage.eINSTANCE.getPackage2Folder__Marker(), obj -> {
			Collection<EObject> children = new LinkedList<>();
			return children;
		});
		explorationConsumer.put(ExtTypeModel.ExtTypeModelPackage.eINSTANCE.getPackage(), obj -> {
			Collection<EObject> children = new LinkedList<>();
			ExtTypeModel.Package _package = (ExtTypeModel.Package) obj;
			children.addAll(_package.getSubPackages());
			children.addAll(_package.getTypes());
			return children;
		});
		explorationConsumer.put(ExtType2Doc_ConcSync.ExtType2Doc_ConcSyncPackage.eINSTANCE.getJDoc2Annotation(), obj -> {
			Collection<EObject> children = new LinkedList<>();
			return children;
		});
		explorationConsumer.put(ExtTypeModel.ExtTypeModelPackage.eINSTANCE.getNamedElement(), obj -> {
			Collection<EObject> children = new LinkedList<>();
			return children;
		});
		explorationConsumer.put(ExtDocModel.ExtDocModelPackage.eINSTANCE.getDoc(), obj -> {
			Collection<EObject> children = new LinkedList<>();
			ExtDocModel.Doc _doc = (ExtDocModel.Doc) obj;
			children.addAll(_doc.getEntries());
			return children;
		});
		explorationConsumer.put(runtime.impl.RuntimePackageImpl.eINSTANCE.getTGGRuleApplication(), obj -> {
			Collection<EObject> children = new LinkedList<>();
			return children;
		});
	}
}

