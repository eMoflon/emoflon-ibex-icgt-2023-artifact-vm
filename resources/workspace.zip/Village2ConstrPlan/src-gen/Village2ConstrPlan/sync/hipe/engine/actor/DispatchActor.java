package Village2ConstrPlan.sync.hipe.engine.actor;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EObject;

import java.text.DecimalFormat;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.time.Duration;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.function.Consumer;

import akka.actor.AbstractActor;
import akka.actor.ActorRef;
import akka.stream.ActorMaterializer;
import akka.stream.javadsl.*;
import static akka.pattern.Patterns.ask;

import hipe.engine.util.HiPEMultiUtil;
import hipe.engine.util.IncUtil;
import hipe.engine.message.NewInput;
import hipe.engine.message.NoMoreInput;
import hipe.engine.message.input.ObjectAdded;
import hipe.engine.message.input.ObjectDeleted;
import hipe.engine.message.input.ReferenceAdded;
import hipe.engine.message.input.ReferenceDeleted;		
import hipe.engine.message.input.AttributeChanged;
import hipe.engine.message.input.NotificationContainer;

import hipe.generic.actor.junction.util.HiPEConfig;

public class DispatchActor extends AbstractActor {
	
	private int counter = 0;
	public long time = 0;
				
	private Map<String, ActorRef> name2actor;
	
	private Map<Object, Consumer<Object>> type2addConsumer = HiPEMultiUtil.createMap();
	private Map<Object, Consumer<Notification>> feature2setConsumer = HiPEMultiUtil.createMap();
	private Map<Object, Consumer<Notification>> feature2addEdgeConsumer = HiPEMultiUtil.createMap();
	private Map<Object, Consumer<Notification>> feature2removeEdgeConsumer = HiPEMultiUtil.createMap();
	
	private IncUtil incUtil;
	
	private ActorMaterializer materializer;
	
	public DispatchActor(Map<String, ActorRef> name2actor, IncUtil incUtil) {
		this.name2actor = name2actor;
		this.incUtil = incUtil;
		
		initializeAdd();
		initializeSet();
		initializeAddEdge();
		initializeRemoveEdge();
	
		materializer = ActorMaterializer.create(getContext());
	}
	
	private void initializeAdd() {
		type2addConsumer.put(Village.VillagePackage.eINSTANCE.getVillageSquare(), obj -> {
			Village.VillageSquare _villagesquare = (Village.VillageSquare) obj;
			incUtil.newMessage();
			name2actor.get("VillageSquare_object_SP0").tell(new ObjectAdded<Village.VillageSquare>(incUtil, _villagesquare), getSelf());
			incUtil.newMessage();
			name2actor.get("VillageSquare_object_SP1").tell(new ObjectAdded<Village.VillageSquare>(incUtil, _villagesquare), getSelf());
		});
		type2addConsumer.put(ConstructionPlan.ConstructionPlanPackage.eINSTANCE.getPlanCollection(), obj -> {
			ConstructionPlan.PlanCollection _plancollection = (ConstructionPlan.PlanCollection) obj;
			incUtil.newMessage();
			name2actor.get("PlanCollection_object_SP0").tell(new ObjectAdded<ConstructionPlan.PlanCollection>(incUtil, _plancollection), getSelf());
			incUtil.newMessage();
			name2actor.get("PlanCollection_object_SP1").tell(new ObjectAdded<ConstructionPlan.PlanCollection>(incUtil, _plancollection), getSelf());
		});
		type2addConsumer.put(ConstructionPlan.ConstructionPlanPackage.eINSTANCE.getSaddleRoof(), obj -> {
			ConstructionPlan.SaddleRoof _saddleroof = (ConstructionPlan.SaddleRoof) obj;
			incUtil.newMessage();
			name2actor.get("SaddleRoof_object").tell(new ObjectAdded<ConstructionPlan.SaddleRoof>(incUtil, _saddleroof), getSelf());
			incUtil.newMessage();
			name2actor.get("Component_object").tell(new ObjectAdded<ConstructionPlan.Component>(incUtil, _saddleroof), getSelf());
		});
		type2addConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getVilla2Constr__Marker(), obj -> {
			Village2ConstrPlan.Villa2Constr__Marker _villa2constr__marker = (Village2ConstrPlan.Villa2Constr__Marker) obj;
			incUtil.newMessage();
			name2actor.get("Villa2Constr__Marker_object").tell(new ObjectAdded<Village2ConstrPlan.Villa2Constr__Marker>(incUtil, _villa2constr__marker), getSelf());
		});
		type2addConsumer.put(ConstructionPlan.ConstructionPlanPackage.eINSTANCE.getPlan(), obj -> {
			ConstructionPlan.Plan _plan = (ConstructionPlan.Plan) obj;
			incUtil.newMessage();
			name2actor.get("Plan_object_SP0").tell(new ObjectAdded<ConstructionPlan.Plan>(incUtil, _plan), getSelf());
			incUtil.newMessage();
			name2actor.get("Plan_object_SP1").tell(new ObjectAdded<ConstructionPlan.Plan>(incUtil, _plan), getSelf());
		});
		type2addConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getHouse2Constr(), obj -> {
			Village2ConstrPlan.House2Constr _house2constr = (Village2ConstrPlan.House2Constr) obj;
			incUtil.newMessage();
			name2actor.get("House2Constr_object_SP0").tell(new ObjectAdded<Village2ConstrPlan.House2Constr>(incUtil, _house2constr), getSelf());
			incUtil.newMessage();
			name2actor.get("House2Constr_object_SP1").tell(new ObjectAdded<Village2ConstrPlan.House2Constr>(incUtil, _house2constr), getSelf());
		});
		type2addConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getCorner2Constr__Marker(), obj -> {
			Village2ConstrPlan.Corner2Constr__Marker _corner2constr__marker = (Village2ConstrPlan.Corner2Constr__Marker) obj;
			incUtil.newMessage();
			name2actor.get("Corner2Constr__Marker_object").tell(new ObjectAdded<Village2ConstrPlan.Corner2Constr__Marker>(incUtil, _corner2constr__marker), getSelf());
		});
		type2addConsumer.put(ConstructionPlan.ConstructionPlanPackage.eINSTANCE.getComponent(), obj -> {
			ConstructionPlan.Component _component = (ConstructionPlan.Component) obj;
			incUtil.newMessage();
			name2actor.get("Component_object").tell(new ObjectAdded<ConstructionPlan.Component>(incUtil, _component), getSelf());
		});
		type2addConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getCube2Constr__Marker(), obj -> {
			Village2ConstrPlan.Cube2Constr__Marker _cube2constr__marker = (Village2ConstrPlan.Cube2Constr__Marker) obj;
			incUtil.newMessage();
			name2actor.get("Cube2Constr__Marker_object").tell(new ObjectAdded<Village2ConstrPlan.Cube2Constr__Marker>(incUtil, _cube2constr__marker), getSelf());
		});
		type2addConsumer.put(Village.VillagePackage.eINSTANCE.getHouse(), obj -> {
			Village.House _house = (Village.House) obj;
			incUtil.newMessage();
			name2actor.get("House_object_SP0").tell(new ObjectAdded<Village.House>(incUtil, _house), getSelf());
			incUtil.newMessage();
			name2actor.get("House_object_SP1").tell(new ObjectAdded<Village.House>(incUtil, _house), getSelf());
			incUtil.newMessage();
			name2actor.get("House_object_SP2").tell(new ObjectAdded<Village.House>(incUtil, _house), getSelf());
		});
		type2addConsumer.put(ConstructionPlan.ConstructionPlanPackage.eINSTANCE.getCellar(), obj -> {
			ConstructionPlan.Cellar _cellar = (ConstructionPlan.Cellar) obj;
			incUtil.newMessage();
			name2actor.get("Cellar_object").tell(new ObjectAdded<ConstructionPlan.Cellar>(incUtil, _cellar), getSelf());
			incUtil.newMessage();
			name2actor.get("Component_object").tell(new ObjectAdded<ConstructionPlan.Component>(incUtil, _cellar), getSelf());
		});
		type2addConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getVillageSquare2PlanCollection(), obj -> {
			Village2ConstrPlan.VillageSquare2PlanCollection _villagesquare2plancollection = (Village2ConstrPlan.VillageSquare2PlanCollection) obj;
			incUtil.newMessage();
			name2actor.get("VillageSquare2PlanCollection_object").tell(new ObjectAdded<Village2ConstrPlan.VillageSquare2PlanCollection>(incUtil, _villagesquare2plancollection), getSelf());
		});
		type2addConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getVillageSquare2PlanCollection__Marker(), obj -> {
			Village2ConstrPlan.VillageSquare2PlanCollection__Marker _villagesquare2plancollection__marker = (Village2ConstrPlan.VillageSquare2PlanCollection__Marker) obj;
			incUtil.newMessage();
			name2actor.get("VillageSquare2PlanCollection__Marker_object").tell(new ObjectAdded<Village2ConstrPlan.VillageSquare2PlanCollection__Marker>(incUtil, _villagesquare2plancollection__marker), getSelf());
		});
		type2addConsumer.put(ConstructionPlan.ConstructionPlanPackage.eINSTANCE.getBasement(), obj -> {
			ConstructionPlan.Basement _basement = (ConstructionPlan.Basement) obj;
			incUtil.newMessage();
			name2actor.get("Basement_object_SP0").tell(new ObjectAdded<ConstructionPlan.Basement>(incUtil, _basement), getSelf());
			incUtil.newMessage();
			name2actor.get("Basement_object_SP1").tell(new ObjectAdded<ConstructionPlan.Basement>(incUtil, _basement), getSelf());
			incUtil.newMessage();
			name2actor.get("Component_object").tell(new ObjectAdded<ConstructionPlan.Component>(incUtil, _basement), getSelf());
		});
		type2addConsumer.put(ConstructionPlan.ConstructionPlanPackage.eINSTANCE.getConstruction(), obj -> {
			ConstructionPlan.Construction _construction = (ConstructionPlan.Construction) obj;
			incUtil.newMessage();
			name2actor.get("Construction_object_SP0").tell(new ObjectAdded<ConstructionPlan.Construction>(incUtil, _construction), getSelf());
			incUtil.newMessage();
			name2actor.get("Construction_object_SP1").tell(new ObjectAdded<ConstructionPlan.Construction>(incUtil, _construction), getSelf());
			incUtil.newMessage();
			name2actor.get("Construction_object_SP2").tell(new ObjectAdded<ConstructionPlan.Construction>(incUtil, _construction), getSelf());
		});
	}
	
	private void initializeSet() {
		feature2setConsumer.put(Village.VillagePackage.eINSTANCE.getHouse_Name(), notification -> {
			if(notification.getNotifier() instanceof Village.House) {
				incUtil.newMessage();
				name2actor.get("House_object_SP0").tell(new AttributeChanged<Village.House>(incUtil, (Village.House) notification.getNotifier(), notification.getOldValue()), getSelf());
			}
			if(notification.getNotifier() instanceof Village.House) {
				incUtil.newMessage();
				name2actor.get("House_object_SP2").tell(new AttributeChanged<Village.House>(incUtil, (Village.House) notification.getNotifier(), notification.getOldValue()), getSelf());
			}
			if(notification.getNotifier() instanceof Village.House) {
				incUtil.newMessage();
				name2actor.get("House_object_SP1").tell(new AttributeChanged<Village.House>(incUtil, (Village.House) notification.getNotifier(), notification.getOldValue()), getSelf());
			}
		});
		
		feature2setConsumer.put(Village.VillagePackage.eINSTANCE.getHouse_Type(), notification -> {
			if(notification.getNotifier() instanceof Village.House) {
				incUtil.newMessage();
				name2actor.get("House_object_SP0").tell(new AttributeChanged<Village.House>(incUtil, (Village.House) notification.getNotifier(), notification.getOldValue()), getSelf());
			}
			if(notification.getNotifier() instanceof Village.House) {
				incUtil.newMessage();
				name2actor.get("House_object_SP2").tell(new AttributeChanged<Village.House>(incUtil, (Village.House) notification.getNotifier(), notification.getOldValue()), getSelf());
			}
			if(notification.getNotifier() instanceof Village.House) {
				incUtil.newMessage();
				name2actor.get("House_object_SP1").tell(new AttributeChanged<Village.House>(incUtil, (Village.House) notification.getNotifier(), notification.getOldValue()), getSelf());
			}
		});
		
		feature2setConsumer.put(ConstructionPlan.ConstructionPlanPackage.eINSTANCE.getConstruction_Name(), notification -> {
			if(notification.getNotifier() instanceof ConstructionPlan.Construction) {
				incUtil.newMessage();
				name2actor.get("Construction_object_SP0").tell(new AttributeChanged<ConstructionPlan.Construction>(incUtil, (ConstructionPlan.Construction) notification.getNotifier(), notification.getOldValue()), getSelf());
			}
			if(notification.getNotifier() instanceof ConstructionPlan.Construction) {
				incUtil.newMessage();
				name2actor.get("Construction_object_SP2").tell(new AttributeChanged<ConstructionPlan.Construction>(incUtil, (ConstructionPlan.Construction) notification.getNotifier(), notification.getOldValue()), getSelf());
			}
			if(notification.getNotifier() instanceof ConstructionPlan.Construction) {
				incUtil.newMessage();
				name2actor.get("Construction_object_SP1").tell(new AttributeChanged<ConstructionPlan.Construction>(incUtil, (ConstructionPlan.Construction) notification.getNotifier(), notification.getOldValue()), getSelf());
			}
		});
		
	}
	
	private void initializeAddEdge() {
		feature2addEdgeConsumer.put(ConstructionPlan.ConstructionPlanPackage.eINSTANCE.getPlan_Constructions(), notification -> {
			incUtil.newMessage();
			name2actor.get("Corner2Constr__BWD_5_localSearch").tell(new ReferenceAdded<ConstructionPlan.Plan, ConstructionPlan.Construction>(incUtil,(ConstructionPlan.Plan) notification.getNotifier(), (ConstructionPlan.Construction) notification.getNewValue(), "ConstructionPlan.Plan_constructions_Construction"), getSelf());
			incUtil.newMessage();
			name2actor.get("Corner2Constr__CONSISTENCY_15_localSearch").tell(new ReferenceAdded<ConstructionPlan.Plan, ConstructionPlan.Construction>(incUtil,(ConstructionPlan.Plan) notification.getNotifier(), (ConstructionPlan.Construction) notification.getNewValue(), "ConstructionPlan.Plan_constructions_Construction"), getSelf());
			incUtil.newMessage();
			name2actor.get("Cube2Constr__BWD_34_localSearch").tell(new ReferenceAdded<ConstructionPlan.Plan, ConstructionPlan.Construction>(incUtil,(ConstructionPlan.Plan) notification.getNotifier(), (ConstructionPlan.Construction) notification.getNewValue(), "ConstructionPlan.Plan_constructions_Construction"), getSelf());
			incUtil.newMessage();
			name2actor.get("Cube2Constr__BWD_34_localSearch").tell(new ReferenceAdded<ConstructionPlan.Plan, ConstructionPlan.Construction>(incUtil,(ConstructionPlan.Plan) notification.getNotifier(), (ConstructionPlan.Construction) notification.getNewValue(), "ConstructionPlan.Plan_constructions_Construction"), getSelf());
			incUtil.newMessage();
			name2actor.get("Cube2Constr__CONSISTENCY_45_localSearch").tell(new ReferenceAdded<ConstructionPlan.Plan, ConstructionPlan.Construction>(incUtil,(ConstructionPlan.Plan) notification.getNotifier(), (ConstructionPlan.Construction) notification.getNewValue(), "ConstructionPlan.Plan_constructions_Construction"), getSelf());
			incUtil.newMessage();
			name2actor.get("Cube2Constr__CONSISTENCY_45_localSearch").tell(new ReferenceAdded<ConstructionPlan.Plan, ConstructionPlan.Construction>(incUtil,(ConstructionPlan.Plan) notification.getNotifier(), (ConstructionPlan.Construction) notification.getNewValue(), "ConstructionPlan.Plan_constructions_Construction"), getSelf());
			incUtil.newMessage();
			name2actor.get("Cube2Constr__FWD_56_localSearch").tell(new ReferenceAdded<ConstructionPlan.Plan, ConstructionPlan.Construction>(incUtil,(ConstructionPlan.Plan) notification.getNotifier(), (ConstructionPlan.Construction) notification.getNewValue(), "ConstructionPlan.Plan_constructions_Construction"), getSelf());
			incUtil.newMessage();
			name2actor.get("Villa2Constr__BWD_66_localSearch").tell(new ReferenceAdded<ConstructionPlan.Plan, ConstructionPlan.Construction>(incUtil,(ConstructionPlan.Plan) notification.getNotifier(), (ConstructionPlan.Construction) notification.getNewValue(), "ConstructionPlan.Plan_constructions_Construction"), getSelf());
			incUtil.newMessage();
			name2actor.get("Villa2Constr__BWD_66_localSearch").tell(new ReferenceAdded<ConstructionPlan.Plan, ConstructionPlan.Construction>(incUtil,(ConstructionPlan.Plan) notification.getNotifier(), (ConstructionPlan.Construction) notification.getNewValue(), "ConstructionPlan.Plan_constructions_Construction"), getSelf());
			incUtil.newMessage();
			name2actor.get("Villa2Constr__CONSISTENCY_77_localSearch").tell(new ReferenceAdded<ConstructionPlan.Plan, ConstructionPlan.Construction>(incUtil,(ConstructionPlan.Plan) notification.getNotifier(), (ConstructionPlan.Construction) notification.getNewValue(), "ConstructionPlan.Plan_constructions_Construction"), getSelf());
			incUtil.newMessage();
			name2actor.get("Villa2Constr__CONSISTENCY_77_localSearch").tell(new ReferenceAdded<ConstructionPlan.Plan, ConstructionPlan.Construction>(incUtil,(ConstructionPlan.Plan) notification.getNotifier(), (ConstructionPlan.Construction) notification.getNewValue(), "ConstructionPlan.Plan_constructions_Construction"), getSelf());
			incUtil.newMessage();
			name2actor.get("Villa2Constr__FWD_88_localSearch").tell(new ReferenceAdded<ConstructionPlan.Plan, ConstructionPlan.Construction>(incUtil,(ConstructionPlan.Plan) notification.getNotifier(), (ConstructionPlan.Construction) notification.getNewValue(), "ConstructionPlan.Plan_constructions_Construction"), getSelf());
		});
		feature2addEdgeConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getCube2Constr__Marker_CONTEXT__TRG__cst(), notification -> {
			incUtil.newMessage();
			name2actor.get("Cube2Constr__CONSISTENCY_45_localSearch").tell(new ReferenceAdded<Village2ConstrPlan.Cube2Constr__Marker, ConstructionPlan.Construction>(incUtil,(Village2ConstrPlan.Cube2Constr__Marker) notification.getNotifier(), (ConstructionPlan.Construction) notification.getNewValue(), "Village2ConstrPlan.Cube2Constr__Marker_CONTEXT__TRG__cst_Construction"), getSelf());
		});
		feature2addEdgeConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getVilla2Constr__Marker_CONTEXT__CORR__h2cst(), notification -> {
			incUtil.newMessage();
			name2actor.get("Villa2Constr__CONSISTENCY_77_localSearch").tell(new ReferenceAdded<Village2ConstrPlan.Villa2Constr__Marker, Village2ConstrPlan.House2Constr>(incUtil,(Village2ConstrPlan.Villa2Constr__Marker) notification.getNotifier(), (Village2ConstrPlan.House2Constr) notification.getNewValue(), "Village2ConstrPlan.Villa2Constr__Marker_CONTEXT__CORR__h2cst_House2Constr"), getSelf());
		});
		feature2addEdgeConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getVilla2Constr__Marker_CREATE__CORR__nh2ncst(), notification -> {
			incUtil.newMessage();
			name2actor.get("Villa2Constr__CONSISTENCY_77_localSearch").tell(new ReferenceAdded<Village2ConstrPlan.Villa2Constr__Marker, Village2ConstrPlan.House2Constr>(incUtil,(Village2ConstrPlan.Villa2Constr__Marker) notification.getNotifier(), (Village2ConstrPlan.House2Constr) notification.getNewValue(), "Village2ConstrPlan.Villa2Constr__Marker_CREATE__CORR__nh2ncst_House2Constr"), getSelf());
		});
		feature2addEdgeConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getCorner2Constr__Marker_CREATE__TRG__bt(), notification -> {
			incUtil.newMessage();
			name2actor.get("Corner2Constr__CONSISTENCY_15_localSearch").tell(new ReferenceAdded<Village2ConstrPlan.Corner2Constr__Marker, ConstructionPlan.Basement>(incUtil,(Village2ConstrPlan.Corner2Constr__Marker) notification.getNotifier(), (ConstructionPlan.Basement) notification.getNewValue(), "Village2ConstrPlan.Corner2Constr__Marker_CREATE__TRG__bt_Basement"), getSelf());
		});
		feature2addEdgeConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getCorner2Constr__Marker_CREATE__SRC__h(), notification -> {
			incUtil.newMessage();
			name2actor.get("Corner2Constr__CONSISTENCY_15_localSearch").tell(new ReferenceAdded<Village2ConstrPlan.Corner2Constr__Marker, Village.House>(incUtil,(Village2ConstrPlan.Corner2Constr__Marker) notification.getNotifier(), (Village.House) notification.getNewValue(), "Village2ConstrPlan.Corner2Constr__Marker_CREATE__SRC__h_House"), getSelf());
		});
		feature2addEdgeConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getVilla2Constr__Marker_CREATE__SRC__nh(), notification -> {
			incUtil.newMessage();
			name2actor.get("Villa2Constr__CONSISTENCY_77_localSearch").tell(new ReferenceAdded<Village2ConstrPlan.Villa2Constr__Marker, Village.House>(incUtil,(Village2ConstrPlan.Villa2Constr__Marker) notification.getNotifier(), (Village.House) notification.getNewValue(), "Village2ConstrPlan.Villa2Constr__Marker_CREATE__SRC__nh_House"), getSelf());
		});
		feature2addEdgeConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getCorner2Constr__Marker_CONTEXT__SRC__vs(), notification -> {
			incUtil.newMessage();
			name2actor.get("Corner2Constr__CONSISTENCY_15_localSearch").tell(new ReferenceAdded<Village2ConstrPlan.Corner2Constr__Marker, Village.VillageSquare>(incUtil,(Village2ConstrPlan.Corner2Constr__Marker) notification.getNotifier(), (Village.VillageSquare) notification.getNewValue(), "Village2ConstrPlan.Corner2Constr__Marker_CONTEXT__SRC__vs_VillageSquare"), getSelf());
		});
		feature2addEdgeConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getVilla2Constr__Marker_CONTEXT__TRG__cst(), notification -> {
			incUtil.newMessage();
			name2actor.get("Villa2Constr__CONSISTENCY_77_localSearch").tell(new ReferenceAdded<Village2ConstrPlan.Villa2Constr__Marker, ConstructionPlan.Construction>(incUtil,(Village2ConstrPlan.Villa2Constr__Marker) notification.getNotifier(), (ConstructionPlan.Construction) notification.getNewValue(), "Village2ConstrPlan.Villa2Constr__Marker_CONTEXT__TRG__cst_Construction"), getSelf());
		});
		feature2addEdgeConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getVilla2Constr__Marker_CREATE__TRG__bt(), notification -> {
			incUtil.newMessage();
			name2actor.get("Villa2Constr__CONSISTENCY_77_localSearch").tell(new ReferenceAdded<Village2ConstrPlan.Villa2Constr__Marker, ConstructionPlan.Basement>(incUtil,(Village2ConstrPlan.Villa2Constr__Marker) notification.getNotifier(), (ConstructionPlan.Basement) notification.getNewValue(), "Village2ConstrPlan.Villa2Constr__Marker_CREATE__TRG__bt_Basement"), getSelf());
		});
		feature2addEdgeConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getVillageSquare2PlanCollection__Marker_CREATE__SRC__vs(), notification -> {
			incUtil.newMessage();
			name2actor.get("VillageSquare2PlanCollection__CONSISTENCY_95_localSearch").tell(new ReferenceAdded<Village2ConstrPlan.VillageSquare2PlanCollection__Marker, Village.VillageSquare>(incUtil,(Village2ConstrPlan.VillageSquare2PlanCollection__Marker) notification.getNotifier(), (Village.VillageSquare) notification.getNewValue(), "Village2ConstrPlan.VillageSquare2PlanCollection__Marker_CREATE__SRC__vs_VillageSquare"), getSelf());
		});
		feature2addEdgeConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getVillageSquare2PlanCollection__Marker_CREATE__TRG__pc(), notification -> {
			incUtil.newMessage();
			name2actor.get("VillageSquare2PlanCollection__CONSISTENCY_95_localSearch").tell(new ReferenceAdded<Village2ConstrPlan.VillageSquare2PlanCollection__Marker, ConstructionPlan.PlanCollection>(incUtil,(Village2ConstrPlan.VillageSquare2PlanCollection__Marker) notification.getNotifier(), (ConstructionPlan.PlanCollection) notification.getNewValue(), "Village2ConstrPlan.VillageSquare2PlanCollection__Marker_CREATE__TRG__pc_PlanCollection"), getSelf());
		});
		feature2addEdgeConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getCube2Constr__Marker_CREATE__SRC__nh(), notification -> {
			incUtil.newMessage();
			name2actor.get("Cube2Constr__CONSISTENCY_45_localSearch").tell(new ReferenceAdded<Village2ConstrPlan.Cube2Constr__Marker, Village.House>(incUtil,(Village2ConstrPlan.Cube2Constr__Marker) notification.getNotifier(), (Village.House) notification.getNewValue(), "Village2ConstrPlan.Cube2Constr__Marker_CREATE__SRC__nh_House"), getSelf());
		});
		feature2addEdgeConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getVilla2Constr__Marker_CONTEXT__TRG__p(), notification -> {
			incUtil.newMessage();
			name2actor.get("Villa2Constr__CONSISTENCY_77_localSearch").tell(new ReferenceAdded<Village2ConstrPlan.Villa2Constr__Marker, ConstructionPlan.Plan>(incUtil,(Village2ConstrPlan.Villa2Constr__Marker) notification.getNotifier(), (ConstructionPlan.Plan) notification.getNewValue(), "Village2ConstrPlan.Villa2Constr__Marker_CONTEXT__TRG__p_Plan"), getSelf());
		});
		feature2addEdgeConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getCube2Constr__Marker_CONTEXT__CORR__h2cst(), notification -> {
			incUtil.newMessage();
			name2actor.get("Cube2Constr__CONSISTENCY_45_localSearch").tell(new ReferenceAdded<Village2ConstrPlan.Cube2Constr__Marker, Village2ConstrPlan.House2Constr>(incUtil,(Village2ConstrPlan.Cube2Constr__Marker) notification.getNotifier(), (Village2ConstrPlan.House2Constr) notification.getNewValue(), "Village2ConstrPlan.Cube2Constr__Marker_CONTEXT__CORR__h2cst_House2Constr"), getSelf());
		});
		feature2addEdgeConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getVilla2Constr__Marker_CREATE__TRG__sr(), notification -> {
			incUtil.newMessage();
			name2actor.get("Villa2Constr__CONSISTENCY_77_localSearch").tell(new ReferenceAdded<Village2ConstrPlan.Villa2Constr__Marker, ConstructionPlan.SaddleRoof>(incUtil,(Village2ConstrPlan.Villa2Constr__Marker) notification.getNotifier(), (ConstructionPlan.SaddleRoof) notification.getNewValue(), "Village2ConstrPlan.Villa2Constr__Marker_CREATE__TRG__sr_SaddleRoof"), getSelf());
		});
		feature2addEdgeConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getCorner2Constr__Marker_CREATE__CORR__h2cst(), notification -> {
			incUtil.newMessage();
			name2actor.get("Corner2Constr__CONSISTENCY_15_localSearch").tell(new ReferenceAdded<Village2ConstrPlan.Corner2Constr__Marker, Village2ConstrPlan.House2Constr>(incUtil,(Village2ConstrPlan.Corner2Constr__Marker) notification.getNotifier(), (Village2ConstrPlan.House2Constr) notification.getNewValue(), "Village2ConstrPlan.Corner2Constr__Marker_CREATE__CORR__h2cst_House2Constr"), getSelf());
		});
		feature2addEdgeConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getVilla2Constr__Marker_CREATE__TRG__ncst(), notification -> {
			incUtil.newMessage();
			name2actor.get("Villa2Constr__CONSISTENCY_77_localSearch").tell(new ReferenceAdded<Village2ConstrPlan.Villa2Constr__Marker, ConstructionPlan.Construction>(incUtil,(Village2ConstrPlan.Villa2Constr__Marker) notification.getNotifier(), (ConstructionPlan.Construction) notification.getNewValue(), "Village2ConstrPlan.Villa2Constr__Marker_CREATE__TRG__ncst_Construction"), getSelf());
		});
		feature2addEdgeConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getCorner2Constr__Marker_CONTEXT__TRG__pc(), notification -> {
			incUtil.newMessage();
			name2actor.get("Corner2Constr__CONSISTENCY_15_localSearch").tell(new ReferenceAdded<Village2ConstrPlan.Corner2Constr__Marker, ConstructionPlan.PlanCollection>(incUtil,(Village2ConstrPlan.Corner2Constr__Marker) notification.getNotifier(), (ConstructionPlan.PlanCollection) notification.getNewValue(), "Village2ConstrPlan.Corner2Constr__Marker_CONTEXT__TRG__pc_PlanCollection"), getSelf());
		});
		feature2addEdgeConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getCorner2Constr__Marker_CREATE__TRG__p(), notification -> {
			incUtil.newMessage();
			name2actor.get("Corner2Constr__CONSISTENCY_15_localSearch").tell(new ReferenceAdded<Village2ConstrPlan.Corner2Constr__Marker, ConstructionPlan.Plan>(incUtil,(Village2ConstrPlan.Corner2Constr__Marker) notification.getNotifier(), (ConstructionPlan.Plan) notification.getNewValue(), "Village2ConstrPlan.Corner2Constr__Marker_CREATE__TRG__p_Plan"), getSelf());
		});
		feature2addEdgeConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getHouse2Constr_Source(), notification -> {
			incUtil.newMessage();
			name2actor.get("Corner2Constr__CONSISTENCY_15_localSearch").tell(new ReferenceAdded<Village2ConstrPlan.House2Constr, Village.House>(incUtil,(Village2ConstrPlan.House2Constr) notification.getNotifier(), (Village.House) notification.getNewValue(), "Village2ConstrPlan.House2Constr_source_House"), getSelf());
			incUtil.newMessage();
			name2actor.get("Cube2Constr__BWD_34_localSearch").tell(new ReferenceAdded<Village2ConstrPlan.House2Constr, Village.House>(incUtil,(Village2ConstrPlan.House2Constr) notification.getNotifier(), (Village.House) notification.getNewValue(), "Village2ConstrPlan.House2Constr_source_House"), getSelf());
			incUtil.newMessage();
			name2actor.get("Cube2Constr__CONSISTENCY_45_localSearch").tell(new ReferenceAdded<Village2ConstrPlan.House2Constr, Village.House>(incUtil,(Village2ConstrPlan.House2Constr) notification.getNotifier(), (Village.House) notification.getNewValue(), "Village2ConstrPlan.House2Constr_source_House"), getSelf());
			incUtil.newMessage();
			name2actor.get("Cube2Constr__CONSISTENCY_45_localSearch").tell(new ReferenceAdded<Village2ConstrPlan.House2Constr, Village.House>(incUtil,(Village2ConstrPlan.House2Constr) notification.getNotifier(), (Village.House) notification.getNewValue(), "Village2ConstrPlan.House2Constr_source_House"), getSelf());
			incUtil.newMessage();
			name2actor.get("Cube2Constr__FWD_56_localSearch").tell(new ReferenceAdded<Village2ConstrPlan.House2Constr, Village.House>(incUtil,(Village2ConstrPlan.House2Constr) notification.getNotifier(), (Village.House) notification.getNewValue(), "Village2ConstrPlan.House2Constr_source_House"), getSelf());
			incUtil.newMessage();
			name2actor.get("Villa2Constr__BWD_66_localSearch").tell(new ReferenceAdded<Village2ConstrPlan.House2Constr, Village.House>(incUtil,(Village2ConstrPlan.House2Constr) notification.getNotifier(), (Village.House) notification.getNewValue(), "Village2ConstrPlan.House2Constr_source_House"), getSelf());
			incUtil.newMessage();
			name2actor.get("Villa2Constr__CONSISTENCY_77_localSearch").tell(new ReferenceAdded<Village2ConstrPlan.House2Constr, Village.House>(incUtil,(Village2ConstrPlan.House2Constr) notification.getNotifier(), (Village.House) notification.getNewValue(), "Village2ConstrPlan.House2Constr_source_House"), getSelf());
			incUtil.newMessage();
			name2actor.get("Villa2Constr__CONSISTENCY_77_localSearch").tell(new ReferenceAdded<Village2ConstrPlan.House2Constr, Village.House>(incUtil,(Village2ConstrPlan.House2Constr) notification.getNotifier(), (Village.House) notification.getNewValue(), "Village2ConstrPlan.House2Constr_source_House"), getSelf());
			incUtil.newMessage();
			name2actor.get("Villa2Constr__FWD_88_localSearch").tell(new ReferenceAdded<Village2ConstrPlan.House2Constr, Village.House>(incUtil,(Village2ConstrPlan.House2Constr) notification.getNotifier(), (Village.House) notification.getNewValue(), "Village2ConstrPlan.House2Constr_source_House"), getSelf());
		});
		feature2addEdgeConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getCube2Constr__Marker_CREATE__TRG__cl(), notification -> {
			incUtil.newMessage();
			name2actor.get("Cube2Constr__CONSISTENCY_45_localSearch").tell(new ReferenceAdded<Village2ConstrPlan.Cube2Constr__Marker, ConstructionPlan.Cellar>(incUtil,(Village2ConstrPlan.Cube2Constr__Marker) notification.getNotifier(), (ConstructionPlan.Cellar) notification.getNewValue(), "Village2ConstrPlan.Cube2Constr__Marker_CREATE__TRG__cl_Cellar"), getSelf());
		});
		feature2addEdgeConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getHouse2Constr_Target(), notification -> {
			incUtil.newMessage();
			name2actor.get("Corner2Constr__CONSISTENCY_15_localSearch").tell(new ReferenceAdded<Village2ConstrPlan.House2Constr, ConstructionPlan.Construction>(incUtil,(Village2ConstrPlan.House2Constr) notification.getNotifier(), (ConstructionPlan.Construction) notification.getNewValue(), "Village2ConstrPlan.House2Constr_target_Construction"), getSelf());
			incUtil.newMessage();
			name2actor.get("Cube2Constr__BWD_34_localSearch").tell(new ReferenceAdded<Village2ConstrPlan.House2Constr, ConstructionPlan.Construction>(incUtil,(Village2ConstrPlan.House2Constr) notification.getNotifier(), (ConstructionPlan.Construction) notification.getNewValue(), "Village2ConstrPlan.House2Constr_target_Construction"), getSelf());
			incUtil.newMessage();
			name2actor.get("Cube2Constr__CONSISTENCY_45_localSearch").tell(new ReferenceAdded<Village2ConstrPlan.House2Constr, ConstructionPlan.Construction>(incUtil,(Village2ConstrPlan.House2Constr) notification.getNotifier(), (ConstructionPlan.Construction) notification.getNewValue(), "Village2ConstrPlan.House2Constr_target_Construction"), getSelf());
			incUtil.newMessage();
			name2actor.get("Cube2Constr__CONSISTENCY_45_localSearch").tell(new ReferenceAdded<Village2ConstrPlan.House2Constr, ConstructionPlan.Construction>(incUtil,(Village2ConstrPlan.House2Constr) notification.getNotifier(), (ConstructionPlan.Construction) notification.getNewValue(), "Village2ConstrPlan.House2Constr_target_Construction"), getSelf());
			incUtil.newMessage();
			name2actor.get("Cube2Constr__FWD_56_localSearch").tell(new ReferenceAdded<Village2ConstrPlan.House2Constr, ConstructionPlan.Construction>(incUtil,(Village2ConstrPlan.House2Constr) notification.getNotifier(), (ConstructionPlan.Construction) notification.getNewValue(), "Village2ConstrPlan.House2Constr_target_Construction"), getSelf());
			incUtil.newMessage();
			name2actor.get("Villa2Constr__BWD_66_localSearch").tell(new ReferenceAdded<Village2ConstrPlan.House2Constr, ConstructionPlan.Construction>(incUtil,(Village2ConstrPlan.House2Constr) notification.getNotifier(), (ConstructionPlan.Construction) notification.getNewValue(), "Village2ConstrPlan.House2Constr_target_Construction"), getSelf());
			incUtil.newMessage();
			name2actor.get("Villa2Constr__CONSISTENCY_77_localSearch").tell(new ReferenceAdded<Village2ConstrPlan.House2Constr, ConstructionPlan.Construction>(incUtil,(Village2ConstrPlan.House2Constr) notification.getNotifier(), (ConstructionPlan.Construction) notification.getNewValue(), "Village2ConstrPlan.House2Constr_target_Construction"), getSelf());
			incUtil.newMessage();
			name2actor.get("Villa2Constr__CONSISTENCY_77_localSearch").tell(new ReferenceAdded<Village2ConstrPlan.House2Constr, ConstructionPlan.Construction>(incUtil,(Village2ConstrPlan.House2Constr) notification.getNotifier(), (ConstructionPlan.Construction) notification.getNewValue(), "Village2ConstrPlan.House2Constr_target_Construction"), getSelf());
			incUtil.newMessage();
			name2actor.get("Villa2Constr__FWD_88_localSearch").tell(new ReferenceAdded<Village2ConstrPlan.House2Constr, ConstructionPlan.Construction>(incUtil,(Village2ConstrPlan.House2Constr) notification.getNotifier(), (ConstructionPlan.Construction) notification.getNewValue(), "Village2ConstrPlan.House2Constr_target_Construction"), getSelf());
		});
		feature2addEdgeConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getCube2Constr__Marker_CONTEXT__SRC__h(), notification -> {
			incUtil.newMessage();
			name2actor.get("Cube2Constr__CONSISTENCY_45_localSearch").tell(new ReferenceAdded<Village2ConstrPlan.Cube2Constr__Marker, Village.House>(incUtil,(Village2ConstrPlan.Cube2Constr__Marker) notification.getNotifier(), (Village.House) notification.getNewValue(), "Village2ConstrPlan.Cube2Constr__Marker_CONTEXT__SRC__h_House"), getSelf());
		});
		feature2addEdgeConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getVilla2Constr__Marker_CONTEXT__SRC__h(), notification -> {
			incUtil.newMessage();
			name2actor.get("Villa2Constr__CONSISTENCY_77_localSearch").tell(new ReferenceAdded<Village2ConstrPlan.Villa2Constr__Marker, Village.House>(incUtil,(Village2ConstrPlan.Villa2Constr__Marker) notification.getNotifier(), (Village.House) notification.getNewValue(), "Village2ConstrPlan.Villa2Constr__Marker_CONTEXT__SRC__h_House"), getSelf());
		});
		feature2addEdgeConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getVillageSquare2PlanCollection__Marker_CREATE__CORR__vs2pl(), notification -> {
			incUtil.newMessage();
			name2actor.get("VillageSquare2PlanCollection__CONSISTENCY_95_localSearch").tell(new ReferenceAdded<Village2ConstrPlan.VillageSquare2PlanCollection__Marker, Village2ConstrPlan.VillageSquare2PlanCollection>(incUtil,(Village2ConstrPlan.VillageSquare2PlanCollection__Marker) notification.getNotifier(), (Village2ConstrPlan.VillageSquare2PlanCollection) notification.getNewValue(), "Village2ConstrPlan.VillageSquare2PlanCollection__Marker_CREATE__CORR__vs2pl_VillageSquare2PlanCollection"), getSelf());
		});
		feature2addEdgeConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getVillageSquare2PlanCollection_Target(), notification -> {
			incUtil.newMessage();
			name2actor.get("Corner2Constr__BWD_5_localSearch").tell(new ReferenceAdded<Village2ConstrPlan.VillageSquare2PlanCollection, ConstructionPlan.PlanCollection>(incUtil,(Village2ConstrPlan.VillageSquare2PlanCollection) notification.getNotifier(), (ConstructionPlan.PlanCollection) notification.getNewValue(), "Village2ConstrPlan.VillageSquare2PlanCollection_target_PlanCollection"), getSelf());
			incUtil.newMessage();
			name2actor.get("Corner2Constr__CONSISTENCY_15_localSearch").tell(new ReferenceAdded<Village2ConstrPlan.VillageSquare2PlanCollection, ConstructionPlan.PlanCollection>(incUtil,(Village2ConstrPlan.VillageSquare2PlanCollection) notification.getNotifier(), (ConstructionPlan.PlanCollection) notification.getNewValue(), "Village2ConstrPlan.VillageSquare2PlanCollection_target_PlanCollection"), getSelf());
			incUtil.newMessage();
			name2actor.get("Corner2Constr__FWD_25_localSearch").tell(new ReferenceAdded<Village2ConstrPlan.VillageSquare2PlanCollection, ConstructionPlan.PlanCollection>(incUtil,(Village2ConstrPlan.VillageSquare2PlanCollection) notification.getNotifier(), (ConstructionPlan.PlanCollection) notification.getNewValue(), "Village2ConstrPlan.VillageSquare2PlanCollection_target_PlanCollection"), getSelf());
			incUtil.newMessage();
			name2actor.get("VillageSquare2PlanCollection__CONSISTENCY_95_localSearch").tell(new ReferenceAdded<Village2ConstrPlan.VillageSquare2PlanCollection, ConstructionPlan.PlanCollection>(incUtil,(Village2ConstrPlan.VillageSquare2PlanCollection) notification.getNotifier(), (ConstructionPlan.PlanCollection) notification.getNewValue(), "Village2ConstrPlan.VillageSquare2PlanCollection_target_PlanCollection"), getSelf());
		});
		feature2addEdgeConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getCorner2Constr__Marker_CONTEXT__CORR__vs2pc(), notification -> {
			incUtil.newMessage();
			name2actor.get("Corner2Constr__CONSISTENCY_15_localSearch").tell(new ReferenceAdded<Village2ConstrPlan.Corner2Constr__Marker, Village2ConstrPlan.VillageSquare2PlanCollection>(incUtil,(Village2ConstrPlan.Corner2Constr__Marker) notification.getNotifier(), (Village2ConstrPlan.VillageSquare2PlanCollection) notification.getNewValue(), "Village2ConstrPlan.Corner2Constr__Marker_CONTEXT__CORR__vs2pc_VillageSquare2PlanCollection"), getSelf());
		});
		feature2addEdgeConsumer.put(ConstructionPlan.ConstructionPlanPackage.eINSTANCE.getComponent_NextStep(), notification -> {
			incUtil.newMessage();
			name2actor.get("Cube2Constr__BWD_34_localSearch").tell(new ReferenceAdded<ConstructionPlan.Component, ConstructionPlan.Component>(incUtil,(ConstructionPlan.Component) notification.getNotifier(), (ConstructionPlan.Component) notification.getNewValue(), "ConstructionPlan.Component_nextStep_Component"), getSelf());
			incUtil.newMessage();
			name2actor.get("Cube2Constr__CONSISTENCY_45_localSearch").tell(new ReferenceAdded<ConstructionPlan.Component, ConstructionPlan.Component>(incUtil,(ConstructionPlan.Component) notification.getNotifier(), (ConstructionPlan.Component) notification.getNewValue(), "ConstructionPlan.Component_nextStep_Component"), getSelf());
			incUtil.newMessage();
			name2actor.get("Villa2Constr__BWD_66_localSearch").tell(new ReferenceAdded<ConstructionPlan.Component, ConstructionPlan.Component>(incUtil,(ConstructionPlan.Component) notification.getNotifier(), (ConstructionPlan.Component) notification.getNewValue(), "ConstructionPlan.Component_nextStep_Component"), getSelf());
			incUtil.newMessage();
			name2actor.get("Villa2Constr__CONSISTENCY_77_localSearch").tell(new ReferenceAdded<ConstructionPlan.Component, ConstructionPlan.Component>(incUtil,(ConstructionPlan.Component) notification.getNotifier(), (ConstructionPlan.Component) notification.getNewValue(), "ConstructionPlan.Component_nextStep_Component"), getSelf());
		});
		feature2addEdgeConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getCube2Constr__Marker_CREATE__TRG__bt(), notification -> {
			incUtil.newMessage();
			name2actor.get("Cube2Constr__CONSISTENCY_45_localSearch").tell(new ReferenceAdded<Village2ConstrPlan.Cube2Constr__Marker, ConstructionPlan.Basement>(incUtil,(Village2ConstrPlan.Cube2Constr__Marker) notification.getNotifier(), (ConstructionPlan.Basement) notification.getNewValue(), "Village2ConstrPlan.Cube2Constr__Marker_CREATE__TRG__bt_Basement"), getSelf());
		});
		feature2addEdgeConsumer.put(Village.VillagePackage.eINSTANCE.getHouse_NextHouse(), notification -> {
			incUtil.newMessage();
			name2actor.get("Corner2Constr_h_nextHouse_incoming_SRC__FILTER_NAC_SRC_12_localSearch").tell(new ReferenceAdded<Village.House, Village.House>(incUtil,(Village.House) notification.getNotifier(), (Village.House) notification.getNewValue(), "Village.House_nextHouse_House"), getSelf());
			incUtil.newMessage();
			name2actor.get("Cube2Constr__CONSISTENCY_45_localSearch").tell(new ReferenceAdded<Village.House, Village.House>(incUtil,(Village.House) notification.getNotifier(), (Village.House) notification.getNewValue(), "Village.House_nextHouse_House"), getSelf());
			incUtil.newMessage();
			name2actor.get("Cube2Constr__FWD_56_localSearch").tell(new ReferenceAdded<Village.House, Village.House>(incUtil,(Village.House) notification.getNotifier(), (Village.House) notification.getNewValue(), "Village.House_nextHouse_House"), getSelf());
			incUtil.newMessage();
			name2actor.get("Villa2Constr__CONSISTENCY_77_localSearch").tell(new ReferenceAdded<Village.House, Village.House>(incUtil,(Village.House) notification.getNotifier(), (Village.House) notification.getNewValue(), "Village.House_nextHouse_House"), getSelf());
			incUtil.newMessage();
			name2actor.get("Villa2Constr__FWD_88_localSearch").tell(new ReferenceAdded<Village.House, Village.House>(incUtil,(Village.House) notification.getNotifier(), (Village.House) notification.getNewValue(), "Village.House_nextHouse_House"), getSelf());
		});
		feature2addEdgeConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getCube2Constr__Marker_CREATE__CORR__nh2ncst(), notification -> {
			incUtil.newMessage();
			name2actor.get("Cube2Constr__CONSISTENCY_45_localSearch").tell(new ReferenceAdded<Village2ConstrPlan.Cube2Constr__Marker, Village2ConstrPlan.House2Constr>(incUtil,(Village2ConstrPlan.Cube2Constr__Marker) notification.getNotifier(), (Village2ConstrPlan.House2Constr) notification.getNewValue(), "Village2ConstrPlan.Cube2Constr__Marker_CREATE__CORR__nh2ncst_House2Constr"), getSelf());
		});
		feature2addEdgeConsumer.put(ConstructionPlan.ConstructionPlanPackage.eINSTANCE.getPlanCollection_Plans(), notification -> {
			incUtil.newMessage();
			name2actor.get("Corner2Constr__BWD_5_localSearch").tell(new ReferenceAdded<ConstructionPlan.PlanCollection, ConstructionPlan.Plan>(incUtil,(ConstructionPlan.PlanCollection) notification.getNotifier(), (ConstructionPlan.Plan) notification.getNewValue(), "ConstructionPlan.PlanCollection_plans_Plan"), getSelf());
			incUtil.newMessage();
			name2actor.get("Corner2Constr__CONSISTENCY_15_localSearch").tell(new ReferenceAdded<ConstructionPlan.PlanCollection, ConstructionPlan.Plan>(incUtil,(ConstructionPlan.PlanCollection) notification.getNotifier(), (ConstructionPlan.Plan) notification.getNewValue(), "ConstructionPlan.PlanCollection_plans_Plan"), getSelf());
		});
		feature2addEdgeConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getCorner2Constr__Marker_CREATE__TRG__cst(), notification -> {
			incUtil.newMessage();
			name2actor.get("Corner2Constr__CONSISTENCY_15_localSearch").tell(new ReferenceAdded<Village2ConstrPlan.Corner2Constr__Marker, ConstructionPlan.Construction>(incUtil,(Village2ConstrPlan.Corner2Constr__Marker) notification.getNotifier(), (ConstructionPlan.Construction) notification.getNewValue(), "Village2ConstrPlan.Corner2Constr__Marker_CREATE__TRG__cst_Construction"), getSelf());
		});
		feature2addEdgeConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getCube2Constr__Marker_CONTEXT__TRG__p(), notification -> {
			incUtil.newMessage();
			name2actor.get("Cube2Constr__CONSISTENCY_45_localSearch").tell(new ReferenceAdded<Village2ConstrPlan.Cube2Constr__Marker, ConstructionPlan.Plan>(incUtil,(Village2ConstrPlan.Cube2Constr__Marker) notification.getNotifier(), (ConstructionPlan.Plan) notification.getNewValue(), "Village2ConstrPlan.Cube2Constr__Marker_CONTEXT__TRG__p_Plan"), getSelf());
		});
		feature2addEdgeConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getCube2Constr__Marker_CREATE__TRG__ncst(), notification -> {
			incUtil.newMessage();
			name2actor.get("Cube2Constr__CONSISTENCY_45_localSearch").tell(new ReferenceAdded<Village2ConstrPlan.Cube2Constr__Marker, ConstructionPlan.Construction>(incUtil,(Village2ConstrPlan.Cube2Constr__Marker) notification.getNotifier(), (ConstructionPlan.Construction) notification.getNewValue(), "Village2ConstrPlan.Cube2Constr__Marker_CREATE__TRG__ncst_Construction"), getSelf());
		});
		feature2addEdgeConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getVillageSquare2PlanCollection_Source(), notification -> {
			incUtil.newMessage();
			name2actor.get("Corner2Constr__BWD_5_localSearch").tell(new ReferenceAdded<Village2ConstrPlan.VillageSquare2PlanCollection, Village.VillageSquare>(incUtil,(Village2ConstrPlan.VillageSquare2PlanCollection) notification.getNotifier(), (Village.VillageSquare) notification.getNewValue(), "Village2ConstrPlan.VillageSquare2PlanCollection_source_VillageSquare"), getSelf());
			incUtil.newMessage();
			name2actor.get("Corner2Constr__CONSISTENCY_15_localSearch").tell(new ReferenceAdded<Village2ConstrPlan.VillageSquare2PlanCollection, Village.VillageSquare>(incUtil,(Village2ConstrPlan.VillageSquare2PlanCollection) notification.getNotifier(), (Village.VillageSquare) notification.getNewValue(), "Village2ConstrPlan.VillageSquare2PlanCollection_source_VillageSquare"), getSelf());
			incUtil.newMessage();
			name2actor.get("Corner2Constr__FWD_25_localSearch").tell(new ReferenceAdded<Village2ConstrPlan.VillageSquare2PlanCollection, Village.VillageSquare>(incUtil,(Village2ConstrPlan.VillageSquare2PlanCollection) notification.getNotifier(), (Village.VillageSquare) notification.getNewValue(), "Village2ConstrPlan.VillageSquare2PlanCollection_source_VillageSquare"), getSelf());
			incUtil.newMessage();
			name2actor.get("VillageSquare2PlanCollection__CONSISTENCY_95_localSearch").tell(new ReferenceAdded<Village2ConstrPlan.VillageSquare2PlanCollection, Village.VillageSquare>(incUtil,(Village2ConstrPlan.VillageSquare2PlanCollection) notification.getNotifier(), (Village.VillageSquare) notification.getNewValue(), "Village2ConstrPlan.VillageSquare2PlanCollection_source_VillageSquare"), getSelf());
		});
		feature2addEdgeConsumer.put(Village.VillagePackage.eINSTANCE.getVillageSquare_StreetCorner(), notification -> {
			incUtil.newMessage();
			name2actor.get("Corner2Constr__CONSISTENCY_15_localSearch").tell(new ReferenceAdded<Village.VillageSquare, Village.House>(incUtil,(Village.VillageSquare) notification.getNotifier(), (Village.House) notification.getNewValue(), "Village.VillageSquare_streetCorner_House"), getSelf());
			incUtil.newMessage();
			name2actor.get("Corner2Constr__FWD_25_localSearch").tell(new ReferenceAdded<Village.VillageSquare, Village.House>(incUtil,(Village.VillageSquare) notification.getNotifier(), (Village.House) notification.getNewValue(), "Village.VillageSquare_streetCorner_House"), getSelf());
			incUtil.newMessage();
			name2actor.get("Cube2Constr_nh_streetCorner_incoming_SRC__FILTER_NAC_SRC_42_localSearch").tell(new ReferenceAdded<Village.VillageSquare, Village.House>(incUtil,(Village.VillageSquare) notification.getNotifier(), (Village.House) notification.getNewValue(), "Village.VillageSquare_streetCorner_House"), getSelf());
			incUtil.newMessage();
			name2actor.get("Villa2Constr_nh_streetCorner_incoming_SRC__FILTER_NAC_SRC_74_localSearch").tell(new ReferenceAdded<Village.VillageSquare, Village.House>(incUtil,(Village.VillageSquare) notification.getNotifier(), (Village.House) notification.getNewValue(), "Village.VillageSquare_streetCorner_House"), getSelf());
		});
		feature2addEdgeConsumer.put(ConstructionPlan.ConstructionPlanPackage.eINSTANCE.getConstruction_FirstStep(), notification -> {
			incUtil.newMessage();
			name2actor.get("Corner2Constr_cst_firstStep_outgoing_TRG__FILTER_NAC_TRG_1_localSearch").tell(new ReferenceAdded<ConstructionPlan.Construction, ConstructionPlan.Component>(incUtil,(ConstructionPlan.Construction) notification.getNotifier(), (ConstructionPlan.Component) notification.getNewValue(), "ConstructionPlan.Construction_firstStep_Component"), getSelf());
			incUtil.newMessage();
			name2actor.get("Corner2Constr_cst_firstStep_outgoing_TRG__FILTER_NAC_TRG_1_localSearch").tell(new ReferenceAdded<ConstructionPlan.Construction, ConstructionPlan.Component>(incUtil,(ConstructionPlan.Construction) notification.getNotifier(), (ConstructionPlan.Component) notification.getNewValue(), "ConstructionPlan.Construction_firstStep_Component"), getSelf());
			incUtil.newMessage();
			name2actor.get("Corner2Constr__BWD_5_localSearch").tell(new ReferenceAdded<ConstructionPlan.Construction, ConstructionPlan.Component>(incUtil,(ConstructionPlan.Construction) notification.getNotifier(), (ConstructionPlan.Component) notification.getNewValue(), "ConstructionPlan.Construction_firstStep_Component"), getSelf());
			incUtil.newMessage();
			name2actor.get("Corner2Constr__CONSISTENCY_15_localSearch").tell(new ReferenceAdded<ConstructionPlan.Construction, ConstructionPlan.Component>(incUtil,(ConstructionPlan.Construction) notification.getNotifier(), (ConstructionPlan.Component) notification.getNewValue(), "ConstructionPlan.Construction_firstStep_Component"), getSelf());
			incUtil.newMessage();
			name2actor.get("Cube2Constr_ncst_firstStep_outgoing_TRG__FILTER_NAC_TRG_30_localSearch").tell(new ReferenceAdded<ConstructionPlan.Construction, ConstructionPlan.Component>(incUtil,(ConstructionPlan.Construction) notification.getNotifier(), (ConstructionPlan.Component) notification.getNewValue(), "ConstructionPlan.Construction_firstStep_Component"), getSelf());
			incUtil.newMessage();
			name2actor.get("Cube2Constr_ncst_firstStep_outgoing_TRG__FILTER_NAC_TRG_30_localSearch").tell(new ReferenceAdded<ConstructionPlan.Construction, ConstructionPlan.Component>(incUtil,(ConstructionPlan.Construction) notification.getNotifier(), (ConstructionPlan.Component) notification.getNewValue(), "ConstructionPlan.Construction_firstStep_Component"), getSelf());
			incUtil.newMessage();
			name2actor.get("Cube2Constr__BWD_34_localSearch").tell(new ReferenceAdded<ConstructionPlan.Construction, ConstructionPlan.Component>(incUtil,(ConstructionPlan.Construction) notification.getNotifier(), (ConstructionPlan.Component) notification.getNewValue(), "ConstructionPlan.Construction_firstStep_Component"), getSelf());
			incUtil.newMessage();
			name2actor.get("Cube2Constr__CONSISTENCY_45_localSearch").tell(new ReferenceAdded<ConstructionPlan.Construction, ConstructionPlan.Component>(incUtil,(ConstructionPlan.Construction) notification.getNotifier(), (ConstructionPlan.Component) notification.getNewValue(), "ConstructionPlan.Construction_firstStep_Component"), getSelf());
			incUtil.newMessage();
			name2actor.get("Villa2Constr_ncst_firstStep_outgoing_TRG__FILTER_NAC_TRG_62_localSearch").tell(new ReferenceAdded<ConstructionPlan.Construction, ConstructionPlan.Component>(incUtil,(ConstructionPlan.Construction) notification.getNotifier(), (ConstructionPlan.Component) notification.getNewValue(), "ConstructionPlan.Construction_firstStep_Component"), getSelf());
			incUtil.newMessage();
			name2actor.get("Villa2Constr_ncst_firstStep_outgoing_TRG__FILTER_NAC_TRG_62_localSearch").tell(new ReferenceAdded<ConstructionPlan.Construction, ConstructionPlan.Component>(incUtil,(ConstructionPlan.Construction) notification.getNotifier(), (ConstructionPlan.Component) notification.getNewValue(), "ConstructionPlan.Construction_firstStep_Component"), getSelf());
			incUtil.newMessage();
			name2actor.get("Villa2Constr__BWD_66_localSearch").tell(new ReferenceAdded<ConstructionPlan.Construction, ConstructionPlan.Component>(incUtil,(ConstructionPlan.Construction) notification.getNotifier(), (ConstructionPlan.Component) notification.getNewValue(), "ConstructionPlan.Construction_firstStep_Component"), getSelf());
			incUtil.newMessage();
			name2actor.get("Villa2Constr__CONSISTENCY_77_localSearch").tell(new ReferenceAdded<ConstructionPlan.Construction, ConstructionPlan.Component>(incUtil,(ConstructionPlan.Construction) notification.getNotifier(), (ConstructionPlan.Component) notification.getNewValue(), "ConstructionPlan.Construction_firstStep_Component"), getSelf());
		});
	}
	
	private void initializeRemoveEdge() {
		feature2removeEdgeConsumer.put(ConstructionPlan.ConstructionPlanPackage.eINSTANCE.getPlan_Constructions(), notification -> {
			incUtil.newMessage();
			name2actor.get("Corner2Constr__BWD_5_localSearch").tell(new ReferenceDeleted<ConstructionPlan.Plan, ConstructionPlan.Construction>(incUtil, (ConstructionPlan.Plan) notification.getNotifier(), (ConstructionPlan.Construction) notification.getOldValue(), "ConstructionPlan.Plan_constructions_Construction"), getSelf());
			incUtil.newMessage();
			name2actor.get("Corner2Constr__CONSISTENCY_15_localSearch").tell(new ReferenceDeleted<ConstructionPlan.Plan, ConstructionPlan.Construction>(incUtil, (ConstructionPlan.Plan) notification.getNotifier(), (ConstructionPlan.Construction) notification.getOldValue(), "ConstructionPlan.Plan_constructions_Construction"), getSelf());
			incUtil.newMessage();
			name2actor.get("Cube2Constr__BWD_34_localSearch").tell(new ReferenceDeleted<ConstructionPlan.Plan, ConstructionPlan.Construction>(incUtil, (ConstructionPlan.Plan) notification.getNotifier(), (ConstructionPlan.Construction) notification.getOldValue(), "ConstructionPlan.Plan_constructions_Construction"), getSelf());
			incUtil.newMessage();
			name2actor.get("Cube2Constr__BWD_34_localSearch").tell(new ReferenceDeleted<ConstructionPlan.Plan, ConstructionPlan.Construction>(incUtil, (ConstructionPlan.Plan) notification.getNotifier(), (ConstructionPlan.Construction) notification.getOldValue(), "ConstructionPlan.Plan_constructions_Construction"), getSelf());
			incUtil.newMessage();
			name2actor.get("Cube2Constr__CONSISTENCY_45_localSearch").tell(new ReferenceDeleted<ConstructionPlan.Plan, ConstructionPlan.Construction>(incUtil, (ConstructionPlan.Plan) notification.getNotifier(), (ConstructionPlan.Construction) notification.getOldValue(), "ConstructionPlan.Plan_constructions_Construction"), getSelf());
			incUtil.newMessage();
			name2actor.get("Cube2Constr__CONSISTENCY_45_localSearch").tell(new ReferenceDeleted<ConstructionPlan.Plan, ConstructionPlan.Construction>(incUtil, (ConstructionPlan.Plan) notification.getNotifier(), (ConstructionPlan.Construction) notification.getOldValue(), "ConstructionPlan.Plan_constructions_Construction"), getSelf());
			incUtil.newMessage();
			name2actor.get("Cube2Constr__FWD_56_localSearch").tell(new ReferenceDeleted<ConstructionPlan.Plan, ConstructionPlan.Construction>(incUtil, (ConstructionPlan.Plan) notification.getNotifier(), (ConstructionPlan.Construction) notification.getOldValue(), "ConstructionPlan.Plan_constructions_Construction"), getSelf());
			incUtil.newMessage();
			name2actor.get("Villa2Constr__BWD_66_localSearch").tell(new ReferenceDeleted<ConstructionPlan.Plan, ConstructionPlan.Construction>(incUtil, (ConstructionPlan.Plan) notification.getNotifier(), (ConstructionPlan.Construction) notification.getOldValue(), "ConstructionPlan.Plan_constructions_Construction"), getSelf());
			incUtil.newMessage();
			name2actor.get("Villa2Constr__BWD_66_localSearch").tell(new ReferenceDeleted<ConstructionPlan.Plan, ConstructionPlan.Construction>(incUtil, (ConstructionPlan.Plan) notification.getNotifier(), (ConstructionPlan.Construction) notification.getOldValue(), "ConstructionPlan.Plan_constructions_Construction"), getSelf());
			incUtil.newMessage();
			name2actor.get("Villa2Constr__CONSISTENCY_77_localSearch").tell(new ReferenceDeleted<ConstructionPlan.Plan, ConstructionPlan.Construction>(incUtil, (ConstructionPlan.Plan) notification.getNotifier(), (ConstructionPlan.Construction) notification.getOldValue(), "ConstructionPlan.Plan_constructions_Construction"), getSelf());
			incUtil.newMessage();
			name2actor.get("Villa2Constr__CONSISTENCY_77_localSearch").tell(new ReferenceDeleted<ConstructionPlan.Plan, ConstructionPlan.Construction>(incUtil, (ConstructionPlan.Plan) notification.getNotifier(), (ConstructionPlan.Construction) notification.getOldValue(), "ConstructionPlan.Plan_constructions_Construction"), getSelf());
			incUtil.newMessage();
			name2actor.get("Villa2Constr__FWD_88_localSearch").tell(new ReferenceDeleted<ConstructionPlan.Plan, ConstructionPlan.Construction>(incUtil, (ConstructionPlan.Plan) notification.getNotifier(), (ConstructionPlan.Construction) notification.getOldValue(), "ConstructionPlan.Plan_constructions_Construction"), getSelf());
		});
		feature2removeEdgeConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getCube2Constr__Marker_CONTEXT__TRG__cst(), notification -> {
			incUtil.newMessage();
			name2actor.get("Cube2Constr__CONSISTENCY_45_localSearch").tell(new ReferenceDeleted<Village2ConstrPlan.Cube2Constr__Marker, ConstructionPlan.Construction>(incUtil, (Village2ConstrPlan.Cube2Constr__Marker) notification.getNotifier(), (ConstructionPlan.Construction) notification.getOldValue(), "Village2ConstrPlan.Cube2Constr__Marker_CONTEXT__TRG__cst_Construction"), getSelf());
		});
		feature2removeEdgeConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getVilla2Constr__Marker_CONTEXT__CORR__h2cst(), notification -> {
			incUtil.newMessage();
			name2actor.get("Villa2Constr__CONSISTENCY_77_localSearch").tell(new ReferenceDeleted<Village2ConstrPlan.Villa2Constr__Marker, Village2ConstrPlan.House2Constr>(incUtil, (Village2ConstrPlan.Villa2Constr__Marker) notification.getNotifier(), (Village2ConstrPlan.House2Constr) notification.getOldValue(), "Village2ConstrPlan.Villa2Constr__Marker_CONTEXT__CORR__h2cst_House2Constr"), getSelf());
		});
		feature2removeEdgeConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getVilla2Constr__Marker_CREATE__CORR__nh2ncst(), notification -> {
			incUtil.newMessage();
			name2actor.get("Villa2Constr__CONSISTENCY_77_localSearch").tell(new ReferenceDeleted<Village2ConstrPlan.Villa2Constr__Marker, Village2ConstrPlan.House2Constr>(incUtil, (Village2ConstrPlan.Villa2Constr__Marker) notification.getNotifier(), (Village2ConstrPlan.House2Constr) notification.getOldValue(), "Village2ConstrPlan.Villa2Constr__Marker_CREATE__CORR__nh2ncst_House2Constr"), getSelf());
		});
		feature2removeEdgeConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getCorner2Constr__Marker_CREATE__TRG__bt(), notification -> {
			incUtil.newMessage();
			name2actor.get("Corner2Constr__CONSISTENCY_15_localSearch").tell(new ReferenceDeleted<Village2ConstrPlan.Corner2Constr__Marker, ConstructionPlan.Basement>(incUtil, (Village2ConstrPlan.Corner2Constr__Marker) notification.getNotifier(), (ConstructionPlan.Basement) notification.getOldValue(), "Village2ConstrPlan.Corner2Constr__Marker_CREATE__TRG__bt_Basement"), getSelf());
		});
		feature2removeEdgeConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getCorner2Constr__Marker_CREATE__SRC__h(), notification -> {
			incUtil.newMessage();
			name2actor.get("Corner2Constr__CONSISTENCY_15_localSearch").tell(new ReferenceDeleted<Village2ConstrPlan.Corner2Constr__Marker, Village.House>(incUtil, (Village2ConstrPlan.Corner2Constr__Marker) notification.getNotifier(), (Village.House) notification.getOldValue(), "Village2ConstrPlan.Corner2Constr__Marker_CREATE__SRC__h_House"), getSelf());
		});
		feature2removeEdgeConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getVilla2Constr__Marker_CREATE__SRC__nh(), notification -> {
			incUtil.newMessage();
			name2actor.get("Villa2Constr__CONSISTENCY_77_localSearch").tell(new ReferenceDeleted<Village2ConstrPlan.Villa2Constr__Marker, Village.House>(incUtil, (Village2ConstrPlan.Villa2Constr__Marker) notification.getNotifier(), (Village.House) notification.getOldValue(), "Village2ConstrPlan.Villa2Constr__Marker_CREATE__SRC__nh_House"), getSelf());
		});
		feature2removeEdgeConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getCorner2Constr__Marker_CONTEXT__SRC__vs(), notification -> {
			incUtil.newMessage();
			name2actor.get("Corner2Constr__CONSISTENCY_15_localSearch").tell(new ReferenceDeleted<Village2ConstrPlan.Corner2Constr__Marker, Village.VillageSquare>(incUtil, (Village2ConstrPlan.Corner2Constr__Marker) notification.getNotifier(), (Village.VillageSquare) notification.getOldValue(), "Village2ConstrPlan.Corner2Constr__Marker_CONTEXT__SRC__vs_VillageSquare"), getSelf());
		});
		feature2removeEdgeConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getVilla2Constr__Marker_CONTEXT__TRG__cst(), notification -> {
			incUtil.newMessage();
			name2actor.get("Villa2Constr__CONSISTENCY_77_localSearch").tell(new ReferenceDeleted<Village2ConstrPlan.Villa2Constr__Marker, ConstructionPlan.Construction>(incUtil, (Village2ConstrPlan.Villa2Constr__Marker) notification.getNotifier(), (ConstructionPlan.Construction) notification.getOldValue(), "Village2ConstrPlan.Villa2Constr__Marker_CONTEXT__TRG__cst_Construction"), getSelf());
		});
		feature2removeEdgeConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getVilla2Constr__Marker_CREATE__TRG__bt(), notification -> {
			incUtil.newMessage();
			name2actor.get("Villa2Constr__CONSISTENCY_77_localSearch").tell(new ReferenceDeleted<Village2ConstrPlan.Villa2Constr__Marker, ConstructionPlan.Basement>(incUtil, (Village2ConstrPlan.Villa2Constr__Marker) notification.getNotifier(), (ConstructionPlan.Basement) notification.getOldValue(), "Village2ConstrPlan.Villa2Constr__Marker_CREATE__TRG__bt_Basement"), getSelf());
		});
		feature2removeEdgeConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getVillageSquare2PlanCollection__Marker_CREATE__SRC__vs(), notification -> {
			incUtil.newMessage();
			name2actor.get("VillageSquare2PlanCollection__CONSISTENCY_95_localSearch").tell(new ReferenceDeleted<Village2ConstrPlan.VillageSquare2PlanCollection__Marker, Village.VillageSquare>(incUtil, (Village2ConstrPlan.VillageSquare2PlanCollection__Marker) notification.getNotifier(), (Village.VillageSquare) notification.getOldValue(), "Village2ConstrPlan.VillageSquare2PlanCollection__Marker_CREATE__SRC__vs_VillageSquare"), getSelf());
		});
		feature2removeEdgeConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getVillageSquare2PlanCollection__Marker_CREATE__TRG__pc(), notification -> {
			incUtil.newMessage();
			name2actor.get("VillageSquare2PlanCollection__CONSISTENCY_95_localSearch").tell(new ReferenceDeleted<Village2ConstrPlan.VillageSquare2PlanCollection__Marker, ConstructionPlan.PlanCollection>(incUtil, (Village2ConstrPlan.VillageSquare2PlanCollection__Marker) notification.getNotifier(), (ConstructionPlan.PlanCollection) notification.getOldValue(), "Village2ConstrPlan.VillageSquare2PlanCollection__Marker_CREATE__TRG__pc_PlanCollection"), getSelf());
		});
		feature2removeEdgeConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getCube2Constr__Marker_CREATE__SRC__nh(), notification -> {
			incUtil.newMessage();
			name2actor.get("Cube2Constr__CONSISTENCY_45_localSearch").tell(new ReferenceDeleted<Village2ConstrPlan.Cube2Constr__Marker, Village.House>(incUtil, (Village2ConstrPlan.Cube2Constr__Marker) notification.getNotifier(), (Village.House) notification.getOldValue(), "Village2ConstrPlan.Cube2Constr__Marker_CREATE__SRC__nh_House"), getSelf());
		});
		feature2removeEdgeConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getVilla2Constr__Marker_CONTEXT__TRG__p(), notification -> {
			incUtil.newMessage();
			name2actor.get("Villa2Constr__CONSISTENCY_77_localSearch").tell(new ReferenceDeleted<Village2ConstrPlan.Villa2Constr__Marker, ConstructionPlan.Plan>(incUtil, (Village2ConstrPlan.Villa2Constr__Marker) notification.getNotifier(), (ConstructionPlan.Plan) notification.getOldValue(), "Village2ConstrPlan.Villa2Constr__Marker_CONTEXT__TRG__p_Plan"), getSelf());
		});
		feature2removeEdgeConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getCube2Constr__Marker_CONTEXT__CORR__h2cst(), notification -> {
			incUtil.newMessage();
			name2actor.get("Cube2Constr__CONSISTENCY_45_localSearch").tell(new ReferenceDeleted<Village2ConstrPlan.Cube2Constr__Marker, Village2ConstrPlan.House2Constr>(incUtil, (Village2ConstrPlan.Cube2Constr__Marker) notification.getNotifier(), (Village2ConstrPlan.House2Constr) notification.getOldValue(), "Village2ConstrPlan.Cube2Constr__Marker_CONTEXT__CORR__h2cst_House2Constr"), getSelf());
		});
		feature2removeEdgeConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getVilla2Constr__Marker_CREATE__TRG__sr(), notification -> {
			incUtil.newMessage();
			name2actor.get("Villa2Constr__CONSISTENCY_77_localSearch").tell(new ReferenceDeleted<Village2ConstrPlan.Villa2Constr__Marker, ConstructionPlan.SaddleRoof>(incUtil, (Village2ConstrPlan.Villa2Constr__Marker) notification.getNotifier(), (ConstructionPlan.SaddleRoof) notification.getOldValue(), "Village2ConstrPlan.Villa2Constr__Marker_CREATE__TRG__sr_SaddleRoof"), getSelf());
		});
		feature2removeEdgeConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getCorner2Constr__Marker_CREATE__CORR__h2cst(), notification -> {
			incUtil.newMessage();
			name2actor.get("Corner2Constr__CONSISTENCY_15_localSearch").tell(new ReferenceDeleted<Village2ConstrPlan.Corner2Constr__Marker, Village2ConstrPlan.House2Constr>(incUtil, (Village2ConstrPlan.Corner2Constr__Marker) notification.getNotifier(), (Village2ConstrPlan.House2Constr) notification.getOldValue(), "Village2ConstrPlan.Corner2Constr__Marker_CREATE__CORR__h2cst_House2Constr"), getSelf());
		});
		feature2removeEdgeConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getVilla2Constr__Marker_CREATE__TRG__ncst(), notification -> {
			incUtil.newMessage();
			name2actor.get("Villa2Constr__CONSISTENCY_77_localSearch").tell(new ReferenceDeleted<Village2ConstrPlan.Villa2Constr__Marker, ConstructionPlan.Construction>(incUtil, (Village2ConstrPlan.Villa2Constr__Marker) notification.getNotifier(), (ConstructionPlan.Construction) notification.getOldValue(), "Village2ConstrPlan.Villa2Constr__Marker_CREATE__TRG__ncst_Construction"), getSelf());
		});
		feature2removeEdgeConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getCorner2Constr__Marker_CONTEXT__TRG__pc(), notification -> {
			incUtil.newMessage();
			name2actor.get("Corner2Constr__CONSISTENCY_15_localSearch").tell(new ReferenceDeleted<Village2ConstrPlan.Corner2Constr__Marker, ConstructionPlan.PlanCollection>(incUtil, (Village2ConstrPlan.Corner2Constr__Marker) notification.getNotifier(), (ConstructionPlan.PlanCollection) notification.getOldValue(), "Village2ConstrPlan.Corner2Constr__Marker_CONTEXT__TRG__pc_PlanCollection"), getSelf());
		});
		feature2removeEdgeConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getCorner2Constr__Marker_CREATE__TRG__p(), notification -> {
			incUtil.newMessage();
			name2actor.get("Corner2Constr__CONSISTENCY_15_localSearch").tell(new ReferenceDeleted<Village2ConstrPlan.Corner2Constr__Marker, ConstructionPlan.Plan>(incUtil, (Village2ConstrPlan.Corner2Constr__Marker) notification.getNotifier(), (ConstructionPlan.Plan) notification.getOldValue(), "Village2ConstrPlan.Corner2Constr__Marker_CREATE__TRG__p_Plan"), getSelf());
		});
		feature2removeEdgeConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getHouse2Constr_Source(), notification -> {
			incUtil.newMessage();
			name2actor.get("Corner2Constr__CONSISTENCY_15_localSearch").tell(new ReferenceDeleted<Village2ConstrPlan.House2Constr, Village.House>(incUtil, (Village2ConstrPlan.House2Constr) notification.getNotifier(), (Village.House) notification.getOldValue(), "Village2ConstrPlan.House2Constr_source_House"), getSelf());
			incUtil.newMessage();
			name2actor.get("Cube2Constr__BWD_34_localSearch").tell(new ReferenceDeleted<Village2ConstrPlan.House2Constr, Village.House>(incUtil, (Village2ConstrPlan.House2Constr) notification.getNotifier(), (Village.House) notification.getOldValue(), "Village2ConstrPlan.House2Constr_source_House"), getSelf());
			incUtil.newMessage();
			name2actor.get("Cube2Constr__CONSISTENCY_45_localSearch").tell(new ReferenceDeleted<Village2ConstrPlan.House2Constr, Village.House>(incUtil, (Village2ConstrPlan.House2Constr) notification.getNotifier(), (Village.House) notification.getOldValue(), "Village2ConstrPlan.House2Constr_source_House"), getSelf());
			incUtil.newMessage();
			name2actor.get("Cube2Constr__CONSISTENCY_45_localSearch").tell(new ReferenceDeleted<Village2ConstrPlan.House2Constr, Village.House>(incUtil, (Village2ConstrPlan.House2Constr) notification.getNotifier(), (Village.House) notification.getOldValue(), "Village2ConstrPlan.House2Constr_source_House"), getSelf());
			incUtil.newMessage();
			name2actor.get("Cube2Constr__FWD_56_localSearch").tell(new ReferenceDeleted<Village2ConstrPlan.House2Constr, Village.House>(incUtil, (Village2ConstrPlan.House2Constr) notification.getNotifier(), (Village.House) notification.getOldValue(), "Village2ConstrPlan.House2Constr_source_House"), getSelf());
			incUtil.newMessage();
			name2actor.get("Villa2Constr__BWD_66_localSearch").tell(new ReferenceDeleted<Village2ConstrPlan.House2Constr, Village.House>(incUtil, (Village2ConstrPlan.House2Constr) notification.getNotifier(), (Village.House) notification.getOldValue(), "Village2ConstrPlan.House2Constr_source_House"), getSelf());
			incUtil.newMessage();
			name2actor.get("Villa2Constr__CONSISTENCY_77_localSearch").tell(new ReferenceDeleted<Village2ConstrPlan.House2Constr, Village.House>(incUtil, (Village2ConstrPlan.House2Constr) notification.getNotifier(), (Village.House) notification.getOldValue(), "Village2ConstrPlan.House2Constr_source_House"), getSelf());
			incUtil.newMessage();
			name2actor.get("Villa2Constr__CONSISTENCY_77_localSearch").tell(new ReferenceDeleted<Village2ConstrPlan.House2Constr, Village.House>(incUtil, (Village2ConstrPlan.House2Constr) notification.getNotifier(), (Village.House) notification.getOldValue(), "Village2ConstrPlan.House2Constr_source_House"), getSelf());
			incUtil.newMessage();
			name2actor.get("Villa2Constr__FWD_88_localSearch").tell(new ReferenceDeleted<Village2ConstrPlan.House2Constr, Village.House>(incUtil, (Village2ConstrPlan.House2Constr) notification.getNotifier(), (Village.House) notification.getOldValue(), "Village2ConstrPlan.House2Constr_source_House"), getSelf());
		});
		feature2removeEdgeConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getCube2Constr__Marker_CREATE__TRG__cl(), notification -> {
			incUtil.newMessage();
			name2actor.get("Cube2Constr__CONSISTENCY_45_localSearch").tell(new ReferenceDeleted<Village2ConstrPlan.Cube2Constr__Marker, ConstructionPlan.Cellar>(incUtil, (Village2ConstrPlan.Cube2Constr__Marker) notification.getNotifier(), (ConstructionPlan.Cellar) notification.getOldValue(), "Village2ConstrPlan.Cube2Constr__Marker_CREATE__TRG__cl_Cellar"), getSelf());
		});
		feature2removeEdgeConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getHouse2Constr_Target(), notification -> {
			incUtil.newMessage();
			name2actor.get("Corner2Constr__CONSISTENCY_15_localSearch").tell(new ReferenceDeleted<Village2ConstrPlan.House2Constr, ConstructionPlan.Construction>(incUtil, (Village2ConstrPlan.House2Constr) notification.getNotifier(), (ConstructionPlan.Construction) notification.getOldValue(), "Village2ConstrPlan.House2Constr_target_Construction"), getSelf());
			incUtil.newMessage();
			name2actor.get("Cube2Constr__BWD_34_localSearch").tell(new ReferenceDeleted<Village2ConstrPlan.House2Constr, ConstructionPlan.Construction>(incUtil, (Village2ConstrPlan.House2Constr) notification.getNotifier(), (ConstructionPlan.Construction) notification.getOldValue(), "Village2ConstrPlan.House2Constr_target_Construction"), getSelf());
			incUtil.newMessage();
			name2actor.get("Cube2Constr__CONSISTENCY_45_localSearch").tell(new ReferenceDeleted<Village2ConstrPlan.House2Constr, ConstructionPlan.Construction>(incUtil, (Village2ConstrPlan.House2Constr) notification.getNotifier(), (ConstructionPlan.Construction) notification.getOldValue(), "Village2ConstrPlan.House2Constr_target_Construction"), getSelf());
			incUtil.newMessage();
			name2actor.get("Cube2Constr__CONSISTENCY_45_localSearch").tell(new ReferenceDeleted<Village2ConstrPlan.House2Constr, ConstructionPlan.Construction>(incUtil, (Village2ConstrPlan.House2Constr) notification.getNotifier(), (ConstructionPlan.Construction) notification.getOldValue(), "Village2ConstrPlan.House2Constr_target_Construction"), getSelf());
			incUtil.newMessage();
			name2actor.get("Cube2Constr__FWD_56_localSearch").tell(new ReferenceDeleted<Village2ConstrPlan.House2Constr, ConstructionPlan.Construction>(incUtil, (Village2ConstrPlan.House2Constr) notification.getNotifier(), (ConstructionPlan.Construction) notification.getOldValue(), "Village2ConstrPlan.House2Constr_target_Construction"), getSelf());
			incUtil.newMessage();
			name2actor.get("Villa2Constr__BWD_66_localSearch").tell(new ReferenceDeleted<Village2ConstrPlan.House2Constr, ConstructionPlan.Construction>(incUtil, (Village2ConstrPlan.House2Constr) notification.getNotifier(), (ConstructionPlan.Construction) notification.getOldValue(), "Village2ConstrPlan.House2Constr_target_Construction"), getSelf());
			incUtil.newMessage();
			name2actor.get("Villa2Constr__CONSISTENCY_77_localSearch").tell(new ReferenceDeleted<Village2ConstrPlan.House2Constr, ConstructionPlan.Construction>(incUtil, (Village2ConstrPlan.House2Constr) notification.getNotifier(), (ConstructionPlan.Construction) notification.getOldValue(), "Village2ConstrPlan.House2Constr_target_Construction"), getSelf());
			incUtil.newMessage();
			name2actor.get("Villa2Constr__CONSISTENCY_77_localSearch").tell(new ReferenceDeleted<Village2ConstrPlan.House2Constr, ConstructionPlan.Construction>(incUtil, (Village2ConstrPlan.House2Constr) notification.getNotifier(), (ConstructionPlan.Construction) notification.getOldValue(), "Village2ConstrPlan.House2Constr_target_Construction"), getSelf());
			incUtil.newMessage();
			name2actor.get("Villa2Constr__FWD_88_localSearch").tell(new ReferenceDeleted<Village2ConstrPlan.House2Constr, ConstructionPlan.Construction>(incUtil, (Village2ConstrPlan.House2Constr) notification.getNotifier(), (ConstructionPlan.Construction) notification.getOldValue(), "Village2ConstrPlan.House2Constr_target_Construction"), getSelf());
		});
		feature2removeEdgeConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getCube2Constr__Marker_CONTEXT__SRC__h(), notification -> {
			incUtil.newMessage();
			name2actor.get("Cube2Constr__CONSISTENCY_45_localSearch").tell(new ReferenceDeleted<Village2ConstrPlan.Cube2Constr__Marker, Village.House>(incUtil, (Village2ConstrPlan.Cube2Constr__Marker) notification.getNotifier(), (Village.House) notification.getOldValue(), "Village2ConstrPlan.Cube2Constr__Marker_CONTEXT__SRC__h_House"), getSelf());
		});
		feature2removeEdgeConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getVilla2Constr__Marker_CONTEXT__SRC__h(), notification -> {
			incUtil.newMessage();
			name2actor.get("Villa2Constr__CONSISTENCY_77_localSearch").tell(new ReferenceDeleted<Village2ConstrPlan.Villa2Constr__Marker, Village.House>(incUtil, (Village2ConstrPlan.Villa2Constr__Marker) notification.getNotifier(), (Village.House) notification.getOldValue(), "Village2ConstrPlan.Villa2Constr__Marker_CONTEXT__SRC__h_House"), getSelf());
		});
		feature2removeEdgeConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getVillageSquare2PlanCollection__Marker_CREATE__CORR__vs2pl(), notification -> {
			incUtil.newMessage();
			name2actor.get("VillageSquare2PlanCollection__CONSISTENCY_95_localSearch").tell(new ReferenceDeleted<Village2ConstrPlan.VillageSquare2PlanCollection__Marker, Village2ConstrPlan.VillageSquare2PlanCollection>(incUtil, (Village2ConstrPlan.VillageSquare2PlanCollection__Marker) notification.getNotifier(), (Village2ConstrPlan.VillageSquare2PlanCollection) notification.getOldValue(), "Village2ConstrPlan.VillageSquare2PlanCollection__Marker_CREATE__CORR__vs2pl_VillageSquare2PlanCollection"), getSelf());
		});
		feature2removeEdgeConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getVillageSquare2PlanCollection_Target(), notification -> {
			incUtil.newMessage();
			name2actor.get("Corner2Constr__BWD_5_localSearch").tell(new ReferenceDeleted<Village2ConstrPlan.VillageSquare2PlanCollection, ConstructionPlan.PlanCollection>(incUtil, (Village2ConstrPlan.VillageSquare2PlanCollection) notification.getNotifier(), (ConstructionPlan.PlanCollection) notification.getOldValue(), "Village2ConstrPlan.VillageSquare2PlanCollection_target_PlanCollection"), getSelf());
			incUtil.newMessage();
			name2actor.get("Corner2Constr__CONSISTENCY_15_localSearch").tell(new ReferenceDeleted<Village2ConstrPlan.VillageSquare2PlanCollection, ConstructionPlan.PlanCollection>(incUtil, (Village2ConstrPlan.VillageSquare2PlanCollection) notification.getNotifier(), (ConstructionPlan.PlanCollection) notification.getOldValue(), "Village2ConstrPlan.VillageSquare2PlanCollection_target_PlanCollection"), getSelf());
			incUtil.newMessage();
			name2actor.get("Corner2Constr__FWD_25_localSearch").tell(new ReferenceDeleted<Village2ConstrPlan.VillageSquare2PlanCollection, ConstructionPlan.PlanCollection>(incUtil, (Village2ConstrPlan.VillageSquare2PlanCollection) notification.getNotifier(), (ConstructionPlan.PlanCollection) notification.getOldValue(), "Village2ConstrPlan.VillageSquare2PlanCollection_target_PlanCollection"), getSelf());
			incUtil.newMessage();
			name2actor.get("VillageSquare2PlanCollection__CONSISTENCY_95_localSearch").tell(new ReferenceDeleted<Village2ConstrPlan.VillageSquare2PlanCollection, ConstructionPlan.PlanCollection>(incUtil, (Village2ConstrPlan.VillageSquare2PlanCollection) notification.getNotifier(), (ConstructionPlan.PlanCollection) notification.getOldValue(), "Village2ConstrPlan.VillageSquare2PlanCollection_target_PlanCollection"), getSelf());
		});
		feature2removeEdgeConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getCorner2Constr__Marker_CONTEXT__CORR__vs2pc(), notification -> {
			incUtil.newMessage();
			name2actor.get("Corner2Constr__CONSISTENCY_15_localSearch").tell(new ReferenceDeleted<Village2ConstrPlan.Corner2Constr__Marker, Village2ConstrPlan.VillageSquare2PlanCollection>(incUtil, (Village2ConstrPlan.Corner2Constr__Marker) notification.getNotifier(), (Village2ConstrPlan.VillageSquare2PlanCollection) notification.getOldValue(), "Village2ConstrPlan.Corner2Constr__Marker_CONTEXT__CORR__vs2pc_VillageSquare2PlanCollection"), getSelf());
		});
		feature2removeEdgeConsumer.put(ConstructionPlan.ConstructionPlanPackage.eINSTANCE.getComponent_NextStep(), notification -> {
			incUtil.newMessage();
			name2actor.get("Cube2Constr__BWD_34_localSearch").tell(new ReferenceDeleted<ConstructionPlan.Component, ConstructionPlan.Component>(incUtil, (ConstructionPlan.Component) notification.getNotifier(), (ConstructionPlan.Component) notification.getOldValue(), "ConstructionPlan.Component_nextStep_Component"), getSelf());
			incUtil.newMessage();
			name2actor.get("Cube2Constr__CONSISTENCY_45_localSearch").tell(new ReferenceDeleted<ConstructionPlan.Component, ConstructionPlan.Component>(incUtil, (ConstructionPlan.Component) notification.getNotifier(), (ConstructionPlan.Component) notification.getOldValue(), "ConstructionPlan.Component_nextStep_Component"), getSelf());
			incUtil.newMessage();
			name2actor.get("Villa2Constr__BWD_66_localSearch").tell(new ReferenceDeleted<ConstructionPlan.Component, ConstructionPlan.Component>(incUtil, (ConstructionPlan.Component) notification.getNotifier(), (ConstructionPlan.Component) notification.getOldValue(), "ConstructionPlan.Component_nextStep_Component"), getSelf());
			incUtil.newMessage();
			name2actor.get("Villa2Constr__CONSISTENCY_77_localSearch").tell(new ReferenceDeleted<ConstructionPlan.Component, ConstructionPlan.Component>(incUtil, (ConstructionPlan.Component) notification.getNotifier(), (ConstructionPlan.Component) notification.getOldValue(), "ConstructionPlan.Component_nextStep_Component"), getSelf());
		});
		feature2removeEdgeConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getCube2Constr__Marker_CREATE__TRG__bt(), notification -> {
			incUtil.newMessage();
			name2actor.get("Cube2Constr__CONSISTENCY_45_localSearch").tell(new ReferenceDeleted<Village2ConstrPlan.Cube2Constr__Marker, ConstructionPlan.Basement>(incUtil, (Village2ConstrPlan.Cube2Constr__Marker) notification.getNotifier(), (ConstructionPlan.Basement) notification.getOldValue(), "Village2ConstrPlan.Cube2Constr__Marker_CREATE__TRG__bt_Basement"), getSelf());
		});
		feature2removeEdgeConsumer.put(Village.VillagePackage.eINSTANCE.getHouse_NextHouse(), notification -> {
			incUtil.newMessage();
			name2actor.get("Corner2Constr_h_nextHouse_incoming_SRC__FILTER_NAC_SRC_12_localSearch").tell(new ReferenceDeleted<Village.House, Village.House>(incUtil, (Village.House) notification.getNotifier(), (Village.House) notification.getOldValue(), "Village.House_nextHouse_House"), getSelf());
			incUtil.newMessage();
			name2actor.get("Cube2Constr__CONSISTENCY_45_localSearch").tell(new ReferenceDeleted<Village.House, Village.House>(incUtil, (Village.House) notification.getNotifier(), (Village.House) notification.getOldValue(), "Village.House_nextHouse_House"), getSelf());
			incUtil.newMessage();
			name2actor.get("Cube2Constr__FWD_56_localSearch").tell(new ReferenceDeleted<Village.House, Village.House>(incUtil, (Village.House) notification.getNotifier(), (Village.House) notification.getOldValue(), "Village.House_nextHouse_House"), getSelf());
			incUtil.newMessage();
			name2actor.get("Villa2Constr__CONSISTENCY_77_localSearch").tell(new ReferenceDeleted<Village.House, Village.House>(incUtil, (Village.House) notification.getNotifier(), (Village.House) notification.getOldValue(), "Village.House_nextHouse_House"), getSelf());
			incUtil.newMessage();
			name2actor.get("Villa2Constr__FWD_88_localSearch").tell(new ReferenceDeleted<Village.House, Village.House>(incUtil, (Village.House) notification.getNotifier(), (Village.House) notification.getOldValue(), "Village.House_nextHouse_House"), getSelf());
		});
		feature2removeEdgeConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getCube2Constr__Marker_CREATE__CORR__nh2ncst(), notification -> {
			incUtil.newMessage();
			name2actor.get("Cube2Constr__CONSISTENCY_45_localSearch").tell(new ReferenceDeleted<Village2ConstrPlan.Cube2Constr__Marker, Village2ConstrPlan.House2Constr>(incUtil, (Village2ConstrPlan.Cube2Constr__Marker) notification.getNotifier(), (Village2ConstrPlan.House2Constr) notification.getOldValue(), "Village2ConstrPlan.Cube2Constr__Marker_CREATE__CORR__nh2ncst_House2Constr"), getSelf());
		});
		feature2removeEdgeConsumer.put(ConstructionPlan.ConstructionPlanPackage.eINSTANCE.getPlanCollection_Plans(), notification -> {
			incUtil.newMessage();
			name2actor.get("Corner2Constr__BWD_5_localSearch").tell(new ReferenceDeleted<ConstructionPlan.PlanCollection, ConstructionPlan.Plan>(incUtil, (ConstructionPlan.PlanCollection) notification.getNotifier(), (ConstructionPlan.Plan) notification.getOldValue(), "ConstructionPlan.PlanCollection_plans_Plan"), getSelf());
			incUtil.newMessage();
			name2actor.get("Corner2Constr__CONSISTENCY_15_localSearch").tell(new ReferenceDeleted<ConstructionPlan.PlanCollection, ConstructionPlan.Plan>(incUtil, (ConstructionPlan.PlanCollection) notification.getNotifier(), (ConstructionPlan.Plan) notification.getOldValue(), "ConstructionPlan.PlanCollection_plans_Plan"), getSelf());
		});
		feature2removeEdgeConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getCorner2Constr__Marker_CREATE__TRG__cst(), notification -> {
			incUtil.newMessage();
			name2actor.get("Corner2Constr__CONSISTENCY_15_localSearch").tell(new ReferenceDeleted<Village2ConstrPlan.Corner2Constr__Marker, ConstructionPlan.Construction>(incUtil, (Village2ConstrPlan.Corner2Constr__Marker) notification.getNotifier(), (ConstructionPlan.Construction) notification.getOldValue(), "Village2ConstrPlan.Corner2Constr__Marker_CREATE__TRG__cst_Construction"), getSelf());
		});
		feature2removeEdgeConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getCube2Constr__Marker_CONTEXT__TRG__p(), notification -> {
			incUtil.newMessage();
			name2actor.get("Cube2Constr__CONSISTENCY_45_localSearch").tell(new ReferenceDeleted<Village2ConstrPlan.Cube2Constr__Marker, ConstructionPlan.Plan>(incUtil, (Village2ConstrPlan.Cube2Constr__Marker) notification.getNotifier(), (ConstructionPlan.Plan) notification.getOldValue(), "Village2ConstrPlan.Cube2Constr__Marker_CONTEXT__TRG__p_Plan"), getSelf());
		});
		feature2removeEdgeConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getCube2Constr__Marker_CREATE__TRG__ncst(), notification -> {
			incUtil.newMessage();
			name2actor.get("Cube2Constr__CONSISTENCY_45_localSearch").tell(new ReferenceDeleted<Village2ConstrPlan.Cube2Constr__Marker, ConstructionPlan.Construction>(incUtil, (Village2ConstrPlan.Cube2Constr__Marker) notification.getNotifier(), (ConstructionPlan.Construction) notification.getOldValue(), "Village2ConstrPlan.Cube2Constr__Marker_CREATE__TRG__ncst_Construction"), getSelf());
		});
		feature2removeEdgeConsumer.put(Village2ConstrPlan.Village2ConstrPlanPackage.eINSTANCE.getVillageSquare2PlanCollection_Source(), notification -> {
			incUtil.newMessage();
			name2actor.get("Corner2Constr__BWD_5_localSearch").tell(new ReferenceDeleted<Village2ConstrPlan.VillageSquare2PlanCollection, Village.VillageSquare>(incUtil, (Village2ConstrPlan.VillageSquare2PlanCollection) notification.getNotifier(), (Village.VillageSquare) notification.getOldValue(), "Village2ConstrPlan.VillageSquare2PlanCollection_source_VillageSquare"), getSelf());
			incUtil.newMessage();
			name2actor.get("Corner2Constr__CONSISTENCY_15_localSearch").tell(new ReferenceDeleted<Village2ConstrPlan.VillageSquare2PlanCollection, Village.VillageSquare>(incUtil, (Village2ConstrPlan.VillageSquare2PlanCollection) notification.getNotifier(), (Village.VillageSquare) notification.getOldValue(), "Village2ConstrPlan.VillageSquare2PlanCollection_source_VillageSquare"), getSelf());
			incUtil.newMessage();
			name2actor.get("Corner2Constr__FWD_25_localSearch").tell(new ReferenceDeleted<Village2ConstrPlan.VillageSquare2PlanCollection, Village.VillageSquare>(incUtil, (Village2ConstrPlan.VillageSquare2PlanCollection) notification.getNotifier(), (Village.VillageSquare) notification.getOldValue(), "Village2ConstrPlan.VillageSquare2PlanCollection_source_VillageSquare"), getSelf());
			incUtil.newMessage();
			name2actor.get("VillageSquare2PlanCollection__CONSISTENCY_95_localSearch").tell(new ReferenceDeleted<Village2ConstrPlan.VillageSquare2PlanCollection, Village.VillageSquare>(incUtil, (Village2ConstrPlan.VillageSquare2PlanCollection) notification.getNotifier(), (Village.VillageSquare) notification.getOldValue(), "Village2ConstrPlan.VillageSquare2PlanCollection_source_VillageSquare"), getSelf());
		});
		feature2removeEdgeConsumer.put(Village.VillagePackage.eINSTANCE.getVillageSquare_StreetCorner(), notification -> {
			incUtil.newMessage();
			name2actor.get("Corner2Constr__CONSISTENCY_15_localSearch").tell(new ReferenceDeleted<Village.VillageSquare, Village.House>(incUtil, (Village.VillageSquare) notification.getNotifier(), (Village.House) notification.getOldValue(), "Village.VillageSquare_streetCorner_House"), getSelf());
			incUtil.newMessage();
			name2actor.get("Corner2Constr__FWD_25_localSearch").tell(new ReferenceDeleted<Village.VillageSquare, Village.House>(incUtil, (Village.VillageSquare) notification.getNotifier(), (Village.House) notification.getOldValue(), "Village.VillageSquare_streetCorner_House"), getSelf());
			incUtil.newMessage();
			name2actor.get("Cube2Constr_nh_streetCorner_incoming_SRC__FILTER_NAC_SRC_42_localSearch").tell(new ReferenceDeleted<Village.VillageSquare, Village.House>(incUtil, (Village.VillageSquare) notification.getNotifier(), (Village.House) notification.getOldValue(), "Village.VillageSquare_streetCorner_House"), getSelf());
			incUtil.newMessage();
			name2actor.get("Villa2Constr_nh_streetCorner_incoming_SRC__FILTER_NAC_SRC_74_localSearch").tell(new ReferenceDeleted<Village.VillageSquare, Village.House>(incUtil, (Village.VillageSquare) notification.getNotifier(), (Village.House) notification.getOldValue(), "Village.VillageSquare_streetCorner_House"), getSelf());
		});
		feature2removeEdgeConsumer.put(ConstructionPlan.ConstructionPlanPackage.eINSTANCE.getConstruction_FirstStep(), notification -> {
			incUtil.newMessage();
			name2actor.get("Corner2Constr_cst_firstStep_outgoing_TRG__FILTER_NAC_TRG_1_localSearch").tell(new ReferenceDeleted<ConstructionPlan.Construction, ConstructionPlan.Component>(incUtil, (ConstructionPlan.Construction) notification.getNotifier(), (ConstructionPlan.Component) notification.getOldValue(), "ConstructionPlan.Construction_firstStep_Component"), getSelf());
			incUtil.newMessage();
			name2actor.get("Corner2Constr_cst_firstStep_outgoing_TRG__FILTER_NAC_TRG_1_localSearch").tell(new ReferenceDeleted<ConstructionPlan.Construction, ConstructionPlan.Component>(incUtil, (ConstructionPlan.Construction) notification.getNotifier(), (ConstructionPlan.Component) notification.getOldValue(), "ConstructionPlan.Construction_firstStep_Component"), getSelf());
			incUtil.newMessage();
			name2actor.get("Corner2Constr__BWD_5_localSearch").tell(new ReferenceDeleted<ConstructionPlan.Construction, ConstructionPlan.Component>(incUtil, (ConstructionPlan.Construction) notification.getNotifier(), (ConstructionPlan.Component) notification.getOldValue(), "ConstructionPlan.Construction_firstStep_Component"), getSelf());
			incUtil.newMessage();
			name2actor.get("Corner2Constr__CONSISTENCY_15_localSearch").tell(new ReferenceDeleted<ConstructionPlan.Construction, ConstructionPlan.Component>(incUtil, (ConstructionPlan.Construction) notification.getNotifier(), (ConstructionPlan.Component) notification.getOldValue(), "ConstructionPlan.Construction_firstStep_Component"), getSelf());
			incUtil.newMessage();
			name2actor.get("Cube2Constr_ncst_firstStep_outgoing_TRG__FILTER_NAC_TRG_30_localSearch").tell(new ReferenceDeleted<ConstructionPlan.Construction, ConstructionPlan.Component>(incUtil, (ConstructionPlan.Construction) notification.getNotifier(), (ConstructionPlan.Component) notification.getOldValue(), "ConstructionPlan.Construction_firstStep_Component"), getSelf());
			incUtil.newMessage();
			name2actor.get("Cube2Constr_ncst_firstStep_outgoing_TRG__FILTER_NAC_TRG_30_localSearch").tell(new ReferenceDeleted<ConstructionPlan.Construction, ConstructionPlan.Component>(incUtil, (ConstructionPlan.Construction) notification.getNotifier(), (ConstructionPlan.Component) notification.getOldValue(), "ConstructionPlan.Construction_firstStep_Component"), getSelf());
			incUtil.newMessage();
			name2actor.get("Cube2Constr__BWD_34_localSearch").tell(new ReferenceDeleted<ConstructionPlan.Construction, ConstructionPlan.Component>(incUtil, (ConstructionPlan.Construction) notification.getNotifier(), (ConstructionPlan.Component) notification.getOldValue(), "ConstructionPlan.Construction_firstStep_Component"), getSelf());
			incUtil.newMessage();
			name2actor.get("Cube2Constr__CONSISTENCY_45_localSearch").tell(new ReferenceDeleted<ConstructionPlan.Construction, ConstructionPlan.Component>(incUtil, (ConstructionPlan.Construction) notification.getNotifier(), (ConstructionPlan.Component) notification.getOldValue(), "ConstructionPlan.Construction_firstStep_Component"), getSelf());
			incUtil.newMessage();
			name2actor.get("Villa2Constr_ncst_firstStep_outgoing_TRG__FILTER_NAC_TRG_62_localSearch").tell(new ReferenceDeleted<ConstructionPlan.Construction, ConstructionPlan.Component>(incUtil, (ConstructionPlan.Construction) notification.getNotifier(), (ConstructionPlan.Component) notification.getOldValue(), "ConstructionPlan.Construction_firstStep_Component"), getSelf());
			incUtil.newMessage();
			name2actor.get("Villa2Constr_ncst_firstStep_outgoing_TRG__FILTER_NAC_TRG_62_localSearch").tell(new ReferenceDeleted<ConstructionPlan.Construction, ConstructionPlan.Component>(incUtil, (ConstructionPlan.Construction) notification.getNotifier(), (ConstructionPlan.Component) notification.getOldValue(), "ConstructionPlan.Construction_firstStep_Component"), getSelf());
			incUtil.newMessage();
			name2actor.get("Villa2Constr__BWD_66_localSearch").tell(new ReferenceDeleted<ConstructionPlan.Construction, ConstructionPlan.Component>(incUtil, (ConstructionPlan.Construction) notification.getNotifier(), (ConstructionPlan.Component) notification.getOldValue(), "ConstructionPlan.Construction_firstStep_Component"), getSelf());
			incUtil.newMessage();
			name2actor.get("Villa2Constr__CONSISTENCY_77_localSearch").tell(new ReferenceDeleted<ConstructionPlan.Construction, ConstructionPlan.Component>(incUtil, (ConstructionPlan.Construction) notification.getNotifier(), (ConstructionPlan.Component) notification.getOldValue(), "ConstructionPlan.Construction_firstStep_Component"), getSelf());
		});
	}

	@Override
	public void preStart() throws Exception {
		super.preStart();
	}

	@Override
	public void postStop() throws Exception {
		if(HiPEConfig.logWorkloadActivated) {
			DecimalFormat df = new DecimalFormat("0.#####");
	        df.setMaximumFractionDigits(5);
			System.err.println("DispatchNode" + ";"  + counter + ";" + df.format((double) time / (double) (1000 * 1000 * 1000)));
		}
	}

	@Override
	public Receive createReceive() {
		return receiveBuilder() //
				.match(NotificationContainer.class, this::handleNotificationContainer)
				.match(NoMoreInput.class, this::sendFinished) //
				.build();
	}

	private void sendFinished(NoMoreInput m) {
		incUtil.allMessagesInserted();
	}
	
	private void handleNotificationContainer(NotificationContainer nc) {
		counter++;
		long tic = System.nanoTime();
		nc.notifications.parallelStream().forEach(this::handleNotification);
		time += System.nanoTime() - tic;
	}
	
	private void handleNotification(Notification notification) {
		switch (notification.getEventType()) {
		case Notification.ADD:
			handleAdd(notification);
			break;
		case Notification.REMOVE:
			handleRemove(notification);
			break;
		case Notification.REMOVING_ADAPTER:
			handleRemoveAdapter(notification);
			break;	
		case Notification.SET:
			handleSet(notification);
			break;
		}
	}

	private void handleAdd(Notification notification) {
		if(notification.getFeature() == null) 
			handleAddedNode(notification.getNewValue());
		else
			handleAddedEdge(notification);
	}

	private void handleAddedNode(Object node) {
		if(node == null) 
			return;
			
		EObject obj = (EObject) node;
		if(type2addConsumer.containsKey(obj.eClass())) {
			type2addConsumer.get(obj.eClass()).accept(node);
		}
	}
	
	private void handleSet(Notification notification) {
		Object feature = notification.getFeature();
		if(feature2setConsumer.containsKey(feature)) {
			feature2setConsumer.get(feature).accept(notification);
		}
	}

	private void handleAddedEdge(Notification notification) {
		//check for self-edges
		if(notification.getNotifier().equals(notification.getNewValue()))
			handleAddedNode(notification.getNewValue());
					
		Object feature = notification.getFeature();
		if(feature2addEdgeConsumer.containsKey(feature)) {
			feature2addEdgeConsumer.get(feature).accept(notification);
		}
	}

	private void handleRemove(Notification notification) {
		Object feature = notification.getFeature();
		if(feature2removeEdgeConsumer.containsKey(feature)) {
			feature2removeEdgeConsumer.get(feature).accept(notification);
		}
	}
	
	private void handleRemoveAdapter(Notification notification) {
		Object node = notification.getNotifier();
		if (node instanceof Village2ConstrPlan.VillageSquare2PlanCollection) {
			incUtil.newMessage();
			name2actor.get("VillageSquare2PlanCollection_object").tell(new ObjectDeleted<Village2ConstrPlan.VillageSquare2PlanCollection>(incUtil, (Village2ConstrPlan.VillageSquare2PlanCollection) node), getSelf());
		}
		if (node instanceof Village2ConstrPlan.Corner2Constr__Marker) {
			incUtil.newMessage();
			name2actor.get("Corner2Constr__Marker_object").tell(new ObjectDeleted<Village2ConstrPlan.Corner2Constr__Marker>(incUtil, (Village2ConstrPlan.Corner2Constr__Marker) node), getSelf());
		}
		if (node instanceof Village2ConstrPlan.Cube2Constr__Marker) {
			incUtil.newMessage();
			name2actor.get("Cube2Constr__Marker_object").tell(new ObjectDeleted<Village2ConstrPlan.Cube2Constr__Marker>(incUtil, (Village2ConstrPlan.Cube2Constr__Marker) node), getSelf());
		}
		if (node instanceof Village2ConstrPlan.Villa2Constr__Marker) {
			incUtil.newMessage();
			name2actor.get("Villa2Constr__Marker_object").tell(new ObjectDeleted<Village2ConstrPlan.Villa2Constr__Marker>(incUtil, (Village2ConstrPlan.Villa2Constr__Marker) node), getSelf());
		}
		if (node instanceof Village2ConstrPlan.VillageSquare2PlanCollection__Marker) {
			incUtil.newMessage();
			name2actor.get("VillageSquare2PlanCollection__Marker_object").tell(new ObjectDeleted<Village2ConstrPlan.VillageSquare2PlanCollection__Marker>(incUtil, (Village2ConstrPlan.VillageSquare2PlanCollection__Marker) node), getSelf());
		}
		if (node instanceof Village2ConstrPlan.House2Constr) {
			incUtil.newMessage();
			name2actor.get("House2Constr_object_SP0").tell(new ObjectDeleted<Village2ConstrPlan.House2Constr>(incUtil, (Village2ConstrPlan.House2Constr) node), getSelf());
		}
		if (node instanceof Village2ConstrPlan.House2Constr) {
			incUtil.newMessage();
			name2actor.get("House2Constr_object_SP1").tell(new ObjectDeleted<Village2ConstrPlan.House2Constr>(incUtil, (Village2ConstrPlan.House2Constr) node), getSelf());
		}
		if (node instanceof Village.VillageSquare) {
			incUtil.newMessage();
			name2actor.get("VillageSquare_object_SP0").tell(new ObjectDeleted<Village.VillageSquare>(incUtil, (Village.VillageSquare) node), getSelf());
		}
		if (node instanceof Village.VillageSquare) {
			incUtil.newMessage();
			name2actor.get("VillageSquare_object_SP1").tell(new ObjectDeleted<Village.VillageSquare>(incUtil, (Village.VillageSquare) node), getSelf());
		}
		if (node instanceof Village.House) {
			incUtil.newMessage();
			name2actor.get("House_object_SP0").tell(new ObjectDeleted<Village.House>(incUtil, (Village.House) node), getSelf());
		}
		if (node instanceof Village.House) {
			incUtil.newMessage();
			name2actor.get("House_object_SP1").tell(new ObjectDeleted<Village.House>(incUtil, (Village.House) node), getSelf());
		}
		if (node instanceof Village.House) {
			incUtil.newMessage();
			name2actor.get("House_object_SP2").tell(new ObjectDeleted<Village.House>(incUtil, (Village.House) node), getSelf());
		}
		if (node instanceof ConstructionPlan.Component) {
			incUtil.newMessage();
			name2actor.get("Component_object").tell(new ObjectDeleted<ConstructionPlan.Component>(incUtil, (ConstructionPlan.Component) node), getSelf());
		}
		if (node instanceof ConstructionPlan.Cellar) {
			incUtil.newMessage();
			name2actor.get("Cellar_object").tell(new ObjectDeleted<ConstructionPlan.Cellar>(incUtil, (ConstructionPlan.Cellar) node), getSelf());
		}
		if (node instanceof ConstructionPlan.SaddleRoof) {
			incUtil.newMessage();
			name2actor.get("SaddleRoof_object").tell(new ObjectDeleted<ConstructionPlan.SaddleRoof>(incUtil, (ConstructionPlan.SaddleRoof) node), getSelf());
		}
		if (node instanceof ConstructionPlan.PlanCollection) {
			incUtil.newMessage();
			name2actor.get("PlanCollection_object_SP0").tell(new ObjectDeleted<ConstructionPlan.PlanCollection>(incUtil, (ConstructionPlan.PlanCollection) node), getSelf());
		}
		if (node instanceof ConstructionPlan.PlanCollection) {
			incUtil.newMessage();
			name2actor.get("PlanCollection_object_SP1").tell(new ObjectDeleted<ConstructionPlan.PlanCollection>(incUtil, (ConstructionPlan.PlanCollection) node), getSelf());
		}
		if (node instanceof ConstructionPlan.Basement) {
			incUtil.newMessage();
			name2actor.get("Basement_object_SP0").tell(new ObjectDeleted<ConstructionPlan.Basement>(incUtil, (ConstructionPlan.Basement) node), getSelf());
		}
		if (node instanceof ConstructionPlan.Basement) {
			incUtil.newMessage();
			name2actor.get("Basement_object_SP1").tell(new ObjectDeleted<ConstructionPlan.Basement>(incUtil, (ConstructionPlan.Basement) node), getSelf());
		}
		if (node instanceof ConstructionPlan.Construction) {
			incUtil.newMessage();
			name2actor.get("Construction_object_SP0").tell(new ObjectDeleted<ConstructionPlan.Construction>(incUtil, (ConstructionPlan.Construction) node), getSelf());
		}
		if (node instanceof ConstructionPlan.Construction) {
			incUtil.newMessage();
			name2actor.get("Construction_object_SP1").tell(new ObjectDeleted<ConstructionPlan.Construction>(incUtil, (ConstructionPlan.Construction) node), getSelf());
		}
		if (node instanceof ConstructionPlan.Construction) {
			incUtil.newMessage();
			name2actor.get("Construction_object_SP2").tell(new ObjectDeleted<ConstructionPlan.Construction>(incUtil, (ConstructionPlan.Construction) node), getSelf());
		}
		if (node instanceof ConstructionPlan.Plan) {
			incUtil.newMessage();
			name2actor.get("Plan_object_SP0").tell(new ObjectDeleted<ConstructionPlan.Plan>(incUtil, (ConstructionPlan.Plan) node), getSelf());
		}
		if (node instanceof ConstructionPlan.Plan) {
			incUtil.newMessage();
			name2actor.get("Plan_object_SP1").tell(new ObjectDeleted<ConstructionPlan.Plan>(incUtil, (ConstructionPlan.Plan) node), getSelf());
		}
	}
}

