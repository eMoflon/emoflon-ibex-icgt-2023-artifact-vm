package ExtType2Doc_LookAhead.impl;

import ExtType2Doc_LookAhead.Package2Folder;
import ExtType2Doc_LookAhead.Type2Doc;
import ExtType2Doc_LookAhead.Method2Entry;
import ExtType2Doc_LookAhead.Param2Entry;
import ExtType2Doc_LookAhead.Field2Entry;
import ExtType2Doc_LookAhead.ExtendingType2Doc__Marker;
import ExtType2Doc_LookAhead.Field2Entry__Marker;
import ExtType2Doc_LookAhead.ImplementingType2Doc__Marker;
import ExtType2Doc_LookAhead.Method2Entry__Marker;
import ExtType2Doc_LookAhead.Package2Folder__Marker;
import ExtType2Doc_LookAhead.Param2Entry__Marker;
import ExtType2Doc_LookAhead.SubPackage2Folder__Marker;
import ExtType2Doc_LookAhead.Type2Doc__Marker;


import ExtType2Doc_LookAhead.ExtType2Doc_LookAheadFactory;
import ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage;

import ExtTypeModel.ExtTypeModelPackage;
import ExtDocModel.ExtDocModelPackage;
import runtime.RuntimePackage;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.ecore.EcorePackage;

import org.eclipse.emf.ecore.impl.EPackageImpl;

import org.emoflon.smartemf.runtime.SmartPackageImpl;

public class ExtType2Doc_LookAheadPackageImpl extends SmartPackageImpl
		implements ExtType2Doc_LookAheadPackage {
			
	private EClass package2FolderEClass = null;
	private EReference package2Folder_sourceEReference = null;
	private EReference package2Folder_targetEReference = null;
	private EClass type2DocEClass = null;
	private EReference type2Doc_sourceEReference = null;
	private EReference type2Doc_targetEReference = null;
	private EClass method2EntryEClass = null;
	private EReference method2Entry_sourceEReference = null;
	private EReference method2Entry_targetEReference = null;
	private EClass param2EntryEClass = null;
	private EReference param2Entry_sourceEReference = null;
	private EReference param2Entry_targetEReference = null;
	private EClass field2EntryEClass = null;
	private EReference field2Entry_sourceEReference = null;
	private EReference field2Entry_targetEReference = null;
	private EClass extendingType2Doc__MarkerEClass = null;
	private EReference extendingType2Doc__Marker_cREATE__SRC__ntEReference = null;
	private EReference extendingType2Doc__Marker_cONTEXT__SRC__pEReference = null;
	private EReference extendingType2Doc__Marker_cONTEXT__SRC__tEReference = null;
	private EReference extendingType2Doc__Marker_cONTEXT__TRG__dEReference = null;
	private EReference extendingType2Doc__Marker_cONTEXT__TRG__fEReference = null;
	private EReference extendingType2Doc__Marker_cREATE__TRG__ndEReference = null;
	private EReference extendingType2Doc__Marker_cREATE__CORR__nt2ndEReference = null;
	private EReference extendingType2Doc__Marker_cONTEXT__CORR__p2fEReference = null;
	private EReference extendingType2Doc__Marker_cONTEXT__CORR__t2dEReference = null;
	private EClass field2Entry__MarkerEClass = null;
	private EReference field2Entry__Marker_cREATE__SRC__fEReference = null;
	private EReference field2Entry__Marker_cONTEXT__SRC__tEReference = null;
	private EReference field2Entry__Marker_cONTEXT__TRG__dEReference = null;
	private EReference field2Entry__Marker_cREATE__TRG__eEReference = null;
	private EReference field2Entry__Marker_cREATE__CORR__f2eEReference = null;
	private EReference field2Entry__Marker_cONTEXT__CORR__t2dEReference = null;
	private EClass implementingType2Doc__MarkerEClass = null;
	private EReference implementingType2Doc__Marker_cONTEXT__SRC__itEReference = null;
	private EReference implementingType2Doc__Marker_cONTEXT__SRC__tEReference = null;
	private EReference implementingType2Doc__Marker_cONTEXT__TRG__dEReference = null;
	private EReference implementingType2Doc__Marker_cONTEXT__TRG__idEReference = null;
	private EReference implementingType2Doc__Marker_cONTEXT__CORR__it2idEReference = null;
	private EReference implementingType2Doc__Marker_cONTEXT__CORR__t2dEReference = null;
	private EClass method2Entry__MarkerEClass = null;
	private EReference method2Entry__Marker_cREATE__SRC__mEReference = null;
	private EReference method2Entry__Marker_cONTEXT__SRC__tEReference = null;
	private EReference method2Entry__Marker_cONTEXT__TRG__dEReference = null;
	private EReference method2Entry__Marker_cREATE__TRG__eEReference = null;
	private EReference method2Entry__Marker_cREATE__CORR__m2eEReference = null;
	private EReference method2Entry__Marker_cONTEXT__CORR__t2dEReference = null;
	private EClass package2Folder__MarkerEClass = null;
	private EReference package2Folder__Marker_cREATE__SRC__pEReference = null;
	private EReference package2Folder__Marker_cREATE__TRG__fEReference = null;
	private EReference package2Folder__Marker_cREATE__CORR__p2fEReference = null;
	private EClass param2Entry__MarkerEClass = null;
	private EReference param2Entry__Marker_cONTEXT__SRC__mEReference = null;
	private EReference param2Entry__Marker_cREATE__SRC__pEReference = null;
	private EReference param2Entry__Marker_cONTEXT__TRG__eEReference = null;
	private EReference param2Entry__Marker_cONTEXT__CORR__m2eEReference = null;
	private EReference param2Entry__Marker_cREATE__CORR__p2eEReference = null;
	private EClass subPackage2Folder__MarkerEClass = null;
	private EReference subPackage2Folder__Marker_cONTEXT__SRC__pEReference = null;
	private EReference subPackage2Folder__Marker_cREATE__SRC__spEReference = null;
	private EReference subPackage2Folder__Marker_cONTEXT__TRG__fEReference = null;
	private EReference subPackage2Folder__Marker_cREATE__TRG__sfEReference = null;
	private EReference subPackage2Folder__Marker_cONTEXT__CORR__p2fEReference = null;
	private EReference subPackage2Folder__Marker_cREATE__CORR__sp2fEReference = null;
	private EClass type2Doc__MarkerEClass = null;
	private EReference type2Doc__Marker_cONTEXT__SRC__pEReference = null;
	private EReference type2Doc__Marker_cREATE__SRC__tEReference = null;
	private EReference type2Doc__Marker_cREATE__TRG__dEReference = null;
	private EReference type2Doc__Marker_cONTEXT__TRG__fEReference = null;
	private EReference type2Doc__Marker_cONTEXT__CORR__p2fEReference = null;
	private EReference type2Doc__Marker_cREATE__CORR__t2dEReference = null;
	
	

	private ExtType2Doc_LookAheadPackageImpl() {
		super(eNS_URI, ExtType2Doc_LookAhead.ExtType2Doc_LookAheadFactory.eINSTANCE);
	}

	private static boolean isRegistered = false;
	private boolean isCreated = false;
	private boolean isInitialized = false;

	public static ExtType2Doc_LookAheadPackage init() {
		if (isRegistered)
			return (ExtType2Doc_LookAheadPackage) EPackage.Registry.INSTANCE
					.getEPackage(ExtType2Doc_LookAheadPackage.eNS_URI);

		// Obtain or create and register package
		Object registeredExtType2Doc_LookAheadPackage = EPackage.Registry.INSTANCE.get(eNS_URI);
		ExtType2Doc_LookAheadPackageImpl theExtType2Doc_LookAheadPackage = registeredExtType2Doc_LookAheadPackage instanceof ExtType2Doc_LookAheadPackageImpl
				? (ExtType2Doc_LookAheadPackageImpl) registeredExtType2Doc_LookAheadPackage
				: new ExtType2Doc_LookAheadPackageImpl();

		isRegistered = true;

		// Create package meta-data objects
		theExtType2Doc_LookAheadPackage.createPackageContents();

		// Initialize created meta-data
		theExtType2Doc_LookAheadPackage.initializePackageContents();
		
		// Inject internal eOpposites to unidirectional references
		theExtType2Doc_LookAheadPackage.injectDynamicOpposites();
		
		// Inject external references into foreign packages
		theExtType2Doc_LookAheadPackage.injectExternalReferences();

		// Mark meta-data to indicate it can't be changed
		theExtType2Doc_LookAheadPackage.freeze();

		// Update the registry and return the package
		EPackage.Registry.INSTANCE.put(ExtType2Doc_LookAheadPackage.eNS_URI,
				theExtType2Doc_LookAheadPackage);
				
		theExtType2Doc_LookAheadPackage.fetchDynamicEStructuralFeaturesOfSuperTypes();
		return theExtType2Doc_LookAheadPackage;
	}

	@Override
	public EClass getPackage2Folder() {
		return package2FolderEClass;
	}
	@Override
	public EReference getPackage2Folder_Source() {
		return package2Folder_sourceEReference;	
	}
	@Override
	public EReference getPackage2Folder_Target() {
		return package2Folder_targetEReference;	
	}
	@Override
	public EClass getType2Doc() {
		return type2DocEClass;
	}
	@Override
	public EReference getType2Doc_Source() {
		return type2Doc_sourceEReference;	
	}
	@Override
	public EReference getType2Doc_Target() {
		return type2Doc_targetEReference;	
	}
	@Override
	public EClass getMethod2Entry() {
		return method2EntryEClass;
	}
	@Override
	public EReference getMethod2Entry_Source() {
		return method2Entry_sourceEReference;	
	}
	@Override
	public EReference getMethod2Entry_Target() {
		return method2Entry_targetEReference;	
	}
	@Override
	public EClass getParam2Entry() {
		return param2EntryEClass;
	}
	@Override
	public EReference getParam2Entry_Source() {
		return param2Entry_sourceEReference;	
	}
	@Override
	public EReference getParam2Entry_Target() {
		return param2Entry_targetEReference;	
	}
	@Override
	public EClass getField2Entry() {
		return field2EntryEClass;
	}
	@Override
	public EReference getField2Entry_Source() {
		return field2Entry_sourceEReference;	
	}
	@Override
	public EReference getField2Entry_Target() {
		return field2Entry_targetEReference;	
	}
	@Override
	public EClass getExtendingType2Doc__Marker() {
		return extendingType2Doc__MarkerEClass;
	}
	@Override
	public EReference getExtendingType2Doc__Marker_CREATE__SRC__nt() {
		return extendingType2Doc__Marker_cREATE__SRC__ntEReference;	
	}
	@Override
	public EReference getExtendingType2Doc__Marker_CONTEXT__SRC__p() {
		return extendingType2Doc__Marker_cONTEXT__SRC__pEReference;	
	}
	@Override
	public EReference getExtendingType2Doc__Marker_CONTEXT__SRC__t() {
		return extendingType2Doc__Marker_cONTEXT__SRC__tEReference;	
	}
	@Override
	public EReference getExtendingType2Doc__Marker_CONTEXT__TRG__d() {
		return extendingType2Doc__Marker_cONTEXT__TRG__dEReference;	
	}
	@Override
	public EReference getExtendingType2Doc__Marker_CONTEXT__TRG__f() {
		return extendingType2Doc__Marker_cONTEXT__TRG__fEReference;	
	}
	@Override
	public EReference getExtendingType2Doc__Marker_CREATE__TRG__nd() {
		return extendingType2Doc__Marker_cREATE__TRG__ndEReference;	
	}
	@Override
	public EReference getExtendingType2Doc__Marker_CREATE__CORR__nt2nd() {
		return extendingType2Doc__Marker_cREATE__CORR__nt2ndEReference;	
	}
	@Override
	public EReference getExtendingType2Doc__Marker_CONTEXT__CORR__p2f() {
		return extendingType2Doc__Marker_cONTEXT__CORR__p2fEReference;	
	}
	@Override
	public EReference getExtendingType2Doc__Marker_CONTEXT__CORR__t2d() {
		return extendingType2Doc__Marker_cONTEXT__CORR__t2dEReference;	
	}
	@Override
	public EClass getField2Entry__Marker() {
		return field2Entry__MarkerEClass;
	}
	@Override
	public EReference getField2Entry__Marker_CREATE__SRC__f() {
		return field2Entry__Marker_cREATE__SRC__fEReference;	
	}
	@Override
	public EReference getField2Entry__Marker_CONTEXT__SRC__t() {
		return field2Entry__Marker_cONTEXT__SRC__tEReference;	
	}
	@Override
	public EReference getField2Entry__Marker_CONTEXT__TRG__d() {
		return field2Entry__Marker_cONTEXT__TRG__dEReference;	
	}
	@Override
	public EReference getField2Entry__Marker_CREATE__TRG__e() {
		return field2Entry__Marker_cREATE__TRG__eEReference;	
	}
	@Override
	public EReference getField2Entry__Marker_CREATE__CORR__f2e() {
		return field2Entry__Marker_cREATE__CORR__f2eEReference;	
	}
	@Override
	public EReference getField2Entry__Marker_CONTEXT__CORR__t2d() {
		return field2Entry__Marker_cONTEXT__CORR__t2dEReference;	
	}
	@Override
	public EClass getImplementingType2Doc__Marker() {
		return implementingType2Doc__MarkerEClass;
	}
	@Override
	public EReference getImplementingType2Doc__Marker_CONTEXT__SRC__it() {
		return implementingType2Doc__Marker_cONTEXT__SRC__itEReference;	
	}
	@Override
	public EReference getImplementingType2Doc__Marker_CONTEXT__SRC__t() {
		return implementingType2Doc__Marker_cONTEXT__SRC__tEReference;	
	}
	@Override
	public EReference getImplementingType2Doc__Marker_CONTEXT__TRG__d() {
		return implementingType2Doc__Marker_cONTEXT__TRG__dEReference;	
	}
	@Override
	public EReference getImplementingType2Doc__Marker_CONTEXT__TRG__id() {
		return implementingType2Doc__Marker_cONTEXT__TRG__idEReference;	
	}
	@Override
	public EReference getImplementingType2Doc__Marker_CONTEXT__CORR__it2id() {
		return implementingType2Doc__Marker_cONTEXT__CORR__it2idEReference;	
	}
	@Override
	public EReference getImplementingType2Doc__Marker_CONTEXT__CORR__t2d() {
		return implementingType2Doc__Marker_cONTEXT__CORR__t2dEReference;	
	}
	@Override
	public EClass getMethod2Entry__Marker() {
		return method2Entry__MarkerEClass;
	}
	@Override
	public EReference getMethod2Entry__Marker_CREATE__SRC__m() {
		return method2Entry__Marker_cREATE__SRC__mEReference;	
	}
	@Override
	public EReference getMethod2Entry__Marker_CONTEXT__SRC__t() {
		return method2Entry__Marker_cONTEXT__SRC__tEReference;	
	}
	@Override
	public EReference getMethod2Entry__Marker_CONTEXT__TRG__d() {
		return method2Entry__Marker_cONTEXT__TRG__dEReference;	
	}
	@Override
	public EReference getMethod2Entry__Marker_CREATE__TRG__e() {
		return method2Entry__Marker_cREATE__TRG__eEReference;	
	}
	@Override
	public EReference getMethod2Entry__Marker_CREATE__CORR__m2e() {
		return method2Entry__Marker_cREATE__CORR__m2eEReference;	
	}
	@Override
	public EReference getMethod2Entry__Marker_CONTEXT__CORR__t2d() {
		return method2Entry__Marker_cONTEXT__CORR__t2dEReference;	
	}
	@Override
	public EClass getPackage2Folder__Marker() {
		return package2Folder__MarkerEClass;
	}
	@Override
	public EReference getPackage2Folder__Marker_CREATE__SRC__p() {
		return package2Folder__Marker_cREATE__SRC__pEReference;	
	}
	@Override
	public EReference getPackage2Folder__Marker_CREATE__TRG__f() {
		return package2Folder__Marker_cREATE__TRG__fEReference;	
	}
	@Override
	public EReference getPackage2Folder__Marker_CREATE__CORR__p2f() {
		return package2Folder__Marker_cREATE__CORR__p2fEReference;	
	}
	@Override
	public EClass getParam2Entry__Marker() {
		return param2Entry__MarkerEClass;
	}
	@Override
	public EReference getParam2Entry__Marker_CONTEXT__SRC__m() {
		return param2Entry__Marker_cONTEXT__SRC__mEReference;	
	}
	@Override
	public EReference getParam2Entry__Marker_CREATE__SRC__p() {
		return param2Entry__Marker_cREATE__SRC__pEReference;	
	}
	@Override
	public EReference getParam2Entry__Marker_CONTEXT__TRG__e() {
		return param2Entry__Marker_cONTEXT__TRG__eEReference;	
	}
	@Override
	public EReference getParam2Entry__Marker_CONTEXT__CORR__m2e() {
		return param2Entry__Marker_cONTEXT__CORR__m2eEReference;	
	}
	@Override
	public EReference getParam2Entry__Marker_CREATE__CORR__p2e() {
		return param2Entry__Marker_cREATE__CORR__p2eEReference;	
	}
	@Override
	public EClass getSubPackage2Folder__Marker() {
		return subPackage2Folder__MarkerEClass;
	}
	@Override
	public EReference getSubPackage2Folder__Marker_CONTEXT__SRC__p() {
		return subPackage2Folder__Marker_cONTEXT__SRC__pEReference;	
	}
	@Override
	public EReference getSubPackage2Folder__Marker_CREATE__SRC__sp() {
		return subPackage2Folder__Marker_cREATE__SRC__spEReference;	
	}
	@Override
	public EReference getSubPackage2Folder__Marker_CONTEXT__TRG__f() {
		return subPackage2Folder__Marker_cONTEXT__TRG__fEReference;	
	}
	@Override
	public EReference getSubPackage2Folder__Marker_CREATE__TRG__sf() {
		return subPackage2Folder__Marker_cREATE__TRG__sfEReference;	
	}
	@Override
	public EReference getSubPackage2Folder__Marker_CONTEXT__CORR__p2f() {
		return subPackage2Folder__Marker_cONTEXT__CORR__p2fEReference;	
	}
	@Override
	public EReference getSubPackage2Folder__Marker_CREATE__CORR__sp2f() {
		return subPackage2Folder__Marker_cREATE__CORR__sp2fEReference;	
	}
	@Override
	public EClass getType2Doc__Marker() {
		return type2Doc__MarkerEClass;
	}
	@Override
	public EReference getType2Doc__Marker_CONTEXT__SRC__p() {
		return type2Doc__Marker_cONTEXT__SRC__pEReference;	
	}
	@Override
	public EReference getType2Doc__Marker_CREATE__SRC__t() {
		return type2Doc__Marker_cREATE__SRC__tEReference;	
	}
	@Override
	public EReference getType2Doc__Marker_CREATE__TRG__d() {
		return type2Doc__Marker_cREATE__TRG__dEReference;	
	}
	@Override
	public EReference getType2Doc__Marker_CONTEXT__TRG__f() {
		return type2Doc__Marker_cONTEXT__TRG__fEReference;	
	}
	@Override
	public EReference getType2Doc__Marker_CONTEXT__CORR__p2f() {
		return type2Doc__Marker_cONTEXT__CORR__p2fEReference;	
	}
	@Override
	public EReference getType2Doc__Marker_CREATE__CORR__t2d() {
		return type2Doc__Marker_cREATE__CORR__t2dEReference;	
	}
	
	

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ExtType2Doc_LookAhead.ExtType2Doc_LookAheadFactory getExtType2Doc_LookAheadFactory() {
		return (ExtType2Doc_LookAhead.ExtType2Doc_LookAheadFactory) getEFactoryInstance();
	}

	public void createPackageContents() {
		if (isCreated)
			return;
		isCreated = true;

		// Create classes and their features
		package2FolderEClass = createEClass(PACKAGE2_FOLDER);
		createEReference(package2FolderEClass, PACKAGE2_FOLDER__SOURCE);
		package2Folder_sourceEReference = (EReference) package2FolderEClass.getEStructuralFeatures().get(0);
		createEReference(package2FolderEClass, PACKAGE2_FOLDER__TARGET);
		package2Folder_targetEReference = (EReference) package2FolderEClass.getEStructuralFeatures().get(1);
		
		type2DocEClass = createEClass(TYPE2_DOC);
		createEReference(type2DocEClass, TYPE2_DOC__SOURCE);
		type2Doc_sourceEReference = (EReference) type2DocEClass.getEStructuralFeatures().get(0);
		createEReference(type2DocEClass, TYPE2_DOC__TARGET);
		type2Doc_targetEReference = (EReference) type2DocEClass.getEStructuralFeatures().get(1);
		
		method2EntryEClass = createEClass(METHOD2_ENTRY);
		createEReference(method2EntryEClass, METHOD2_ENTRY__SOURCE);
		method2Entry_sourceEReference = (EReference) method2EntryEClass.getEStructuralFeatures().get(0);
		createEReference(method2EntryEClass, METHOD2_ENTRY__TARGET);
		method2Entry_targetEReference = (EReference) method2EntryEClass.getEStructuralFeatures().get(1);
		
		param2EntryEClass = createEClass(PARAM2_ENTRY);
		createEReference(param2EntryEClass, PARAM2_ENTRY__SOURCE);
		param2Entry_sourceEReference = (EReference) param2EntryEClass.getEStructuralFeatures().get(0);
		createEReference(param2EntryEClass, PARAM2_ENTRY__TARGET);
		param2Entry_targetEReference = (EReference) param2EntryEClass.getEStructuralFeatures().get(1);
		
		field2EntryEClass = createEClass(FIELD2_ENTRY);
		createEReference(field2EntryEClass, FIELD2_ENTRY__SOURCE);
		field2Entry_sourceEReference = (EReference) field2EntryEClass.getEStructuralFeatures().get(0);
		createEReference(field2EntryEClass, FIELD2_ENTRY__TARGET);
		field2Entry_targetEReference = (EReference) field2EntryEClass.getEStructuralFeatures().get(1);
		
		extendingType2Doc__MarkerEClass = createEClass(EXTENDING_TYPE2_DOC___MARKER);
		createEReference(extendingType2Doc__MarkerEClass, EXTENDING_TYPE2_DOC___MARKER__CREAT_E__SR_C__NT);
		extendingType2Doc__Marker_cREATE__SRC__ntEReference = (EReference) extendingType2Doc__MarkerEClass.getEStructuralFeatures().get(0);
		createEReference(extendingType2Doc__MarkerEClass, EXTENDING_TYPE2_DOC___MARKER__CONTEX_T__SR_C__P);
		extendingType2Doc__Marker_cONTEXT__SRC__pEReference = (EReference) extendingType2Doc__MarkerEClass.getEStructuralFeatures().get(1);
		createEReference(extendingType2Doc__MarkerEClass, EXTENDING_TYPE2_DOC___MARKER__CONTEX_T__SR_C__T);
		extendingType2Doc__Marker_cONTEXT__SRC__tEReference = (EReference) extendingType2Doc__MarkerEClass.getEStructuralFeatures().get(2);
		createEReference(extendingType2Doc__MarkerEClass, EXTENDING_TYPE2_DOC___MARKER__CONTEX_T__TR_G__D);
		extendingType2Doc__Marker_cONTEXT__TRG__dEReference = (EReference) extendingType2Doc__MarkerEClass.getEStructuralFeatures().get(3);
		createEReference(extendingType2Doc__MarkerEClass, EXTENDING_TYPE2_DOC___MARKER__CONTEX_T__TR_G__F);
		extendingType2Doc__Marker_cONTEXT__TRG__fEReference = (EReference) extendingType2Doc__MarkerEClass.getEStructuralFeatures().get(4);
		createEReference(extendingType2Doc__MarkerEClass, EXTENDING_TYPE2_DOC___MARKER__CREAT_E__TR_G__ND);
		extendingType2Doc__Marker_cREATE__TRG__ndEReference = (EReference) extendingType2Doc__MarkerEClass.getEStructuralFeatures().get(5);
		createEReference(extendingType2Doc__MarkerEClass, EXTENDING_TYPE2_DOC___MARKER__CREAT_E__COR_R__NT2ND);
		extendingType2Doc__Marker_cREATE__CORR__nt2ndEReference = (EReference) extendingType2Doc__MarkerEClass.getEStructuralFeatures().get(6);
		createEReference(extendingType2Doc__MarkerEClass, EXTENDING_TYPE2_DOC___MARKER__CONTEX_T__COR_R__P2F);
		extendingType2Doc__Marker_cONTEXT__CORR__p2fEReference = (EReference) extendingType2Doc__MarkerEClass.getEStructuralFeatures().get(7);
		createEReference(extendingType2Doc__MarkerEClass, EXTENDING_TYPE2_DOC___MARKER__CONTEX_T__COR_R__T2D);
		extendingType2Doc__Marker_cONTEXT__CORR__t2dEReference = (EReference) extendingType2Doc__MarkerEClass.getEStructuralFeatures().get(8);
		
		field2Entry__MarkerEClass = createEClass(FIELD2_ENTRY___MARKER);
		createEReference(field2Entry__MarkerEClass, FIELD2_ENTRY___MARKER__CREAT_E__SR_C__F);
		field2Entry__Marker_cREATE__SRC__fEReference = (EReference) field2Entry__MarkerEClass.getEStructuralFeatures().get(0);
		createEReference(field2Entry__MarkerEClass, FIELD2_ENTRY___MARKER__CONTEX_T__SR_C__T);
		field2Entry__Marker_cONTEXT__SRC__tEReference = (EReference) field2Entry__MarkerEClass.getEStructuralFeatures().get(1);
		createEReference(field2Entry__MarkerEClass, FIELD2_ENTRY___MARKER__CONTEX_T__TR_G__D);
		field2Entry__Marker_cONTEXT__TRG__dEReference = (EReference) field2Entry__MarkerEClass.getEStructuralFeatures().get(2);
		createEReference(field2Entry__MarkerEClass, FIELD2_ENTRY___MARKER__CREAT_E__TR_G__E);
		field2Entry__Marker_cREATE__TRG__eEReference = (EReference) field2Entry__MarkerEClass.getEStructuralFeatures().get(3);
		createEReference(field2Entry__MarkerEClass, FIELD2_ENTRY___MARKER__CREAT_E__COR_R__F2E);
		field2Entry__Marker_cREATE__CORR__f2eEReference = (EReference) field2Entry__MarkerEClass.getEStructuralFeatures().get(4);
		createEReference(field2Entry__MarkerEClass, FIELD2_ENTRY___MARKER__CONTEX_T__COR_R__T2D);
		field2Entry__Marker_cONTEXT__CORR__t2dEReference = (EReference) field2Entry__MarkerEClass.getEStructuralFeatures().get(5);
		
		implementingType2Doc__MarkerEClass = createEClass(IMPLEMENTING_TYPE2_DOC___MARKER);
		createEReference(implementingType2Doc__MarkerEClass, IMPLEMENTING_TYPE2_DOC___MARKER__CONTEX_T__SR_C__IT);
		implementingType2Doc__Marker_cONTEXT__SRC__itEReference = (EReference) implementingType2Doc__MarkerEClass.getEStructuralFeatures().get(0);
		createEReference(implementingType2Doc__MarkerEClass, IMPLEMENTING_TYPE2_DOC___MARKER__CONTEX_T__SR_C__T);
		implementingType2Doc__Marker_cONTEXT__SRC__tEReference = (EReference) implementingType2Doc__MarkerEClass.getEStructuralFeatures().get(1);
		createEReference(implementingType2Doc__MarkerEClass, IMPLEMENTING_TYPE2_DOC___MARKER__CONTEX_T__TR_G__D);
		implementingType2Doc__Marker_cONTEXT__TRG__dEReference = (EReference) implementingType2Doc__MarkerEClass.getEStructuralFeatures().get(2);
		createEReference(implementingType2Doc__MarkerEClass, IMPLEMENTING_TYPE2_DOC___MARKER__CONTEX_T__TR_G__ID);
		implementingType2Doc__Marker_cONTEXT__TRG__idEReference = (EReference) implementingType2Doc__MarkerEClass.getEStructuralFeatures().get(3);
		createEReference(implementingType2Doc__MarkerEClass, IMPLEMENTING_TYPE2_DOC___MARKER__CONTEX_T__COR_R__IT2ID);
		implementingType2Doc__Marker_cONTEXT__CORR__it2idEReference = (EReference) implementingType2Doc__MarkerEClass.getEStructuralFeatures().get(4);
		createEReference(implementingType2Doc__MarkerEClass, IMPLEMENTING_TYPE2_DOC___MARKER__CONTEX_T__COR_R__T2D);
		implementingType2Doc__Marker_cONTEXT__CORR__t2dEReference = (EReference) implementingType2Doc__MarkerEClass.getEStructuralFeatures().get(5);
		
		method2Entry__MarkerEClass = createEClass(METHOD2_ENTRY___MARKER);
		createEReference(method2Entry__MarkerEClass, METHOD2_ENTRY___MARKER__CREAT_E__SR_C__M);
		method2Entry__Marker_cREATE__SRC__mEReference = (EReference) method2Entry__MarkerEClass.getEStructuralFeatures().get(0);
		createEReference(method2Entry__MarkerEClass, METHOD2_ENTRY___MARKER__CONTEX_T__SR_C__T);
		method2Entry__Marker_cONTEXT__SRC__tEReference = (EReference) method2Entry__MarkerEClass.getEStructuralFeatures().get(1);
		createEReference(method2Entry__MarkerEClass, METHOD2_ENTRY___MARKER__CONTEX_T__TR_G__D);
		method2Entry__Marker_cONTEXT__TRG__dEReference = (EReference) method2Entry__MarkerEClass.getEStructuralFeatures().get(2);
		createEReference(method2Entry__MarkerEClass, METHOD2_ENTRY___MARKER__CREAT_E__TR_G__E);
		method2Entry__Marker_cREATE__TRG__eEReference = (EReference) method2Entry__MarkerEClass.getEStructuralFeatures().get(3);
		createEReference(method2Entry__MarkerEClass, METHOD2_ENTRY___MARKER__CREAT_E__COR_R__M2E);
		method2Entry__Marker_cREATE__CORR__m2eEReference = (EReference) method2Entry__MarkerEClass.getEStructuralFeatures().get(4);
		createEReference(method2Entry__MarkerEClass, METHOD2_ENTRY___MARKER__CONTEX_T__COR_R__T2D);
		method2Entry__Marker_cONTEXT__CORR__t2dEReference = (EReference) method2Entry__MarkerEClass.getEStructuralFeatures().get(5);
		
		package2Folder__MarkerEClass = createEClass(PACKAGE2_FOLDER___MARKER);
		createEReference(package2Folder__MarkerEClass, PACKAGE2_FOLDER___MARKER__CREAT_E__SR_C__P);
		package2Folder__Marker_cREATE__SRC__pEReference = (EReference) package2Folder__MarkerEClass.getEStructuralFeatures().get(0);
		createEReference(package2Folder__MarkerEClass, PACKAGE2_FOLDER___MARKER__CREAT_E__TR_G__F);
		package2Folder__Marker_cREATE__TRG__fEReference = (EReference) package2Folder__MarkerEClass.getEStructuralFeatures().get(1);
		createEReference(package2Folder__MarkerEClass, PACKAGE2_FOLDER___MARKER__CREAT_E__COR_R__P2F);
		package2Folder__Marker_cREATE__CORR__p2fEReference = (EReference) package2Folder__MarkerEClass.getEStructuralFeatures().get(2);
		
		param2Entry__MarkerEClass = createEClass(PARAM2_ENTRY___MARKER);
		createEReference(param2Entry__MarkerEClass, PARAM2_ENTRY___MARKER__CONTEX_T__SR_C__M);
		param2Entry__Marker_cONTEXT__SRC__mEReference = (EReference) param2Entry__MarkerEClass.getEStructuralFeatures().get(0);
		createEReference(param2Entry__MarkerEClass, PARAM2_ENTRY___MARKER__CREAT_E__SR_C__P);
		param2Entry__Marker_cREATE__SRC__pEReference = (EReference) param2Entry__MarkerEClass.getEStructuralFeatures().get(1);
		createEReference(param2Entry__MarkerEClass, PARAM2_ENTRY___MARKER__CONTEX_T__TR_G__E);
		param2Entry__Marker_cONTEXT__TRG__eEReference = (EReference) param2Entry__MarkerEClass.getEStructuralFeatures().get(2);
		createEReference(param2Entry__MarkerEClass, PARAM2_ENTRY___MARKER__CONTEX_T__COR_R__M2E);
		param2Entry__Marker_cONTEXT__CORR__m2eEReference = (EReference) param2Entry__MarkerEClass.getEStructuralFeatures().get(3);
		createEReference(param2Entry__MarkerEClass, PARAM2_ENTRY___MARKER__CREAT_E__COR_R__P2E);
		param2Entry__Marker_cREATE__CORR__p2eEReference = (EReference) param2Entry__MarkerEClass.getEStructuralFeatures().get(4);
		
		subPackage2Folder__MarkerEClass = createEClass(SUB_PACKAGE2_FOLDER___MARKER);
		createEReference(subPackage2Folder__MarkerEClass, SUB_PACKAGE2_FOLDER___MARKER__CONTEX_T__SR_C__P);
		subPackage2Folder__Marker_cONTEXT__SRC__pEReference = (EReference) subPackage2Folder__MarkerEClass.getEStructuralFeatures().get(0);
		createEReference(subPackage2Folder__MarkerEClass, SUB_PACKAGE2_FOLDER___MARKER__CREAT_E__SR_C__SP);
		subPackage2Folder__Marker_cREATE__SRC__spEReference = (EReference) subPackage2Folder__MarkerEClass.getEStructuralFeatures().get(1);
		createEReference(subPackage2Folder__MarkerEClass, SUB_PACKAGE2_FOLDER___MARKER__CONTEX_T__TR_G__F);
		subPackage2Folder__Marker_cONTEXT__TRG__fEReference = (EReference) subPackage2Folder__MarkerEClass.getEStructuralFeatures().get(2);
		createEReference(subPackage2Folder__MarkerEClass, SUB_PACKAGE2_FOLDER___MARKER__CREAT_E__TR_G__SF);
		subPackage2Folder__Marker_cREATE__TRG__sfEReference = (EReference) subPackage2Folder__MarkerEClass.getEStructuralFeatures().get(3);
		createEReference(subPackage2Folder__MarkerEClass, SUB_PACKAGE2_FOLDER___MARKER__CONTEX_T__COR_R__P2F);
		subPackage2Folder__Marker_cONTEXT__CORR__p2fEReference = (EReference) subPackage2Folder__MarkerEClass.getEStructuralFeatures().get(4);
		createEReference(subPackage2Folder__MarkerEClass, SUB_PACKAGE2_FOLDER___MARKER__CREAT_E__COR_R__SP2F);
		subPackage2Folder__Marker_cREATE__CORR__sp2fEReference = (EReference) subPackage2Folder__MarkerEClass.getEStructuralFeatures().get(5);
		
		type2Doc__MarkerEClass = createEClass(TYPE2_DOC___MARKER);
		createEReference(type2Doc__MarkerEClass, TYPE2_DOC___MARKER__CONTEX_T__SR_C__P);
		type2Doc__Marker_cONTEXT__SRC__pEReference = (EReference) type2Doc__MarkerEClass.getEStructuralFeatures().get(0);
		createEReference(type2Doc__MarkerEClass, TYPE2_DOC___MARKER__CREAT_E__SR_C__T);
		type2Doc__Marker_cREATE__SRC__tEReference = (EReference) type2Doc__MarkerEClass.getEStructuralFeatures().get(1);
		createEReference(type2Doc__MarkerEClass, TYPE2_DOC___MARKER__CREAT_E__TR_G__D);
		type2Doc__Marker_cREATE__TRG__dEReference = (EReference) type2Doc__MarkerEClass.getEStructuralFeatures().get(2);
		createEReference(type2Doc__MarkerEClass, TYPE2_DOC___MARKER__CONTEX_T__TR_G__F);
		type2Doc__Marker_cONTEXT__TRG__fEReference = (EReference) type2Doc__MarkerEClass.getEStructuralFeatures().get(3);
		createEReference(type2Doc__MarkerEClass, TYPE2_DOC___MARKER__CONTEX_T__COR_R__P2F);
		type2Doc__Marker_cONTEXT__CORR__p2fEReference = (EReference) type2Doc__MarkerEClass.getEStructuralFeatures().get(4);
		createEReference(type2Doc__MarkerEClass, TYPE2_DOC___MARKER__CREAT_E__COR_R__T2D);
		type2Doc__Marker_cREATE__CORR__t2dEReference = (EReference) type2Doc__MarkerEClass.getEStructuralFeatures().get(5);
		
		// Create enums
		
		// Create data types
	}

	public void initializePackageContents() {
		if (isInitialized)
			return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);
		
		// Obtain other dependent packages
		ExtTypeModelPackage theExtTypeModelPackagePackage = ExtTypeModelPackage.eINSTANCE;
		ExtDocModelPackage theExtDocModelPackagePackage = ExtDocModelPackage.eINSTANCE;
		RuntimePackage theRuntimePackagePackage = RuntimePackage.eINSTANCE;

		// Create type parameters

		// Set bounds for type parameters

		// Add supertypes to classes
		package2FolderEClass.getESuperTypes().add(RuntimePackage.eINSTANCE.getCorrespondenceNode());
		type2DocEClass.getESuperTypes().add(RuntimePackage.eINSTANCE.getCorrespondenceNode());
		method2EntryEClass.getESuperTypes().add(RuntimePackage.eINSTANCE.getCorrespondenceNode());
		param2EntryEClass.getESuperTypes().add(RuntimePackage.eINSTANCE.getCorrespondenceNode());
		field2EntryEClass.getESuperTypes().add(RuntimePackage.eINSTANCE.getCorrespondenceNode());
		extendingType2Doc__MarkerEClass.getESuperTypes().add(RuntimePackage.eINSTANCE.getTGGRuleApplication());
		field2Entry__MarkerEClass.getESuperTypes().add(RuntimePackage.eINSTANCE.getTGGRuleApplication());
		implementingType2Doc__MarkerEClass.getESuperTypes().add(RuntimePackage.eINSTANCE.getTGGRuleApplication());
		method2Entry__MarkerEClass.getESuperTypes().add(RuntimePackage.eINSTANCE.getTGGRuleApplication());
		package2Folder__MarkerEClass.getESuperTypes().add(RuntimePackage.eINSTANCE.getTGGRuleApplication());
		param2Entry__MarkerEClass.getESuperTypes().add(RuntimePackage.eINSTANCE.getTGGRuleApplication());
		subPackage2Folder__MarkerEClass.getESuperTypes().add(RuntimePackage.eINSTANCE.getTGGRuleApplication());
		type2Doc__MarkerEClass.getESuperTypes().add(RuntimePackage.eINSTANCE.getTGGRuleApplication());

		// Initialize classes, features, and operations; add parameters
		initEClass(package2FolderEClass, Package2Folder.class, "Package2Folder", !IS_ABSTRACT, !IS_INTERFACE,
			IS_GENERATED_INSTANCE_CLASS);
		initEReference(getPackage2Folder_Source(), ExtTypeModelPackage.eINSTANCE.getPackage(),  null, 
			"source", null, 0, 1, Package2Folder.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getPackage2Folder_Target(), ExtDocModelPackage.eINSTANCE.getFolder(),  null, 
			"target", null, 0, 1, Package2Folder.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
				
		initEClass(type2DocEClass, Type2Doc.class, "Type2Doc", !IS_ABSTRACT, !IS_INTERFACE,
			IS_GENERATED_INSTANCE_CLASS);
		initEReference(getType2Doc_Source(), ExtTypeModelPackage.eINSTANCE.getType(),  null, 
			"source", null, 0, 1, Type2Doc.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getType2Doc_Target(), ExtDocModelPackage.eINSTANCE.getDoc(),  null, 
			"target", null, 0, 1, Type2Doc.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
				
		initEClass(method2EntryEClass, Method2Entry.class, "Method2Entry", !IS_ABSTRACT, !IS_INTERFACE,
			IS_GENERATED_INSTANCE_CLASS);
		initEReference(getMethod2Entry_Source(), ExtTypeModelPackage.eINSTANCE.getMethod(),  null, 
			"source", null, 0, 1, Method2Entry.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getMethod2Entry_Target(), ExtDocModelPackage.eINSTANCE.getEntry(),  null, 
			"target", null, 0, 1, Method2Entry.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
				
		initEClass(param2EntryEClass, Param2Entry.class, "Param2Entry", !IS_ABSTRACT, !IS_INTERFACE,
			IS_GENERATED_INSTANCE_CLASS);
		initEReference(getParam2Entry_Source(), ExtTypeModelPackage.eINSTANCE.getParameter(),  null, 
			"source", null, 0, 1, Param2Entry.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getParam2Entry_Target(), ExtDocModelPackage.eINSTANCE.getEntry(),  null, 
			"target", null, 0, 1, Param2Entry.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
				
		initEClass(field2EntryEClass, Field2Entry.class, "Field2Entry", !IS_ABSTRACT, !IS_INTERFACE,
			IS_GENERATED_INSTANCE_CLASS);
		initEReference(getField2Entry_Source(), ExtTypeModelPackage.eINSTANCE.getField(),  null, 
			"source", null, 0, 1, Field2Entry.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getField2Entry_Target(), ExtDocModelPackage.eINSTANCE.getEntry(),  null, 
			"target", null, 0, 1, Field2Entry.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
				
		initEClass(extendingType2Doc__MarkerEClass, ExtendingType2Doc__Marker.class, "ExtendingType2Doc__Marker", !IS_ABSTRACT, !IS_INTERFACE,
			IS_GENERATED_INSTANCE_CLASS);
		initEReference(getExtendingType2Doc__Marker_CREATE__SRC__nt(), ExtTypeModelPackage.eINSTANCE.getType(),  null, 
			"CREATE__SRC__nt", null, 1, 1, ExtendingType2Doc__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getExtendingType2Doc__Marker_CONTEXT__SRC__p(), ExtTypeModelPackage.eINSTANCE.getPackage(),  null, 
			"CONTEXT__SRC__p", null, 1, 1, ExtendingType2Doc__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getExtendingType2Doc__Marker_CONTEXT__SRC__t(), ExtTypeModelPackage.eINSTANCE.getType(),  null, 
			"CONTEXT__SRC__t", null, 1, 1, ExtendingType2Doc__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getExtendingType2Doc__Marker_CONTEXT__TRG__d(), ExtDocModelPackage.eINSTANCE.getDoc(),  null, 
			"CONTEXT__TRG__d", null, 1, 1, ExtendingType2Doc__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getExtendingType2Doc__Marker_CONTEXT__TRG__f(), ExtDocModelPackage.eINSTANCE.getFolder(),  null, 
			"CONTEXT__TRG__f", null, 1, 1, ExtendingType2Doc__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getExtendingType2Doc__Marker_CREATE__TRG__nd(), ExtDocModelPackage.eINSTANCE.getDoc(),  null, 
			"CREATE__TRG__nd", null, 1, 1, ExtendingType2Doc__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getExtendingType2Doc__Marker_CREATE__CORR__nt2nd(), this.getType2Doc(),  null, 
			"CREATE__CORR__nt2nd", null, 1, 1, ExtendingType2Doc__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getExtendingType2Doc__Marker_CONTEXT__CORR__p2f(), this.getPackage2Folder(),  null, 
			"CONTEXT__CORR__p2f", null, 1, 1, ExtendingType2Doc__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getExtendingType2Doc__Marker_CONTEXT__CORR__t2d(), this.getType2Doc(),  null, 
			"CONTEXT__CORR__t2d", null, 1, 1, ExtendingType2Doc__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
				
		initEClass(field2Entry__MarkerEClass, Field2Entry__Marker.class, "Field2Entry__Marker", !IS_ABSTRACT, !IS_INTERFACE,
			IS_GENERATED_INSTANCE_CLASS);
		initEReference(getField2Entry__Marker_CREATE__SRC__f(), ExtTypeModelPackage.eINSTANCE.getField(),  null, 
			"CREATE__SRC__f", null, 1, 1, Field2Entry__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getField2Entry__Marker_CONTEXT__SRC__t(), ExtTypeModelPackage.eINSTANCE.getType(),  null, 
			"CONTEXT__SRC__t", null, 1, 1, Field2Entry__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getField2Entry__Marker_CONTEXT__TRG__d(), ExtDocModelPackage.eINSTANCE.getDoc(),  null, 
			"CONTEXT__TRG__d", null, 1, 1, Field2Entry__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getField2Entry__Marker_CREATE__TRG__e(), ExtDocModelPackage.eINSTANCE.getEntry(),  null, 
			"CREATE__TRG__e", null, 1, 1, Field2Entry__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getField2Entry__Marker_CREATE__CORR__f2e(), this.getField2Entry(),  null, 
			"CREATE__CORR__f2e", null, 1, 1, Field2Entry__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getField2Entry__Marker_CONTEXT__CORR__t2d(), this.getType2Doc(),  null, 
			"CONTEXT__CORR__t2d", null, 1, 1, Field2Entry__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
				
		initEClass(implementingType2Doc__MarkerEClass, ImplementingType2Doc__Marker.class, "ImplementingType2Doc__Marker", !IS_ABSTRACT, !IS_INTERFACE,
			IS_GENERATED_INSTANCE_CLASS);
		initEReference(getImplementingType2Doc__Marker_CONTEXT__SRC__it(), ExtTypeModelPackage.eINSTANCE.getType(),  null, 
			"CONTEXT__SRC__it", null, 1, 1, ImplementingType2Doc__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getImplementingType2Doc__Marker_CONTEXT__SRC__t(), ExtTypeModelPackage.eINSTANCE.getType(),  null, 
			"CONTEXT__SRC__t", null, 1, 1, ImplementingType2Doc__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getImplementingType2Doc__Marker_CONTEXT__TRG__d(), ExtDocModelPackage.eINSTANCE.getDoc(),  null, 
			"CONTEXT__TRG__d", null, 1, 1, ImplementingType2Doc__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getImplementingType2Doc__Marker_CONTEXT__TRG__id(), ExtDocModelPackage.eINSTANCE.getDoc(),  null, 
			"CONTEXT__TRG__id", null, 1, 1, ImplementingType2Doc__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getImplementingType2Doc__Marker_CONTEXT__CORR__it2id(), this.getType2Doc(),  null, 
			"CONTEXT__CORR__it2id", null, 1, 1, ImplementingType2Doc__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getImplementingType2Doc__Marker_CONTEXT__CORR__t2d(), this.getType2Doc(),  null, 
			"CONTEXT__CORR__t2d", null, 1, 1, ImplementingType2Doc__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
				
		initEClass(method2Entry__MarkerEClass, Method2Entry__Marker.class, "Method2Entry__Marker", !IS_ABSTRACT, !IS_INTERFACE,
			IS_GENERATED_INSTANCE_CLASS);
		initEReference(getMethod2Entry__Marker_CREATE__SRC__m(), ExtTypeModelPackage.eINSTANCE.getMethod(),  null, 
			"CREATE__SRC__m", null, 1, 1, Method2Entry__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getMethod2Entry__Marker_CONTEXT__SRC__t(), ExtTypeModelPackage.eINSTANCE.getType(),  null, 
			"CONTEXT__SRC__t", null, 1, 1, Method2Entry__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getMethod2Entry__Marker_CONTEXT__TRG__d(), ExtDocModelPackage.eINSTANCE.getDoc(),  null, 
			"CONTEXT__TRG__d", null, 1, 1, Method2Entry__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getMethod2Entry__Marker_CREATE__TRG__e(), ExtDocModelPackage.eINSTANCE.getEntry(),  null, 
			"CREATE__TRG__e", null, 1, 1, Method2Entry__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getMethod2Entry__Marker_CREATE__CORR__m2e(), this.getMethod2Entry(),  null, 
			"CREATE__CORR__m2e", null, 1, 1, Method2Entry__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getMethod2Entry__Marker_CONTEXT__CORR__t2d(), this.getType2Doc(),  null, 
			"CONTEXT__CORR__t2d", null, 1, 1, Method2Entry__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
				
		initEClass(package2Folder__MarkerEClass, Package2Folder__Marker.class, "Package2Folder__Marker", !IS_ABSTRACT, !IS_INTERFACE,
			IS_GENERATED_INSTANCE_CLASS);
		initEReference(getPackage2Folder__Marker_CREATE__SRC__p(), ExtTypeModelPackage.eINSTANCE.getPackage(),  null, 
			"CREATE__SRC__p", null, 1, 1, Package2Folder__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getPackage2Folder__Marker_CREATE__TRG__f(), ExtDocModelPackage.eINSTANCE.getFolder(),  null, 
			"CREATE__TRG__f", null, 1, 1, Package2Folder__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getPackage2Folder__Marker_CREATE__CORR__p2f(), this.getPackage2Folder(),  null, 
			"CREATE__CORR__p2f", null, 1, 1, Package2Folder__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
				
		initEClass(param2Entry__MarkerEClass, Param2Entry__Marker.class, "Param2Entry__Marker", !IS_ABSTRACT, !IS_INTERFACE,
			IS_GENERATED_INSTANCE_CLASS);
		initEReference(getParam2Entry__Marker_CONTEXT__SRC__m(), ExtTypeModelPackage.eINSTANCE.getMethod(),  null, 
			"CONTEXT__SRC__m", null, 1, 1, Param2Entry__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getParam2Entry__Marker_CREATE__SRC__p(), ExtTypeModelPackage.eINSTANCE.getParameter(),  null, 
			"CREATE__SRC__p", null, 1, 1, Param2Entry__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getParam2Entry__Marker_CONTEXT__TRG__e(), ExtDocModelPackage.eINSTANCE.getEntry(),  null, 
			"CONTEXT__TRG__e", null, 1, 1, Param2Entry__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getParam2Entry__Marker_CONTEXT__CORR__m2e(), this.getMethod2Entry(),  null, 
			"CONTEXT__CORR__m2e", null, 1, 1, Param2Entry__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getParam2Entry__Marker_CREATE__CORR__p2e(), this.getParam2Entry(),  null, 
			"CREATE__CORR__p2e", null, 1, 1, Param2Entry__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
				
		initEClass(subPackage2Folder__MarkerEClass, SubPackage2Folder__Marker.class, "SubPackage2Folder__Marker", !IS_ABSTRACT, !IS_INTERFACE,
			IS_GENERATED_INSTANCE_CLASS);
		initEReference(getSubPackage2Folder__Marker_CONTEXT__SRC__p(), ExtTypeModelPackage.eINSTANCE.getPackage(),  null, 
			"CONTEXT__SRC__p", null, 1, 1, SubPackage2Folder__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getSubPackage2Folder__Marker_CREATE__SRC__sp(), ExtTypeModelPackage.eINSTANCE.getPackage(),  null, 
			"CREATE__SRC__sp", null, 1, 1, SubPackage2Folder__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getSubPackage2Folder__Marker_CONTEXT__TRG__f(), ExtDocModelPackage.eINSTANCE.getFolder(),  null, 
			"CONTEXT__TRG__f", null, 1, 1, SubPackage2Folder__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getSubPackage2Folder__Marker_CREATE__TRG__sf(), ExtDocModelPackage.eINSTANCE.getFolder(),  null, 
			"CREATE__TRG__sf", null, 1, 1, SubPackage2Folder__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getSubPackage2Folder__Marker_CONTEXT__CORR__p2f(), this.getPackage2Folder(),  null, 
			"CONTEXT__CORR__p2f", null, 1, 1, SubPackage2Folder__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getSubPackage2Folder__Marker_CREATE__CORR__sp2f(), this.getPackage2Folder(),  null, 
			"CREATE__CORR__sp2f", null, 1, 1, SubPackage2Folder__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
				
		initEClass(type2Doc__MarkerEClass, Type2Doc__Marker.class, "Type2Doc__Marker", !IS_ABSTRACT, !IS_INTERFACE,
			IS_GENERATED_INSTANCE_CLASS);
		initEReference(getType2Doc__Marker_CONTEXT__SRC__p(), ExtTypeModelPackage.eINSTANCE.getPackage(),  null, 
			"CONTEXT__SRC__p", null, 1, 1, Type2Doc__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getType2Doc__Marker_CREATE__SRC__t(), ExtTypeModelPackage.eINSTANCE.getType(),  null, 
			"CREATE__SRC__t", null, 1, 1, Type2Doc__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getType2Doc__Marker_CREATE__TRG__d(), ExtDocModelPackage.eINSTANCE.getDoc(),  null, 
			"CREATE__TRG__d", null, 1, 1, Type2Doc__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getType2Doc__Marker_CONTEXT__TRG__f(), ExtDocModelPackage.eINSTANCE.getFolder(),  null, 
			"CONTEXT__TRG__f", null, 1, 1, Type2Doc__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getType2Doc__Marker_CONTEXT__CORR__p2f(), this.getPackage2Folder(),  null, 
			"CONTEXT__CORR__p2f", null, 1, 1, Type2Doc__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getType2Doc__Marker_CREATE__CORR__t2d(), this.getType2Doc(),  null, 
			"CREATE__CORR__t2d", null, 1, 1, Type2Doc__Marker.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
				
		
		// Initialize enums and add enum literals
		
		// Initialize data types
		
		// Create resource
		createResource(eNS_URI);
	}

} 

