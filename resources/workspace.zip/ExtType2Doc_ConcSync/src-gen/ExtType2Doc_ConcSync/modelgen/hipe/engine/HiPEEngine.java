package ExtType2Doc_ConcSync.modelgen.hipe.engine;

import akka.actor.ActorRef;
import akka.actor.Props;

import ExtType2Doc_ConcSync.modelgen.hipe.engine.actor.NotificationActor;
import ExtType2Doc_ConcSync.modelgen.hipe.engine.actor.DispatchActor;
import ExtType2Doc_ConcSync.modelgen.hipe.engine.actor.localsearch.ExtendingType2Doc__GEN_1_localSearch;
import ExtType2Doc_ConcSync.modelgen.hipe.engine.actor.localsearch.Field2Entry__GEN_8_localSearch;
import ExtType2Doc_ConcSync.modelgen.hipe.engine.actor.localsearch.JDoc2Annotation__GEN_17_localSearch;
import ExtType2Doc_ConcSync.modelgen.hipe.engine.actor.localsearch.Method2Entry__GEN_21_localSearch;
import ExtType2Doc_ConcSync.modelgen.hipe.engine.actor.localsearch.Package2Folder__GEN_25_localSearch;
import ExtType2Doc_ConcSync.modelgen.hipe.engine.actor.localsearch.Param2Entry__GEN_29_localSearch;
import ExtType2Doc_ConcSync.modelgen.hipe.engine.actor.localsearch.Type2Doc__GEN_33_localSearch;

import hipe.engine.IHiPEEngine;
import hipe.engine.message.InitGenReferenceActor;

import hipe.generic.actor.GenericObjectActor;
import hipe.generic.actor.GenericReferenceActor;
import hipe.generic.actor.GenericProductionActor;
import hipe.generic.actor.junction.*;

import hipe.network.*;

public class HiPEEngine extends IHiPEEngine{
	
	public HiPEEngine(HiPENetwork network) {
		super(network);
	}
	
	public HiPEEngine() {
		super();
	}
	
	@Override
	public String getClassLocation() {
		return getClass().getProtectionDomain().getCodeSource().getLocation().getPath().toString();
	}
	
	@Override
	public String getPackageName() {
		return getClass().getPackageName();
	}
	
	@Override
	protected ActorRef getDispatchActor() {
		return system.actorOf(
			Props.create(DispatchActor.class, () -> new DispatchActor(name2actor, incUtil)),
			"DispatchActor");
	}
	
	@Override
	protected ActorRef getNotificationActor(boolean cascadingNotifications) {
		return system.actorOf(
			Props.create(NotificationActor.class, () -> new NotificationActor(dispatcher, incUtil, cascadingNotifications)), 
			"NotificationActor");
	}
	
	@Override
	public void createProductionNodes() {
		classes.put("ExtendingType2Doc__GEN_production", GenericProductionActor.class);
		productionNodes2pattern.put("ExtendingType2Doc__GEN_production", "ExtendingType2Doc__GEN");
		classes.put("Field2Entry__GEN_production", GenericProductionActor.class);
		productionNodes2pattern.put("Field2Entry__GEN_production", "Field2Entry__GEN");
		classes.put("GlossaryEntry__GEN_production", GenericProductionActor.class);
		productionNodes2pattern.put("GlossaryEntry__GEN_production", "GlossaryEntry__GEN");
		classes.put("GlossaryLink__GEN_production", GenericProductionActor.class);
		productionNodes2pattern.put("GlossaryLink__GEN_production", "GlossaryLink__GEN");
		classes.put("Glossary__GEN_production", GenericProductionActor.class);
		productionNodes2pattern.put("Glossary__GEN_production", "Glossary__GEN");
		classes.put("JDoc2Annotation__GEN_production", GenericProductionActor.class);
		productionNodes2pattern.put("JDoc2Annotation__GEN_production", "JDoc2Annotation__GEN");
		classes.put("Method2Entry__GEN_production", GenericProductionActor.class);
		productionNodes2pattern.put("Method2Entry__GEN_production", "Method2Entry__GEN");
		classes.put("Package2Folder__GEN_production", GenericProductionActor.class);
		productionNodes2pattern.put("Package2Folder__GEN_production", "Package2Folder__GEN");
		classes.put("Param2Entry__GEN_production", GenericProductionActor.class);
		productionNodes2pattern.put("Param2Entry__GEN_production", "Param2Entry__GEN");
		classes.put("Type2Doc__GEN_production", GenericProductionActor.class);
		productionNodes2pattern.put("Type2Doc__GEN_production", "Type2Doc__GEN");
		
	}
	
	@Override
	public void createJunctionNodes() {
		classes.put("ExtendingType2Doc__GEN_1_localSearch", ExtendingType2Doc__GEN_1_localSearch.class);
		classes.put("Field2Entry__GEN_8_localSearch", Field2Entry__GEN_8_localSearch.class);
		classes.put("GlossaryLink__GEN_13_junction", GenericJunctionActor.class);
		classes.put("JDoc2Annotation__GEN_17_localSearch", JDoc2Annotation__GEN_17_localSearch.class);
		classes.put("Method2Entry__GEN_21_localSearch", Method2Entry__GEN_21_localSearch.class);
		classes.put("Package2Folder__GEN_25_localSearch", Package2Folder__GEN_25_localSearch.class);
		classes.put("Param2Entry__GEN_29_localSearch", Param2Entry__GEN_29_localSearch.class);
		classes.put("Type2Doc__GEN_33_localSearch", Type2Doc__GEN_33_localSearch.class);
	}
	
	@Override
	public void createReferenceNodes() {
		
	}
	
	@Override
	public void createObjectNodes() {
		classes.put("Doc_object",Doc_object.class);
		classes.put("Folder_object",Folder_object.class);
		classes.put("Package_object",Package_object.class);
		classes.put("Package2Folder_object",Package2Folder_object.class);
		classes.put("Type_object",Type_object.class);
		classes.put("Type2Doc_object",Type2Doc_object.class);
		classes.put("Glossary_object",Glossary_object.class);
		classes.put("Entry_object",Entry_object.class);
		classes.put("GlossaryEntry_object",GlossaryEntry_object.class);
		classes.put("DocContainer_object",DocContainer_object.class);
		classes.put("Method_object",Method_object.class);
		classes.put("Method2Entry_object",Method2Entry_object.class);
		classes.put("Project_object",Project_object.class);
		classes.put("Project2DocContainer_object",Project2DocContainer_object.class);
		
	}
	
	@Override
	public void initializeReferenceNodes() {
	}
}

class Doc_object extends GenericObjectActor<ExtDocModel.Doc> { }
class Folder_object extends GenericObjectActor<ExtDocModel.Folder> { }
class Package_object extends GenericObjectActor<ExtTypeModel.Package> { }
class Package2Folder_object extends GenericObjectActor<ExtType2Doc_ConcSync.Package2Folder> { }
class Type_object extends GenericObjectActor<ExtTypeModel.Type> { }
class Type2Doc_object extends GenericObjectActor<ExtType2Doc_ConcSync.Type2Doc> { }
class Glossary_object extends GenericObjectActor<ExtDocModel.Glossary> { }
class Entry_object extends GenericObjectActor<ExtDocModel.Entry> { }
class GlossaryEntry_object extends GenericObjectActor<ExtDocModel.GlossaryEntry> { }
class DocContainer_object extends GenericObjectActor<ExtDocModel.DocContainer> { }
class Method_object extends GenericObjectActor<ExtTypeModel.Method> { }
class Method2Entry_object extends GenericObjectActor<ExtType2Doc_ConcSync.Method2Entry> { }
class Project_object extends GenericObjectActor<ExtTypeModel.Project> { }
class Project2DocContainer_object extends GenericObjectActor<ExtType2Doc_ConcSync.Project2DocContainer> { }


