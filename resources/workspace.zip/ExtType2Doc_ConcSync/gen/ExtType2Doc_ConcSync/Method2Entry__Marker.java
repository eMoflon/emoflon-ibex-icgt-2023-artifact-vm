package ExtType2Doc_ConcSync;

import runtime.RuntimePackage;
import ExtType2Doc_ConcSync.ExtType2Doc_ConcSyncPackage;

import org.emoflon.smartemf.runtime.notification.SmartEMFNotification;
import org.emoflon.smartemf.runtime.SmartObject;
import org.emoflon.smartemf.runtime.collections.*;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EStructuralFeature;

public interface Method2Entry__Marker extends EObject, runtime.TGGRuleApplication {
	
    public runtime.Protocol getProtocol();
    
    public void setProtocol(runtime.Protocol value);
    
    public ExtTypeModel.Method getCREATE__SRC__m();
    
    public void setCREATE__SRC__m(ExtTypeModel.Method value);
    
    public ExtTypeModel.Type getCONTEXT__SRC__t();
    
    public void setCONTEXT__SRC__t(ExtTypeModel.Type value);
    
    public ExtDocModel.Doc getCONTEXT__TRG__d();
    
    public void setCONTEXT__TRG__d(ExtDocModel.Doc value);
    
    public ExtDocModel.Entry getCREATE__TRG__e();
    
    public void setCREATE__TRG__e(ExtDocModel.Entry value);
    
    public ExtType2Doc_ConcSync.Method2Entry getCREATE__CORR__m2e();
    
    public void setCREATE__CORR__m2e(ExtType2Doc_ConcSync.Method2Entry value);
    
    public ExtType2Doc_ConcSync.Type2Doc getCONTEXT__CORR__t2d();
    
    public void setCONTEXT__CORR__t2d(ExtType2Doc_ConcSync.Type2Doc value);
    

}
