package ExtType2Doc_LookAhead.modelgen.hipe.engine.actor;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EObject;

import java.text.DecimalFormat;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.time.Duration;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.function.Consumer;

import akka.actor.AbstractActor;
import akka.actor.ActorRef;
import akka.stream.ActorMaterializer;
import akka.stream.javadsl.*;
import static akka.pattern.Patterns.ask;

import hipe.engine.util.HiPEMultiUtil;
import hipe.engine.util.IncUtil;
import hipe.engine.message.NewInput;
import hipe.engine.message.NoMoreInput;
import hipe.engine.message.input.ObjectAdded;
import hipe.engine.message.input.ObjectDeleted;
import hipe.engine.message.input.ReferenceAdded;
import hipe.engine.message.input.ReferenceDeleted;		
import hipe.engine.message.input.AttributeChanged;
import hipe.engine.message.input.NotificationContainer;

import hipe.generic.actor.junction.util.HiPEConfig;

public class DispatchActor extends AbstractActor {
	
	private int counter = 0;
	public long time = 0;
				
	private Map<String, ActorRef> name2actor;
	
	private Map<Object, Consumer<Object>> type2addConsumer = HiPEMultiUtil.createMap();
	private Map<Object, Consumer<Notification>> feature2setConsumer = HiPEMultiUtil.createMap();
	private Map<Object, Consumer<Notification>> feature2addEdgeConsumer = HiPEMultiUtil.createMap();
	private Map<Object, Consumer<Notification>> feature2removeEdgeConsumer = HiPEMultiUtil.createMap();
	
	private IncUtil incUtil;
	
	private ActorMaterializer materializer;
	
	public DispatchActor(Map<String, ActorRef> name2actor, IncUtil incUtil) {
		this.name2actor = name2actor;
		this.incUtil = incUtil;
		
		initializeAdd();
		initializeSet();
		initializeAddEdge();
		initializeRemoveEdge();
	
		materializer = ActorMaterializer.create(getContext());
	}
	
	private void initializeAdd() {
		type2addConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getPackage2Folder(), obj -> {
			ExtType2Doc_LookAhead.Package2Folder _package2folder = (ExtType2Doc_LookAhead.Package2Folder) obj;
			incUtil.newMessage();
			name2actor.get("Package2Folder_object").tell(new ObjectAdded<ExtType2Doc_LookAhead.Package2Folder>(incUtil, _package2folder), getSelf());
		});
		type2addConsumer.put(ExtDocModel.ExtDocModelPackage.eINSTANCE.getFolder(), obj -> {
			ExtDocModel.Folder _folder = (ExtDocModel.Folder) obj;
			incUtil.newMessage();
			name2actor.get("Folder_object").tell(new ObjectAdded<ExtDocModel.Folder>(incUtil, _folder), getSelf());
		});
		type2addConsumer.put(ExtDocModel.ExtDocModelPackage.eINSTANCE.getEntry(), obj -> {
			ExtDocModel.Entry _entry = (ExtDocModel.Entry) obj;
			incUtil.newMessage();
			name2actor.get("Entry_object").tell(new ObjectAdded<ExtDocModel.Entry>(incUtil, _entry), getSelf());
		});
		type2addConsumer.put(ExtTypeModel.ExtTypeModelPackage.eINSTANCE.getType(), obj -> {
			ExtTypeModel.Type _type = (ExtTypeModel.Type) obj;
			incUtil.newMessage();
			name2actor.get("Type_object_SP0").tell(new ObjectAdded<ExtTypeModel.Type>(incUtil, _type), getSelf());
			incUtil.newMessage();
			name2actor.get("Type_object_SP1").tell(new ObjectAdded<ExtTypeModel.Type>(incUtil, _type), getSelf());
		});
		type2addConsumer.put(ExtTypeModel.ExtTypeModelPackage.eINSTANCE.getPackage(), obj -> {
			ExtTypeModel.Package _package = (ExtTypeModel.Package) obj;
			incUtil.newMessage();
			name2actor.get("Package_object").tell(new ObjectAdded<ExtTypeModel.Package>(incUtil, _package), getSelf());
		});
		type2addConsumer.put(ExtDocModel.ExtDocModelPackage.eINSTANCE.getDoc(), obj -> {
			ExtDocModel.Doc _doc = (ExtDocModel.Doc) obj;
			incUtil.newMessage();
			name2actor.get("Doc_object").tell(new ObjectAdded<ExtDocModel.Doc>(incUtil, _doc), getSelf());
		});
		type2addConsumer.put(ExtTypeModel.ExtTypeModelPackage.eINSTANCE.getMethod(), obj -> {
			ExtTypeModel.Method _method = (ExtTypeModel.Method) obj;
			incUtil.newMessage();
			name2actor.get("Method_object").tell(new ObjectAdded<ExtTypeModel.Method>(incUtil, _method), getSelf());
		});
		type2addConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getMethod2Entry(), obj -> {
			ExtType2Doc_LookAhead.Method2Entry _method2entry = (ExtType2Doc_LookAhead.Method2Entry) obj;
			incUtil.newMessage();
			name2actor.get("Method2Entry_object").tell(new ObjectAdded<ExtType2Doc_LookAhead.Method2Entry>(incUtil, _method2entry), getSelf());
		});
		type2addConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getType2Doc(), obj -> {
			ExtType2Doc_LookAhead.Type2Doc _type2doc = (ExtType2Doc_LookAhead.Type2Doc) obj;
			incUtil.newMessage();
			name2actor.get("Type2Doc_object_SP0").tell(new ObjectAdded<ExtType2Doc_LookAhead.Type2Doc>(incUtil, _type2doc), getSelf());
			incUtil.newMessage();
			name2actor.get("Type2Doc_object_SP1").tell(new ObjectAdded<ExtType2Doc_LookAhead.Type2Doc>(incUtil, _type2doc), getSelf());
		});
	}
	
	private void initializeSet() {
		feature2setConsumer.put(ExtTypeModel.ExtTypeModelPackage.eINSTANCE.getType_Interface(), notification -> {
			if(notification.getNotifier() instanceof ExtTypeModel.Type) {
				incUtil.newMessage();
				name2actor.get("Type_object_SP1").tell(new AttributeChanged<ExtTypeModel.Type>(incUtil, (ExtTypeModel.Type) notification.getNotifier(), notification.getOldValue()), getSelf());
			}
			if(notification.getNotifier() instanceof ExtTypeModel.Type) {
				incUtil.newMessage();
				name2actor.get("Type_object_SP0").tell(new AttributeChanged<ExtTypeModel.Type>(incUtil, (ExtTypeModel.Type) notification.getNotifier(), notification.getOldValue()), getSelf());
			}
		});
		
	}
	
	private void initializeAddEdge() {
		feature2addEdgeConsumer.put(ExtTypeModel.ExtTypeModelPackage.eINSTANCE.getPackage_Types(), notification -> {
			incUtil.newMessage();
			name2actor.get("ExtendingType2Doc__GEN_1_localSearch").tell(new ReferenceAdded<ExtTypeModel.Package, ExtTypeModel.Type>(incUtil,(ExtTypeModel.Package) notification.getNotifier(), (ExtTypeModel.Type) notification.getNewValue(), "ExtTypeModel.Package_types_Type"), getSelf());
		});
		feature2addEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getMethod2Entry_Target(), notification -> {
			incUtil.newMessage();
			name2actor.get("Param2Entry__GEN_29_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.Method2Entry, ExtDocModel.Entry>(incUtil,(ExtType2Doc_LookAhead.Method2Entry) notification.getNotifier(), (ExtDocModel.Entry) notification.getNewValue(), "ExtType2Doc_LookAhead.Method2Entry_target_Entry"), getSelf());
		});
		feature2addEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getType2Doc_Source(), notification -> {
			incUtil.newMessage();
			name2actor.get("Type2Doc_source_0_reference").tell(new ReferenceAdded<ExtType2Doc_LookAhead.Type2Doc, ExtTypeModel.Type>(incUtil,(ExtType2Doc_LookAhead.Type2Doc) notification.getNotifier(), (ExtTypeModel.Type) notification.getNewValue(), "ExtType2Doc_LookAhead.Type2Doc_source_Type"), getSelf());
			incUtil.newMessage();
			name2actor.get("Type2Doc_source_1_reference").tell(new ReferenceAdded<ExtType2Doc_LookAhead.Type2Doc, ExtTypeModel.Type>(incUtil,(ExtType2Doc_LookAhead.Type2Doc) notification.getNotifier(), (ExtTypeModel.Type) notification.getNewValue(), "ExtType2Doc_LookAhead.Type2Doc_source_Type"), getSelf());
			incUtil.newMessage();
			name2actor.get("ExtendingType2Doc__GEN_1_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.Type2Doc, ExtTypeModel.Type>(incUtil,(ExtType2Doc_LookAhead.Type2Doc) notification.getNotifier(), (ExtTypeModel.Type) notification.getNewValue(), "ExtType2Doc_LookAhead.Type2Doc_source_Type"), getSelf());
			incUtil.newMessage();
			name2actor.get("Field2Entry__GEN_8_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.Type2Doc, ExtTypeModel.Type>(incUtil,(ExtType2Doc_LookAhead.Type2Doc) notification.getNotifier(), (ExtTypeModel.Type) notification.getNewValue(), "ExtType2Doc_LookAhead.Type2Doc_source_Type"), getSelf());
			incUtil.newMessage();
			name2actor.get("Method2Entry__GEN_25_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.Type2Doc, ExtTypeModel.Type>(incUtil,(ExtType2Doc_LookAhead.Type2Doc) notification.getNotifier(), (ExtTypeModel.Type) notification.getNewValue(), "ExtType2Doc_LookAhead.Type2Doc_source_Type"), getSelf());
		});
		feature2addEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getMethod2Entry_Source(), notification -> {
			incUtil.newMessage();
			name2actor.get("Param2Entry__GEN_29_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.Method2Entry, ExtTypeModel.Method>(incUtil,(ExtType2Doc_LookAhead.Method2Entry) notification.getNotifier(), (ExtTypeModel.Method) notification.getNewValue(), "ExtType2Doc_LookAhead.Method2Entry_source_Method"), getSelf());
		});
		feature2addEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getType2Doc_Target(), notification -> {
			incUtil.newMessage();
			name2actor.get("Type2Doc_target_0_reference").tell(new ReferenceAdded<ExtType2Doc_LookAhead.Type2Doc, ExtDocModel.Doc>(incUtil,(ExtType2Doc_LookAhead.Type2Doc) notification.getNotifier(), (ExtDocModel.Doc) notification.getNewValue(), "ExtType2Doc_LookAhead.Type2Doc_target_Doc"), getSelf());
			incUtil.newMessage();
			name2actor.get("ExtendingType2Doc__GEN_1_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.Type2Doc, ExtDocModel.Doc>(incUtil,(ExtType2Doc_LookAhead.Type2Doc) notification.getNotifier(), (ExtDocModel.Doc) notification.getNewValue(), "ExtType2Doc_LookAhead.Type2Doc_target_Doc"), getSelf());
			incUtil.newMessage();
			name2actor.get("Field2Entry__GEN_8_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.Type2Doc, ExtDocModel.Doc>(incUtil,(ExtType2Doc_LookAhead.Type2Doc) notification.getNotifier(), (ExtDocModel.Doc) notification.getNewValue(), "ExtType2Doc_LookAhead.Type2Doc_target_Doc"), getSelf());
			incUtil.newMessage();
			name2actor.get("Method2Entry__GEN_25_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.Type2Doc, ExtDocModel.Doc>(incUtil,(ExtType2Doc_LookAhead.Type2Doc) notification.getNotifier(), (ExtDocModel.Doc) notification.getNewValue(), "ExtType2Doc_LookAhead.Type2Doc_target_Doc"), getSelf());
		});
		feature2addEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getPackage2Folder_Source(), notification -> {
			incUtil.newMessage();
			name2actor.get("ExtendingType2Doc__GEN_1_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.Package2Folder, ExtTypeModel.Package>(incUtil,(ExtType2Doc_LookAhead.Package2Folder) notification.getNotifier(), (ExtTypeModel.Package) notification.getNewValue(), "ExtType2Doc_LookAhead.Package2Folder_source_Package"), getSelf());
			incUtil.newMessage();
			name2actor.get("SubPackage2Folder__GEN_33_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.Package2Folder, ExtTypeModel.Package>(incUtil,(ExtType2Doc_LookAhead.Package2Folder) notification.getNotifier(), (ExtTypeModel.Package) notification.getNewValue(), "ExtType2Doc_LookAhead.Package2Folder_source_Package"), getSelf());
			incUtil.newMessage();
			name2actor.get("Type2Doc__GEN_37_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.Package2Folder, ExtTypeModel.Package>(incUtil,(ExtType2Doc_LookAhead.Package2Folder) notification.getNotifier(), (ExtTypeModel.Package) notification.getNewValue(), "ExtType2Doc_LookAhead.Package2Folder_source_Package"), getSelf());
		});
		feature2addEdgeConsumer.put(ExtDocModel.ExtDocModelPackage.eINSTANCE.getDoc_Folder(), notification -> {
			incUtil.newMessage();
			name2actor.get("ExtendingType2Doc__GEN_1_localSearch").tell(new ReferenceAdded<ExtDocModel.Doc, ExtDocModel.Folder>(incUtil,(ExtDocModel.Doc) notification.getNotifier(), (ExtDocModel.Folder) notification.getNewValue(), "ExtDocModel.Doc_folder_Folder"), getSelf());
		});
		feature2addEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getPackage2Folder_Target(), notification -> {
			incUtil.newMessage();
			name2actor.get("ExtendingType2Doc__GEN_1_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.Package2Folder, ExtDocModel.Folder>(incUtil,(ExtType2Doc_LookAhead.Package2Folder) notification.getNotifier(), (ExtDocModel.Folder) notification.getNewValue(), "ExtType2Doc_LookAhead.Package2Folder_target_Folder"), getSelf());
			incUtil.newMessage();
			name2actor.get("SubPackage2Folder__GEN_33_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.Package2Folder, ExtDocModel.Folder>(incUtil,(ExtType2Doc_LookAhead.Package2Folder) notification.getNotifier(), (ExtDocModel.Folder) notification.getNewValue(), "ExtType2Doc_LookAhead.Package2Folder_target_Folder"), getSelf());
			incUtil.newMessage();
			name2actor.get("Type2Doc__GEN_37_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.Package2Folder, ExtDocModel.Folder>(incUtil,(ExtType2Doc_LookAhead.Package2Folder) notification.getNotifier(), (ExtDocModel.Folder) notification.getNewValue(), "ExtType2Doc_LookAhead.Package2Folder_target_Folder"), getSelf());
		});
	}
	
	private void initializeRemoveEdge() {
		feature2removeEdgeConsumer.put(ExtTypeModel.ExtTypeModelPackage.eINSTANCE.getPackage_Types(), notification -> {
			incUtil.newMessage();
			name2actor.get("ExtendingType2Doc__GEN_1_localSearch").tell(new ReferenceDeleted<ExtTypeModel.Package, ExtTypeModel.Type>(incUtil, (ExtTypeModel.Package) notification.getNotifier(), (ExtTypeModel.Type) notification.getOldValue(), "ExtTypeModel.Package_types_Type"), getSelf());
		});
		feature2removeEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getMethod2Entry_Target(), notification -> {
			incUtil.newMessage();
			name2actor.get("Param2Entry__GEN_29_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.Method2Entry, ExtDocModel.Entry>(incUtil, (ExtType2Doc_LookAhead.Method2Entry) notification.getNotifier(), (ExtDocModel.Entry) notification.getOldValue(), "ExtType2Doc_LookAhead.Method2Entry_target_Entry"), getSelf());
		});
		feature2removeEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getType2Doc_Source(), notification -> {
			incUtil.newMessage();
			name2actor.get("Type2Doc_source_0_reference").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.Type2Doc, ExtTypeModel.Type>(incUtil, (ExtType2Doc_LookAhead.Type2Doc) notification.getNotifier(), (ExtTypeModel.Type) notification.getOldValue(), "ExtType2Doc_LookAhead.Type2Doc_source_Type"), getSelf());
			incUtil.newMessage();
			name2actor.get("Type2Doc_source_1_reference").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.Type2Doc, ExtTypeModel.Type>(incUtil, (ExtType2Doc_LookAhead.Type2Doc) notification.getNotifier(), (ExtTypeModel.Type) notification.getOldValue(), "ExtType2Doc_LookAhead.Type2Doc_source_Type"), getSelf());
			incUtil.newMessage();
			name2actor.get("ExtendingType2Doc__GEN_1_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.Type2Doc, ExtTypeModel.Type>(incUtil, (ExtType2Doc_LookAhead.Type2Doc) notification.getNotifier(), (ExtTypeModel.Type) notification.getOldValue(), "ExtType2Doc_LookAhead.Type2Doc_source_Type"), getSelf());
			incUtil.newMessage();
			name2actor.get("Field2Entry__GEN_8_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.Type2Doc, ExtTypeModel.Type>(incUtil, (ExtType2Doc_LookAhead.Type2Doc) notification.getNotifier(), (ExtTypeModel.Type) notification.getOldValue(), "ExtType2Doc_LookAhead.Type2Doc_source_Type"), getSelf());
			incUtil.newMessage();
			name2actor.get("Method2Entry__GEN_25_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.Type2Doc, ExtTypeModel.Type>(incUtil, (ExtType2Doc_LookAhead.Type2Doc) notification.getNotifier(), (ExtTypeModel.Type) notification.getOldValue(), "ExtType2Doc_LookAhead.Type2Doc_source_Type"), getSelf());
		});
		feature2removeEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getMethod2Entry_Source(), notification -> {
			incUtil.newMessage();
			name2actor.get("Param2Entry__GEN_29_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.Method2Entry, ExtTypeModel.Method>(incUtil, (ExtType2Doc_LookAhead.Method2Entry) notification.getNotifier(), (ExtTypeModel.Method) notification.getOldValue(), "ExtType2Doc_LookAhead.Method2Entry_source_Method"), getSelf());
		});
		feature2removeEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getType2Doc_Target(), notification -> {
			incUtil.newMessage();
			name2actor.get("Type2Doc_target_0_reference").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.Type2Doc, ExtDocModel.Doc>(incUtil, (ExtType2Doc_LookAhead.Type2Doc) notification.getNotifier(), (ExtDocModel.Doc) notification.getOldValue(), "ExtType2Doc_LookAhead.Type2Doc_target_Doc"), getSelf());
			incUtil.newMessage();
			name2actor.get("ExtendingType2Doc__GEN_1_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.Type2Doc, ExtDocModel.Doc>(incUtil, (ExtType2Doc_LookAhead.Type2Doc) notification.getNotifier(), (ExtDocModel.Doc) notification.getOldValue(), "ExtType2Doc_LookAhead.Type2Doc_target_Doc"), getSelf());
			incUtil.newMessage();
			name2actor.get("Field2Entry__GEN_8_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.Type2Doc, ExtDocModel.Doc>(incUtil, (ExtType2Doc_LookAhead.Type2Doc) notification.getNotifier(), (ExtDocModel.Doc) notification.getOldValue(), "ExtType2Doc_LookAhead.Type2Doc_target_Doc"), getSelf());
			incUtil.newMessage();
			name2actor.get("Method2Entry__GEN_25_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.Type2Doc, ExtDocModel.Doc>(incUtil, (ExtType2Doc_LookAhead.Type2Doc) notification.getNotifier(), (ExtDocModel.Doc) notification.getOldValue(), "ExtType2Doc_LookAhead.Type2Doc_target_Doc"), getSelf());
		});
		feature2removeEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getPackage2Folder_Source(), notification -> {
			incUtil.newMessage();
			name2actor.get("ExtendingType2Doc__GEN_1_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.Package2Folder, ExtTypeModel.Package>(incUtil, (ExtType2Doc_LookAhead.Package2Folder) notification.getNotifier(), (ExtTypeModel.Package) notification.getOldValue(), "ExtType2Doc_LookAhead.Package2Folder_source_Package"), getSelf());
			incUtil.newMessage();
			name2actor.get("SubPackage2Folder__GEN_33_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.Package2Folder, ExtTypeModel.Package>(incUtil, (ExtType2Doc_LookAhead.Package2Folder) notification.getNotifier(), (ExtTypeModel.Package) notification.getOldValue(), "ExtType2Doc_LookAhead.Package2Folder_source_Package"), getSelf());
			incUtil.newMessage();
			name2actor.get("Type2Doc__GEN_37_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.Package2Folder, ExtTypeModel.Package>(incUtil, (ExtType2Doc_LookAhead.Package2Folder) notification.getNotifier(), (ExtTypeModel.Package) notification.getOldValue(), "ExtType2Doc_LookAhead.Package2Folder_source_Package"), getSelf());
		});
		feature2removeEdgeConsumer.put(ExtDocModel.ExtDocModelPackage.eINSTANCE.getDoc_Folder(), notification -> {
			incUtil.newMessage();
			name2actor.get("ExtendingType2Doc__GEN_1_localSearch").tell(new ReferenceDeleted<ExtDocModel.Doc, ExtDocModel.Folder>(incUtil, (ExtDocModel.Doc) notification.getNotifier(), (ExtDocModel.Folder) notification.getOldValue(), "ExtDocModel.Doc_folder_Folder"), getSelf());
		});
		feature2removeEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getPackage2Folder_Target(), notification -> {
			incUtil.newMessage();
			name2actor.get("ExtendingType2Doc__GEN_1_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.Package2Folder, ExtDocModel.Folder>(incUtil, (ExtType2Doc_LookAhead.Package2Folder) notification.getNotifier(), (ExtDocModel.Folder) notification.getOldValue(), "ExtType2Doc_LookAhead.Package2Folder_target_Folder"), getSelf());
			incUtil.newMessage();
			name2actor.get("SubPackage2Folder__GEN_33_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.Package2Folder, ExtDocModel.Folder>(incUtil, (ExtType2Doc_LookAhead.Package2Folder) notification.getNotifier(), (ExtDocModel.Folder) notification.getOldValue(), "ExtType2Doc_LookAhead.Package2Folder_target_Folder"), getSelf());
			incUtil.newMessage();
			name2actor.get("Type2Doc__GEN_37_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.Package2Folder, ExtDocModel.Folder>(incUtil, (ExtType2Doc_LookAhead.Package2Folder) notification.getNotifier(), (ExtDocModel.Folder) notification.getOldValue(), "ExtType2Doc_LookAhead.Package2Folder_target_Folder"), getSelf());
		});
	}

	@Override
	public void preStart() throws Exception {
		super.preStart();
	}

	@Override
	public void postStop() throws Exception {
		if(HiPEConfig.logWorkloadActivated) {
			DecimalFormat df = new DecimalFormat("0.#####");
	        df.setMaximumFractionDigits(5);
			System.err.println("DispatchNode" + ";"  + counter + ";" + df.format((double) time / (double) (1000 * 1000 * 1000)));
		}
	}

	@Override
	public Receive createReceive() {
		return receiveBuilder() //
				.match(NotificationContainer.class, this::handleNotificationContainer)
				.match(NoMoreInput.class, this::sendFinished) //
				.build();
	}

	private void sendFinished(NoMoreInput m) {
		incUtil.allMessagesInserted();
	}
	
	private void handleNotificationContainer(NotificationContainer nc) {
		counter++;
		long tic = System.nanoTime();
		nc.notifications.parallelStream().forEach(this::handleNotification);
		time += System.nanoTime() - tic;
	}
	
	private void handleNotification(Notification notification) {
		switch (notification.getEventType()) {
		case Notification.ADD:
			handleAdd(notification);
			break;
		case Notification.REMOVE:
			handleRemove(notification);
			break;
		case Notification.REMOVING_ADAPTER:
			handleRemoveAdapter(notification);
			break;	
		case Notification.SET:
			handleSet(notification);
			break;
		}
	}

	private void handleAdd(Notification notification) {
		if(notification.getFeature() == null) 
			handleAddedNode(notification.getNewValue());
		else
			handleAddedEdge(notification);
	}

	private void handleAddedNode(Object node) {
		if(node == null) 
			return;
			
		EObject obj = (EObject) node;
		if(type2addConsumer.containsKey(obj.eClass())) {
			type2addConsumer.get(obj.eClass()).accept(node);
		}
	}
	
	private void handleSet(Notification notification) {
		Object feature = notification.getFeature();
		if(feature2setConsumer.containsKey(feature)) {
			feature2setConsumer.get(feature).accept(notification);
		}
	}

	private void handleAddedEdge(Notification notification) {
		//check for self-edges
		if(notification.getNotifier().equals(notification.getNewValue()))
			handleAddedNode(notification.getNewValue());
					
		Object feature = notification.getFeature();
		if(feature2addEdgeConsumer.containsKey(feature)) {
			feature2addEdgeConsumer.get(feature).accept(notification);
		}
	}

	private void handleRemove(Notification notification) {
		Object feature = notification.getFeature();
		if(feature2removeEdgeConsumer.containsKey(feature)) {
			feature2removeEdgeConsumer.get(feature).accept(notification);
		}
	}
	
	private void handleRemoveAdapter(Notification notification) {
		Object node = notification.getNotifier();
		if (node instanceof ExtType2Doc_LookAhead.Package2Folder) {
			incUtil.newMessage();
			name2actor.get("Package2Folder_object").tell(new ObjectDeleted<ExtType2Doc_LookAhead.Package2Folder>(incUtil, (ExtType2Doc_LookAhead.Package2Folder) node), getSelf());
		}
		if (node instanceof ExtType2Doc_LookAhead.Method2Entry) {
			incUtil.newMessage();
			name2actor.get("Method2Entry_object").tell(new ObjectDeleted<ExtType2Doc_LookAhead.Method2Entry>(incUtil, (ExtType2Doc_LookAhead.Method2Entry) node), getSelf());
		}
		if (node instanceof ExtType2Doc_LookAhead.Type2Doc) {
			incUtil.newMessage();
			name2actor.get("Type2Doc_object_SP0").tell(new ObjectDeleted<ExtType2Doc_LookAhead.Type2Doc>(incUtil, (ExtType2Doc_LookAhead.Type2Doc) node), getSelf());
		}
		if (node instanceof ExtType2Doc_LookAhead.Type2Doc) {
			incUtil.newMessage();
			name2actor.get("Type2Doc_object_SP1").tell(new ObjectDeleted<ExtType2Doc_LookAhead.Type2Doc>(incUtil, (ExtType2Doc_LookAhead.Type2Doc) node), getSelf());
		}
		if (node instanceof ExtDocModel.Doc) {
			incUtil.newMessage();
			name2actor.get("Doc_object").tell(new ObjectDeleted<ExtDocModel.Doc>(incUtil, (ExtDocModel.Doc) node), getSelf());
		}
		if (node instanceof ExtDocModel.Folder) {
			incUtil.newMessage();
			name2actor.get("Folder_object").tell(new ObjectDeleted<ExtDocModel.Folder>(incUtil, (ExtDocModel.Folder) node), getSelf());
		}
		if (node instanceof ExtDocModel.Entry) {
			incUtil.newMessage();
			name2actor.get("Entry_object").tell(new ObjectDeleted<ExtDocModel.Entry>(incUtil, (ExtDocModel.Entry) node), getSelf());
		}
		if (node instanceof ExtTypeModel.Package) {
			incUtil.newMessage();
			name2actor.get("Package_object").tell(new ObjectDeleted<ExtTypeModel.Package>(incUtil, (ExtTypeModel.Package) node), getSelf());
		}
		if (node instanceof ExtTypeModel.Method) {
			incUtil.newMessage();
			name2actor.get("Method_object").tell(new ObjectDeleted<ExtTypeModel.Method>(incUtil, (ExtTypeModel.Method) node), getSelf());
		}
		if (node instanceof ExtTypeModel.Type) {
			incUtil.newMessage();
			name2actor.get("Type_object_SP0").tell(new ObjectDeleted<ExtTypeModel.Type>(incUtil, (ExtTypeModel.Type) node), getSelf());
		}
		if (node instanceof ExtTypeModel.Type) {
			incUtil.newMessage();
			name2actor.get("Type_object_SP1").tell(new ObjectDeleted<ExtTypeModel.Type>(incUtil, (ExtTypeModel.Type) node), getSelf());
		}
	}
}

