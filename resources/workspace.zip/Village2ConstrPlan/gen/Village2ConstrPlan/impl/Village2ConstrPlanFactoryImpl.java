package Village2ConstrPlan.impl;

import Village2ConstrPlan.VillageSquare2PlanCollection;
import Village2ConstrPlan.House2Constr;
import Village2ConstrPlan.Corner2Constr__Marker;
import Village2ConstrPlan.Cube2Constr__Marker;
import Village2ConstrPlan.DoubleCube2Constr__Marker;
import Village2ConstrPlan.Villa2Constr__Marker;
import Village2ConstrPlan.VillageSquare2PlanCollection__Marker;


import Village2ConstrPlan.Village2ConstrPlanFactory;
import Village2ConstrPlan.Village2ConstrPlanPackage;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

public class Village2ConstrPlanFactoryImpl extends EFactoryImpl implements Village2ConstrPlan.Village2ConstrPlanFactory {

	public static Village2ConstrPlan.Village2ConstrPlanFactory init() {
		try {
			Village2ConstrPlanFactory theVillage2ConstrPlanFactory = (Village2ConstrPlanFactory) EPackage.Registry.INSTANCE
					.getEFactory(Village2ConstrPlanPackage.eNS_URI);
			if (theVillage2ConstrPlanFactory != null) {
				return theVillage2ConstrPlanFactory;
			}
		} catch (java.lang.Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new Village2ConstrPlanFactoryImpl();
	}

	public Village2ConstrPlanFactoryImpl() {
		super();
	}

	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
		case Village2ConstrPlanPackage.VILLAGE_SQUARE2_PLAN_COLLECTION:
			return createVillageSquare2PlanCollection();
		case Village2ConstrPlanPackage.HOUSE2_CONSTR:
			return createHouse2Constr();
		case Village2ConstrPlanPackage.CORNER2_CONSTR___MARKER:
			return createCorner2Constr__Marker();
		case Village2ConstrPlanPackage.CUBE2_CONSTR___MARKER:
			return createCube2Constr__Marker();
		case Village2ConstrPlanPackage.DOUBLE_CUBE2_CONSTR___MARKER:
			return createDoubleCube2Constr__Marker();
		case Village2ConstrPlanPackage.VILLA2_CONSTR___MARKER:
			return createVilla2Constr__Marker();
		case Village2ConstrPlanPackage.VILLAGE_SQUARE2_PLAN_COLLECTION___MARKER:
			return createVillageSquare2PlanCollection__Marker();
		default:
			throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}
	
	
	@Override
	public Village2ConstrPlan.VillageSquare2PlanCollection createVillageSquare2PlanCollection() {
		VillageSquare2PlanCollectionImpl villageSquare2PlanCollection = new VillageSquare2PlanCollectionImpl();
		return villageSquare2PlanCollection;
	}
	@Override
	public Village2ConstrPlan.House2Constr createHouse2Constr() {
		House2ConstrImpl house2Constr = new House2ConstrImpl();
		return house2Constr;
	}
	@Override
	public Village2ConstrPlan.Corner2Constr__Marker createCorner2Constr__Marker() {
		Corner2Constr__MarkerImpl corner2Constr__Marker = new Corner2Constr__MarkerImpl();
		return corner2Constr__Marker;
	}
	@Override
	public Village2ConstrPlan.Cube2Constr__Marker createCube2Constr__Marker() {
		Cube2Constr__MarkerImpl cube2Constr__Marker = new Cube2Constr__MarkerImpl();
		return cube2Constr__Marker;
	}
	@Override
	public Village2ConstrPlan.DoubleCube2Constr__Marker createDoubleCube2Constr__Marker() {
		DoubleCube2Constr__MarkerImpl doubleCube2Constr__Marker = new DoubleCube2Constr__MarkerImpl();
		return doubleCube2Constr__Marker;
	}
	@Override
	public Village2ConstrPlan.Villa2Constr__Marker createVilla2Constr__Marker() {
		Villa2Constr__MarkerImpl villa2Constr__Marker = new Villa2Constr__MarkerImpl();
		return villa2Constr__Marker;
	}
	@Override
	public Village2ConstrPlan.VillageSquare2PlanCollection__Marker createVillageSquare2PlanCollection__Marker() {
		VillageSquare2PlanCollection__MarkerImpl villageSquare2PlanCollection__Marker = new VillageSquare2PlanCollection__MarkerImpl();
		return villageSquare2PlanCollection__Marker;
	}
	

	@Override
	public Village2ConstrPlanPackage getVillage2ConstrPlanPackage() {
	return (Village2ConstrPlanPackage) getEPackage();
	}
} 
