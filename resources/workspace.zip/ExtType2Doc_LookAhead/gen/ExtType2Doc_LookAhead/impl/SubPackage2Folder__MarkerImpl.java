package ExtType2Doc_LookAhead.impl;

import ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage;
import runtime.RuntimePackage;
import ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage;

import org.emoflon.smartemf.runtime.*;
import org.emoflon.smartemf.runtime.collections.*;
import org.emoflon.smartemf.persistence.SmartEMFResource;
import org.emoflon.smartemf.runtime.notification.SmartEMFNotification;
import org.emoflon.smartemf.runtime.notification.NotifyStatus;

import java.util.function.Consumer;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EcoreFactory;
import org.eclipse.emf.ecore.EcorePackage;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.resource.Resource;

public class SubPackage2Folder__MarkerImpl extends SmartObject implements ExtType2Doc_LookAhead.SubPackage2Folder__Marker {

    protected runtime.Protocol protocol = null;
    protected ExtTypeModel.Package CONTEXT__SRC__p = null;
    protected ExtTypeModel.Package CREATE__SRC__sp = null;
    protected ExtDocModel.Folder CONTEXT__TRG__f = null;
    protected ExtDocModel.Folder CREATE__TRG__sf = null;
    protected ExtType2Doc_LookAhead.Package2Folder CONTEXT__CORR__p2f = null;
    protected ExtType2Doc_LookAhead.Package2Folder CREATE__CORR__sp2f = null;
	
	protected SubPackage2Folder__MarkerImpl() {
		super(ExtType2Doc_LookAheadPackage.Literals.SUB_PACKAGE2_FOLDER___MARKER);
	}
	
    
    @Override
    public runtime.Protocol getProtocol() {
    	return this.protocol;
    }
    
    @Override
    public void setProtocol(runtime.Protocol value) {
    	
    	Object oldValue = this.protocol;
    	
    	if(value == null && oldValue == null)
    		return;
    		
    	if(value != null && value.equals(oldValue))
    		return;
    		
    	
    	
    		       	if(this.protocol != null && value == null) {
    		       		resetContainmentSilently();
    		       	}
    		        this.protocol = value;
    		        
    	
    	
    	        	sendNotification(SmartEMFNotification.createSetNotification(this, RuntimePackage.Literals.TGG_RULE_APPLICATION__PROTOCOL, oldValue, value, -1));
    	        	
    	
    	        	if(oldValue != null) {
    	        		((SmartObject) oldValue).eInverseRemove(this, RuntimePackage.Literals.PROTOCOL__STEPS);
    	        	}
    	        	if(value != null) {
    	        		((SmartObject) value).eInverseAdd(this, RuntimePackage.Literals.PROTOCOL__STEPS);
    	        	}
    }
    
    private void setProtocolAsInverse(runtime.Protocol value) {
			    
			    Object oldValue = this.protocol;
			    
			    if(value == null && oldValue == null)
			    	return;
			    	
			    if(value != null && value.equals(oldValue))
			    	return;
			    	
			    
			    
			    	       	if(this.protocol != null && value == null) {
			    	       		resetContainmentSilently();
			    	       	}
			    	        this.protocol = value;
			    	        
			    
			    
			            	sendNotification(SmartEMFNotification.createSetNotification(this, RuntimePackage.Literals.TGG_RULE_APPLICATION__PROTOCOL, oldValue, value, -1));
			            	
    }
    
    @Override
    public ExtTypeModel.Package getCONTEXT__SRC__p() {
    	return this.CONTEXT__SRC__p;
    }
    
    @Override
    public void setCONTEXT__SRC__p(ExtTypeModel.Package value) {
    	
    	Object oldValue = this.CONTEXT__SRC__p;
    	
    	if(value == null && oldValue == null)
    		return;
    		
    	if(value != null && value.equals(oldValue))
    		return;
    		
    	
    	
    		        this.CONTEXT__SRC__p = value;
    		        
    	
    	
    	        	sendNotification(SmartEMFNotification.createSetNotification(this, ExtType2Doc_LookAheadPackage.Literals.SUB_PACKAGE2_FOLDER___MARKER__CONTEX_T__SR_C__P, oldValue, value, -1));
    	        	
    	        	if(ExtType2Doc_LookAheadPackage.Literals.SUB_PACKAGE2_FOLDER___MARKER__CONTEX_T__SR_C__P.getEOpposite() != null) {
    	        		if(oldValue != null) {
    	        			((SmartObject) oldValue).eInverseRemove(this, ExtType2Doc_LookAheadPackage.Literals.SUB_PACKAGE2_FOLDER___MARKER__CONTEX_T__SR_C__P.getEOpposite());
    	        		}
    	        		if(value != null) {
    	        		    ((SmartObject) value).eInverseAdd(this, ExtType2Doc_LookAheadPackage.Literals.SUB_PACKAGE2_FOLDER___MARKER__CONTEX_T__SR_C__P.getEOpposite());
    	        		}
    	        	}
    }
    
    
    @Override
    public ExtTypeModel.Package getCREATE__SRC__sp() {
    	return this.CREATE__SRC__sp;
    }
    
    @Override
    public void setCREATE__SRC__sp(ExtTypeModel.Package value) {
    	
    	Object oldValue = this.CREATE__SRC__sp;
    	
    	if(value == null && oldValue == null)
    		return;
    		
    	if(value != null && value.equals(oldValue))
    		return;
    		
    	
    	
    		        this.CREATE__SRC__sp = value;
    		        
    	
    	
    	        	sendNotification(SmartEMFNotification.createSetNotification(this, ExtType2Doc_LookAheadPackage.Literals.SUB_PACKAGE2_FOLDER___MARKER__CREAT_E__SR_C__SP, oldValue, value, -1));
    	        	
    	        	if(ExtType2Doc_LookAheadPackage.Literals.SUB_PACKAGE2_FOLDER___MARKER__CREAT_E__SR_C__SP.getEOpposite() != null) {
    	        		if(oldValue != null) {
    	        			((SmartObject) oldValue).eInverseRemove(this, ExtType2Doc_LookAheadPackage.Literals.SUB_PACKAGE2_FOLDER___MARKER__CREAT_E__SR_C__SP.getEOpposite());
    	        		}
    	        		if(value != null) {
    	        		    ((SmartObject) value).eInverseAdd(this, ExtType2Doc_LookAheadPackage.Literals.SUB_PACKAGE2_FOLDER___MARKER__CREAT_E__SR_C__SP.getEOpposite());
    	        		}
    	        	}
    }
    
    
    @Override
    public ExtDocModel.Folder getCONTEXT__TRG__f() {
    	return this.CONTEXT__TRG__f;
    }
    
    @Override
    public void setCONTEXT__TRG__f(ExtDocModel.Folder value) {
    	
    	Object oldValue = this.CONTEXT__TRG__f;
    	
    	if(value == null && oldValue == null)
    		return;
    		
    	if(value != null && value.equals(oldValue))
    		return;
    		
    	
    	
    		        this.CONTEXT__TRG__f = value;
    		        
    	
    	
    	        	sendNotification(SmartEMFNotification.createSetNotification(this, ExtType2Doc_LookAheadPackage.Literals.SUB_PACKAGE2_FOLDER___MARKER__CONTEX_T__TR_G__F, oldValue, value, -1));
    	        	
    	        	if(ExtType2Doc_LookAheadPackage.Literals.SUB_PACKAGE2_FOLDER___MARKER__CONTEX_T__TR_G__F.getEOpposite() != null) {
    	        		if(oldValue != null) {
    	        			((SmartObject) oldValue).eInverseRemove(this, ExtType2Doc_LookAheadPackage.Literals.SUB_PACKAGE2_FOLDER___MARKER__CONTEX_T__TR_G__F.getEOpposite());
    	        		}
    	        		if(value != null) {
    	        		    ((SmartObject) value).eInverseAdd(this, ExtType2Doc_LookAheadPackage.Literals.SUB_PACKAGE2_FOLDER___MARKER__CONTEX_T__TR_G__F.getEOpposite());
    	        		}
    	        	}
    }
    
    
    @Override
    public ExtDocModel.Folder getCREATE__TRG__sf() {
    	return this.CREATE__TRG__sf;
    }
    
    @Override
    public void setCREATE__TRG__sf(ExtDocModel.Folder value) {
    	
    	Object oldValue = this.CREATE__TRG__sf;
    	
    	if(value == null && oldValue == null)
    		return;
    		
    	if(value != null && value.equals(oldValue))
    		return;
    		
    	
    	
    		        this.CREATE__TRG__sf = value;
    		        
    	
    	
    	        	sendNotification(SmartEMFNotification.createSetNotification(this, ExtType2Doc_LookAheadPackage.Literals.SUB_PACKAGE2_FOLDER___MARKER__CREAT_E__TR_G__SF, oldValue, value, -1));
    	        	
    	        	if(ExtType2Doc_LookAheadPackage.Literals.SUB_PACKAGE2_FOLDER___MARKER__CREAT_E__TR_G__SF.getEOpposite() != null) {
    	        		if(oldValue != null) {
    	        			((SmartObject) oldValue).eInverseRemove(this, ExtType2Doc_LookAheadPackage.Literals.SUB_PACKAGE2_FOLDER___MARKER__CREAT_E__TR_G__SF.getEOpposite());
    	        		}
    	        		if(value != null) {
    	        		    ((SmartObject) value).eInverseAdd(this, ExtType2Doc_LookAheadPackage.Literals.SUB_PACKAGE2_FOLDER___MARKER__CREAT_E__TR_G__SF.getEOpposite());
    	        		}
    	        	}
    }
    
    
    @Override
    public ExtType2Doc_LookAhead.Package2Folder getCONTEXT__CORR__p2f() {
    	return this.CONTEXT__CORR__p2f;
    }
    
    @Override
    public void setCONTEXT__CORR__p2f(ExtType2Doc_LookAhead.Package2Folder value) {
    	
    	Object oldValue = this.CONTEXT__CORR__p2f;
    	
    	if(value == null && oldValue == null)
    		return;
    		
    	if(value != null && value.equals(oldValue))
    		return;
    		
    	
    	
    		        this.CONTEXT__CORR__p2f = value;
    		        
    	
    	
    	        	sendNotification(SmartEMFNotification.createSetNotification(this, ExtType2Doc_LookAheadPackage.Literals.SUB_PACKAGE2_FOLDER___MARKER__CONTEX_T__COR_R__P2F, oldValue, value, -1));
    	        	
    	        	if(ExtType2Doc_LookAheadPackage.Literals.SUB_PACKAGE2_FOLDER___MARKER__CONTEX_T__COR_R__P2F.getEOpposite() != null) {
    	        		if(oldValue != null) {
    	        			((SmartObject) oldValue).eInverseRemove(this, ExtType2Doc_LookAheadPackage.Literals.SUB_PACKAGE2_FOLDER___MARKER__CONTEX_T__COR_R__P2F.getEOpposite());
    	        		}
    	        		if(value != null) {
    	        		    ((SmartObject) value).eInverseAdd(this, ExtType2Doc_LookAheadPackage.Literals.SUB_PACKAGE2_FOLDER___MARKER__CONTEX_T__COR_R__P2F.getEOpposite());
    	        		}
    	        	}
    }
    
    
    @Override
    public ExtType2Doc_LookAhead.Package2Folder getCREATE__CORR__sp2f() {
    	return this.CREATE__CORR__sp2f;
    }
    
    @Override
    public void setCREATE__CORR__sp2f(ExtType2Doc_LookAhead.Package2Folder value) {
    	
    	Object oldValue = this.CREATE__CORR__sp2f;
    	
    	if(value == null && oldValue == null)
    		return;
    		
    	if(value != null && value.equals(oldValue))
    		return;
    		
    	
    	
    		        this.CREATE__CORR__sp2f = value;
    		        
    	
    	
    	        	sendNotification(SmartEMFNotification.createSetNotification(this, ExtType2Doc_LookAheadPackage.Literals.SUB_PACKAGE2_FOLDER___MARKER__CREAT_E__COR_R__SP2F, oldValue, value, -1));
    	        	
    	        	if(ExtType2Doc_LookAheadPackage.Literals.SUB_PACKAGE2_FOLDER___MARKER__CREAT_E__COR_R__SP2F.getEOpposite() != null) {
    	        		if(oldValue != null) {
    	        			((SmartObject) oldValue).eInverseRemove(this, ExtType2Doc_LookAheadPackage.Literals.SUB_PACKAGE2_FOLDER___MARKER__CREAT_E__COR_R__SP2F.getEOpposite());
    	        		}
    	        		if(value != null) {
    	        		    ((SmartObject) value).eInverseAdd(this, ExtType2Doc_LookAheadPackage.Literals.SUB_PACKAGE2_FOLDER___MARKER__CREAT_E__COR_R__SP2F.getEOpposite());
    	        		}
    	        	}
    }
    

    @Override
    public void eSet(EStructuralFeature eFeature, Object newValue){
    	if (RuntimePackage.Literals.TGG_RULE_APPLICATION__PROTOCOL.equals(eFeature)) {
    		setProtocol((runtime.Protocol) newValue); 
    		return;
    	}
    	if (ExtType2Doc_LookAheadPackage.Literals.SUB_PACKAGE2_FOLDER___MARKER__CONTEX_T__SR_C__P.equals(eFeature)) {
    		setCONTEXT__SRC__p((ExtTypeModel.Package) newValue); 
    		return;
    	}
    	if (ExtType2Doc_LookAheadPackage.Literals.SUB_PACKAGE2_FOLDER___MARKER__CREAT_E__SR_C__SP.equals(eFeature)) {
    		setCREATE__SRC__sp((ExtTypeModel.Package) newValue); 
    		return;
    	}
    	if (ExtType2Doc_LookAheadPackage.Literals.SUB_PACKAGE2_FOLDER___MARKER__CONTEX_T__TR_G__F.equals(eFeature)) {
    		setCONTEXT__TRG__f((ExtDocModel.Folder) newValue); 
    		return;
    	}
    	if (ExtType2Doc_LookAheadPackage.Literals.SUB_PACKAGE2_FOLDER___MARKER__CREAT_E__TR_G__SF.equals(eFeature)) {
    		setCREATE__TRG__sf((ExtDocModel.Folder) newValue); 
    		return;
    	}
    	if (ExtType2Doc_LookAheadPackage.Literals.SUB_PACKAGE2_FOLDER___MARKER__CONTEX_T__COR_R__P2F.equals(eFeature)) {
    		setCONTEXT__CORR__p2f((ExtType2Doc_LookAhead.Package2Folder) newValue); 
    		return;
    	}
    	if (ExtType2Doc_LookAheadPackage.Literals.SUB_PACKAGE2_FOLDER___MARKER__CREAT_E__COR_R__SP2F.equals(eFeature)) {
    		setCREATE__CORR__sp2f((ExtType2Doc_LookAhead.Package2Folder) newValue); 
    		return;
    	}
    	eDynamicSet(eFeature, newValue);
    }
    
    @Override
    public void eUnset(EStructuralFeature eFeature){
    	if (RuntimePackage.Literals.TGG_RULE_APPLICATION__PROTOCOL.equals(eFeature)) {
    		setProtocol((runtime.Protocol)null); 
    		return;
    	}
    	if (ExtType2Doc_LookAheadPackage.Literals.SUB_PACKAGE2_FOLDER___MARKER__CONTEX_T__SR_C__P.equals(eFeature)) {
    		setCONTEXT__SRC__p((ExtTypeModel.Package)null); 
    		return;
    	}
    	if (ExtType2Doc_LookAheadPackage.Literals.SUB_PACKAGE2_FOLDER___MARKER__CREAT_E__SR_C__SP.equals(eFeature)) {
    		setCREATE__SRC__sp((ExtTypeModel.Package)null); 
    		return;
    	}
    	if (ExtType2Doc_LookAheadPackage.Literals.SUB_PACKAGE2_FOLDER___MARKER__CONTEX_T__TR_G__F.equals(eFeature)) {
    		setCONTEXT__TRG__f((ExtDocModel.Folder)null); 
    		return;
    	}
    	if (ExtType2Doc_LookAheadPackage.Literals.SUB_PACKAGE2_FOLDER___MARKER__CREAT_E__TR_G__SF.equals(eFeature)) {
    		setCREATE__TRG__sf((ExtDocModel.Folder)null); 
    		return;
    	}
    	if (ExtType2Doc_LookAheadPackage.Literals.SUB_PACKAGE2_FOLDER___MARKER__CONTEX_T__COR_R__P2F.equals(eFeature)) {
    		setCONTEXT__CORR__p2f((ExtType2Doc_LookAhead.Package2Folder)null); 
    		return;
    	}
    	if (ExtType2Doc_LookAheadPackage.Literals.SUB_PACKAGE2_FOLDER___MARKER__CREAT_E__COR_R__SP2F.equals(eFeature)) {
    		setCREATE__CORR__sp2f((ExtType2Doc_LookAhead.Package2Folder)null); 
    		return;
    	}
    	eDynamicUnset(eFeature);
    }

    @Override
    public String toString(){
		return super.toString();
    }

 	@Override
    public Object eGet(EStructuralFeature eFeature){
    	if (RuntimePackage.Literals.TGG_RULE_APPLICATION__PROTOCOL.equals(eFeature))
    		return getProtocol();
    	if (ExtType2Doc_LookAheadPackage.Literals.SUB_PACKAGE2_FOLDER___MARKER__CONTEX_T__SR_C__P.equals(eFeature))
    		return getCONTEXT__SRC__p();
    	if (ExtType2Doc_LookAheadPackage.Literals.SUB_PACKAGE2_FOLDER___MARKER__CREAT_E__SR_C__SP.equals(eFeature))
    		return getCREATE__SRC__sp();
    	if (ExtType2Doc_LookAheadPackage.Literals.SUB_PACKAGE2_FOLDER___MARKER__CONTEX_T__TR_G__F.equals(eFeature))
    		return getCONTEXT__TRG__f();
    	if (ExtType2Doc_LookAheadPackage.Literals.SUB_PACKAGE2_FOLDER___MARKER__CREAT_E__TR_G__SF.equals(eFeature))
    		return getCREATE__TRG__sf();
    	if (ExtType2Doc_LookAheadPackage.Literals.SUB_PACKAGE2_FOLDER___MARKER__CONTEX_T__COR_R__P2F.equals(eFeature))
    		return getCONTEXT__CORR__p2f();
    	if (ExtType2Doc_LookAheadPackage.Literals.SUB_PACKAGE2_FOLDER___MARKER__CREAT_E__COR_R__SP2F.equals(eFeature))
    		return getCREATE__CORR__sp2f();
    	return eDynamicGet(eFeature);
    }

    @Override
    public Object eGet(int featureID, boolean resolve, boolean coreType){
    	throw new UnsupportedOperationException("This method has been deactivated since it is not always safe to use.");
    }
    
    @Override
    public void eInverseAdd(Object otherEnd, EStructuralFeature feature) {
if (RuntimePackage.Literals.TGG_RULE_APPLICATION__PROTOCOL.equals(feature)) {
setProtocolAsInverse((runtime.Protocol) otherEnd); 
 	return;
			        }	
	    if(feature == null)
	    	return;
	    	
    	eDynamicInverseAdd(otherEnd, feature);
	    	}
    	
    @Override
	    	public void eInverseRemove(Object otherEnd, EStructuralFeature feature) {
if (RuntimePackage.Literals.TGG_RULE_APPLICATION__PROTOCOL.equals(feature)) {
setProtocolAsInverse(null); 
 	return;
			        }
	    if(feature == null)
	    	return;
	    		    		
    	eDynamicInverseRemove(otherEnd, feature);
	    	}
    
    @Override
    /**
    * This method sets the resource and generates REMOVING_ADAPTER and ADD notifications
    */
    protected void setResourceOfContainments(Consumer<SmartObject> setResourceCall) {
	    	}
	    	
	    	@Override
	    	/**
	    	* This method sets the resource and only generates REMOVING_ADAPTER notifications (no ADD messages)
	    	*/
    protected void setResourceOfContainmentsSilently(Resource r) { 		
	    	}
}
