package ExtDocModel;

import ExtDocModel.NamedElement;
import ExtDocModel.Folder;
import ExtDocModel.Doc;
import ExtDocModel.Entry;
import ExtDocModel.Annotation;
import ExtDocModel.Glossary;
import ExtDocModel.GlossaryEntry;
import ExtDocModel.DocContainer;

import org.eclipse.emf.ecore.EFactory;

public interface ExtDocModelFactory extends EFactory {

	ExtDocModelFactory eINSTANCE = ExtDocModel.impl.ExtDocModelFactoryImpl.init();
	
	Folder createFolder();
	
	Doc createDoc();
	
	Entry createEntry();
	
	Annotation createAnnotation();
	
	Glossary createGlossary();
	
	GlossaryEntry createGlossaryEntry();
	
	DocContainer createDocContainer();
	
	
	ExtDocModelPackage getExtDocModelPackage();

}
