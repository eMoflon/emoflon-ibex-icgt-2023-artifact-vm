package Village.impl;

import Village.VillageSquare;
import Village.House;

import Village.HouseType;

import Village.VillageFactory;
import Village.VillagePackage;


import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.ecore.EcorePackage;

import org.eclipse.emf.ecore.impl.EPackageImpl;

import org.emoflon.smartemf.runtime.SmartPackageImpl;

public class VillagePackageImpl extends SmartPackageImpl
		implements VillagePackage {
			
	private EClass villageSquareEClass = null;
	private EReference villageSquare_streetCornerEReference = null;
	private EClass houseEClass = null;
	private EReference house_nextHouseEReference = null;
	private EAttribute house_nameEAttribute = null;
	private EAttribute house_typeEAttribute = null;
	private EAttribute house_addressEAttribute = null;
	
	private EEnum houseTypeEEnum = null;
	

	private VillagePackageImpl() {
		super(eNS_URI, Village.VillageFactory.eINSTANCE);
	}

	private static boolean isRegistered = false;
	private boolean isCreated = false;
	private boolean isInitialized = false;

	public static VillagePackage init() {
		if (isRegistered)
			return (VillagePackage) EPackage.Registry.INSTANCE
					.getEPackage(VillagePackage.eNS_URI);

		// Obtain or create and register package
		Object registeredVillagePackage = EPackage.Registry.INSTANCE.get(eNS_URI);
		VillagePackageImpl theVillagePackage = registeredVillagePackage instanceof VillagePackageImpl
				? (VillagePackageImpl) registeredVillagePackage
				: new VillagePackageImpl();

		isRegistered = true;

		// Create package meta-data objects
		theVillagePackage.createPackageContents();

		// Initialize created meta-data
		theVillagePackage.initializePackageContents();
		
		// Inject internal eOpposites to unidirectional references
		theVillagePackage.injectDynamicOpposites();
		
		// Inject external references into foreign packages
		theVillagePackage.injectExternalReferences();

		// Mark meta-data to indicate it can't be changed
		theVillagePackage.freeze();

		// Update the registry and return the package
		EPackage.Registry.INSTANCE.put(VillagePackage.eNS_URI,
				theVillagePackage);
				
		theVillagePackage.fetchDynamicEStructuralFeaturesOfSuperTypes();
		return theVillagePackage;
	}

	@Override
	public EClass getVillageSquare() {
		return villageSquareEClass;
	}
	@Override
	public EReference getVillageSquare_StreetCorner() {
		return villageSquare_streetCornerEReference;	
	}
	@Override
	public EClass getHouse() {
		return houseEClass;
	}
	@Override
	public EReference getHouse_NextHouse() {
		return house_nextHouseEReference;	
	}
	@Override
	public EAttribute getHouse_Name() {
		return house_nameEAttribute;	
	}
	@Override
	public EAttribute getHouse_Type() {
		return house_typeEAttribute;	
	}
	@Override
	public EAttribute getHouse_Address() {
		return house_addressEAttribute;	
	}
	
	@Override
	public EEnum getHouseType() {
		return houseTypeEEnum;
	}
	

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Village.VillageFactory getVillageFactory() {
		return (Village.VillageFactory) getEFactoryInstance();
	}

	public void createPackageContents() {
		if (isCreated)
			return;
		isCreated = true;

		// Create classes and their features
		villageSquareEClass = createEClass(VILLAGE_SQUARE);
		createEReference(villageSquareEClass, VILLAGE_SQUARE__STREET_CORNER);
		villageSquare_streetCornerEReference = (EReference) villageSquareEClass.getEStructuralFeatures().get(0);
		
		houseEClass = createEClass(HOUSE);
		createEReference(houseEClass, HOUSE__NEXT_HOUSE);
		house_nextHouseEReference = (EReference) houseEClass.getEStructuralFeatures().get(0);
		createEAttribute(houseEClass, HOUSE__NAME);
		house_nameEAttribute = (EAttribute) houseEClass.getEStructuralFeatures().get(1);
		createEAttribute(houseEClass, HOUSE__TYPE);
		house_typeEAttribute = (EAttribute) houseEClass.getEStructuralFeatures().get(2);
		createEAttribute(houseEClass, HOUSE__ADDRESS);
		house_addressEAttribute = (EAttribute) houseEClass.getEStructuralFeatures().get(3);
		
		// Create enums
		houseTypeEEnum = createEEnum(HOUSE_TYPE);
		
		// Create data types
	}

	public void initializePackageContents() {
		if (isInitialized)
			return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);
		
		// Obtain other dependent packages

		// Create type parameters

		// Set bounds for type parameters

		// Add supertypes to classes

		// Initialize classes, features, and operations; add parameters
		initEClass(villageSquareEClass, VillageSquare.class, "VillageSquare", !IS_ABSTRACT, !IS_INTERFACE,
			IS_GENERATED_INSTANCE_CLASS);
		initEReference(getVillageSquare_StreetCorner(), this.getHouse(),  null, 
			"streetCorner", null, 0, -1, VillageSquare.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
				
		initEClass(houseEClass, House.class, "House", !IS_ABSTRACT, !IS_INTERFACE,
			IS_GENERATED_INSTANCE_CLASS);
		initEReference(getHouse_NextHouse(), this.getHouse(),  null, 
			"nextHouse", null, 0, 1, House.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getHouse_Name(), ecorePackage.getEString(),
			"name", null, 0, 1, House.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, IS_ID, IS_UNIQUE,
			!IS_DERIVED, IS_ORDERED);
		initEAttribute(getHouse_Type(), this.getHouseType(),
			"type", "CORNER", 0, 1, House.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, IS_ID, IS_UNIQUE,
			!IS_DERIVED, IS_ORDERED);
		initEAttribute(getHouse_Address(), ecorePackage.getEString(),
			"address", null, 0, 1, House.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, IS_ID, IS_UNIQUE,
			!IS_DERIVED, IS_ORDERED);
		
		
		// Initialize enums and add enum literals
		initEEnum(houseTypeEEnum, HouseType.class, "HouseType");
		addEEnumLiteral(houseTypeEEnum, Village.HouseType.CORNER);
		addEEnumLiteral(houseTypeEEnum, Village.HouseType.CUBE);
		addEEnumLiteral(houseTypeEEnum, Village.HouseType.VILLA);
		
		// Initialize data types
		
		// Create resource
		createResource(eNS_URI);
	}

} 

