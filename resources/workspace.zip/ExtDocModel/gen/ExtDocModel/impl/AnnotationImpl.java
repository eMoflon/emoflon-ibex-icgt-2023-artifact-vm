package ExtDocModel.impl;

import ExtDocModel.ExtDocModelPackage;
import ExtDocModel.ExtDocModelPackage;

import org.emoflon.smartemf.runtime.*;
import org.emoflon.smartemf.runtime.collections.*;
import org.emoflon.smartemf.persistence.SmartEMFResource;
import org.emoflon.smartemf.runtime.notification.SmartEMFNotification;
import org.emoflon.smartemf.runtime.notification.NotifyStatus;

import java.util.function.Consumer;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EcoreFactory;
import org.eclipse.emf.ecore.EcorePackage;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.resource.Resource;

public class AnnotationImpl extends SmartObject implements ExtDocModel.Annotation {

    protected ExtDocModel.Entry entry = null;
    protected java.lang.String value = null;
	
	protected AnnotationImpl() {
		super(ExtDocModelPackage.Literals.ANNOTATION);
	}
	
    
    @Override
    public ExtDocModel.Entry getEntry() {
    	return this.entry;
    }
    
    @Override
    public void setEntry(ExtDocModel.Entry value) {
    	
    	Object oldValue = this.entry;
    	
    	if(value == null && oldValue == null)
    		return;
    		
    	if(value != null && value.equals(oldValue))
    		return;
    		
    	
    	
    		       	if(this.entry != null && value == null) {
    		       		resetContainmentSilently();
    		       	}
    		        this.entry = value;
    		        
    	
    	
    	        	sendNotification(SmartEMFNotification.createSetNotification(this, ExtDocModelPackage.Literals.ANNOTATION__ENTRY, oldValue, value, -1));
    	        	
    	
    	        	if(oldValue != null) {
    	        		((SmartObject) oldValue).eInverseRemove(this, ExtDocModelPackage.Literals.ENTRY__ANNOTATIONS);
    	        	}
    	        	if(value != null) {
    	        		((SmartObject) value).eInverseAdd(this, ExtDocModelPackage.Literals.ENTRY__ANNOTATIONS);
    	        	}
    }
    
    private void setEntryAsInverse(ExtDocModel.Entry value) {
			    
			    Object oldValue = this.entry;
			    
			    if(value == null && oldValue == null)
			    	return;
			    	
			    if(value != null && value.equals(oldValue))
			    	return;
			    	
			    
			    
			    	       	if(this.entry != null && value == null) {
			    	       		resetContainmentSilently();
			    	       	}
			    	        this.entry = value;
			    	        
			    
			    
			            	sendNotification(SmartEMFNotification.createSetNotification(this, ExtDocModelPackage.Literals.ANNOTATION__ENTRY, oldValue, value, -1));
			            	
    }
    
    @Override
    public java.lang.String getValue() {
    	return this.value;
    }
    
    @Override
    public void setValue(java.lang.String value) {
    	Object oldValue = this.value;
    	this.value = value;
    	
    	        	sendNotification(SmartEMFNotification.createSetNotification(this, ExtDocModelPackage.Literals.ANNOTATION__VALUE, oldValue, value, -1));
    }
    

    @Override
    public void eSet(EStructuralFeature eFeature, Object newValue){
    	if (ExtDocModelPackage.Literals.ANNOTATION__ENTRY.equals(eFeature)) {
    		setEntry((ExtDocModel.Entry) newValue); 
    		return;
    	}
    	if (ExtDocModelPackage.Literals.ANNOTATION__VALUE.equals(eFeature)) {
    		setValue((java.lang.String) newValue); 
    		return;
    	}
    	eDynamicSet(eFeature, newValue);
    }
    
    @Override
    public void eUnset(EStructuralFeature eFeature){
    	if (ExtDocModelPackage.Literals.ANNOTATION__ENTRY.equals(eFeature)) {
    		setEntry((ExtDocModel.Entry)null); 
    		return;
    	}
    	if (ExtDocModelPackage.Literals.ANNOTATION__VALUE.equals(eFeature)) {
    		setValue((java.lang.String)null); 
    		return;
    	}
    	eDynamicUnset(eFeature);
    }

    @Override
    public String toString(){
		StringBuilder b = new StringBuilder();
		b.append(super.toString());
		b.append(" (");
		if (SmartEMFConfig.simpleStringRepresentations()) {
			b.append("value: ");
			b.append(getValue());
		} else {
			b.append("value: ");
			b.append(getValue());
		}
		b.append(")");
		return b.toString();
    }

 	@Override
    public Object eGet(EStructuralFeature eFeature){
    	if (ExtDocModelPackage.Literals.ANNOTATION__ENTRY.equals(eFeature))
    		return getEntry();
    	if (ExtDocModelPackage.Literals.ANNOTATION__VALUE.equals(eFeature))
    		return getValue();
    	return eDynamicGet(eFeature);
    }

    @Override
    public Object eGet(int featureID, boolean resolve, boolean coreType){
    	throw new UnsupportedOperationException("This method has been deactivated since it is not always safe to use.");
    }
    
    @Override
    public void eInverseAdd(Object otherEnd, EStructuralFeature feature) {
if (ExtDocModelPackage.Literals.ANNOTATION__ENTRY.equals(feature)) {
setEntryAsInverse((ExtDocModel.Entry) otherEnd); 
 	return;
			        }	
	    if(feature == null)
	    	return;
	    	
    	eDynamicInverseAdd(otherEnd, feature);
	    	}
    	
    @Override
	    	public void eInverseRemove(Object otherEnd, EStructuralFeature feature) {
if (ExtDocModelPackage.Literals.ANNOTATION__ENTRY.equals(feature)) {
setEntryAsInverse(null); 
 	return;
			        }
	    if(feature == null)
	    	return;
	    		    		
    	eDynamicInverseRemove(otherEnd, feature);
	    	}
    
    @Override
    /**
    * This method sets the resource and generates REMOVING_ADAPTER and ADD notifications
    */
    protected void setResourceOfContainments(Consumer<SmartObject> setResourceCall) {
	    	}
	    	
	    	@Override
	    	/**
	    	* This method sets the resource and only generates REMOVING_ADAPTER notifications (no ADD messages)
	    	*/
    protected void setResourceOfContainmentsSilently(Resource r) { 		
	    	}
}
