package ExtType2Doc_ConcSync.impl;

import ExtType2Doc_ConcSync.ExtType2Doc_ConcSyncPackage;
import runtime.RuntimePackage;
import ExtType2Doc_ConcSync.ExtType2Doc_ConcSyncPackage;

import org.emoflon.smartemf.runtime.*;
import org.emoflon.smartemf.runtime.collections.*;
import org.emoflon.smartemf.persistence.SmartEMFResource;
import org.emoflon.smartemf.runtime.notification.SmartEMFNotification;
import org.emoflon.smartemf.runtime.notification.NotifyStatus;

import java.util.function.Consumer;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EcoreFactory;
import org.eclipse.emf.ecore.EcorePackage;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.resource.Resource;

public class Package2Folder__MarkerImpl extends SmartObject implements ExtType2Doc_ConcSync.Package2Folder__Marker {

    protected runtime.Protocol protocol = null;
    protected ExtTypeModel.Package CREATE__SRC__p = null;
    protected ExtTypeModel.Project CONTEXT__SRC__pr = null;
    protected ExtDocModel.DocContainer CONTEXT__TRG__dc = null;
    protected ExtDocModel.Folder CREATE__TRG__f = null;
    protected ExtType2Doc_ConcSync.Package2Folder CREATE__CORR__p2f = null;
    protected ExtType2Doc_ConcSync.Project2DocContainer CONTEXT__CORR__pr2dc = null;
	
	protected Package2Folder__MarkerImpl() {
		super(ExtType2Doc_ConcSyncPackage.Literals.PACKAGE2_FOLDER___MARKER);
	}
	
    
    @Override
    public runtime.Protocol getProtocol() {
    	return this.protocol;
    }
    
    @Override
    public void setProtocol(runtime.Protocol value) {
    	
    	Object oldValue = this.protocol;
    	
    	if(value == null && oldValue == null)
    		return;
    		
    	if(value != null && value.equals(oldValue))
    		return;
    		
    	
    	
    		       	if(this.protocol != null && value == null) {
    		       		resetContainmentSilently();
    		       	}
    		        this.protocol = value;
    		        
    	
    	
    	        	sendNotification(SmartEMFNotification.createSetNotification(this, RuntimePackage.Literals.TGG_RULE_APPLICATION__PROTOCOL, oldValue, value, -1));
    	        	
    	
    	        	if(oldValue != null) {
    	        		((SmartObject) oldValue).eInverseRemove(this, RuntimePackage.Literals.PROTOCOL__STEPS);
    	        	}
    	        	if(value != null) {
    	        		((SmartObject) value).eInverseAdd(this, RuntimePackage.Literals.PROTOCOL__STEPS);
    	        	}
    }
    
    private void setProtocolAsInverse(runtime.Protocol value) {
			    
			    Object oldValue = this.protocol;
			    
			    if(value == null && oldValue == null)
			    	return;
			    	
			    if(value != null && value.equals(oldValue))
			    	return;
			    	
			    
			    
			    	       	if(this.protocol != null && value == null) {
			    	       		resetContainmentSilently();
			    	       	}
			    	        this.protocol = value;
			    	        
			    
			    
			            	sendNotification(SmartEMFNotification.createSetNotification(this, RuntimePackage.Literals.TGG_RULE_APPLICATION__PROTOCOL, oldValue, value, -1));
			            	
    }
    
    @Override
    public ExtTypeModel.Package getCREATE__SRC__p() {
    	return this.CREATE__SRC__p;
    }
    
    @Override
    public void setCREATE__SRC__p(ExtTypeModel.Package value) {
    	
    	Object oldValue = this.CREATE__SRC__p;
    	
    	if(value == null && oldValue == null)
    		return;
    		
    	if(value != null && value.equals(oldValue))
    		return;
    		
    	
    	
    		        this.CREATE__SRC__p = value;
    		        
    	
    	
    	        	sendNotification(SmartEMFNotification.createSetNotification(this, ExtType2Doc_ConcSyncPackage.Literals.PACKAGE2_FOLDER___MARKER__CREAT_E__SR_C__P, oldValue, value, -1));
    	        	
    	        	if(ExtType2Doc_ConcSyncPackage.Literals.PACKAGE2_FOLDER___MARKER__CREAT_E__SR_C__P.getEOpposite() != null) {
    	        		if(oldValue != null) {
    	        			((SmartObject) oldValue).eInverseRemove(this, ExtType2Doc_ConcSyncPackage.Literals.PACKAGE2_FOLDER___MARKER__CREAT_E__SR_C__P.getEOpposite());
    	        		}
    	        		if(value != null) {
    	        		    ((SmartObject) value).eInverseAdd(this, ExtType2Doc_ConcSyncPackage.Literals.PACKAGE2_FOLDER___MARKER__CREAT_E__SR_C__P.getEOpposite());
    	        		}
    	        	}
    }
    
    
    @Override
    public ExtTypeModel.Project getCONTEXT__SRC__pr() {
    	return this.CONTEXT__SRC__pr;
    }
    
    @Override
    public void setCONTEXT__SRC__pr(ExtTypeModel.Project value) {
    	
    	Object oldValue = this.CONTEXT__SRC__pr;
    	
    	if(value == null && oldValue == null)
    		return;
    		
    	if(value != null && value.equals(oldValue))
    		return;
    		
    	
    	
    		        this.CONTEXT__SRC__pr = value;
    		        
    	
    	
    	        	sendNotification(SmartEMFNotification.createSetNotification(this, ExtType2Doc_ConcSyncPackage.Literals.PACKAGE2_FOLDER___MARKER__CONTEX_T__SR_C__PR, oldValue, value, -1));
    	        	
    	        	if(ExtType2Doc_ConcSyncPackage.Literals.PACKAGE2_FOLDER___MARKER__CONTEX_T__SR_C__PR.getEOpposite() != null) {
    	        		if(oldValue != null) {
    	        			((SmartObject) oldValue).eInverseRemove(this, ExtType2Doc_ConcSyncPackage.Literals.PACKAGE2_FOLDER___MARKER__CONTEX_T__SR_C__PR.getEOpposite());
    	        		}
    	        		if(value != null) {
    	        		    ((SmartObject) value).eInverseAdd(this, ExtType2Doc_ConcSyncPackage.Literals.PACKAGE2_FOLDER___MARKER__CONTEX_T__SR_C__PR.getEOpposite());
    	        		}
    	        	}
    }
    
    
    @Override
    public ExtDocModel.DocContainer getCONTEXT__TRG__dc() {
    	return this.CONTEXT__TRG__dc;
    }
    
    @Override
    public void setCONTEXT__TRG__dc(ExtDocModel.DocContainer value) {
    	
    	Object oldValue = this.CONTEXT__TRG__dc;
    	
    	if(value == null && oldValue == null)
    		return;
    		
    	if(value != null && value.equals(oldValue))
    		return;
    		
    	
    	
    		        this.CONTEXT__TRG__dc = value;
    		        
    	
    	
    	        	sendNotification(SmartEMFNotification.createSetNotification(this, ExtType2Doc_ConcSyncPackage.Literals.PACKAGE2_FOLDER___MARKER__CONTEX_T__TR_G__DC, oldValue, value, -1));
    	        	
    	        	if(ExtType2Doc_ConcSyncPackage.Literals.PACKAGE2_FOLDER___MARKER__CONTEX_T__TR_G__DC.getEOpposite() != null) {
    	        		if(oldValue != null) {
    	        			((SmartObject) oldValue).eInverseRemove(this, ExtType2Doc_ConcSyncPackage.Literals.PACKAGE2_FOLDER___MARKER__CONTEX_T__TR_G__DC.getEOpposite());
    	        		}
    	        		if(value != null) {
    	        		    ((SmartObject) value).eInverseAdd(this, ExtType2Doc_ConcSyncPackage.Literals.PACKAGE2_FOLDER___MARKER__CONTEX_T__TR_G__DC.getEOpposite());
    	        		}
    	        	}
    }
    
    
    @Override
    public ExtDocModel.Folder getCREATE__TRG__f() {
    	return this.CREATE__TRG__f;
    }
    
    @Override
    public void setCREATE__TRG__f(ExtDocModel.Folder value) {
    	
    	Object oldValue = this.CREATE__TRG__f;
    	
    	if(value == null && oldValue == null)
    		return;
    		
    	if(value != null && value.equals(oldValue))
    		return;
    		
    	
    	
    		        this.CREATE__TRG__f = value;
    		        
    	
    	
    	        	sendNotification(SmartEMFNotification.createSetNotification(this, ExtType2Doc_ConcSyncPackage.Literals.PACKAGE2_FOLDER___MARKER__CREAT_E__TR_G__F, oldValue, value, -1));
    	        	
    	        	if(ExtType2Doc_ConcSyncPackage.Literals.PACKAGE2_FOLDER___MARKER__CREAT_E__TR_G__F.getEOpposite() != null) {
    	        		if(oldValue != null) {
    	        			((SmartObject) oldValue).eInverseRemove(this, ExtType2Doc_ConcSyncPackage.Literals.PACKAGE2_FOLDER___MARKER__CREAT_E__TR_G__F.getEOpposite());
    	        		}
    	        		if(value != null) {
    	        		    ((SmartObject) value).eInverseAdd(this, ExtType2Doc_ConcSyncPackage.Literals.PACKAGE2_FOLDER___MARKER__CREAT_E__TR_G__F.getEOpposite());
    	        		}
    	        	}
    }
    
    
    @Override
    public ExtType2Doc_ConcSync.Package2Folder getCREATE__CORR__p2f() {
    	return this.CREATE__CORR__p2f;
    }
    
    @Override
    public void setCREATE__CORR__p2f(ExtType2Doc_ConcSync.Package2Folder value) {
    	
    	Object oldValue = this.CREATE__CORR__p2f;
    	
    	if(value == null && oldValue == null)
    		return;
    		
    	if(value != null && value.equals(oldValue))
    		return;
    		
    	
    	
    		        this.CREATE__CORR__p2f = value;
    		        
    	
    	
    	        	sendNotification(SmartEMFNotification.createSetNotification(this, ExtType2Doc_ConcSyncPackage.Literals.PACKAGE2_FOLDER___MARKER__CREAT_E__COR_R__P2F, oldValue, value, -1));
    	        	
    	        	if(ExtType2Doc_ConcSyncPackage.Literals.PACKAGE2_FOLDER___MARKER__CREAT_E__COR_R__P2F.getEOpposite() != null) {
    	        		if(oldValue != null) {
    	        			((SmartObject) oldValue).eInverseRemove(this, ExtType2Doc_ConcSyncPackage.Literals.PACKAGE2_FOLDER___MARKER__CREAT_E__COR_R__P2F.getEOpposite());
    	        		}
    	        		if(value != null) {
    	        		    ((SmartObject) value).eInverseAdd(this, ExtType2Doc_ConcSyncPackage.Literals.PACKAGE2_FOLDER___MARKER__CREAT_E__COR_R__P2F.getEOpposite());
    	        		}
    	        	}
    }
    
    
    @Override
    public ExtType2Doc_ConcSync.Project2DocContainer getCONTEXT__CORR__pr2dc() {
    	return this.CONTEXT__CORR__pr2dc;
    }
    
    @Override
    public void setCONTEXT__CORR__pr2dc(ExtType2Doc_ConcSync.Project2DocContainer value) {
    	
    	Object oldValue = this.CONTEXT__CORR__pr2dc;
    	
    	if(value == null && oldValue == null)
    		return;
    		
    	if(value != null && value.equals(oldValue))
    		return;
    		
    	
    	
    		        this.CONTEXT__CORR__pr2dc = value;
    		        
    	
    	
    	        	sendNotification(SmartEMFNotification.createSetNotification(this, ExtType2Doc_ConcSyncPackage.Literals.PACKAGE2_FOLDER___MARKER__CONTEX_T__COR_R__PR2DC, oldValue, value, -1));
    	        	
    	        	if(ExtType2Doc_ConcSyncPackage.Literals.PACKAGE2_FOLDER___MARKER__CONTEX_T__COR_R__PR2DC.getEOpposite() != null) {
    	        		if(oldValue != null) {
    	        			((SmartObject) oldValue).eInverseRemove(this, ExtType2Doc_ConcSyncPackage.Literals.PACKAGE2_FOLDER___MARKER__CONTEX_T__COR_R__PR2DC.getEOpposite());
    	        		}
    	        		if(value != null) {
    	        		    ((SmartObject) value).eInverseAdd(this, ExtType2Doc_ConcSyncPackage.Literals.PACKAGE2_FOLDER___MARKER__CONTEX_T__COR_R__PR2DC.getEOpposite());
    	        		}
    	        	}
    }
    

    @Override
    public void eSet(EStructuralFeature eFeature, Object newValue){
    	if (RuntimePackage.Literals.TGG_RULE_APPLICATION__PROTOCOL.equals(eFeature)) {
    		setProtocol((runtime.Protocol) newValue); 
    		return;
    	}
    	if (ExtType2Doc_ConcSyncPackage.Literals.PACKAGE2_FOLDER___MARKER__CREAT_E__SR_C__P.equals(eFeature)) {
    		setCREATE__SRC__p((ExtTypeModel.Package) newValue); 
    		return;
    	}
    	if (ExtType2Doc_ConcSyncPackage.Literals.PACKAGE2_FOLDER___MARKER__CONTEX_T__SR_C__PR.equals(eFeature)) {
    		setCONTEXT__SRC__pr((ExtTypeModel.Project) newValue); 
    		return;
    	}
    	if (ExtType2Doc_ConcSyncPackage.Literals.PACKAGE2_FOLDER___MARKER__CONTEX_T__TR_G__DC.equals(eFeature)) {
    		setCONTEXT__TRG__dc((ExtDocModel.DocContainer) newValue); 
    		return;
    	}
    	if (ExtType2Doc_ConcSyncPackage.Literals.PACKAGE2_FOLDER___MARKER__CREAT_E__TR_G__F.equals(eFeature)) {
    		setCREATE__TRG__f((ExtDocModel.Folder) newValue); 
    		return;
    	}
    	if (ExtType2Doc_ConcSyncPackage.Literals.PACKAGE2_FOLDER___MARKER__CREAT_E__COR_R__P2F.equals(eFeature)) {
    		setCREATE__CORR__p2f((ExtType2Doc_ConcSync.Package2Folder) newValue); 
    		return;
    	}
    	if (ExtType2Doc_ConcSyncPackage.Literals.PACKAGE2_FOLDER___MARKER__CONTEX_T__COR_R__PR2DC.equals(eFeature)) {
    		setCONTEXT__CORR__pr2dc((ExtType2Doc_ConcSync.Project2DocContainer) newValue); 
    		return;
    	}
    	eDynamicSet(eFeature, newValue);
    }
    
    @Override
    public void eUnset(EStructuralFeature eFeature){
    	if (RuntimePackage.Literals.TGG_RULE_APPLICATION__PROTOCOL.equals(eFeature)) {
    		setProtocol((runtime.Protocol)null); 
    		return;
    	}
    	if (ExtType2Doc_ConcSyncPackage.Literals.PACKAGE2_FOLDER___MARKER__CREAT_E__SR_C__P.equals(eFeature)) {
    		setCREATE__SRC__p((ExtTypeModel.Package)null); 
    		return;
    	}
    	if (ExtType2Doc_ConcSyncPackage.Literals.PACKAGE2_FOLDER___MARKER__CONTEX_T__SR_C__PR.equals(eFeature)) {
    		setCONTEXT__SRC__pr((ExtTypeModel.Project)null); 
    		return;
    	}
    	if (ExtType2Doc_ConcSyncPackage.Literals.PACKAGE2_FOLDER___MARKER__CONTEX_T__TR_G__DC.equals(eFeature)) {
    		setCONTEXT__TRG__dc((ExtDocModel.DocContainer)null); 
    		return;
    	}
    	if (ExtType2Doc_ConcSyncPackage.Literals.PACKAGE2_FOLDER___MARKER__CREAT_E__TR_G__F.equals(eFeature)) {
    		setCREATE__TRG__f((ExtDocModel.Folder)null); 
    		return;
    	}
    	if (ExtType2Doc_ConcSyncPackage.Literals.PACKAGE2_FOLDER___MARKER__CREAT_E__COR_R__P2F.equals(eFeature)) {
    		setCREATE__CORR__p2f((ExtType2Doc_ConcSync.Package2Folder)null); 
    		return;
    	}
    	if (ExtType2Doc_ConcSyncPackage.Literals.PACKAGE2_FOLDER___MARKER__CONTEX_T__COR_R__PR2DC.equals(eFeature)) {
    		setCONTEXT__CORR__pr2dc((ExtType2Doc_ConcSync.Project2DocContainer)null); 
    		return;
    	}
    	eDynamicUnset(eFeature);
    }

    @Override
    public String toString(){
		return super.toString();
    }

 	@Override
    public Object eGet(EStructuralFeature eFeature){
    	if (RuntimePackage.Literals.TGG_RULE_APPLICATION__PROTOCOL.equals(eFeature))
    		return getProtocol();
    	if (ExtType2Doc_ConcSyncPackage.Literals.PACKAGE2_FOLDER___MARKER__CREAT_E__SR_C__P.equals(eFeature))
    		return getCREATE__SRC__p();
    	if (ExtType2Doc_ConcSyncPackage.Literals.PACKAGE2_FOLDER___MARKER__CONTEX_T__SR_C__PR.equals(eFeature))
    		return getCONTEXT__SRC__pr();
    	if (ExtType2Doc_ConcSyncPackage.Literals.PACKAGE2_FOLDER___MARKER__CONTEX_T__TR_G__DC.equals(eFeature))
    		return getCONTEXT__TRG__dc();
    	if (ExtType2Doc_ConcSyncPackage.Literals.PACKAGE2_FOLDER___MARKER__CREAT_E__TR_G__F.equals(eFeature))
    		return getCREATE__TRG__f();
    	if (ExtType2Doc_ConcSyncPackage.Literals.PACKAGE2_FOLDER___MARKER__CREAT_E__COR_R__P2F.equals(eFeature))
    		return getCREATE__CORR__p2f();
    	if (ExtType2Doc_ConcSyncPackage.Literals.PACKAGE2_FOLDER___MARKER__CONTEX_T__COR_R__PR2DC.equals(eFeature))
    		return getCONTEXT__CORR__pr2dc();
    	return eDynamicGet(eFeature);
    }

    @Override
    public Object eGet(int featureID, boolean resolve, boolean coreType){
    	throw new UnsupportedOperationException("This method has been deactivated since it is not always safe to use.");
    }
    
    @Override
    public void eInverseAdd(Object otherEnd, EStructuralFeature feature) {
if (RuntimePackage.Literals.TGG_RULE_APPLICATION__PROTOCOL.equals(feature)) {
setProtocolAsInverse((runtime.Protocol) otherEnd); 
 	return;
			        }	
	    if(feature == null)
	    	return;
	    	
    	eDynamicInverseAdd(otherEnd, feature);
	    	}
    	
    @Override
	    	public void eInverseRemove(Object otherEnd, EStructuralFeature feature) {
if (RuntimePackage.Literals.TGG_RULE_APPLICATION__PROTOCOL.equals(feature)) {
setProtocolAsInverse(null); 
 	return;
			        }
	    if(feature == null)
	    	return;
	    		    		
    	eDynamicInverseRemove(otherEnd, feature);
	    	}
    
    @Override
    /**
    * This method sets the resource and generates REMOVING_ADAPTER and ADD notifications
    */
    protected void setResourceOfContainments(Consumer<SmartObject> setResourceCall) {
	    	}
	    	
	    	@Override
	    	/**
	    	* This method sets the resource and only generates REMOVING_ADAPTER notifications (no ADD messages)
	    	*/
    protected void setResourceOfContainmentsSilently(Resource r) { 		
	    	}
}
