package ExtType2Doc_LookAhead.integrate.hipe.engine;

import akka.actor.ActorRef;
import akka.actor.Props;

import ExtType2Doc_LookAhead.integrate.hipe.engine.actor.NotificationActor;
import ExtType2Doc_LookAhead.integrate.hipe.engine.actor.DispatchActor;
import ExtType2Doc_LookAhead.integrate.hipe.engine.actor.localsearch.ExtendingType2Doc__TRG_1_localSearch;
import ExtType2Doc_LookAhead.integrate.hipe.engine.actor.localsearch.ExtendingType2Doc__BWD_5_localSearch;
import ExtType2Doc_LookAhead.integrate.hipe.engine.actor.localsearch.ExtendingType2Doc__SRC_10_localSearch;
import ExtType2Doc_LookAhead.integrate.hipe.engine.actor.localsearch.ExtendingType2Doc__FWD_14_localSearch;
import ExtType2Doc_LookAhead.integrate.hipe.engine.actor.localsearch.ExtendingType2Doc__CONSISTENCY_19_localSearch;
import ExtType2Doc_LookAhead.integrate.hipe.engine.actor.localsearch.Field2Entry__TRG_22_localSearch;
import ExtType2Doc_LookAhead.integrate.hipe.engine.actor.localsearch.Field2Entry__BWD_25_localSearch;
import ExtType2Doc_LookAhead.integrate.hipe.engine.actor.localsearch.Field2Entry__SRC_28_localSearch;
import ExtType2Doc_LookAhead.integrate.hipe.engine.actor.localsearch.Field2Entry__FWD_31_localSearch;
import ExtType2Doc_LookAhead.integrate.hipe.engine.actor.localsearch.Field2Entry__CONSISTENCY_34_localSearch;
import ExtType2Doc_LookAhead.integrate.hipe.engine.actor.localsearch.ImplementingType2Doc__TRG_37_localSearch;
import ExtType2Doc_LookAhead.integrate.hipe.engine.actor.localsearch.ImplementingType2Doc__BWD_40_localSearch;
import ExtType2Doc_LookAhead.integrate.hipe.engine.actor.localsearch.ImplementingType2Doc__SRC_45_localSearch;
import ExtType2Doc_LookAhead.integrate.hipe.engine.actor.localsearch.ImplementingType2Doc__FWD_48_localSearch;
import ExtType2Doc_LookAhead.integrate.hipe.engine.actor.localsearch.ImplementingType2Doc__CONSISTENCY_53_localSearch;
import ExtType2Doc_LookAhead.integrate.hipe.engine.actor.localsearch.Method2Entry__TRG_55_localSearch;
import ExtType2Doc_LookAhead.integrate.hipe.engine.actor.localsearch.Method2Entry__BWD_58_localSearch;
import ExtType2Doc_LookAhead.integrate.hipe.engine.actor.localsearch.Method2Entry__SRC_61_localSearch;
import ExtType2Doc_LookAhead.integrate.hipe.engine.actor.localsearch.Method2Entry__FWD_64_localSearch;
import ExtType2Doc_LookAhead.integrate.hipe.engine.actor.localsearch.Method2Entry__CONSISTENCY_67_localSearch;
import ExtType2Doc_LookAhead.integrate.hipe.engine.actor.localsearch.Package2Folder_f_superFolder_outgoing_TRG__FILTER_NAC_TRG_70_localSearch;
import ExtType2Doc_LookAhead.integrate.hipe.engine.actor.localsearch.Package2Folder_p_superPackage_outgoing_SRC__FILTER_NAC_SRC_75_localSearch;
import ExtType2Doc_LookAhead.integrate.hipe.engine.actor.localsearch.Package2Folder__CONSISTENCY_80_localSearch;
import ExtType2Doc_LookAhead.integrate.hipe.engine.actor.localsearch.Param2Entry__SRC_83_localSearch;
import ExtType2Doc_LookAhead.integrate.hipe.engine.actor.localsearch.Param2Entry__FWD_86_localSearch;
import ExtType2Doc_LookAhead.integrate.hipe.engine.actor.localsearch.Param2Entry__CONSISTENCY_89_localSearch;
import ExtType2Doc_LookAhead.integrate.hipe.engine.actor.localsearch.SubPackage2Folder__TRG_92_localSearch;
import ExtType2Doc_LookAhead.integrate.hipe.engine.actor.localsearch.SubPackage2Folder__BWD_95_localSearch;
import ExtType2Doc_LookAhead.integrate.hipe.engine.actor.localsearch.SubPackage2Folder__SRC_98_localSearch;
import ExtType2Doc_LookAhead.integrate.hipe.engine.actor.localsearch.SubPackage2Folder__FWD_101_localSearch;
import ExtType2Doc_LookAhead.integrate.hipe.engine.actor.localsearch.SubPackage2Folder__CONSISTENCY_104_localSearch;
import ExtType2Doc_LookAhead.integrate.hipe.engine.actor.localsearch.Type2Doc__TRG_107_localSearch;
import ExtType2Doc_LookAhead.integrate.hipe.engine.actor.localsearch.Type2Doc__BWD_110_localSearch;
import ExtType2Doc_LookAhead.integrate.hipe.engine.actor.localsearch.Type2Doc__SRC_113_localSearch;
import ExtType2Doc_LookAhead.integrate.hipe.engine.actor.localsearch.Type2Doc__FWD_116_localSearch;
import ExtType2Doc_LookAhead.integrate.hipe.engine.actor.localsearch.Type2Doc__CONSISTENCY_119_localSearch;

import hipe.engine.IHiPEEngine;
import hipe.engine.message.InitGenReferenceActor;

import hipe.generic.actor.GenericObjectActor;
import hipe.generic.actor.GenericReferenceActor;
import hipe.generic.actor.GenericProductionActor;
import hipe.generic.actor.junction.*;

import hipe.network.*;

public class HiPEEngine extends IHiPEEngine{
	
	public HiPEEngine(HiPENetwork network) {
		super(network);
	}
	
	public HiPEEngine() {
		super();
	}
	
	@Override
	public String getClassLocation() {
		return getClass().getProtectionDomain().getCodeSource().getLocation().getPath().toString();
	}
	
	@Override
	public String getPackageName() {
		return getClass().getPackageName();
	}
	
	@Override
	protected ActorRef getDispatchActor() {
		return system.actorOf(
			Props.create(DispatchActor.class, () -> new DispatchActor(name2actor, incUtil)),
			"DispatchActor");
	}
	
	@Override
	protected ActorRef getNotificationActor(boolean cascadingNotifications) {
		return system.actorOf(
			Props.create(NotificationActor.class, () -> new NotificationActor(dispatcher, incUtil, cascadingNotifications)), 
			"NotificationActor");
	}
	
	@Override
	public void createProductionNodes() {
		classes.put("ExtendingType2Doc__BWD_production", GenericProductionActor.class);
		productionNodes2pattern.put("ExtendingType2Doc__BWD_production", "ExtendingType2Doc__BWD");
		classes.put("ExtendingType2Doc__CONSISTENCY_production", GenericProductionActor.class);
		productionNodes2pattern.put("ExtendingType2Doc__CONSISTENCY_production", "ExtendingType2Doc__CONSISTENCY");
		classes.put("ExtendingType2Doc__FWD_production", GenericProductionActor.class);
		productionNodes2pattern.put("ExtendingType2Doc__FWD_production", "ExtendingType2Doc__FWD");
		classes.put("ExtendingType2Doc__SRC_production", GenericProductionActor.class);
		productionNodes2pattern.put("ExtendingType2Doc__SRC_production", "ExtendingType2Doc__SRC");
		classes.put("ExtendingType2Doc__TRG_production", GenericProductionActor.class);
		productionNodes2pattern.put("ExtendingType2Doc__TRG_production", "ExtendingType2Doc__TRG");
		classes.put("Field2Entry__BWD_production", GenericProductionActor.class);
		productionNodes2pattern.put("Field2Entry__BWD_production", "Field2Entry__BWD");
		classes.put("Field2Entry__CONSISTENCY_production", GenericProductionActor.class);
		productionNodes2pattern.put("Field2Entry__CONSISTENCY_production", "Field2Entry__CONSISTENCY");
		classes.put("Field2Entry__FWD_production", GenericProductionActor.class);
		productionNodes2pattern.put("Field2Entry__FWD_production", "Field2Entry__FWD");
		classes.put("Field2Entry__SRC_production", GenericProductionActor.class);
		productionNodes2pattern.put("Field2Entry__SRC_production", "Field2Entry__SRC");
		classes.put("Field2Entry__TRG_production", GenericProductionActor.class);
		productionNodes2pattern.put("Field2Entry__TRG_production", "Field2Entry__TRG");
		classes.put("ImplementingType2Doc__BWD_production", GenericProductionActor.class);
		productionNodes2pattern.put("ImplementingType2Doc__BWD_production", "ImplementingType2Doc__BWD");
		classes.put("ImplementingType2Doc__CONSISTENCY_production", GenericProductionActor.class);
		productionNodes2pattern.put("ImplementingType2Doc__CONSISTENCY_production", "ImplementingType2Doc__CONSISTENCY");
		classes.put("ImplementingType2Doc__FWD_production", GenericProductionActor.class);
		productionNodes2pattern.put("ImplementingType2Doc__FWD_production", "ImplementingType2Doc__FWD");
		classes.put("ImplementingType2Doc__SRC_production", GenericProductionActor.class);
		productionNodes2pattern.put("ImplementingType2Doc__SRC_production", "ImplementingType2Doc__SRC");
		classes.put("ImplementingType2Doc__TRG_production", GenericProductionActor.class);
		productionNodes2pattern.put("ImplementingType2Doc__TRG_production", "ImplementingType2Doc__TRG");
		classes.put("Method2Entry__BWD_production", GenericProductionActor.class);
		productionNodes2pattern.put("Method2Entry__BWD_production", "Method2Entry__BWD");
		classes.put("Method2Entry__CONSISTENCY_production", GenericProductionActor.class);
		productionNodes2pattern.put("Method2Entry__CONSISTENCY_production", "Method2Entry__CONSISTENCY");
		classes.put("Method2Entry__FWD_production", GenericProductionActor.class);
		productionNodes2pattern.put("Method2Entry__FWD_production", "Method2Entry__FWD");
		classes.put("Method2Entry__SRC_production", GenericProductionActor.class);
		productionNodes2pattern.put("Method2Entry__SRC_production", "Method2Entry__SRC");
		classes.put("Method2Entry__TRG_production", GenericProductionActor.class);
		productionNodes2pattern.put("Method2Entry__TRG_production", "Method2Entry__TRG");
		classes.put("Package2Folder__BWD_production", GenericProductionActor.class);
		productionNodes2pattern.put("Package2Folder__BWD_production", "Package2Folder__BWD");
		classes.put("Package2Folder__CONSISTENCY_production", GenericProductionActor.class);
		productionNodes2pattern.put("Package2Folder__CONSISTENCY_production", "Package2Folder__CONSISTENCY");
		classes.put("Package2Folder__FWD_production", GenericProductionActor.class);
		productionNodes2pattern.put("Package2Folder__FWD_production", "Package2Folder__FWD");
		classes.put("Package2Folder_f_superFolder_outgoing_TRG__FILTER_NAC_TRG_production", GenericProductionActor.class);
		productionNodes2pattern.put("Package2Folder_f_superFolder_outgoing_TRG__FILTER_NAC_TRG_production", "Package2Folder_f_superFolder_outgoing_TRG__FILTER_NAC_TRG");
		classes.put("Package2Folder_p_superPackage_outgoing_SRC__FILTER_NAC_SRC_production", GenericProductionActor.class);
		productionNodes2pattern.put("Package2Folder_p_superPackage_outgoing_SRC__FILTER_NAC_SRC_production", "Package2Folder_p_superPackage_outgoing_SRC__FILTER_NAC_SRC");
		classes.put("Param2Entry__CONSISTENCY_production", GenericProductionActor.class);
		productionNodes2pattern.put("Param2Entry__CONSISTENCY_production", "Param2Entry__CONSISTENCY");
		classes.put("Param2Entry__FWD_production", GenericProductionActor.class);
		productionNodes2pattern.put("Param2Entry__FWD_production", "Param2Entry__FWD");
		classes.put("Param2Entry__SRC_production", GenericProductionActor.class);
		productionNodes2pattern.put("Param2Entry__SRC_production", "Param2Entry__SRC");
		classes.put("SubPackage2Folder__BWD_production", GenericProductionActor.class);
		productionNodes2pattern.put("SubPackage2Folder__BWD_production", "SubPackage2Folder__BWD");
		classes.put("SubPackage2Folder__CONSISTENCY_production", GenericProductionActor.class);
		productionNodes2pattern.put("SubPackage2Folder__CONSISTENCY_production", "SubPackage2Folder__CONSISTENCY");
		classes.put("SubPackage2Folder__FWD_production", GenericProductionActor.class);
		productionNodes2pattern.put("SubPackage2Folder__FWD_production", "SubPackage2Folder__FWD");
		classes.put("SubPackage2Folder__SRC_production", GenericProductionActor.class);
		productionNodes2pattern.put("SubPackage2Folder__SRC_production", "SubPackage2Folder__SRC");
		classes.put("SubPackage2Folder__TRG_production", GenericProductionActor.class);
		productionNodes2pattern.put("SubPackage2Folder__TRG_production", "SubPackage2Folder__TRG");
		classes.put("Type2Doc__BWD_production", GenericProductionActor.class);
		productionNodes2pattern.put("Type2Doc__BWD_production", "Type2Doc__BWD");
		classes.put("Type2Doc__CONSISTENCY_production", GenericProductionActor.class);
		productionNodes2pattern.put("Type2Doc__CONSISTENCY_production", "Type2Doc__CONSISTENCY");
		classes.put("Type2Doc__FWD_production", GenericProductionActor.class);
		productionNodes2pattern.put("Type2Doc__FWD_production", "Type2Doc__FWD");
		classes.put("Type2Doc__SRC_production", GenericProductionActor.class);
		productionNodes2pattern.put("Type2Doc__SRC_production", "Type2Doc__SRC");
		classes.put("Type2Doc__TRG_production", GenericProductionActor.class);
		productionNodes2pattern.put("Type2Doc__TRG_production", "Type2Doc__TRG");
		
	}
	
	@Override
	public void createJunctionNodes() {
		classes.put("ExtendingType2Doc__TRG_1_localSearch", ExtendingType2Doc__TRG_1_localSearch.class);
		classes.put("ExtendingType2Doc__BWD_5_localSearch", ExtendingType2Doc__BWD_5_localSearch.class);
		classes.put("ExtendingType2Doc__SRC_10_localSearch", ExtendingType2Doc__SRC_10_localSearch.class);
		classes.put("ExtendingType2Doc__FWD_14_localSearch", ExtendingType2Doc__FWD_14_localSearch.class);
		classes.put("ExtendingType2Doc__CONSISTENCY_19_localSearch", ExtendingType2Doc__CONSISTENCY_19_localSearch.class);
		classes.put("Field2Entry__TRG_22_localSearch", Field2Entry__TRG_22_localSearch.class);
		classes.put("Field2Entry__BWD_25_localSearch", Field2Entry__BWD_25_localSearch.class);
		classes.put("Field2Entry__SRC_28_localSearch", Field2Entry__SRC_28_localSearch.class);
		classes.put("Field2Entry__FWD_31_localSearch", Field2Entry__FWD_31_localSearch.class);
		classes.put("Field2Entry__CONSISTENCY_34_localSearch", Field2Entry__CONSISTENCY_34_localSearch.class);
		classes.put("ImplementingType2Doc__TRG_37_localSearch", ImplementingType2Doc__TRG_37_localSearch.class);
		classes.put("ImplementingType2Doc__BWD_40_localSearch", ImplementingType2Doc__BWD_40_localSearch.class);
		classes.put("ImplementingType2Doc__SRC_45_localSearch", ImplementingType2Doc__SRC_45_localSearch.class);
		classes.put("ImplementingType2Doc__FWD_48_localSearch", ImplementingType2Doc__FWD_48_localSearch.class);
		classes.put("ImplementingType2Doc__CONSISTENCY_53_localSearch", ImplementingType2Doc__CONSISTENCY_53_localSearch.class);
		classes.put("Method2Entry__TRG_55_localSearch", Method2Entry__TRG_55_localSearch.class);
		classes.put("Method2Entry__BWD_58_localSearch", Method2Entry__BWD_58_localSearch.class);
		classes.put("Method2Entry__SRC_61_localSearch", Method2Entry__SRC_61_localSearch.class);
		classes.put("Method2Entry__FWD_64_localSearch", Method2Entry__FWD_64_localSearch.class);
		classes.put("Method2Entry__CONSISTENCY_67_localSearch", Method2Entry__CONSISTENCY_67_localSearch.class);
		classes.put("Package2Folder_f_superFolder_outgoing_TRG__FILTER_NAC_TRG_70_localSearch", Package2Folder_f_superFolder_outgoing_TRG__FILTER_NAC_TRG_70_localSearch.class);
		classes.put("Package2Folder__BWD_73_nacjunction", GenericNACJunctionActor.class);
		classes.put("Package2Folder_p_superPackage_outgoing_SRC__FILTER_NAC_SRC_75_localSearch", Package2Folder_p_superPackage_outgoing_SRC__FILTER_NAC_SRC_75_localSearch.class);
		classes.put("Package2Folder__FWD_78_nacjunction", GenericNACJunctionActor.class);
		classes.put("Package2Folder__CONSISTENCY_80_localSearch", Package2Folder__CONSISTENCY_80_localSearch.class);
		classes.put("Param2Entry__SRC_83_localSearch", Param2Entry__SRC_83_localSearch.class);
		classes.put("Param2Entry__FWD_86_localSearch", Param2Entry__FWD_86_localSearch.class);
		classes.put("Param2Entry__CONSISTENCY_89_localSearch", Param2Entry__CONSISTENCY_89_localSearch.class);
		classes.put("SubPackage2Folder__TRG_92_localSearch", SubPackage2Folder__TRG_92_localSearch.class);
		classes.put("SubPackage2Folder__BWD_95_localSearch", SubPackage2Folder__BWD_95_localSearch.class);
		classes.put("SubPackage2Folder__SRC_98_localSearch", SubPackage2Folder__SRC_98_localSearch.class);
		classes.put("SubPackage2Folder__FWD_101_localSearch", SubPackage2Folder__FWD_101_localSearch.class);
		classes.put("SubPackage2Folder__CONSISTENCY_104_localSearch", SubPackage2Folder__CONSISTENCY_104_localSearch.class);
		classes.put("Type2Doc__TRG_107_localSearch", Type2Doc__TRG_107_localSearch.class);
		classes.put("Type2Doc__BWD_110_localSearch", Type2Doc__BWD_110_localSearch.class);
		classes.put("Type2Doc__SRC_113_localSearch", Type2Doc__SRC_113_localSearch.class);
		classes.put("Type2Doc__FWD_116_localSearch", Type2Doc__FWD_116_localSearch.class);
		classes.put("Type2Doc__CONSISTENCY_119_localSearch", Type2Doc__CONSISTENCY_119_localSearch.class);
	}
	
	@Override
	public void createReferenceNodes() {
		
	}
	
	@Override
	public void createObjectNodes() {
		classes.put("ExtendingType2Doc__Marker_object",ExtendingType2Doc__Marker_object.class);
		classes.put("Entry_object",Entry_object.class);
		classes.put("Field2Entry_object",Field2Entry_object.class);
		classes.put("Field2Entry__Marker_object",Field2Entry__Marker_object.class);
		classes.put("Field_object",Field_object.class);
		classes.put("ImplementingType2Doc__Marker_object",ImplementingType2Doc__Marker_object.class);
		classes.put("Method2Entry_object",Method2Entry_object.class);
		classes.put("Method2Entry__Marker_object",Method2Entry__Marker_object.class);
		classes.put("Method_object",Method_object.class);
		classes.put("Package2Folder__Marker_object",Package2Folder__Marker_object.class);
		classes.put("Param2Entry_object",Param2Entry_object.class);
		classes.put("Param2Entry__Marker_object",Param2Entry__Marker_object.class);
		classes.put("Parameter_object",Parameter_object.class);
		classes.put("SubPackage2Folder__Marker_object",SubPackage2Folder__Marker_object.class);
		classes.put("Type2Doc__Marker_object",Type2Doc__Marker_object.class);
		classes.put("Package_object_SP0",Package_object_SP0.class);
		classes.put("Package_object_SP1",Package_object_SP1.class);
		classes.put("Package2Folder_object_SP0",Package2Folder_object_SP0.class);
		classes.put("Package2Folder_object_SP1",Package2Folder_object_SP1.class);
		classes.put("Type_object_SP0",Type_object_SP0.class);
		classes.put("Type_object_SP1",Type_object_SP1.class);
		classes.put("Type_object_SP2",Type_object_SP2.class);
		classes.put("Type2Doc_object_SP0",Type2Doc_object_SP0.class);
		classes.put("Type2Doc_object_SP1",Type2Doc_object_SP1.class);
		classes.put("Type2Doc_object_SP2",Type2Doc_object_SP2.class);
		classes.put("Doc_object_SP0",Doc_object_SP0.class);
		classes.put("Doc_object_SP1",Doc_object_SP1.class);
		classes.put("Doc_object_SP2",Doc_object_SP2.class);
		classes.put("Folder_object_SP0",Folder_object_SP0.class);
		classes.put("Folder_object_SP1",Folder_object_SP1.class);
		
	}
	
	@Override
	public void initializeReferenceNodes() {
	}
}

class ExtendingType2Doc__Marker_object extends GenericObjectActor<ExtType2Doc_LookAhead.ExtendingType2Doc__Marker> { }
class Entry_object extends GenericObjectActor<ExtDocModel.Entry> { }
class Field2Entry_object extends GenericObjectActor<ExtType2Doc_LookAhead.Field2Entry> { }
class Field2Entry__Marker_object extends GenericObjectActor<ExtType2Doc_LookAhead.Field2Entry__Marker> { }
class Field_object extends GenericObjectActor<ExtTypeModel.Field> { }
class ImplementingType2Doc__Marker_object extends GenericObjectActor<ExtType2Doc_LookAhead.ImplementingType2Doc__Marker> { }
class Method2Entry_object extends GenericObjectActor<ExtType2Doc_LookAhead.Method2Entry> { }
class Method2Entry__Marker_object extends GenericObjectActor<ExtType2Doc_LookAhead.Method2Entry__Marker> { }
class Method_object extends GenericObjectActor<ExtTypeModel.Method> { }
class Package2Folder__Marker_object extends GenericObjectActor<ExtType2Doc_LookAhead.Package2Folder__Marker> { }
class Param2Entry_object extends GenericObjectActor<ExtType2Doc_LookAhead.Param2Entry> { }
class Param2Entry__Marker_object extends GenericObjectActor<ExtType2Doc_LookAhead.Param2Entry__Marker> { }
class Parameter_object extends GenericObjectActor<ExtTypeModel.Parameter> { }
class SubPackage2Folder__Marker_object extends GenericObjectActor<ExtType2Doc_LookAhead.SubPackage2Folder__Marker> { }
class Type2Doc__Marker_object extends GenericObjectActor<ExtType2Doc_LookAhead.Type2Doc__Marker> { }
class Package_object_SP0 extends GenericObjectActor<ExtTypeModel.Package> { }
class Package_object_SP1 extends GenericObjectActor<ExtTypeModel.Package> { }
class Package2Folder_object_SP0 extends GenericObjectActor<ExtType2Doc_LookAhead.Package2Folder> { }
class Package2Folder_object_SP1 extends GenericObjectActor<ExtType2Doc_LookAhead.Package2Folder> { }
class Type_object_SP0 extends GenericObjectActor<ExtTypeModel.Type> { }
class Type_object_SP1 extends GenericObjectActor<ExtTypeModel.Type> { }
class Type_object_SP2 extends GenericObjectActor<ExtTypeModel.Type> { }
class Type2Doc_object_SP0 extends GenericObjectActor<ExtType2Doc_LookAhead.Type2Doc> { }
class Type2Doc_object_SP1 extends GenericObjectActor<ExtType2Doc_LookAhead.Type2Doc> { }
class Type2Doc_object_SP2 extends GenericObjectActor<ExtType2Doc_LookAhead.Type2Doc> { }
class Doc_object_SP0 extends GenericObjectActor<ExtDocModel.Doc> { }
class Doc_object_SP1 extends GenericObjectActor<ExtDocModel.Doc> { }
class Doc_object_SP2 extends GenericObjectActor<ExtDocModel.Doc> { }
class Folder_object_SP0 extends GenericObjectActor<ExtDocModel.Folder> { }
class Folder_object_SP1 extends GenericObjectActor<ExtDocModel.Folder> { }


