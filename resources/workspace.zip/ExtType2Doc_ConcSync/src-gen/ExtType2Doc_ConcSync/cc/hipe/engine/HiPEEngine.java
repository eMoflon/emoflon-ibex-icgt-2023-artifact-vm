package ExtType2Doc_ConcSync.cc.hipe.engine;

import akka.actor.ActorRef;
import akka.actor.Props;

import ExtType2Doc_ConcSync.cc.hipe.engine.actor.NotificationActor;
import ExtType2Doc_ConcSync.cc.hipe.engine.actor.DispatchActor;
import ExtType2Doc_ConcSync.cc.hipe.engine.actor.localsearch.ExtendingType2Doc_nt_inheritsFrom_outgoing_SRC__FILTER_NAC_SRC_1_localSearch;
import ExtType2Doc_ConcSync.cc.hipe.engine.actor.localsearch.ExtendingType2Doc_nd_superDocs_outgoing_TRG__FILTER_NAC_TRG_5_localSearch;
import ExtType2Doc_ConcSync.cc.hipe.engine.actor.localsearch.ExtendingType2Doc__CC_9_localSearch;
import ExtType2Doc_ConcSync.cc.hipe.engine.actor.localsearch.Field2Entry__CC_18_localSearch;
import ExtType2Doc_ConcSync.cc.hipe.engine.actor.localsearch.GlossaryEntry__CC_24_localSearch;
import ExtType2Doc_ConcSync.cc.hipe.engine.actor.localsearch.GlossaryLink__CC_27_localSearch;
import ExtType2Doc_ConcSync.cc.hipe.engine.actor.localsearch.Glossary__CC_30_localSearch;
import ExtType2Doc_ConcSync.cc.hipe.engine.actor.localsearch.JDoc2Annotation__CC_33_localSearch;
import ExtType2Doc_ConcSync.cc.hipe.engine.actor.localsearch.Method2Entry__CC_39_localSearch;
import ExtType2Doc_ConcSync.cc.hipe.engine.actor.localsearch.Package2Folder__CC_45_localSearch;
import ExtType2Doc_ConcSync.cc.hipe.engine.actor.localsearch.Param2Entry__CC_51_localSearch;
import ExtType2Doc_ConcSync.cc.hipe.engine.actor.localsearch.Type2Doc_t_inheritsFrom_outgoing_SRC__FILTER_NAC_SRC_59_localSearch;
import ExtType2Doc_ConcSync.cc.hipe.engine.actor.localsearch.Type2Doc_d_superDocs_outgoing_TRG__FILTER_NAC_TRG_62_localSearch;
import ExtType2Doc_ConcSync.cc.hipe.engine.actor.localsearch.Type2Doc__CC_65_localSearch;

import hipe.engine.IHiPEEngine;
import hipe.engine.message.InitGenReferenceActor;

import hipe.generic.actor.GenericObjectActor;
import hipe.generic.actor.GenericReferenceActor;
import hipe.generic.actor.GenericProductionActor;
import hipe.generic.actor.junction.*;

import hipe.network.*;

public class HiPEEngine extends IHiPEEngine{
	
	public HiPEEngine(HiPENetwork network) {
		super(network);
	}
	
	public HiPEEngine() {
		super();
	}
	
	@Override
	public String getClassLocation() {
		return getClass().getProtectionDomain().getCodeSource().getLocation().getPath().toString();
	}
	
	@Override
	public String getPackageName() {
		return getClass().getPackageName();
	}
	
	@Override
	protected ActorRef getDispatchActor() {
		return system.actorOf(
			Props.create(DispatchActor.class, () -> new DispatchActor(name2actor, incUtil)),
			"DispatchActor");
	}
	
	@Override
	protected ActorRef getNotificationActor(boolean cascadingNotifications) {
		return system.actorOf(
			Props.create(NotificationActor.class, () -> new NotificationActor(dispatcher, incUtil, cascadingNotifications)), 
			"NotificationActor");
	}
	
	@Override
	public void createProductionNodes() {
		classes.put("ExtendingType2Doc__CC_production", GenericProductionActor.class);
		productionNodes2pattern.put("ExtendingType2Doc__CC_production", "ExtendingType2Doc__CC");
		classes.put("ExtendingType2Doc_nd_superDocs_outgoing_TRG__FILTER_NAC_TRG_production", GenericProductionActor.class);
		productionNodes2pattern.put("ExtendingType2Doc_nd_superDocs_outgoing_TRG__FILTER_NAC_TRG_production", "ExtendingType2Doc_nd_superDocs_outgoing_TRG__FILTER_NAC_TRG");
		classes.put("ExtendingType2Doc_nt_inheritsFrom_outgoing_SRC__FILTER_NAC_SRC_production", GenericProductionActor.class);
		productionNodes2pattern.put("ExtendingType2Doc_nt_inheritsFrom_outgoing_SRC__FILTER_NAC_SRC_production", "ExtendingType2Doc_nt_inheritsFrom_outgoing_SRC__FILTER_NAC_SRC");
		classes.put("Field2Entry__CC_production", GenericProductionActor.class);
		productionNodes2pattern.put("Field2Entry__CC_production", "Field2Entry__CC");
		classes.put("GlossaryEntry__CC_production", GenericProductionActor.class);
		productionNodes2pattern.put("GlossaryEntry__CC_production", "GlossaryEntry__CC");
		classes.put("GlossaryLink__CC_production", GenericProductionActor.class);
		productionNodes2pattern.put("GlossaryLink__CC_production", "GlossaryLink__CC");
		classes.put("Glossary__CC_production", GenericProductionActor.class);
		productionNodes2pattern.put("Glossary__CC_production", "Glossary__CC");
		classes.put("JDoc2Annotation__CC_production", GenericProductionActor.class);
		productionNodes2pattern.put("JDoc2Annotation__CC_production", "JDoc2Annotation__CC");
		classes.put("Method2Entry__CC_production", GenericProductionActor.class);
		productionNodes2pattern.put("Method2Entry__CC_production", "Method2Entry__CC");
		classes.put("Package2Folder__CC_production", GenericProductionActor.class);
		productionNodes2pattern.put("Package2Folder__CC_production", "Package2Folder__CC");
		classes.put("Param2Entry__CC_production", GenericProductionActor.class);
		productionNodes2pattern.put("Param2Entry__CC_production", "Param2Entry__CC");
		classes.put("Project2DocCont__CC_production", GenericProductionActor.class);
		productionNodes2pattern.put("Project2DocCont__CC_production", "Project2DocCont__CC");
		classes.put("Type2Doc__CC_production", GenericProductionActor.class);
		productionNodes2pattern.put("Type2Doc__CC_production", "Type2Doc__CC");
		classes.put("Type2Doc_d_superDocs_outgoing_TRG__FILTER_NAC_TRG_production", GenericProductionActor.class);
		productionNodes2pattern.put("Type2Doc_d_superDocs_outgoing_TRG__FILTER_NAC_TRG_production", "Type2Doc_d_superDocs_outgoing_TRG__FILTER_NAC_TRG");
		classes.put("Type2Doc_t_inheritsFrom_outgoing_SRC__FILTER_NAC_SRC_production", GenericProductionActor.class);
		productionNodes2pattern.put("Type2Doc_t_inheritsFrom_outgoing_SRC__FILTER_NAC_SRC_production", "Type2Doc_t_inheritsFrom_outgoing_SRC__FILTER_NAC_SRC");
		
	}
	
	@Override
	public void createJunctionNodes() {
		classes.put("ExtendingType2Doc_nt_inheritsFrom_outgoing_SRC__FILTER_NAC_SRC_1_localSearch", ExtendingType2Doc_nt_inheritsFrom_outgoing_SRC__FILTER_NAC_SRC_1_localSearch.class);
		classes.put("ExtendingType2Doc_nd_superDocs_outgoing_TRG__FILTER_NAC_TRG_5_localSearch", ExtendingType2Doc_nd_superDocs_outgoing_TRG__FILTER_NAC_TRG_5_localSearch.class);
		classes.put("ExtendingType2Doc__CC_9_localSearch", ExtendingType2Doc__CC_9_localSearch.class);
		classes.put("Field2Entry__CC_18_localSearch", Field2Entry__CC_18_localSearch.class);
		classes.put("GlossaryEntry__CC_24_localSearch", GlossaryEntry__CC_24_localSearch.class);
		classes.put("GlossaryLink__CC_27_localSearch", GlossaryLink__CC_27_localSearch.class);
		classes.put("Glossary__CC_30_localSearch", Glossary__CC_30_localSearch.class);
		classes.put("JDoc2Annotation__CC_33_localSearch", JDoc2Annotation__CC_33_localSearch.class);
		classes.put("Method2Entry__CC_39_localSearch", Method2Entry__CC_39_localSearch.class);
		classes.put("Package2Folder__CC_45_localSearch", Package2Folder__CC_45_localSearch.class);
		classes.put("Param2Entry__CC_51_localSearch", Param2Entry__CC_51_localSearch.class);
		classes.put("Project2DocCont__CC_56_junction", GenericJunctionActor.class);
		classes.put("Type2Doc_t_inheritsFrom_outgoing_SRC__FILTER_NAC_SRC_59_localSearch", Type2Doc_t_inheritsFrom_outgoing_SRC__FILTER_NAC_SRC_59_localSearch.class);
		classes.put("Type2Doc_d_superDocs_outgoing_TRG__FILTER_NAC_TRG_62_localSearch", Type2Doc_d_superDocs_outgoing_TRG__FILTER_NAC_TRG_62_localSearch.class);
		classes.put("Type2Doc__CC_65_localSearch", Type2Doc__CC_65_localSearch.class);
	}
	
	@Override
	public void createReferenceNodes() {
		
	}
	
	@Override
	public void createObjectNodes() {
		classes.put("Folder_object",Folder_object.class);
		classes.put("Package_object",Package_object.class);
		classes.put("Package2Folder_object",Package2Folder_object.class);
		classes.put("Type2Doc_object",Type2Doc_object.class);
		classes.put("Field_object",Field_object.class);
		classes.put("GlossaryEntry_object",GlossaryEntry_object.class);
		classes.put("Glossary_object",Glossary_object.class);
		classes.put("DocContainer_object",DocContainer_object.class);
		classes.put("Method_object",Method_object.class);
		classes.put("Method2Entry_object",Method2Entry_object.class);
		classes.put("JavaDoc_object",JavaDoc_object.class);
		classes.put("Annotation_object",Annotation_object.class);
		classes.put("Project_object",Project_object.class);
		classes.put("Project2DocContainer_object",Project2DocContainer_object.class);
		classes.put("Parameter_object",Parameter_object.class);
		classes.put("Doc_object_SP0",Doc_object_SP0.class);
		classes.put("Doc_object_SP1",Doc_object_SP1.class);
		classes.put("Type_object_SP0",Type_object_SP0.class);
		classes.put("Type_object_SP1",Type_object_SP1.class);
		classes.put("Entry_object_SP0",Entry_object_SP0.class);
		classes.put("Entry_object_SP1",Entry_object_SP1.class);
		
	}
	
	@Override
	public void initializeReferenceNodes() {
	}
}

class Folder_object extends GenericObjectActor<ExtDocModel.Folder> { }
class Package_object extends GenericObjectActor<ExtTypeModel.Package> { }
class Package2Folder_object extends GenericObjectActor<ExtType2Doc_ConcSync.Package2Folder> { }
class Type2Doc_object extends GenericObjectActor<ExtType2Doc_ConcSync.Type2Doc> { }
class Field_object extends GenericObjectActor<ExtTypeModel.Field> { }
class GlossaryEntry_object extends GenericObjectActor<ExtDocModel.GlossaryEntry> { }
class Glossary_object extends GenericObjectActor<ExtDocModel.Glossary> { }
class DocContainer_object extends GenericObjectActor<ExtDocModel.DocContainer> { }
class Method_object extends GenericObjectActor<ExtTypeModel.Method> { }
class Method2Entry_object extends GenericObjectActor<ExtType2Doc_ConcSync.Method2Entry> { }
class JavaDoc_object extends GenericObjectActor<ExtTypeModel.JavaDoc> { }
class Annotation_object extends GenericObjectActor<ExtDocModel.Annotation> { }
class Project_object extends GenericObjectActor<ExtTypeModel.Project> { }
class Project2DocContainer_object extends GenericObjectActor<ExtType2Doc_ConcSync.Project2DocContainer> { }
class Parameter_object extends GenericObjectActor<ExtTypeModel.Parameter> { }
class Doc_object_SP0 extends GenericObjectActor<ExtDocModel.Doc> { }
class Doc_object_SP1 extends GenericObjectActor<ExtDocModel.Doc> { }
class Type_object_SP0 extends GenericObjectActor<ExtTypeModel.Type> { }
class Type_object_SP1 extends GenericObjectActor<ExtTypeModel.Type> { }
class Entry_object_SP0 extends GenericObjectActor<ExtDocModel.Entry> { }
class Entry_object_SP1 extends GenericObjectActor<ExtDocModel.Entry> { }


