package org.emoflon.ibex.neo.benchmark.village2constrplan;

public enum RepairMode {
	NONE, LEGACY, PG_BASED
}
