package org.benchmarx.extDocModel.core;

import ExtDocModel.Doc;
import org.benchmarx.util.Normalizer;

@SuppressWarnings("all")
public class DocNormalizer extends Normalizer<Doc> {
  @Override
  public int compare(final Doc o1, final Doc o2) {
    return o1.getName().compareTo(o2.getName());
  }
}
