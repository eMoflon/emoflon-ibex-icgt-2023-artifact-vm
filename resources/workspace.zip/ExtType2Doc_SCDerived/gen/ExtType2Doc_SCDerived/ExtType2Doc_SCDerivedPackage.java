package ExtType2Doc_SCDerived;

import java.lang.String;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.ecore.EEnum;


import org.emoflon.smartemf.runtime.SmartPackage;

public interface ExtType2Doc_SCDerivedPackage extends SmartPackage {

	String eNAME = "ExtType2Doc_SCDerived";
	String eNS_URI = "platform:/resource/ExtType2Doc_SCDerived/model/ExtType2Doc_SCDerived.ecore";
	String eNS_PREFIX = "ExtType2Doc_SCDerived";

	ExtType2Doc_SCDerivedPackage eINSTANCE = ExtType2Doc_SCDerived.impl.ExtType2Doc_SCDerivedPackageImpl.init();

	int PROJECT2_DOC_CONTAINER = 0;
	int PROJECT2_DOC_CONTAINER__SOURCE = 0;
	int PROJECT2_DOC_CONTAINER__TARGET = 1;
	int PROJECT2_DOC_CONTAINER_FEATURE_COUNT = 2;
	int PROJECT2_DOC_CONTAINER_OPERATION_COUNT = 0;
	
	int PACKAGE2_FOLDER = 1;
	int PACKAGE2_FOLDER__SOURCE = 2;
	int PACKAGE2_FOLDER__TARGET = 3;
	int PACKAGE2_FOLDER_FEATURE_COUNT = 2;
	int PACKAGE2_FOLDER_OPERATION_COUNT = 0;
	
	int TYPE2_DOC = 2;
	int TYPE2_DOC__SOURCE = 4;
	int TYPE2_DOC__TARGET = 5;
	int TYPE2_DOC_FEATURE_COUNT = 2;
	int TYPE2_DOC_OPERATION_COUNT = 0;
	
	int METHOD2_ENTRY = 3;
	int METHOD2_ENTRY__SOURCE = 6;
	int METHOD2_ENTRY__TARGET = 7;
	int METHOD2_ENTRY_FEATURE_COUNT = 2;
	int METHOD2_ENTRY_OPERATION_COUNT = 0;
	
	int PARAM2_ENTRY = 4;
	int PARAM2_ENTRY__SOURCE = 8;
	int PARAM2_ENTRY__TARGET = 9;
	int PARAM2_ENTRY_FEATURE_COUNT = 2;
	int PARAM2_ENTRY_OPERATION_COUNT = 0;
	
	int FIELD2_ENTRY = 5;
	int FIELD2_ENTRY__SOURCE = 10;
	int FIELD2_ENTRY__TARGET = 11;
	int FIELD2_ENTRY_FEATURE_COUNT = 2;
	int FIELD2_ENTRY_OPERATION_COUNT = 0;
	
	int EXTENDING_TYPE2_DOC___MARKER = 6;
	int EXTENDING_TYPE2_DOC___MARKER__CREAT_E__SR_C__NT = 12;
	int EXTENDING_TYPE2_DOC___MARKER__CONTEX_T__SR_C__P = 13;
	int EXTENDING_TYPE2_DOC___MARKER__CONTEX_T__SR_C__T = 14;
	int EXTENDING_TYPE2_DOC___MARKER__CONTEX_T__TR_G__D = 15;
	int EXTENDING_TYPE2_DOC___MARKER__CONTEX_T__TR_G__F = 16;
	int EXTENDING_TYPE2_DOC___MARKER__CREAT_E__TR_G__ND = 17;
	int EXTENDING_TYPE2_DOC___MARKER__CREAT_E__COR_R__NT2ND = 18;
	int EXTENDING_TYPE2_DOC___MARKER__CONTEX_T__COR_R__P2F = 19;
	int EXTENDING_TYPE2_DOC___MARKER__CONTEX_T__COR_R__T2D = 20;
	int EXTENDING_TYPE2_DOC___MARKER_FEATURE_COUNT = 10;
	int EXTENDING_TYPE2_DOC___MARKER_OPERATION_COUNT = 0;
	
	int FIELD2_ENTRY___MARKER = 7;
	int FIELD2_ENTRY___MARKER__CREAT_E__SR_C__F = 21;
	int FIELD2_ENTRY___MARKER__CONTEX_T__SR_C__T = 22;
	int FIELD2_ENTRY___MARKER__CONTEX_T__TR_G__D = 23;
	int FIELD2_ENTRY___MARKER__CREAT_E__TR_G__E = 24;
	int FIELD2_ENTRY___MARKER__CREAT_E__COR_R__F2E = 25;
	int FIELD2_ENTRY___MARKER__CONTEX_T__COR_R__T2D = 26;
	int FIELD2_ENTRY___MARKER_FEATURE_COUNT = 7;
	int FIELD2_ENTRY___MARKER_OPERATION_COUNT = 0;
	
	int METHOD2_ENTRY___MARKER = 8;
	int METHOD2_ENTRY___MARKER__CREAT_E__SR_C__M = 27;
	int METHOD2_ENTRY___MARKER__CONTEX_T__SR_C__T = 28;
	int METHOD2_ENTRY___MARKER__CONTEX_T__TR_G__D = 29;
	int METHOD2_ENTRY___MARKER__CREAT_E__TR_G__E = 30;
	int METHOD2_ENTRY___MARKER__CREAT_E__COR_R__M2E = 31;
	int METHOD2_ENTRY___MARKER__CONTEX_T__COR_R__T2D = 32;
	int METHOD2_ENTRY___MARKER_FEATURE_COUNT = 7;
	int METHOD2_ENTRY___MARKER_OPERATION_COUNT = 0;
	
	int PACKAGE2_FOLDER___MARKER = 9;
	int PACKAGE2_FOLDER___MARKER__CREAT_E__SR_C__P = 33;
	int PACKAGE2_FOLDER___MARKER__CONTEX_T__SR_C__PR = 34;
	int PACKAGE2_FOLDER___MARKER__CONTEX_T__TR_G__DC = 35;
	int PACKAGE2_FOLDER___MARKER__CREAT_E__TR_G__F = 36;
	int PACKAGE2_FOLDER___MARKER__CREAT_E__COR_R__P2F = 37;
	int PACKAGE2_FOLDER___MARKER__CONTEX_T__COR_R__PR2DC = 38;
	int PACKAGE2_FOLDER___MARKER_FEATURE_COUNT = 7;
	int PACKAGE2_FOLDER___MARKER_OPERATION_COUNT = 0;
	
	int PARAM2_ENTRY___MARKER = 10;
	int PARAM2_ENTRY___MARKER__CONTEX_T__SR_C__M = 39;
	int PARAM2_ENTRY___MARKER__CREAT_E__SR_C__P = 40;
	int PARAM2_ENTRY___MARKER__CONTEX_T__TR_G__E = 41;
	int PARAM2_ENTRY___MARKER__CONTEX_T__COR_R__M2E = 42;
	int PARAM2_ENTRY___MARKER__CREAT_E__COR_R__P2E = 43;
	int PARAM2_ENTRY___MARKER_FEATURE_COUNT = 6;
	int PARAM2_ENTRY___MARKER_OPERATION_COUNT = 0;
	
	int PROJECT2_DOC_CONT___MARKER = 11;
	int PROJECT2_DOC_CONT___MARKER__CREAT_E__SR_C__PR = 44;
	int PROJECT2_DOC_CONT___MARKER__CREAT_E__TR_G__DC = 45;
	int PROJECT2_DOC_CONT___MARKER__CREAT_E__COR_R__PR2DC = 46;
	int PROJECT2_DOC_CONT___MARKER_FEATURE_COUNT = 4;
	int PROJECT2_DOC_CONT___MARKER_OPERATION_COUNT = 0;
	
	int SUB_PACKAGE2_FOLDER___MARKER = 12;
	int SUB_PACKAGE2_FOLDER___MARKER__CONTEX_T__SR_C__P = 47;
	int SUB_PACKAGE2_FOLDER___MARKER__CREAT_E__SR_C__SP = 48;
	int SUB_PACKAGE2_FOLDER___MARKER__CONTEX_T__TR_G__F = 49;
	int SUB_PACKAGE2_FOLDER___MARKER__CONTEX_T__COR_R__P2F = 50;
	int SUB_PACKAGE2_FOLDER___MARKER__CREAT_E__COR_R__SP2F = 51;
	int SUB_PACKAGE2_FOLDER___MARKER_FEATURE_COUNT = 6;
	int SUB_PACKAGE2_FOLDER___MARKER_OPERATION_COUNT = 0;
	
	int TYPE2_DOC___MARKER = 13;
	int TYPE2_DOC___MARKER__CONTEX_T__SR_C__P = 52;
	int TYPE2_DOC___MARKER__CREAT_E__SR_C__T = 53;
	int TYPE2_DOC___MARKER__CREAT_E__TR_G__D = 54;
	int TYPE2_DOC___MARKER__CONTEX_T__TR_G__F = 55;
	int TYPE2_DOC___MARKER__CONTEX_T__COR_R__P2DC = 56;
	int TYPE2_DOC___MARKER__CREAT_E__COR_R__T2D = 57;
	int TYPE2_DOC___MARKER_FEATURE_COUNT = 7;
	int TYPE2_DOC___MARKER_OPERATION_COUNT = 0;
	
	

	EClass getProject2DocContainer();
	EReference getProject2DocContainer_Source();
	EReference getProject2DocContainer_Target();
	
	EClass getPackage2Folder();
	EReference getPackage2Folder_Source();
	EReference getPackage2Folder_Target();
	
	EClass getType2Doc();
	EReference getType2Doc_Source();
	EReference getType2Doc_Target();
	
	EClass getMethod2Entry();
	EReference getMethod2Entry_Source();
	EReference getMethod2Entry_Target();
	
	EClass getParam2Entry();
	EReference getParam2Entry_Source();
	EReference getParam2Entry_Target();
	
	EClass getField2Entry();
	EReference getField2Entry_Source();
	EReference getField2Entry_Target();
	
	EClass getExtendingType2Doc__Marker();
	EReference getExtendingType2Doc__Marker_CREATE__SRC__nt();
	EReference getExtendingType2Doc__Marker_CONTEXT__SRC__p();
	EReference getExtendingType2Doc__Marker_CONTEXT__SRC__t();
	EReference getExtendingType2Doc__Marker_CONTEXT__TRG__d();
	EReference getExtendingType2Doc__Marker_CONTEXT__TRG__f();
	EReference getExtendingType2Doc__Marker_CREATE__TRG__nd();
	EReference getExtendingType2Doc__Marker_CREATE__CORR__nt2nd();
	EReference getExtendingType2Doc__Marker_CONTEXT__CORR__p2f();
	EReference getExtendingType2Doc__Marker_CONTEXT__CORR__t2d();
	
	EClass getField2Entry__Marker();
	EReference getField2Entry__Marker_CREATE__SRC__f();
	EReference getField2Entry__Marker_CONTEXT__SRC__t();
	EReference getField2Entry__Marker_CONTEXT__TRG__d();
	EReference getField2Entry__Marker_CREATE__TRG__e();
	EReference getField2Entry__Marker_CREATE__CORR__f2e();
	EReference getField2Entry__Marker_CONTEXT__CORR__t2d();
	
	EClass getMethod2Entry__Marker();
	EReference getMethod2Entry__Marker_CREATE__SRC__m();
	EReference getMethod2Entry__Marker_CONTEXT__SRC__t();
	EReference getMethod2Entry__Marker_CONTEXT__TRG__d();
	EReference getMethod2Entry__Marker_CREATE__TRG__e();
	EReference getMethod2Entry__Marker_CREATE__CORR__m2e();
	EReference getMethod2Entry__Marker_CONTEXT__CORR__t2d();
	
	EClass getPackage2Folder__Marker();
	EReference getPackage2Folder__Marker_CREATE__SRC__p();
	EReference getPackage2Folder__Marker_CONTEXT__SRC__pr();
	EReference getPackage2Folder__Marker_CONTEXT__TRG__dc();
	EReference getPackage2Folder__Marker_CREATE__TRG__f();
	EReference getPackage2Folder__Marker_CREATE__CORR__p2f();
	EReference getPackage2Folder__Marker_CONTEXT__CORR__pr2dc();
	
	EClass getParam2Entry__Marker();
	EReference getParam2Entry__Marker_CONTEXT__SRC__m();
	EReference getParam2Entry__Marker_CREATE__SRC__p();
	EReference getParam2Entry__Marker_CONTEXT__TRG__e();
	EReference getParam2Entry__Marker_CONTEXT__CORR__m2e();
	EReference getParam2Entry__Marker_CREATE__CORR__p2e();
	
	EClass getProject2DocCont__Marker();
	EReference getProject2DocCont__Marker_CREATE__SRC__pr();
	EReference getProject2DocCont__Marker_CREATE__TRG__dc();
	EReference getProject2DocCont__Marker_CREATE__CORR__pr2dc();
	
	EClass getSubPackage2Folder__Marker();
	EReference getSubPackage2Folder__Marker_CONTEXT__SRC__p();
	EReference getSubPackage2Folder__Marker_CREATE__SRC__sp();
	EReference getSubPackage2Folder__Marker_CONTEXT__TRG__f();
	EReference getSubPackage2Folder__Marker_CONTEXT__CORR__p2f();
	EReference getSubPackage2Folder__Marker_CREATE__CORR__sp2f();
	
	EClass getType2Doc__Marker();
	EReference getType2Doc__Marker_CONTEXT__SRC__p();
	EReference getType2Doc__Marker_CREATE__SRC__t();
	EReference getType2Doc__Marker_CREATE__TRG__d();
	EReference getType2Doc__Marker_CONTEXT__TRG__f();
	EReference getType2Doc__Marker_CONTEXT__CORR__p2dc();
	EReference getType2Doc__Marker_CREATE__CORR__t2d();
	
	
	ExtType2Doc_SCDerived.ExtType2Doc_SCDerivedFactory getExtType2Doc_SCDerivedFactory();

	interface Literals {
		
		EClass PROJECT2_DOC_CONTAINER = eINSTANCE.getProject2DocContainer();
		
		EReference PROJECT2_DOC_CONTAINER__SOURCE = eINSTANCE.getProject2DocContainer_Source();
		
		EReference PROJECT2_DOC_CONTAINER__TARGET = eINSTANCE.getProject2DocContainer_Target();
		
		EClass PACKAGE2_FOLDER = eINSTANCE.getPackage2Folder();
		
		EReference PACKAGE2_FOLDER__SOURCE = eINSTANCE.getPackage2Folder_Source();
		
		EReference PACKAGE2_FOLDER__TARGET = eINSTANCE.getPackage2Folder_Target();
		
		EClass TYPE2_DOC = eINSTANCE.getType2Doc();
		
		EReference TYPE2_DOC__SOURCE = eINSTANCE.getType2Doc_Source();
		
		EReference TYPE2_DOC__TARGET = eINSTANCE.getType2Doc_Target();
		
		EClass METHOD2_ENTRY = eINSTANCE.getMethod2Entry();
		
		EReference METHOD2_ENTRY__SOURCE = eINSTANCE.getMethod2Entry_Source();
		
		EReference METHOD2_ENTRY__TARGET = eINSTANCE.getMethod2Entry_Target();
		
		EClass PARAM2_ENTRY = eINSTANCE.getParam2Entry();
		
		EReference PARAM2_ENTRY__SOURCE = eINSTANCE.getParam2Entry_Source();
		
		EReference PARAM2_ENTRY__TARGET = eINSTANCE.getParam2Entry_Target();
		
		EClass FIELD2_ENTRY = eINSTANCE.getField2Entry();
		
		EReference FIELD2_ENTRY__SOURCE = eINSTANCE.getField2Entry_Source();
		
		EReference FIELD2_ENTRY__TARGET = eINSTANCE.getField2Entry_Target();
		
		EClass EXTENDING_TYPE2_DOC___MARKER = eINSTANCE.getExtendingType2Doc__Marker();
		
		EReference EXTENDING_TYPE2_DOC___MARKER__CREAT_E__SR_C__NT = eINSTANCE.getExtendingType2Doc__Marker_CREATE__SRC__nt();
		
		EReference EXTENDING_TYPE2_DOC___MARKER__CONTEX_T__SR_C__P = eINSTANCE.getExtendingType2Doc__Marker_CONTEXT__SRC__p();
		
		EReference EXTENDING_TYPE2_DOC___MARKER__CONTEX_T__SR_C__T = eINSTANCE.getExtendingType2Doc__Marker_CONTEXT__SRC__t();
		
		EReference EXTENDING_TYPE2_DOC___MARKER__CONTEX_T__TR_G__D = eINSTANCE.getExtendingType2Doc__Marker_CONTEXT__TRG__d();
		
		EReference EXTENDING_TYPE2_DOC___MARKER__CONTEX_T__TR_G__F = eINSTANCE.getExtendingType2Doc__Marker_CONTEXT__TRG__f();
		
		EReference EXTENDING_TYPE2_DOC___MARKER__CREAT_E__TR_G__ND = eINSTANCE.getExtendingType2Doc__Marker_CREATE__TRG__nd();
		
		EReference EXTENDING_TYPE2_DOC___MARKER__CREAT_E__COR_R__NT2ND = eINSTANCE.getExtendingType2Doc__Marker_CREATE__CORR__nt2nd();
		
		EReference EXTENDING_TYPE2_DOC___MARKER__CONTEX_T__COR_R__P2F = eINSTANCE.getExtendingType2Doc__Marker_CONTEXT__CORR__p2f();
		
		EReference EXTENDING_TYPE2_DOC___MARKER__CONTEX_T__COR_R__T2D = eINSTANCE.getExtendingType2Doc__Marker_CONTEXT__CORR__t2d();
		
		EClass FIELD2_ENTRY___MARKER = eINSTANCE.getField2Entry__Marker();
		
		EReference FIELD2_ENTRY___MARKER__CREAT_E__SR_C__F = eINSTANCE.getField2Entry__Marker_CREATE__SRC__f();
		
		EReference FIELD2_ENTRY___MARKER__CONTEX_T__SR_C__T = eINSTANCE.getField2Entry__Marker_CONTEXT__SRC__t();
		
		EReference FIELD2_ENTRY___MARKER__CONTEX_T__TR_G__D = eINSTANCE.getField2Entry__Marker_CONTEXT__TRG__d();
		
		EReference FIELD2_ENTRY___MARKER__CREAT_E__TR_G__E = eINSTANCE.getField2Entry__Marker_CREATE__TRG__e();
		
		EReference FIELD2_ENTRY___MARKER__CREAT_E__COR_R__F2E = eINSTANCE.getField2Entry__Marker_CREATE__CORR__f2e();
		
		EReference FIELD2_ENTRY___MARKER__CONTEX_T__COR_R__T2D = eINSTANCE.getField2Entry__Marker_CONTEXT__CORR__t2d();
		
		EClass METHOD2_ENTRY___MARKER = eINSTANCE.getMethod2Entry__Marker();
		
		EReference METHOD2_ENTRY___MARKER__CREAT_E__SR_C__M = eINSTANCE.getMethod2Entry__Marker_CREATE__SRC__m();
		
		EReference METHOD2_ENTRY___MARKER__CONTEX_T__SR_C__T = eINSTANCE.getMethod2Entry__Marker_CONTEXT__SRC__t();
		
		EReference METHOD2_ENTRY___MARKER__CONTEX_T__TR_G__D = eINSTANCE.getMethod2Entry__Marker_CONTEXT__TRG__d();
		
		EReference METHOD2_ENTRY___MARKER__CREAT_E__TR_G__E = eINSTANCE.getMethod2Entry__Marker_CREATE__TRG__e();
		
		EReference METHOD2_ENTRY___MARKER__CREAT_E__COR_R__M2E = eINSTANCE.getMethod2Entry__Marker_CREATE__CORR__m2e();
		
		EReference METHOD2_ENTRY___MARKER__CONTEX_T__COR_R__T2D = eINSTANCE.getMethod2Entry__Marker_CONTEXT__CORR__t2d();
		
		EClass PACKAGE2_FOLDER___MARKER = eINSTANCE.getPackage2Folder__Marker();
		
		EReference PACKAGE2_FOLDER___MARKER__CREAT_E__SR_C__P = eINSTANCE.getPackage2Folder__Marker_CREATE__SRC__p();
		
		EReference PACKAGE2_FOLDER___MARKER__CONTEX_T__SR_C__PR = eINSTANCE.getPackage2Folder__Marker_CONTEXT__SRC__pr();
		
		EReference PACKAGE2_FOLDER___MARKER__CONTEX_T__TR_G__DC = eINSTANCE.getPackage2Folder__Marker_CONTEXT__TRG__dc();
		
		EReference PACKAGE2_FOLDER___MARKER__CREAT_E__TR_G__F = eINSTANCE.getPackage2Folder__Marker_CREATE__TRG__f();
		
		EReference PACKAGE2_FOLDER___MARKER__CREAT_E__COR_R__P2F = eINSTANCE.getPackage2Folder__Marker_CREATE__CORR__p2f();
		
		EReference PACKAGE2_FOLDER___MARKER__CONTEX_T__COR_R__PR2DC = eINSTANCE.getPackage2Folder__Marker_CONTEXT__CORR__pr2dc();
		
		EClass PARAM2_ENTRY___MARKER = eINSTANCE.getParam2Entry__Marker();
		
		EReference PARAM2_ENTRY___MARKER__CONTEX_T__SR_C__M = eINSTANCE.getParam2Entry__Marker_CONTEXT__SRC__m();
		
		EReference PARAM2_ENTRY___MARKER__CREAT_E__SR_C__P = eINSTANCE.getParam2Entry__Marker_CREATE__SRC__p();
		
		EReference PARAM2_ENTRY___MARKER__CONTEX_T__TR_G__E = eINSTANCE.getParam2Entry__Marker_CONTEXT__TRG__e();
		
		EReference PARAM2_ENTRY___MARKER__CONTEX_T__COR_R__M2E = eINSTANCE.getParam2Entry__Marker_CONTEXT__CORR__m2e();
		
		EReference PARAM2_ENTRY___MARKER__CREAT_E__COR_R__P2E = eINSTANCE.getParam2Entry__Marker_CREATE__CORR__p2e();
		
		EClass PROJECT2_DOC_CONT___MARKER = eINSTANCE.getProject2DocCont__Marker();
		
		EReference PROJECT2_DOC_CONT___MARKER__CREAT_E__SR_C__PR = eINSTANCE.getProject2DocCont__Marker_CREATE__SRC__pr();
		
		EReference PROJECT2_DOC_CONT___MARKER__CREAT_E__TR_G__DC = eINSTANCE.getProject2DocCont__Marker_CREATE__TRG__dc();
		
		EReference PROJECT2_DOC_CONT___MARKER__CREAT_E__COR_R__PR2DC = eINSTANCE.getProject2DocCont__Marker_CREATE__CORR__pr2dc();
		
		EClass SUB_PACKAGE2_FOLDER___MARKER = eINSTANCE.getSubPackage2Folder__Marker();
		
		EReference SUB_PACKAGE2_FOLDER___MARKER__CONTEX_T__SR_C__P = eINSTANCE.getSubPackage2Folder__Marker_CONTEXT__SRC__p();
		
		EReference SUB_PACKAGE2_FOLDER___MARKER__CREAT_E__SR_C__SP = eINSTANCE.getSubPackage2Folder__Marker_CREATE__SRC__sp();
		
		EReference SUB_PACKAGE2_FOLDER___MARKER__CONTEX_T__TR_G__F = eINSTANCE.getSubPackage2Folder__Marker_CONTEXT__TRG__f();
		
		EReference SUB_PACKAGE2_FOLDER___MARKER__CONTEX_T__COR_R__P2F = eINSTANCE.getSubPackage2Folder__Marker_CONTEXT__CORR__p2f();
		
		EReference SUB_PACKAGE2_FOLDER___MARKER__CREAT_E__COR_R__SP2F = eINSTANCE.getSubPackage2Folder__Marker_CREATE__CORR__sp2f();
		
		EClass TYPE2_DOC___MARKER = eINSTANCE.getType2Doc__Marker();
		
		EReference TYPE2_DOC___MARKER__CONTEX_T__SR_C__P = eINSTANCE.getType2Doc__Marker_CONTEXT__SRC__p();
		
		EReference TYPE2_DOC___MARKER__CREAT_E__SR_C__T = eINSTANCE.getType2Doc__Marker_CREATE__SRC__t();
		
		EReference TYPE2_DOC___MARKER__CREAT_E__TR_G__D = eINSTANCE.getType2Doc__Marker_CREATE__TRG__d();
		
		EReference TYPE2_DOC___MARKER__CONTEX_T__TR_G__F = eINSTANCE.getType2Doc__Marker_CONTEXT__TRG__f();
		
		EReference TYPE2_DOC___MARKER__CONTEX_T__COR_R__P2DC = eINSTANCE.getType2Doc__Marker_CONTEXT__CORR__p2dc();
		
		EReference TYPE2_DOC___MARKER__CREAT_E__COR_R__T2D = eINSTANCE.getType2Doc__Marker_CREATE__CORR__t2d();
		
		
		
		
	}

} 
