package ExtType2Doc_LookAhead.impl;

import ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage;
import runtime.RuntimePackage;
import ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage;

import org.emoflon.smartemf.runtime.*;
import org.emoflon.smartemf.runtime.collections.*;
import org.emoflon.smartemf.persistence.SmartEMFResource;
import org.emoflon.smartemf.runtime.notification.SmartEMFNotification;
import org.emoflon.smartemf.runtime.notification.NotifyStatus;

import java.util.function.Consumer;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EcoreFactory;
import org.eclipse.emf.ecore.EcorePackage;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.resource.Resource;

public class Field2EntryImpl extends SmartObject implements ExtType2Doc_LookAhead.Field2Entry {

    protected ExtTypeModel.Field source = null;
    protected ExtDocModel.Entry target = null;
	
	protected Field2EntryImpl() {
		super(ExtType2Doc_LookAheadPackage.Literals.FIELD2_ENTRY);
	}
	
    
    @Override
    public ExtTypeModel.Field getSource() {
    	return this.source;
    }
    
    @Override
    public void setSource(ExtTypeModel.Field value) {
    	
    	Object oldValue = this.source;
    	
    	if(value == null && oldValue == null)
    		return;
    		
    	if(value != null && value.equals(oldValue))
    		return;
    		
    	
    	
    		        this.source = value;
    		        
    	
    	
    	        	sendNotification(SmartEMFNotification.createSetNotification(this, ExtType2Doc_LookAheadPackage.Literals.FIELD2_ENTRY__SOURCE, oldValue, value, -1));
    	        	
    	        	if(ExtType2Doc_LookAheadPackage.Literals.FIELD2_ENTRY__SOURCE.getEOpposite() != null) {
    	        		if(oldValue != null) {
    	        			((SmartObject) oldValue).eInverseRemove(this, ExtType2Doc_LookAheadPackage.Literals.FIELD2_ENTRY__SOURCE.getEOpposite());
    	        		}
    	        		if(value != null) {
    	        		    ((SmartObject) value).eInverseAdd(this, ExtType2Doc_LookAheadPackage.Literals.FIELD2_ENTRY__SOURCE.getEOpposite());
    	        		}
    	        	}
    }
    
    
    @Override
    public ExtDocModel.Entry getTarget() {
    	return this.target;
    }
    
    @Override
    public void setTarget(ExtDocModel.Entry value) {
    	
    	Object oldValue = this.target;
    	
    	if(value == null && oldValue == null)
    		return;
    		
    	if(value != null && value.equals(oldValue))
    		return;
    		
    	
    	
    		        this.target = value;
    		        
    	
    	
    	        	sendNotification(SmartEMFNotification.createSetNotification(this, ExtType2Doc_LookAheadPackage.Literals.FIELD2_ENTRY__TARGET, oldValue, value, -1));
    	        	
    	        	if(ExtType2Doc_LookAheadPackage.Literals.FIELD2_ENTRY__TARGET.getEOpposite() != null) {
    	        		if(oldValue != null) {
    	        			((SmartObject) oldValue).eInverseRemove(this, ExtType2Doc_LookAheadPackage.Literals.FIELD2_ENTRY__TARGET.getEOpposite());
    	        		}
    	        		if(value != null) {
    	        		    ((SmartObject) value).eInverseAdd(this, ExtType2Doc_LookAheadPackage.Literals.FIELD2_ENTRY__TARGET.getEOpposite());
    	        		}
    	        	}
    }
    

    @Override
    public void eSet(EStructuralFeature eFeature, Object newValue){
    	if (ExtType2Doc_LookAheadPackage.Literals.FIELD2_ENTRY__SOURCE.equals(eFeature)) {
    		setSource((ExtTypeModel.Field) newValue); 
    		return;
    	}
    	if (ExtType2Doc_LookAheadPackage.Literals.FIELD2_ENTRY__TARGET.equals(eFeature)) {
    		setTarget((ExtDocModel.Entry) newValue); 
    		return;
    	}
    	eDynamicSet(eFeature, newValue);
    }
    
    @Override
    public void eUnset(EStructuralFeature eFeature){
    	if (ExtType2Doc_LookAheadPackage.Literals.FIELD2_ENTRY__SOURCE.equals(eFeature)) {
    		setSource((ExtTypeModel.Field)null); 
    		return;
    	}
    	if (ExtType2Doc_LookAheadPackage.Literals.FIELD2_ENTRY__TARGET.equals(eFeature)) {
    		setTarget((ExtDocModel.Entry)null); 
    		return;
    	}
    	eDynamicUnset(eFeature);
    }

    @Override
    public String toString(){
		return super.toString();
    }

 	@Override
    public Object eGet(EStructuralFeature eFeature){
    	if (ExtType2Doc_LookAheadPackage.Literals.FIELD2_ENTRY__SOURCE.equals(eFeature))
    		return getSource();
    	if (ExtType2Doc_LookAheadPackage.Literals.FIELD2_ENTRY__TARGET.equals(eFeature))
    		return getTarget();
    	return eDynamicGet(eFeature);
    }

    @Override
    public Object eGet(int featureID, boolean resolve, boolean coreType){
    	throw new UnsupportedOperationException("This method has been deactivated since it is not always safe to use.");
    }
    
    @Override
    public void eInverseAdd(Object otherEnd, EStructuralFeature feature) {
	    if(feature == null)
	    	return;
	    	
    	eDynamicInverseAdd(otherEnd, feature);
	    	}
    	
    @Override
	    	public void eInverseRemove(Object otherEnd, EStructuralFeature feature) {
	    if(feature == null)
	    	return;
	    		    		
    	eDynamicInverseRemove(otherEnd, feature);
	    	}
    
    @Override
    /**
    * This method sets the resource and generates REMOVING_ADAPTER and ADD notifications
    */
    protected void setResourceOfContainments(Consumer<SmartObject> setResourceCall) {
	    	}
	    	
	    	@Override
	    	/**
	    	* This method sets the resource and only generates REMOVING_ADAPTER notifications (no ADD messages)
	    	*/
    protected void setResourceOfContainmentsSilently(Resource r) { 		
	    	}
}
