package org.benchmarx.extDocModel.core;

import ExtDocModel.Annotation;
import ExtDocModel.Doc;
import ExtDocModel.DocContainer;
import ExtDocModel.Entry;
import ExtDocModel.EntryType;
import ExtDocModel.Folder;
import ExtDocModel.Glossary;
import ExtDocModel.GlossaryEntry;
import java.util.List;
import org.benchmarx.emf.Comparator;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.junit.jupiter.api.Assertions;

@SuppressWarnings("all")
public class ExtDocModelComparator implements Comparator<DocContainer> {
  private boolean checkAttributeValues;

  private FolderNormalizer folderNormalizer;

  private DocNormalizer docNormalizer;

  private EntryNormalizer entryNormalizer;

  private AnnotationNormalizer annotationNormalizer;

  private GlossaryEntryNormalizer glossaryEntryNormalizer;

  public ExtDocModelComparator(final boolean checkAttributeValues) {
    this.checkAttributeValues = checkAttributeValues;
    FolderNormalizer _folderNormalizer = new FolderNormalizer();
    this.folderNormalizer = _folderNormalizer;
    DocNormalizer _docNormalizer = new DocNormalizer();
    this.docNormalizer = _docNormalizer;
    EntryNormalizer _entryNormalizer = new EntryNormalizer();
    this.entryNormalizer = _entryNormalizer;
    AnnotationNormalizer _annotationNormalizer = new AnnotationNormalizer();
    this.annotationNormalizer = _annotationNormalizer;
    GlossaryEntryNormalizer _glossaryEntryNormalizer = new GlossaryEntryNormalizer();
    this.glossaryEntryNormalizer = _glossaryEntryNormalizer;
  }

  @Override
  public void assertEquals(final DocContainer expected, final DocContainer actual) {
    Assertions.assertEquals(this.stringify(expected), this.stringify(actual));
  }

  public String stringify(final DocContainer container) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("DocContainer {");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("folders {");
    _builder.newLine();
    {
      List<Folder> _normalize = this.folderNormalizer.normalize(container.getFolders());
      for(final Folder f : _normalize) {
        _builder.append("\t\t");
        String _stringify = this.stringify(f);
        _builder.append(_stringify, "\t\t");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.append("\t");
    _builder.append("}");
    _builder.newLine();
    _builder.append("\t");
    {
      Glossary _glossary = container.getGlossary();
      boolean _tripleNotEquals = (_glossary != null);
      if (_tripleNotEquals) {
        _builder.append("glossary = ");
        String _stringify_1 = this.stringify(container.getGlossary());
        _builder.append(_stringify_1, "\t");
      }
    }
    _builder.newLineIfNotEmpty();
    _builder.append("}");
    _builder.newLine();
    return _builder.toString();
  }

  public String stringify(final Folder folder) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("Folder {");
    _builder.newLine();
    _builder.append("\t");
    {
      if (this.checkAttributeValues) {
        _builder.append("name = \"");
        String _name = folder.getName();
        _builder.append(_name, "\t");
        _builder.append("\"");
      }
    }
    _builder.newLineIfNotEmpty();
    _builder.append("\t");
    _builder.append("subfolders {");
    _builder.newLine();
    {
      List<Folder> _normalize = this.folderNormalizer.normalize(folder.getSubFolder());
      for(final Folder f : _normalize) {
        _builder.append("\t\t");
        String _stringify = this.stringify(f);
        _builder.append(_stringify, "\t\t");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.append("\t");
    _builder.append("}");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("docs {");
    _builder.newLine();
    {
      List<Doc> _normalize_1 = this.docNormalizer.normalize(folder.getDocs());
      for(final Doc d : _normalize_1) {
        _builder.append("\t\t");
        String _stringify_1 = this.stringify(d);
        _builder.append(_stringify_1, "\t\t");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.append("\t");
    _builder.append("}");
    _builder.newLine();
    _builder.append("}");
    _builder.newLine();
    return _builder.toString();
  }

  public String stringify(final Doc doc) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("Doc {");
    _builder.newLine();
    _builder.append("\t");
    {
      if (this.checkAttributeValues) {
        _builder.append("name = \"");
        String _name = doc.getName();
        _builder.append(_name, "\t");
        _builder.append("\"");
      }
    }
    _builder.newLineIfNotEmpty();
    _builder.append("\t");
    _builder.append("entries {");
    _builder.newLine();
    {
      List<Entry> _normalize = this.entryNormalizer.normalize(doc.getEntries());
      for(final Entry e : _normalize) {
        _builder.append("\t\t");
        String _stringify = this.stringify(e);
        _builder.append(_stringify, "\t\t");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.append("\t");
    _builder.append("}");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("subDocs {");
    _builder.newLine();
    {
      List<Doc> _normalize_1 = this.docNormalizer.normalize(doc.getSubDocs());
      for(final Doc d : _normalize_1) {
        _builder.append("\t\t");
        _builder.append("Doc \"");
        String _name_1 = d.getName();
        _builder.append(_name_1, "\t\t");
        _builder.append("\"");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.append("\t");
    _builder.append("}");
    _builder.newLine();
    _builder.append("}");
    _builder.newLine();
    return _builder.toString();
  }

  public String stringify(final Entry entry) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("Entry {");
    _builder.newLine();
    {
      if (this.checkAttributeValues) {
        _builder.append("\t");
        _builder.append("name = \"");
        String _name = entry.getName();
        _builder.append(_name, "\t");
        _builder.append("\"");
        _builder.newLineIfNotEmpty();
        _builder.append("\t");
        _builder.append("type = \"");
        EntryType _type = entry.getType();
        _builder.append(_type, "\t");
        _builder.append("\"");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.append("\t");
    _builder.append("annotations {");
    _builder.newLine();
    {
      List<Annotation> _normalize = this.annotationNormalizer.normalize(entry.getAnnotations());
      for(final Annotation a : _normalize) {
        _builder.append("\t\t");
        String _stringify = this.stringify(a);
        _builder.append(_stringify, "\t\t");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.append("\t");
    _builder.append("}");
    _builder.newLine();
    _builder.append("}");
    _builder.newLine();
    return _builder.toString();
  }

  public String stringify(final Annotation annotation) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("Annotation {");
    _builder.newLine();
    _builder.append("\t");
    {
      if (this.checkAttributeValues) {
        _builder.append("value = \"");
        String _value = annotation.getValue();
        _builder.append(_value, "\t");
        _builder.append("\"");
      }
    }
    _builder.newLineIfNotEmpty();
    _builder.append("}");
    _builder.newLine();
    return _builder.toString();
  }

  public String stringify(final Glossary glossary) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("Glossary {");
    _builder.newLine();
    _builder.append("\t");
    _builder.append("entries {");
    _builder.newLine();
    {
      List<GlossaryEntry> _normalize = this.glossaryEntryNormalizer.normalize(glossary.getEntries());
      for(final GlossaryEntry e : _normalize) {
        _builder.append("\t\t");
        String _stringify = this.stringify(e);
        _builder.append(_stringify, "\t\t");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.append("\t");
    _builder.append("}");
    _builder.newLine();
    _builder.append("}");
    _builder.newLine();
    return _builder.toString();
  }

  public String stringify(final GlossaryEntry glossaryEntry) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("GlossaryEntry {");
    _builder.newLine();
    _builder.append("\t");
    {
      if (this.checkAttributeValues) {
        _builder.append("name = \"");
        String _name = glossaryEntry.getName();
        _builder.append(_name, "\t");
        _builder.append("\"");
      }
    }
    _builder.newLineIfNotEmpty();
    _builder.append("\t");
    _builder.append("entries {");
    _builder.newLine();
    {
      List<Entry> _normalize = this.entryNormalizer.normalize(glossaryEntry.getEntries());
      for(final Entry e : _normalize) {
        _builder.append("\t\t");
        _builder.append("Entry \"");
        String _name_1 = e.getName();
        _builder.append(_name_1, "\t\t");
        _builder.append("\"");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.append("\t");
    _builder.append("}");
    _builder.newLine();
    _builder.append("}");
    _builder.newLine();
    return _builder.toString();
  }
}
