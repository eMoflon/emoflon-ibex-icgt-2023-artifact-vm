package org.benchmarx.extDocModel.core;

import ExtDocModel.GlossaryEntry;
import org.benchmarx.util.Normalizer;

@SuppressWarnings("all")
public class GlossaryEntryNormalizer extends Normalizer<GlossaryEntry> {
  @Override
  public int compare(final GlossaryEntry o1, final GlossaryEntry o2) {
    return o1.getName().compareTo(o2.getName());
  }
}
