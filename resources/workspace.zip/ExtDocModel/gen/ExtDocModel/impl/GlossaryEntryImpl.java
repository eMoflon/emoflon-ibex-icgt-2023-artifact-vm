package ExtDocModel.impl;

import ExtDocModel.ExtDocModelPackage;
import ExtDocModel.ExtDocModelPackage;

import org.emoflon.smartemf.runtime.*;
import org.emoflon.smartemf.runtime.collections.*;
import org.emoflon.smartemf.persistence.SmartEMFResource;
import org.emoflon.smartemf.runtime.notification.SmartEMFNotification;
import org.emoflon.smartemf.runtime.notification.NotifyStatus;

import java.util.function.Consumer;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EcoreFactory;
import org.eclipse.emf.ecore.EcorePackage;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.resource.Resource;

public class GlossaryEntryImpl extends SmartObject implements ExtDocModel.GlossaryEntry {

    protected java.lang.String name = null;
    protected ExtDocModel.Glossary glossary = null;
    protected LinkedSmartESet<ExtDocModel.Entry> entries = new LinkedSmartESet<ExtDocModel.Entry>(this, ExtDocModelPackage.Literals.GLOSSARY_ENTRY__ENTRIES);
	
	protected GlossaryEntryImpl() {
		super(ExtDocModelPackage.Literals.GLOSSARY_ENTRY);
	}
	
    
    @Override
    public java.lang.String getName() {
    	return this.name;
    }
    
    @Override
    public void setName(java.lang.String value) {
    	Object oldValue = this.name;
    	this.name = value;
    	
    	        	sendNotification(SmartEMFNotification.createSetNotification(this, ExtDocModelPackage.Literals.NAMED_ELEMENT__NAME, oldValue, value, -1));
    }
    
    
    @Override
    public ExtDocModel.Glossary getGlossary() {
    	return this.glossary;
    }
    
    @Override
    public void setGlossary(ExtDocModel.Glossary value) {
    	
    	Object oldValue = this.glossary;
    	
    	if(value == null && oldValue == null)
    		return;
    		
    	if(value != null && value.equals(oldValue))
    		return;
    		
    	
    	
    		       	if(this.glossary != null && value == null) {
    		       		resetContainmentSilently();
    		       	}
    		        this.glossary = value;
    		        
    	
    	
    	        	sendNotification(SmartEMFNotification.createSetNotification(this, ExtDocModelPackage.Literals.GLOSSARY_ENTRY__GLOSSARY, oldValue, value, -1));
    	        	
    	
    	        	if(oldValue != null) {
    	        		((SmartObject) oldValue).eInverseRemove(this, ExtDocModelPackage.Literals.GLOSSARY__ENTRIES);
    	        	}
    	        	if(value != null) {
    	        		((SmartObject) value).eInverseAdd(this, ExtDocModelPackage.Literals.GLOSSARY__ENTRIES);
    	        	}
    }
    
    private void setGlossaryAsInverse(ExtDocModel.Glossary value) {
			    
			    Object oldValue = this.glossary;
			    
			    if(value == null && oldValue == null)
			    	return;
			    	
			    if(value != null && value.equals(oldValue))
			    	return;
			    	
			    
			    
			    	       	if(this.glossary != null && value == null) {
			    	       		resetContainmentSilently();
			    	       	}
			    	        this.glossary = value;
			    	        
			    
			    
			            	sendNotification(SmartEMFNotification.createSetNotification(this, ExtDocModelPackage.Literals.GLOSSARY_ENTRY__GLOSSARY, oldValue, value, -1));
			            	
    }
    
    @Override
    public LinkedSmartESet<ExtDocModel.Entry> getEntries() {
    	return this.entries;
    }
    
    @Override
    public void setEntries(LinkedSmartESet<ExtDocModel.Entry> value) {
    	throw new UnsupportedOperationException("Set methods for SmartEMF collections are not supported.");
    }
    
    private void addEntriesAsInverse(ExtDocModel.Entry value) {
    	if(this.entries.addInternal(value, false) == NotifyStatus.SUCCESS_NO_NOTIFICATION) {
    sendNotification(SmartEMFNotification.createAddNotification(this, ExtDocModelPackage.Literals.GLOSSARY_ENTRY__ENTRIES, value, -1));
    	} 
    }
    
    private void removeEntriesAsInverse(ExtDocModel.Entry value) {
    	entries.removeInternal(value, false, true);
    }

    @Override
    public void eSet(EStructuralFeature eFeature, Object newValue){
    	if (ExtDocModelPackage.Literals.NAMED_ELEMENT__NAME.equals(eFeature)) {
    		setName((java.lang.String) newValue); 
    		return;
    	}
    	if (ExtDocModelPackage.Literals.GLOSSARY_ENTRY__GLOSSARY.equals(eFeature)) {
    		setGlossary((ExtDocModel.Glossary) newValue); 
    		return;
    	}
    	if (ExtDocModelPackage.Literals.GLOSSARY_ENTRY__ENTRIES.equals(eFeature)) {
    		setEntries((LinkedSmartESet<ExtDocModel.Entry>) newValue); 
    		return;
    	}
    	eDynamicSet(eFeature, newValue);
    }
    
    @Override
    public void eUnset(EStructuralFeature eFeature){
    	if (ExtDocModelPackage.Literals.NAMED_ELEMENT__NAME.equals(eFeature)) {
    		setName((java.lang.String)null); 
    		return;
    	}
    	if (ExtDocModelPackage.Literals.GLOSSARY_ENTRY__GLOSSARY.equals(eFeature)) {
    		setGlossary((ExtDocModel.Glossary)null); 
    		return;
    	}
    	if (ExtDocModelPackage.Literals.GLOSSARY_ENTRY__ENTRIES.equals(eFeature)) {
    		getEntries().clear(); 
    		return;
    	}
    	eDynamicUnset(eFeature);
    }

    @Override
    public String toString(){
		StringBuilder b = new StringBuilder();
		b.append(super.toString());
		b.append(" (");
		if (SmartEMFConfig.simpleStringRepresentations()) {
			b.append(getName());
		} else {
			b.append("name: ");
			b.append(getName());
		}
		b.append(")");
		return b.toString();
    }

 	@Override
    public Object eGet(EStructuralFeature eFeature){
    	if (ExtDocModelPackage.Literals.NAMED_ELEMENT__NAME.equals(eFeature))
    		return getName();
    	if (ExtDocModelPackage.Literals.GLOSSARY_ENTRY__GLOSSARY.equals(eFeature))
    		return getGlossary();
    	if (ExtDocModelPackage.Literals.GLOSSARY_ENTRY__ENTRIES.equals(eFeature))
    		return getEntries();
    	return eDynamicGet(eFeature);
    }

    @Override
    public Object eGet(int featureID, boolean resolve, boolean coreType){
    	throw new UnsupportedOperationException("This method has been deactivated since it is not always safe to use.");
    }
    
    @Override
    public void eInverseAdd(Object otherEnd, EStructuralFeature feature) {
if (ExtDocModelPackage.Literals.GLOSSARY_ENTRY__GLOSSARY.equals(feature)) {
setGlossaryAsInverse((ExtDocModel.Glossary) otherEnd); 
 	return;
			        }	
if (ExtDocModelPackage.Literals.GLOSSARY_ENTRY__ENTRIES.equals(feature)) {
	addEntriesAsInverse((ExtDocModel.Entry) otherEnd);
 	return;
			        }	
	    if(feature == null)
	    	return;
	    	
    	eDynamicInverseAdd(otherEnd, feature);
	    	}
    	
    @Override
	    	public void eInverseRemove(Object otherEnd, EStructuralFeature feature) {
if (ExtDocModelPackage.Literals.GLOSSARY_ENTRY__GLOSSARY.equals(feature)) {
setGlossaryAsInverse(null); 
 	return;
			        }
if (ExtDocModelPackage.Literals.GLOSSARY_ENTRY__ENTRIES.equals(feature)) {
	removeEntriesAsInverse((ExtDocModel.Entry) otherEnd);
 	return;
			        }
	    if(feature == null)
	    	return;
	    		    		
    	eDynamicInverseRemove(otherEnd, feature);
	    	}
    
    @Override
    /**
    * This method sets the resource and generates REMOVING_ADAPTER and ADD notifications
    */
    protected void setResourceOfContainments(Consumer<SmartObject> setResourceCall) {
	    	}
	    	
	    	@Override
	    	/**
	    	* This method sets the resource and only generates REMOVING_ADAPTER notifications (no ADD messages)
	    	*/
    protected void setResourceOfContainmentsSilently(Resource r) { 		
	    	}
}
