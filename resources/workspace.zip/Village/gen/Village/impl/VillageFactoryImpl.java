package Village.impl;

import Village.VillageSquare;
import Village.House;

import Village.HouseType;

import Village.VillageFactory;
import Village.VillagePackage;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

public class VillageFactoryImpl extends EFactoryImpl implements Village.VillageFactory {

	public static Village.VillageFactory init() {
		try {
			VillageFactory theVillageFactory = (VillageFactory) EPackage.Registry.INSTANCE
					.getEFactory(VillagePackage.eNS_URI);
			if (theVillageFactory != null) {
				return theVillageFactory;
			}
		} catch (java.lang.Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new VillageFactoryImpl();
	}

	public VillageFactoryImpl() {
		super();
	}

	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
		case VillagePackage.VILLAGE_SQUARE:
			return createVillageSquare();
		case VillagePackage.HOUSE:
			return createHouse();
		default:
			throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}
	
		@Override
		public Object createFromString(EDataType eDataType, String initialValue) {
			switch (eDataType.getClassifierID()) {
			case VillagePackage.HOUSE_TYPE:
				return createHouseTypeFromString(eDataType, initialValue);
			default:
				throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
			}
		}

	@Override
	public String convertToString(EDataType eDataType, Object instanceValue) {
		switch (eDataType.getClassifierID()) {
		case VillagePackage.HOUSE_TYPE:
			return convertHouseTypeToString(eDataType, instanceValue);
		default:
			throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}
	
	@Override
	public Village.VillageSquare createVillageSquare() {
		VillageSquareImpl villageSquare = new VillageSquareImpl();
		return villageSquare;
	}
	@Override
	public Village.House createHouse() {
		HouseImpl house = new HouseImpl();
		return house;
	}
	
	public HouseType createHouseTypeFromString(EDataType eDataType, String initialValue) {
		HouseType result = HouseType.get(initialValue);
		if (result == null)
			throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
				
		return result;
	}
	
	public String convertHouseTypeToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	@Override
	public VillagePackage getVillagePackage() {
	return (VillagePackage) getEPackage();
	}
} 
