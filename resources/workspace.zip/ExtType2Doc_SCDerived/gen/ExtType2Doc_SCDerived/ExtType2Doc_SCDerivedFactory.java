package ExtType2Doc_SCDerived;

import ExtType2Doc_SCDerived.Project2DocContainer;
import ExtType2Doc_SCDerived.Package2Folder;
import ExtType2Doc_SCDerived.Type2Doc;
import ExtType2Doc_SCDerived.Method2Entry;
import ExtType2Doc_SCDerived.Param2Entry;
import ExtType2Doc_SCDerived.Field2Entry;
import ExtType2Doc_SCDerived.ExtendingType2Doc__Marker;
import ExtType2Doc_SCDerived.Field2Entry__Marker;
import ExtType2Doc_SCDerived.Method2Entry__Marker;
import ExtType2Doc_SCDerived.Package2Folder__Marker;
import ExtType2Doc_SCDerived.Param2Entry__Marker;
import ExtType2Doc_SCDerived.Project2DocCont__Marker;
import ExtType2Doc_SCDerived.SubPackage2Folder__Marker;
import ExtType2Doc_SCDerived.Type2Doc__Marker;

import org.eclipse.emf.ecore.EFactory;

public interface ExtType2Doc_SCDerivedFactory extends EFactory {

	ExtType2Doc_SCDerivedFactory eINSTANCE = ExtType2Doc_SCDerived.impl.ExtType2Doc_SCDerivedFactoryImpl.init();
	
	Project2DocContainer createProject2DocContainer();
	
	Package2Folder createPackage2Folder();
	
	Type2Doc createType2Doc();
	
	Method2Entry createMethod2Entry();
	
	Param2Entry createParam2Entry();
	
	Field2Entry createField2Entry();
	
	ExtendingType2Doc__Marker createExtendingType2Doc__Marker();
	
	Field2Entry__Marker createField2Entry__Marker();
	
	Method2Entry__Marker createMethod2Entry__Marker();
	
	Package2Folder__Marker createPackage2Folder__Marker();
	
	Param2Entry__Marker createParam2Entry__Marker();
	
	Project2DocCont__Marker createProject2DocCont__Marker();
	
	SubPackage2Folder__Marker createSubPackage2Folder__Marker();
	
	Type2Doc__Marker createType2Doc__Marker();
	
	
	ExtType2Doc_SCDerivedPackage getExtType2Doc_SCDerivedPackage();

}
