package ExtDocModel;

import java.lang.String;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.eclipse.emf.common.util.Enumerator;

public enum EntryType implements Enumerator {
	
	 FIELD(0, "FIELD", "FIELD"), METHOD(1, "METHOD", "METHOD");
	
	public static final int FIELD_VALUE = 0;
	public static final int METHOD_VALUE = 1;
	
	private static final EntryType[] VALUES_ARRAY = new EntryType[] {FIELD,METHOD};

	public static final List<EntryType> VALUES = Collections.unmodifiableList(Arrays.asList(VALUES_ARRAY));

	public static EntryType get(String literal) {
	for (int i = 0; i < VALUES_ARRAY.length; ++i) {
		EntryType result = VALUES_ARRAY[i];
		if (result.toString().equals(literal)) {
			return result;
		}
	}
	return null;
	}

	public static EntryType getByName(String name) {
	for (int i = 0; i < VALUES_ARRAY.length; ++i) {
		EntryType result = VALUES_ARRAY[i];
		if (result.getName().equals(name)) {
			return result;
		}
	}
	return null;
	}

	public static EntryType get(int value) {
		switch (value) {
		case FIELD_VALUE:
			return FIELD;
		case METHOD_VALUE:
			return METHOD;
		}
		return null;
	}

	private final int value;

	private final String name;

	private final String literal;

	private EntryType(int value, String name, String literal) {
	this.value = value;
	this.name = name;
	this.literal = literal;
	}

	@Override
	public int getValue() {
		return value;
	}

	@Override
	public String getName() {
	return name;
	}

	@Override
	public String getLiteral() {
		return literal;
	}

	@Override
	public String toString() {
	return literal;
	}

}

