package Village2ConstrPlan.impl;

import Village2ConstrPlan.Village2ConstrPlanPackage;
import runtime.RuntimePackage;
import Village2ConstrPlan.Village2ConstrPlanPackage;

import org.emoflon.smartemf.runtime.*;
import org.emoflon.smartemf.runtime.collections.*;
import org.emoflon.smartemf.persistence.SmartEMFResource;
import org.emoflon.smartemf.runtime.notification.SmartEMFNotification;
import org.emoflon.smartemf.runtime.notification.NotifyStatus;

import java.util.function.Consumer;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EcoreFactory;
import org.eclipse.emf.ecore.EcorePackage;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.resource.Resource;

public class Villa2Constr__MarkerImpl extends SmartObject implements Village2ConstrPlan.Villa2Constr__Marker {

    protected runtime.Protocol protocol = null;
    protected Village.House CONTEXT__SRC__h = null;
    protected Village.House CREATE__SRC__nh = null;
    protected ConstructionPlan.Basement CREATE__TRG__bt = null;
    protected ConstructionPlan.Construction CONTEXT__TRG__cst = null;
    protected ConstructionPlan.Construction CREATE__TRG__ncst = null;
    protected ConstructionPlan.Plan CONTEXT__TRG__p = null;
    protected ConstructionPlan.SaddleRoof CREATE__TRG__sr = null;
    protected Village2ConstrPlan.House2Constr CONTEXT__CORR__h2cst = null;
    protected Village2ConstrPlan.House2Constr CREATE__CORR__nh2ncst = null;
	
	protected Villa2Constr__MarkerImpl() {
		super(Village2ConstrPlanPackage.Literals.VILLA2_CONSTR___MARKER);
	}
	
    
    @Override
    public runtime.Protocol getProtocol() {
    	return this.protocol;
    }
    
    @Override
    public void setProtocol(runtime.Protocol value) {
    	
    	Object oldValue = this.protocol;
    	
    	if(value == null && oldValue == null)
    		return;
    		
    	if(value != null && value.equals(oldValue))
    		return;
    		
    	
    	
    		       	if(this.protocol != null && value == null) {
    		       		resetContainmentSilently();
    		       	}
    		        this.protocol = value;
    		        
    	
    	
    	        	sendNotification(SmartEMFNotification.createSetNotification(this, RuntimePackage.Literals.TGG_RULE_APPLICATION__PROTOCOL, oldValue, value, -1));
    	        	
    	
    	        	if(oldValue != null) {
    	        		((SmartObject) oldValue).eInverseRemove(this, RuntimePackage.Literals.PROTOCOL__STEPS);
    	        	}
    	        	if(value != null) {
    	        		((SmartObject) value).eInverseAdd(this, RuntimePackage.Literals.PROTOCOL__STEPS);
    	        	}
    }
    
    private void setProtocolAsInverse(runtime.Protocol value) {
			    
			    Object oldValue = this.protocol;
			    
			    if(value == null && oldValue == null)
			    	return;
			    	
			    if(value != null && value.equals(oldValue))
			    	return;
			    	
			    
			    
			    	       	if(this.protocol != null && value == null) {
			    	       		resetContainmentSilently();
			    	       	}
			    	        this.protocol = value;
			    	        
			    
			    
			            	sendNotification(SmartEMFNotification.createSetNotification(this, RuntimePackage.Literals.TGG_RULE_APPLICATION__PROTOCOL, oldValue, value, -1));
			            	
    }
    
    @Override
    public Village.House getCONTEXT__SRC__h() {
    	return this.CONTEXT__SRC__h;
    }
    
    @Override
    public void setCONTEXT__SRC__h(Village.House value) {
    	
    	Object oldValue = this.CONTEXT__SRC__h;
    	
    	if(value == null && oldValue == null)
    		return;
    		
    	if(value != null && value.equals(oldValue))
    		return;
    		
    	
    	
    		        this.CONTEXT__SRC__h = value;
    		        
    	
    	
    	        	sendNotification(SmartEMFNotification.createSetNotification(this, Village2ConstrPlanPackage.Literals.VILLA2_CONSTR___MARKER__CONTEX_T__SR_C__H, oldValue, value, -1));
    	        	
    	        	if(Village2ConstrPlanPackage.Literals.VILLA2_CONSTR___MARKER__CONTEX_T__SR_C__H.getEOpposite() != null) {
    	        		if(oldValue != null) {
    	        			((SmartObject) oldValue).eInverseRemove(this, Village2ConstrPlanPackage.Literals.VILLA2_CONSTR___MARKER__CONTEX_T__SR_C__H.getEOpposite());
    	        		}
    	        		if(value != null) {
    	        		    ((SmartObject) value).eInverseAdd(this, Village2ConstrPlanPackage.Literals.VILLA2_CONSTR___MARKER__CONTEX_T__SR_C__H.getEOpposite());
    	        		}
    	        	}
    }
    
    
    @Override
    public Village.House getCREATE__SRC__nh() {
    	return this.CREATE__SRC__nh;
    }
    
    @Override
    public void setCREATE__SRC__nh(Village.House value) {
    	
    	Object oldValue = this.CREATE__SRC__nh;
    	
    	if(value == null && oldValue == null)
    		return;
    		
    	if(value != null && value.equals(oldValue))
    		return;
    		
    	
    	
    		        this.CREATE__SRC__nh = value;
    		        
    	
    	
    	        	sendNotification(SmartEMFNotification.createSetNotification(this, Village2ConstrPlanPackage.Literals.VILLA2_CONSTR___MARKER__CREAT_E__SR_C__NH, oldValue, value, -1));
    	        	
    	        	if(Village2ConstrPlanPackage.Literals.VILLA2_CONSTR___MARKER__CREAT_E__SR_C__NH.getEOpposite() != null) {
    	        		if(oldValue != null) {
    	        			((SmartObject) oldValue).eInverseRemove(this, Village2ConstrPlanPackage.Literals.VILLA2_CONSTR___MARKER__CREAT_E__SR_C__NH.getEOpposite());
    	        		}
    	        		if(value != null) {
    	        		    ((SmartObject) value).eInverseAdd(this, Village2ConstrPlanPackage.Literals.VILLA2_CONSTR___MARKER__CREAT_E__SR_C__NH.getEOpposite());
    	        		}
    	        	}
    }
    
    
    @Override
    public ConstructionPlan.Basement getCREATE__TRG__bt() {
    	return this.CREATE__TRG__bt;
    }
    
    @Override
    public void setCREATE__TRG__bt(ConstructionPlan.Basement value) {
    	
    	Object oldValue = this.CREATE__TRG__bt;
    	
    	if(value == null && oldValue == null)
    		return;
    		
    	if(value != null && value.equals(oldValue))
    		return;
    		
    	
    	
    		        this.CREATE__TRG__bt = value;
    		        
    	
    	
    	        	sendNotification(SmartEMFNotification.createSetNotification(this, Village2ConstrPlanPackage.Literals.VILLA2_CONSTR___MARKER__CREAT_E__TR_G__BT, oldValue, value, -1));
    	        	
    	        	if(Village2ConstrPlanPackage.Literals.VILLA2_CONSTR___MARKER__CREAT_E__TR_G__BT.getEOpposite() != null) {
    	        		if(oldValue != null) {
    	        			((SmartObject) oldValue).eInverseRemove(this, Village2ConstrPlanPackage.Literals.VILLA2_CONSTR___MARKER__CREAT_E__TR_G__BT.getEOpposite());
    	        		}
    	        		if(value != null) {
    	        		    ((SmartObject) value).eInverseAdd(this, Village2ConstrPlanPackage.Literals.VILLA2_CONSTR___MARKER__CREAT_E__TR_G__BT.getEOpposite());
    	        		}
    	        	}
    }
    
    
    @Override
    public ConstructionPlan.Construction getCONTEXT__TRG__cst() {
    	return this.CONTEXT__TRG__cst;
    }
    
    @Override
    public void setCONTEXT__TRG__cst(ConstructionPlan.Construction value) {
    	
    	Object oldValue = this.CONTEXT__TRG__cst;
    	
    	if(value == null && oldValue == null)
    		return;
    		
    	if(value != null && value.equals(oldValue))
    		return;
    		
    	
    	
    		        this.CONTEXT__TRG__cst = value;
    		        
    	
    	
    	        	sendNotification(SmartEMFNotification.createSetNotification(this, Village2ConstrPlanPackage.Literals.VILLA2_CONSTR___MARKER__CONTEX_T__TR_G__CST, oldValue, value, -1));
    	        	
    	        	if(Village2ConstrPlanPackage.Literals.VILLA2_CONSTR___MARKER__CONTEX_T__TR_G__CST.getEOpposite() != null) {
    	        		if(oldValue != null) {
    	        			((SmartObject) oldValue).eInverseRemove(this, Village2ConstrPlanPackage.Literals.VILLA2_CONSTR___MARKER__CONTEX_T__TR_G__CST.getEOpposite());
    	        		}
    	        		if(value != null) {
    	        		    ((SmartObject) value).eInverseAdd(this, Village2ConstrPlanPackage.Literals.VILLA2_CONSTR___MARKER__CONTEX_T__TR_G__CST.getEOpposite());
    	        		}
    	        	}
    }
    
    
    @Override
    public ConstructionPlan.Construction getCREATE__TRG__ncst() {
    	return this.CREATE__TRG__ncst;
    }
    
    @Override
    public void setCREATE__TRG__ncst(ConstructionPlan.Construction value) {
    	
    	Object oldValue = this.CREATE__TRG__ncst;
    	
    	if(value == null && oldValue == null)
    		return;
    		
    	if(value != null && value.equals(oldValue))
    		return;
    		
    	
    	
    		        this.CREATE__TRG__ncst = value;
    		        
    	
    	
    	        	sendNotification(SmartEMFNotification.createSetNotification(this, Village2ConstrPlanPackage.Literals.VILLA2_CONSTR___MARKER__CREAT_E__TR_G__NCST, oldValue, value, -1));
    	        	
    	        	if(Village2ConstrPlanPackage.Literals.VILLA2_CONSTR___MARKER__CREAT_E__TR_G__NCST.getEOpposite() != null) {
    	        		if(oldValue != null) {
    	        			((SmartObject) oldValue).eInverseRemove(this, Village2ConstrPlanPackage.Literals.VILLA2_CONSTR___MARKER__CREAT_E__TR_G__NCST.getEOpposite());
    	        		}
    	        		if(value != null) {
    	        		    ((SmartObject) value).eInverseAdd(this, Village2ConstrPlanPackage.Literals.VILLA2_CONSTR___MARKER__CREAT_E__TR_G__NCST.getEOpposite());
    	        		}
    	        	}
    }
    
    
    @Override
    public ConstructionPlan.Plan getCONTEXT__TRG__p() {
    	return this.CONTEXT__TRG__p;
    }
    
    @Override
    public void setCONTEXT__TRG__p(ConstructionPlan.Plan value) {
    	
    	Object oldValue = this.CONTEXT__TRG__p;
    	
    	if(value == null && oldValue == null)
    		return;
    		
    	if(value != null && value.equals(oldValue))
    		return;
    		
    	
    	
    		        this.CONTEXT__TRG__p = value;
    		        
    	
    	
    	        	sendNotification(SmartEMFNotification.createSetNotification(this, Village2ConstrPlanPackage.Literals.VILLA2_CONSTR___MARKER__CONTEX_T__TR_G__P, oldValue, value, -1));
    	        	
    	        	if(Village2ConstrPlanPackage.Literals.VILLA2_CONSTR___MARKER__CONTEX_T__TR_G__P.getEOpposite() != null) {
    	        		if(oldValue != null) {
    	        			((SmartObject) oldValue).eInverseRemove(this, Village2ConstrPlanPackage.Literals.VILLA2_CONSTR___MARKER__CONTEX_T__TR_G__P.getEOpposite());
    	        		}
    	        		if(value != null) {
    	        		    ((SmartObject) value).eInverseAdd(this, Village2ConstrPlanPackage.Literals.VILLA2_CONSTR___MARKER__CONTEX_T__TR_G__P.getEOpposite());
    	        		}
    	        	}
    }
    
    
    @Override
    public ConstructionPlan.SaddleRoof getCREATE__TRG__sr() {
    	return this.CREATE__TRG__sr;
    }
    
    @Override
    public void setCREATE__TRG__sr(ConstructionPlan.SaddleRoof value) {
    	
    	Object oldValue = this.CREATE__TRG__sr;
    	
    	if(value == null && oldValue == null)
    		return;
    		
    	if(value != null && value.equals(oldValue))
    		return;
    		
    	
    	
    		        this.CREATE__TRG__sr = value;
    		        
    	
    	
    	        	sendNotification(SmartEMFNotification.createSetNotification(this, Village2ConstrPlanPackage.Literals.VILLA2_CONSTR___MARKER__CREAT_E__TR_G__SR, oldValue, value, -1));
    	        	
    	        	if(Village2ConstrPlanPackage.Literals.VILLA2_CONSTR___MARKER__CREAT_E__TR_G__SR.getEOpposite() != null) {
    	        		if(oldValue != null) {
    	        			((SmartObject) oldValue).eInverseRemove(this, Village2ConstrPlanPackage.Literals.VILLA2_CONSTR___MARKER__CREAT_E__TR_G__SR.getEOpposite());
    	        		}
    	        		if(value != null) {
    	        		    ((SmartObject) value).eInverseAdd(this, Village2ConstrPlanPackage.Literals.VILLA2_CONSTR___MARKER__CREAT_E__TR_G__SR.getEOpposite());
    	        		}
    	        	}
    }
    
    
    @Override
    public Village2ConstrPlan.House2Constr getCONTEXT__CORR__h2cst() {
    	return this.CONTEXT__CORR__h2cst;
    }
    
    @Override
    public void setCONTEXT__CORR__h2cst(Village2ConstrPlan.House2Constr value) {
    	
    	Object oldValue = this.CONTEXT__CORR__h2cst;
    	
    	if(value == null && oldValue == null)
    		return;
    		
    	if(value != null && value.equals(oldValue))
    		return;
    		
    	
    	
    		        this.CONTEXT__CORR__h2cst = value;
    		        
    	
    	
    	        	sendNotification(SmartEMFNotification.createSetNotification(this, Village2ConstrPlanPackage.Literals.VILLA2_CONSTR___MARKER__CONTEX_T__COR_R__H2CST, oldValue, value, -1));
    	        	
    	        	if(Village2ConstrPlanPackage.Literals.VILLA2_CONSTR___MARKER__CONTEX_T__COR_R__H2CST.getEOpposite() != null) {
    	        		if(oldValue != null) {
    	        			((SmartObject) oldValue).eInverseRemove(this, Village2ConstrPlanPackage.Literals.VILLA2_CONSTR___MARKER__CONTEX_T__COR_R__H2CST.getEOpposite());
    	        		}
    	        		if(value != null) {
    	        		    ((SmartObject) value).eInverseAdd(this, Village2ConstrPlanPackage.Literals.VILLA2_CONSTR___MARKER__CONTEX_T__COR_R__H2CST.getEOpposite());
    	        		}
    	        	}
    }
    
    
    @Override
    public Village2ConstrPlan.House2Constr getCREATE__CORR__nh2ncst() {
    	return this.CREATE__CORR__nh2ncst;
    }
    
    @Override
    public void setCREATE__CORR__nh2ncst(Village2ConstrPlan.House2Constr value) {
    	
    	Object oldValue = this.CREATE__CORR__nh2ncst;
    	
    	if(value == null && oldValue == null)
    		return;
    		
    	if(value != null && value.equals(oldValue))
    		return;
    		
    	
    	
    		        this.CREATE__CORR__nh2ncst = value;
    		        
    	
    	
    	        	sendNotification(SmartEMFNotification.createSetNotification(this, Village2ConstrPlanPackage.Literals.VILLA2_CONSTR___MARKER__CREAT_E__COR_R__NH2NCST, oldValue, value, -1));
    	        	
    	        	if(Village2ConstrPlanPackage.Literals.VILLA2_CONSTR___MARKER__CREAT_E__COR_R__NH2NCST.getEOpposite() != null) {
    	        		if(oldValue != null) {
    	        			((SmartObject) oldValue).eInverseRemove(this, Village2ConstrPlanPackage.Literals.VILLA2_CONSTR___MARKER__CREAT_E__COR_R__NH2NCST.getEOpposite());
    	        		}
    	        		if(value != null) {
    	        		    ((SmartObject) value).eInverseAdd(this, Village2ConstrPlanPackage.Literals.VILLA2_CONSTR___MARKER__CREAT_E__COR_R__NH2NCST.getEOpposite());
    	        		}
    	        	}
    }
    

    @Override
    public void eSet(EStructuralFeature eFeature, Object newValue){
    	if (RuntimePackage.Literals.TGG_RULE_APPLICATION__PROTOCOL.equals(eFeature)) {
    		setProtocol((runtime.Protocol) newValue); 
    		return;
    	}
    	if (Village2ConstrPlanPackage.Literals.VILLA2_CONSTR___MARKER__CONTEX_T__SR_C__H.equals(eFeature)) {
    		setCONTEXT__SRC__h((Village.House) newValue); 
    		return;
    	}
    	if (Village2ConstrPlanPackage.Literals.VILLA2_CONSTR___MARKER__CREAT_E__SR_C__NH.equals(eFeature)) {
    		setCREATE__SRC__nh((Village.House) newValue); 
    		return;
    	}
    	if (Village2ConstrPlanPackage.Literals.VILLA2_CONSTR___MARKER__CREAT_E__TR_G__BT.equals(eFeature)) {
    		setCREATE__TRG__bt((ConstructionPlan.Basement) newValue); 
    		return;
    	}
    	if (Village2ConstrPlanPackage.Literals.VILLA2_CONSTR___MARKER__CONTEX_T__TR_G__CST.equals(eFeature)) {
    		setCONTEXT__TRG__cst((ConstructionPlan.Construction) newValue); 
    		return;
    	}
    	if (Village2ConstrPlanPackage.Literals.VILLA2_CONSTR___MARKER__CREAT_E__TR_G__NCST.equals(eFeature)) {
    		setCREATE__TRG__ncst((ConstructionPlan.Construction) newValue); 
    		return;
    	}
    	if (Village2ConstrPlanPackage.Literals.VILLA2_CONSTR___MARKER__CONTEX_T__TR_G__P.equals(eFeature)) {
    		setCONTEXT__TRG__p((ConstructionPlan.Plan) newValue); 
    		return;
    	}
    	if (Village2ConstrPlanPackage.Literals.VILLA2_CONSTR___MARKER__CREAT_E__TR_G__SR.equals(eFeature)) {
    		setCREATE__TRG__sr((ConstructionPlan.SaddleRoof) newValue); 
    		return;
    	}
    	if (Village2ConstrPlanPackage.Literals.VILLA2_CONSTR___MARKER__CONTEX_T__COR_R__H2CST.equals(eFeature)) {
    		setCONTEXT__CORR__h2cst((Village2ConstrPlan.House2Constr) newValue); 
    		return;
    	}
    	if (Village2ConstrPlanPackage.Literals.VILLA2_CONSTR___MARKER__CREAT_E__COR_R__NH2NCST.equals(eFeature)) {
    		setCREATE__CORR__nh2ncst((Village2ConstrPlan.House2Constr) newValue); 
    		return;
    	}
    	eDynamicSet(eFeature, newValue);
    }
    
    @Override
    public void eUnset(EStructuralFeature eFeature){
    	if (RuntimePackage.Literals.TGG_RULE_APPLICATION__PROTOCOL.equals(eFeature)) {
    		setProtocol((runtime.Protocol)null); 
    		return;
    	}
    	if (Village2ConstrPlanPackage.Literals.VILLA2_CONSTR___MARKER__CONTEX_T__SR_C__H.equals(eFeature)) {
    		setCONTEXT__SRC__h((Village.House)null); 
    		return;
    	}
    	if (Village2ConstrPlanPackage.Literals.VILLA2_CONSTR___MARKER__CREAT_E__SR_C__NH.equals(eFeature)) {
    		setCREATE__SRC__nh((Village.House)null); 
    		return;
    	}
    	if (Village2ConstrPlanPackage.Literals.VILLA2_CONSTR___MARKER__CREAT_E__TR_G__BT.equals(eFeature)) {
    		setCREATE__TRG__bt((ConstructionPlan.Basement)null); 
    		return;
    	}
    	if (Village2ConstrPlanPackage.Literals.VILLA2_CONSTR___MARKER__CONTEX_T__TR_G__CST.equals(eFeature)) {
    		setCONTEXT__TRG__cst((ConstructionPlan.Construction)null); 
    		return;
    	}
    	if (Village2ConstrPlanPackage.Literals.VILLA2_CONSTR___MARKER__CREAT_E__TR_G__NCST.equals(eFeature)) {
    		setCREATE__TRG__ncst((ConstructionPlan.Construction)null); 
    		return;
    	}
    	if (Village2ConstrPlanPackage.Literals.VILLA2_CONSTR___MARKER__CONTEX_T__TR_G__P.equals(eFeature)) {
    		setCONTEXT__TRG__p((ConstructionPlan.Plan)null); 
    		return;
    	}
    	if (Village2ConstrPlanPackage.Literals.VILLA2_CONSTR___MARKER__CREAT_E__TR_G__SR.equals(eFeature)) {
    		setCREATE__TRG__sr((ConstructionPlan.SaddleRoof)null); 
    		return;
    	}
    	if (Village2ConstrPlanPackage.Literals.VILLA2_CONSTR___MARKER__CONTEX_T__COR_R__H2CST.equals(eFeature)) {
    		setCONTEXT__CORR__h2cst((Village2ConstrPlan.House2Constr)null); 
    		return;
    	}
    	if (Village2ConstrPlanPackage.Literals.VILLA2_CONSTR___MARKER__CREAT_E__COR_R__NH2NCST.equals(eFeature)) {
    		setCREATE__CORR__nh2ncst((Village2ConstrPlan.House2Constr)null); 
    		return;
    	}
    	eDynamicUnset(eFeature);
    }

    @Override
    public String toString(){
		return super.toString();
    }

 	@Override
    public Object eGet(EStructuralFeature eFeature){
    	if (RuntimePackage.Literals.TGG_RULE_APPLICATION__PROTOCOL.equals(eFeature))
    		return getProtocol();
    	if (Village2ConstrPlanPackage.Literals.VILLA2_CONSTR___MARKER__CONTEX_T__SR_C__H.equals(eFeature))
    		return getCONTEXT__SRC__h();
    	if (Village2ConstrPlanPackage.Literals.VILLA2_CONSTR___MARKER__CREAT_E__SR_C__NH.equals(eFeature))
    		return getCREATE__SRC__nh();
    	if (Village2ConstrPlanPackage.Literals.VILLA2_CONSTR___MARKER__CREAT_E__TR_G__BT.equals(eFeature))
    		return getCREATE__TRG__bt();
    	if (Village2ConstrPlanPackage.Literals.VILLA2_CONSTR___MARKER__CONTEX_T__TR_G__CST.equals(eFeature))
    		return getCONTEXT__TRG__cst();
    	if (Village2ConstrPlanPackage.Literals.VILLA2_CONSTR___MARKER__CREAT_E__TR_G__NCST.equals(eFeature))
    		return getCREATE__TRG__ncst();
    	if (Village2ConstrPlanPackage.Literals.VILLA2_CONSTR___MARKER__CONTEX_T__TR_G__P.equals(eFeature))
    		return getCONTEXT__TRG__p();
    	if (Village2ConstrPlanPackage.Literals.VILLA2_CONSTR___MARKER__CREAT_E__TR_G__SR.equals(eFeature))
    		return getCREATE__TRG__sr();
    	if (Village2ConstrPlanPackage.Literals.VILLA2_CONSTR___MARKER__CONTEX_T__COR_R__H2CST.equals(eFeature))
    		return getCONTEXT__CORR__h2cst();
    	if (Village2ConstrPlanPackage.Literals.VILLA2_CONSTR___MARKER__CREAT_E__COR_R__NH2NCST.equals(eFeature))
    		return getCREATE__CORR__nh2ncst();
    	return eDynamicGet(eFeature);
    }

    @Override
    public Object eGet(int featureID, boolean resolve, boolean coreType){
    	throw new UnsupportedOperationException("This method has been deactivated since it is not always safe to use.");
    }
    
    @Override
    public void eInverseAdd(Object otherEnd, EStructuralFeature feature) {
if (RuntimePackage.Literals.TGG_RULE_APPLICATION__PROTOCOL.equals(feature)) {
setProtocolAsInverse((runtime.Protocol) otherEnd); 
 	return;
			        }	
	    if(feature == null)
	    	return;
	    	
    	eDynamicInverseAdd(otherEnd, feature);
	    	}
    	
    @Override
	    	public void eInverseRemove(Object otherEnd, EStructuralFeature feature) {
if (RuntimePackage.Literals.TGG_RULE_APPLICATION__PROTOCOL.equals(feature)) {
setProtocolAsInverse(null); 
 	return;
			        }
	    if(feature == null)
	    	return;
	    		    		
    	eDynamicInverseRemove(otherEnd, feature);
	    	}
    
    @Override
    /**
    * This method sets the resource and generates REMOVING_ADAPTER and ADD notifications
    */
    protected void setResourceOfContainments(Consumer<SmartObject> setResourceCall) {
	    	}
	    	
	    	@Override
	    	/**
	    	* This method sets the resource and only generates REMOVING_ADAPTER notifications (no ADD messages)
	    	*/
    protected void setResourceOfContainmentsSilently(Resource r) { 		
	    	}
}
