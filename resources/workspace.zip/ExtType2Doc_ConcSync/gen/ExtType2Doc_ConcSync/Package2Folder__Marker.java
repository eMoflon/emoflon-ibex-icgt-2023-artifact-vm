package ExtType2Doc_ConcSync;

import runtime.RuntimePackage;
import ExtType2Doc_ConcSync.ExtType2Doc_ConcSyncPackage;

import org.emoflon.smartemf.runtime.notification.SmartEMFNotification;
import org.emoflon.smartemf.runtime.SmartObject;
import org.emoflon.smartemf.runtime.collections.*;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EStructuralFeature;

public interface Package2Folder__Marker extends EObject, runtime.TGGRuleApplication {
	
    public runtime.Protocol getProtocol();
    
    public void setProtocol(runtime.Protocol value);
    
    public ExtTypeModel.Package getCREATE__SRC__p();
    
    public void setCREATE__SRC__p(ExtTypeModel.Package value);
    
    public ExtTypeModel.Project getCONTEXT__SRC__pr();
    
    public void setCONTEXT__SRC__pr(ExtTypeModel.Project value);
    
    public ExtDocModel.DocContainer getCONTEXT__TRG__dc();
    
    public void setCONTEXT__TRG__dc(ExtDocModel.DocContainer value);
    
    public ExtDocModel.Folder getCREATE__TRG__f();
    
    public void setCREATE__TRG__f(ExtDocModel.Folder value);
    
    public ExtType2Doc_ConcSync.Package2Folder getCREATE__CORR__p2f();
    
    public void setCREATE__CORR__p2f(ExtType2Doc_ConcSync.Package2Folder value);
    
    public ExtType2Doc_ConcSync.Project2DocContainer getCONTEXT__CORR__pr2dc();
    
    public void setCONTEXT__CORR__pr2dc(ExtType2Doc_ConcSync.Project2DocContainer value);
    

}
