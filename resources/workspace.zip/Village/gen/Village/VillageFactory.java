package Village;

import Village.VillageSquare;
import Village.House;

import org.eclipse.emf.ecore.EFactory;

public interface VillageFactory extends EFactory {

	VillageFactory eINSTANCE = Village.impl.VillageFactoryImpl.init();
	
	VillageSquare createVillageSquare();
	
	House createHouse();
	
	
	VillagePackage getVillagePackage();

}
