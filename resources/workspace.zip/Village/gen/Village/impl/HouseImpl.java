package Village.impl;

import Village.VillagePackage;
import Village.VillagePackage;

import org.emoflon.smartemf.runtime.*;
import org.emoflon.smartemf.runtime.collections.*;
import org.emoflon.smartemf.persistence.SmartEMFResource;
import org.emoflon.smartemf.runtime.notification.SmartEMFNotification;
import org.emoflon.smartemf.runtime.notification.NotifyStatus;

import java.util.function.Consumer;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EcoreFactory;
import org.eclipse.emf.ecore.EcorePackage;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.resource.Resource;

public class HouseImpl extends SmartObject implements Village.House {

    protected Village.House nextHouse = null;
    protected java.lang.String name = null;
    protected Village.HouseType type = Village.HouseType.CORNER;
    protected java.lang.String address = null;
	
	protected HouseImpl() {
		super(VillagePackage.Literals.HOUSE);
	}
	
    
    @Override
    public Village.House getNextHouse() {
    	return this.nextHouse;
    }
    
    @Override
    public void setNextHouse(Village.House value) {
    	
    	Object oldValue = this.nextHouse;
    	
    	if(value == null && oldValue == null)
    		return;
    		
    	if(value != null && value.equals(oldValue))
    		return;
    		
    	
    	Resource.Internal resource = (Resource.Internal) eResource();
    		        if(oldValue != null && value != null) {
    		        	setResourceWithoutChecks(null);
    		        }
    		        
    		        NotifyStatus status = NotifyStatus.SUCCESS_NO_NOTIFICATION;
    	if(oldValue != null) {
    	        		status = ((MinimalSObjectContainer) oldValue).resetContainment();
    	}	
    	
    		        this.nextHouse = value;
    		        
    	
    	
    			 	if(oldValue != null && value != null) {
    		        	setResourceWithoutChecks(resource);
    		        }
    	
    	if(value != null)
    		status = ((MinimalSObjectContainer) this.nextHouse).setContainment(this, VillagePackage.Literals.HOUSE__NEXT_HOUSE);
    	
    	
    	if(status == NotifyStatus.SUCCESS_NO_NOTIFICATION || oldValue != null && value != null)
    	        	sendNotification(SmartEMFNotification.createSetNotification(this, VillagePackage.Literals.HOUSE__NEXT_HOUSE, oldValue, value, -1));
    	        	
    	        	if(VillagePackage.Literals.HOUSE__NEXT_HOUSE.getEOpposite() != null) {
    	        		if(oldValue != null) {
    	        			((SmartObject) oldValue).eInverseRemove(this, VillagePackage.Literals.HOUSE__NEXT_HOUSE.getEOpposite());
    	        		}
    	        		if(value != null) {
    	        		    ((SmartObject) value).eInverseAdd(this, VillagePackage.Literals.HOUSE__NEXT_HOUSE.getEOpposite());
    	        		}
    	        	}
    }
    
    
    @Override
    public java.lang.String getName() {
    	return this.name;
    }
    
    @Override
    public void setName(java.lang.String value) {
    	Object oldValue = this.name;
    	this.name = value;
    	
    	        	sendNotification(SmartEMFNotification.createSetNotification(this, VillagePackage.Literals.HOUSE__NAME, oldValue, value, -1));
    }
    
    
    @Override
    public Village.HouseType getType() {
    	return this.type;
    }
    
    @Override
    public void setType(Village.HouseType value) {
    	Object oldValue = this.type;
    	this.type = value;
    	
    	        	sendNotification(SmartEMFNotification.createSetNotification(this, VillagePackage.Literals.HOUSE__TYPE, oldValue, value, -1));
    }
    
    
    @Override
    public java.lang.String getAddress() {
    	return this.address;
    }
    
    @Override
    public void setAddress(java.lang.String value) {
    	Object oldValue = this.address;
    	this.address = value;
    	
    	        	sendNotification(SmartEMFNotification.createSetNotification(this, VillagePackage.Literals.HOUSE__ADDRESS, oldValue, value, -1));
    }
    

    @Override
    public void eSet(EStructuralFeature eFeature, Object newValue){
    	if (VillagePackage.Literals.HOUSE__NEXT_HOUSE.equals(eFeature)) {
    		setNextHouse((Village.House) newValue); 
    		return;
    	}
    	if (VillagePackage.Literals.HOUSE__NAME.equals(eFeature)) {
    		setName((java.lang.String) newValue); 
    		return;
    	}
    	if (VillagePackage.Literals.HOUSE__TYPE.equals(eFeature)) {
    		setType((Village.HouseType) newValue); 
    		return;
    	}
    	if (VillagePackage.Literals.HOUSE__ADDRESS.equals(eFeature)) {
    		setAddress((java.lang.String) newValue); 
    		return;
    	}
    	eDynamicSet(eFeature, newValue);
    }
    
    @Override
    public void eUnset(EStructuralFeature eFeature){
    	if (VillagePackage.Literals.HOUSE__NEXT_HOUSE.equals(eFeature)) {
    		setNextHouse((Village.House)null); 
    		return;
    	}
    	if (VillagePackage.Literals.HOUSE__NAME.equals(eFeature)) {
    		setName((java.lang.String)null); 
    		return;
    	}
    	if (VillagePackage.Literals.HOUSE__TYPE.equals(eFeature)) {
    		setType((Village.HouseType)Village.HouseType.CORNER); 
    		return;
    	}
    	if (VillagePackage.Literals.HOUSE__ADDRESS.equals(eFeature)) {
    		setAddress((java.lang.String)null); 
    		return;
    	}
    	eDynamicUnset(eFeature);
    }

    @Override
    public String toString(){
		StringBuilder b = new StringBuilder();
		b.append(super.toString());
		b.append(" (");
		if (SmartEMFConfig.simpleStringRepresentations()) {
			b.append(getName());
		} else {
			b.append("name: ");
			b.append(getName());
			b.append(", ");
			b.append("type: ");
			b.append(getType());b.append(", ");
			b.append("address: ");
			b.append(getAddress());
		}
		b.append(")");
		return b.toString();
    }

 	@Override
    public Object eGet(EStructuralFeature eFeature){
    	if (VillagePackage.Literals.HOUSE__NEXT_HOUSE.equals(eFeature))
    		return getNextHouse();
    	if (VillagePackage.Literals.HOUSE__NAME.equals(eFeature))
    		return getName();
    	if (VillagePackage.Literals.HOUSE__TYPE.equals(eFeature))
    		return getType();
    	if (VillagePackage.Literals.HOUSE__ADDRESS.equals(eFeature))
    		return getAddress();
    	return eDynamicGet(eFeature);
    }

    @Override
    public Object eGet(int featureID, boolean resolve, boolean coreType){
    	throw new UnsupportedOperationException("This method has been deactivated since it is not always safe to use.");
    }
    
    @Override
    public void eInverseAdd(Object otherEnd, EStructuralFeature feature) {
	    if(feature == null)
	    	return;
	    	
    	eDynamicInverseAdd(otherEnd, feature);
	    	}
    	
    @Override
	    	public void eInverseRemove(Object otherEnd, EStructuralFeature feature) {
	    if(feature == null)
	    	return;
	    		    		
    	eDynamicInverseRemove(otherEnd, feature);
	    	}
    
    @Override
    /**
    * This method sets the resource and generates REMOVING_ADAPTER and ADD notifications
    */
    protected void setResourceOfContainments(Consumer<SmartObject> setResourceCall) {
if(getNextHouse() != null)
	setResourceCall.accept((SmartObject) getNextHouse());
	    	}
	    	
	    	@Override
	    	/**
	    	* This method sets the resource and only generates REMOVING_ADAPTER notifications (no ADD messages)
	    	*/
    protected void setResourceOfContainmentsSilently(Resource r) { 		
if(getNextHouse() != null)
    ((SmartObject) getNextHouse()).setResourceSilently(r);
	    	}
}
