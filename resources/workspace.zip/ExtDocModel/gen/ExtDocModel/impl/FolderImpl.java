package ExtDocModel.impl;

import ExtDocModel.ExtDocModelPackage;
import ExtDocModel.ExtDocModelPackage;

import org.emoflon.smartemf.runtime.*;
import org.emoflon.smartemf.runtime.collections.*;
import org.emoflon.smartemf.persistence.SmartEMFResource;
import org.emoflon.smartemf.runtime.notification.SmartEMFNotification;
import org.emoflon.smartemf.runtime.notification.NotifyStatus;

import java.util.function.Consumer;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EcoreFactory;
import org.eclipse.emf.ecore.EcorePackage;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.resource.Resource;

public class FolderImpl extends SmartObject implements ExtDocModel.Folder {

    protected java.lang.String name = null;
    protected LinkedSmartESet<ExtDocModel.Doc> docs = new LinkedSmartESet<ExtDocModel.Doc>(this, ExtDocModelPackage.Literals.FOLDER__DOCS);
    protected ExtDocModel.DocContainer container = null;
    protected LinkedSmartESet<ExtDocModel.Folder> subFolder = new LinkedSmartESet<ExtDocModel.Folder>(this, ExtDocModelPackage.Literals.FOLDER__SUB_FOLDER);
    protected ExtDocModel.Folder superFolder = null;
	
	protected FolderImpl() {
		super(ExtDocModelPackage.Literals.FOLDER);
	}
	
    
    @Override
    public java.lang.String getName() {
    	return this.name;
    }
    
    @Override
    public void setName(java.lang.String value) {
    	Object oldValue = this.name;
    	this.name = value;
    	
    	        	sendNotification(SmartEMFNotification.createSetNotification(this, ExtDocModelPackage.Literals.NAMED_ELEMENT__NAME, oldValue, value, -1));
    }
    
    
    @Override
    public LinkedSmartESet<ExtDocModel.Doc> getDocs() {
    	return this.docs;
    }
    
    @Override
    public void setDocs(LinkedSmartESet<ExtDocModel.Doc> value) {
    	throw new UnsupportedOperationException("Set methods for SmartEMF collections are not supported.");
    }
    
    private void addDocsAsInverse(ExtDocModel.Doc value) {
    	if(this.docs.addInternal(value, false) == NotifyStatus.SUCCESS_NO_NOTIFICATION) {
    sendNotification(SmartEMFNotification.createAddNotification(this, ExtDocModelPackage.Literals.FOLDER__DOCS, value, -1));
    	} 
    }
    
    private void removeDocsAsInverse(ExtDocModel.Doc value) {
    	docs.removeInternal(value, false, true);
    }
    
    @Override
    public ExtDocModel.DocContainer getContainer() {
    	return this.container;
    }
    
    @Override
    public void setContainer(ExtDocModel.DocContainer value) {
    	
    	Object oldValue = this.container;
    	
    	if(value == null && oldValue == null)
    		return;
    		
    	if(value != null && value.equals(oldValue))
    		return;
    		
    	
    	
    		       	if(this.container != null && value == null) {
    		       		resetContainmentSilently();
    		       	}
    		        this.container = value;
    		        
    	
    	
    	        	sendNotification(SmartEMFNotification.createSetNotification(this, ExtDocModelPackage.Literals.FOLDER__CONTAINER, oldValue, value, -1));
    	        	
    	
    	        	if(oldValue != null) {
    	        		((SmartObject) oldValue).eInverseRemove(this, ExtDocModelPackage.Literals.DOC_CONTAINER__FOLDERS);
    	        	}
    	        	if(value != null) {
    	        		((SmartObject) value).eInverseAdd(this, ExtDocModelPackage.Literals.DOC_CONTAINER__FOLDERS);
    	        	}
    }
    
    private void setContainerAsInverse(ExtDocModel.DocContainer value) {
			    
			    Object oldValue = this.container;
			    
			    if(value == null && oldValue == null)
			    	return;
			    	
			    if(value != null && value.equals(oldValue))
			    	return;
			    	
			    
			    
			    	       	if(this.container != null && value == null) {
			    	       		resetContainmentSilently();
			    	       	}
			    	        this.container = value;
			    	        
			    
			    
			            	sendNotification(SmartEMFNotification.createSetNotification(this, ExtDocModelPackage.Literals.FOLDER__CONTAINER, oldValue, value, -1));
			            	
    }
    
    @Override
    public LinkedSmartESet<ExtDocModel.Folder> getSubFolder() {
    	return this.subFolder;
    }
    
    @Override
    public void setSubFolder(LinkedSmartESet<ExtDocModel.Folder> value) {
    	throw new UnsupportedOperationException("Set methods for SmartEMF collections are not supported.");
    }
    
    private void addSubFolderAsInverse(ExtDocModel.Folder value) {
    	if(this.subFolder.addInternal(value, false) == NotifyStatus.SUCCESS_NO_NOTIFICATION) {
    sendNotification(SmartEMFNotification.createAddNotification(this, ExtDocModelPackage.Literals.FOLDER__SUB_FOLDER, value, -1));
    	} 
    }
    
    private void removeSubFolderAsInverse(ExtDocModel.Folder value) {
    	subFolder.removeInternal(value, false, true);
    }
    
    @Override
    public ExtDocModel.Folder getSuperFolder() {
    	return this.superFolder;
    }
    
    @Override
    public void setSuperFolder(ExtDocModel.Folder value) {
    	
    	Object oldValue = this.superFolder;
    	
    	if(value == null && oldValue == null)
    		return;
    		
    	if(value != null && value.equals(oldValue))
    		return;
    		
    	
    	
    		       	if(this.superFolder != null && value == null) {
    		       		resetContainmentSilently();
    		       	}
    		        this.superFolder = value;
    		        
    	
    	
    	        	sendNotification(SmartEMFNotification.createSetNotification(this, ExtDocModelPackage.Literals.FOLDER__SUPER_FOLDER, oldValue, value, -1));
    	        	
    	
    	        	if(oldValue != null) {
    	        		((SmartObject) oldValue).eInverseRemove(this, ExtDocModelPackage.Literals.FOLDER__SUB_FOLDER);
    	        	}
    	        	if(value != null) {
    	        		((SmartObject) value).eInverseAdd(this, ExtDocModelPackage.Literals.FOLDER__SUB_FOLDER);
    	        	}
    }
    
    private void setSuperFolderAsInverse(ExtDocModel.Folder value) {
			    
			    Object oldValue = this.superFolder;
			    
			    if(value == null && oldValue == null)
			    	return;
			    	
			    if(value != null && value.equals(oldValue))
			    	return;
			    	
			    
			    
			    	       	if(this.superFolder != null && value == null) {
			    	       		resetContainmentSilently();
			    	       	}
			    	        this.superFolder = value;
			    	        
			    
			    
			            	sendNotification(SmartEMFNotification.createSetNotification(this, ExtDocModelPackage.Literals.FOLDER__SUPER_FOLDER, oldValue, value, -1));
			            	
    }

    @Override
    public void eSet(EStructuralFeature eFeature, Object newValue){
    	if (ExtDocModelPackage.Literals.NAMED_ELEMENT__NAME.equals(eFeature)) {
    		setName((java.lang.String) newValue); 
    		return;
    	}
    	if (ExtDocModelPackage.Literals.FOLDER__DOCS.equals(eFeature)) {
    		setDocs((LinkedSmartESet<ExtDocModel.Doc>) newValue); 
    		return;
    	}
    	if (ExtDocModelPackage.Literals.FOLDER__CONTAINER.equals(eFeature)) {
    		setContainer((ExtDocModel.DocContainer) newValue); 
    		return;
    	}
    	if (ExtDocModelPackage.Literals.FOLDER__SUB_FOLDER.equals(eFeature)) {
    		setSubFolder((LinkedSmartESet<ExtDocModel.Folder>) newValue); 
    		return;
    	}
    	if (ExtDocModelPackage.Literals.FOLDER__SUPER_FOLDER.equals(eFeature)) {
    		setSuperFolder((ExtDocModel.Folder) newValue); 
    		return;
    	}
    	eDynamicSet(eFeature, newValue);
    }
    
    @Override
    public void eUnset(EStructuralFeature eFeature){
    	if (ExtDocModelPackage.Literals.NAMED_ELEMENT__NAME.equals(eFeature)) {
    		setName((java.lang.String)null); 
    		return;
    	}
    	if (ExtDocModelPackage.Literals.FOLDER__DOCS.equals(eFeature)) {
    		getDocs().clear(); 
    		return;
    	}
    	if (ExtDocModelPackage.Literals.FOLDER__CONTAINER.equals(eFeature)) {
    		setContainer((ExtDocModel.DocContainer)null); 
    		return;
    	}
    	if (ExtDocModelPackage.Literals.FOLDER__SUB_FOLDER.equals(eFeature)) {
    		getSubFolder().clear(); 
    		return;
    	}
    	if (ExtDocModelPackage.Literals.FOLDER__SUPER_FOLDER.equals(eFeature)) {
    		setSuperFolder((ExtDocModel.Folder)null); 
    		return;
    	}
    	eDynamicUnset(eFeature);
    }

    @Override
    public String toString(){
		StringBuilder b = new StringBuilder();
		b.append(super.toString());
		b.append(" (");
		if (SmartEMFConfig.simpleStringRepresentations()) {
			b.append(getName());
		} else {
			b.append("name: ");
			b.append(getName());
		}
		b.append(")");
		return b.toString();
    }

 	@Override
    public Object eGet(EStructuralFeature eFeature){
    	if (ExtDocModelPackage.Literals.NAMED_ELEMENT__NAME.equals(eFeature))
    		return getName();
    	if (ExtDocModelPackage.Literals.FOLDER__DOCS.equals(eFeature))
    		return getDocs();
    	if (ExtDocModelPackage.Literals.FOLDER__CONTAINER.equals(eFeature))
    		return getContainer();
    	if (ExtDocModelPackage.Literals.FOLDER__SUB_FOLDER.equals(eFeature))
    		return getSubFolder();
    	if (ExtDocModelPackage.Literals.FOLDER__SUPER_FOLDER.equals(eFeature))
    		return getSuperFolder();
    	return eDynamicGet(eFeature);
    }

    @Override
    public Object eGet(int featureID, boolean resolve, boolean coreType){
    	throw new UnsupportedOperationException("This method has been deactivated since it is not always safe to use.");
    }
    
    @Override
    public void eInverseAdd(Object otherEnd, EStructuralFeature feature) {
if (ExtDocModelPackage.Literals.FOLDER__DOCS.equals(feature)) {
	addDocsAsInverse((ExtDocModel.Doc) otherEnd);
 	return;
			        }	
if (ExtDocModelPackage.Literals.FOLDER__CONTAINER.equals(feature)) {
setContainerAsInverse((ExtDocModel.DocContainer) otherEnd); 
 	return;
			        }	
if (ExtDocModelPackage.Literals.FOLDER__SUB_FOLDER.equals(feature)) {
	addSubFolderAsInverse((ExtDocModel.Folder) otherEnd);
 	return;
			        }	
if (ExtDocModelPackage.Literals.FOLDER__SUPER_FOLDER.equals(feature)) {
setSuperFolderAsInverse((ExtDocModel.Folder) otherEnd); 
 	return;
			        }	
	    if(feature == null)
	    	return;
	    	
    	eDynamicInverseAdd(otherEnd, feature);
	    	}
    	
    @Override
	    	public void eInverseRemove(Object otherEnd, EStructuralFeature feature) {
if (ExtDocModelPackage.Literals.FOLDER__DOCS.equals(feature)) {
	removeDocsAsInverse((ExtDocModel.Doc) otherEnd);
 	return;
			        }
if (ExtDocModelPackage.Literals.FOLDER__CONTAINER.equals(feature)) {
setContainerAsInverse(null); 
 	return;
			        }
if (ExtDocModelPackage.Literals.FOLDER__SUB_FOLDER.equals(feature)) {
	removeSubFolderAsInverse((ExtDocModel.Folder) otherEnd);
 	return;
			        }
if (ExtDocModelPackage.Literals.FOLDER__SUPER_FOLDER.equals(feature)) {
setSuperFolderAsInverse(null); 
 	return;
			        }
	    if(feature == null)
	    	return;
	    		    		
    	eDynamicInverseRemove(otherEnd, feature);
	    	}
    
    @Override
    /**
    * This method sets the resource and generates REMOVING_ADAPTER and ADD notifications
    */
    protected void setResourceOfContainments(Consumer<SmartObject> setResourceCall) {
    	for(Object obj : getDocs()) {
    		setResourceCall.accept(((SmartObject) obj));
	    		}
    	for(Object obj : getSubFolder()) {
    		setResourceCall.accept(((SmartObject) obj));
	    		}
	    	}
	    	
	    	@Override
	    	/**
	    	* This method sets the resource and only generates REMOVING_ADAPTER notifications (no ADD messages)
	    	*/
    protected void setResourceOfContainmentsSilently(Resource r) { 		
    	for(Object obj : getDocs()) {
    		((SmartObject) obj).setResourceSilently(r);
	    		}
    	for(Object obj : getSubFolder()) {
    		((SmartObject) obj).setResourceSilently(r);
	    		}
	    	}
}
