package ConstructionPlan;

import ConstructionPlan.PlanCollection;
import ConstructionPlan.Plan;
import ConstructionPlan.Construction;
import ConstructionPlan.Component;
import ConstructionPlan.Cellar;
import ConstructionPlan.Basement;
import ConstructionPlan.SaddleRoof;

import org.eclipse.emf.ecore.EFactory;

public interface ConstructionPlanFactory extends EFactory {

	ConstructionPlanFactory eINSTANCE = ConstructionPlan.impl.ConstructionPlanFactoryImpl.init();
	
	PlanCollection createPlanCollection();
	
	Plan createPlan();
	
	Construction createConstruction();
	
	Cellar createCellar();
	
	Basement createBasement();
	
	SaddleRoof createSaddleRoof();
	
	
	ConstructionPlanPackage getConstructionPlanPackage();

}
