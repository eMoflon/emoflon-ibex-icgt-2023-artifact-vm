package org.benchmarx.extDocModel.core;

import ExtDocModel.Annotation;
import org.benchmarx.util.Normalizer;

@SuppressWarnings("all")
public class AnnotationNormalizer extends Normalizer<Annotation> {
  @Override
  public int compare(final Annotation o1, final Annotation o2) {
    return o1.getValue().compareTo(o2.getValue());
  }
}
