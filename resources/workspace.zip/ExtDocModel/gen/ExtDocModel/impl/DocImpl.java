package ExtDocModel.impl;

import ExtDocModel.ExtDocModelPackage;
import ExtDocModel.ExtDocModelPackage;

import org.emoflon.smartemf.runtime.*;
import org.emoflon.smartemf.runtime.collections.*;
import org.emoflon.smartemf.persistence.SmartEMFResource;
import org.emoflon.smartemf.runtime.notification.SmartEMFNotification;
import org.emoflon.smartemf.runtime.notification.NotifyStatus;

import java.util.function.Consumer;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EcoreFactory;
import org.eclipse.emf.ecore.EcorePackage;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.resource.Resource;

public class DocImpl extends SmartObject implements ExtDocModel.Doc {

    protected java.lang.String name = null;
    protected ExtDocModel.Folder folder = null;
    protected LinkedSmartESet<ExtDocModel.Entry> entries = new LinkedSmartESet<ExtDocModel.Entry>(this, ExtDocModelPackage.Literals.DOC__ENTRIES);
    protected LinkedSmartESet<ExtDocModel.Doc> subDocs = new LinkedSmartESet<ExtDocModel.Doc>(this, ExtDocModelPackage.Literals.DOC__SUB_DOCS);
    protected LinkedSmartESet<ExtDocModel.Doc> superDocs = new LinkedSmartESet<ExtDocModel.Doc>(this, ExtDocModelPackage.Literals.DOC__SUPER_DOCS);
	
	protected DocImpl() {
		super(ExtDocModelPackage.Literals.DOC);
	}
	
    
    @Override
    public java.lang.String getName() {
    	return this.name;
    }
    
    @Override
    public void setName(java.lang.String value) {
    	Object oldValue = this.name;
    	this.name = value;
    	
    	        	sendNotification(SmartEMFNotification.createSetNotification(this, ExtDocModelPackage.Literals.NAMED_ELEMENT__NAME, oldValue, value, -1));
    }
    
    
    @Override
    public ExtDocModel.Folder getFolder() {
    	return this.folder;
    }
    
    @Override
    public void setFolder(ExtDocModel.Folder value) {
    	
    	Object oldValue = this.folder;
    	
    	if(value == null && oldValue == null)
    		return;
    		
    	if(value != null && value.equals(oldValue))
    		return;
    		
    	
    	
    		       	if(this.folder != null && value == null) {
    		       		resetContainmentSilently();
    		       	}
    		        this.folder = value;
    		        
    	
    	
    	        	sendNotification(SmartEMFNotification.createSetNotification(this, ExtDocModelPackage.Literals.DOC__FOLDER, oldValue, value, -1));
    	        	
    	
    	        	if(oldValue != null) {
    	        		((SmartObject) oldValue).eInverseRemove(this, ExtDocModelPackage.Literals.FOLDER__DOCS);
    	        	}
    	        	if(value != null) {
    	        		((SmartObject) value).eInverseAdd(this, ExtDocModelPackage.Literals.FOLDER__DOCS);
    	        	}
    }
    
    private void setFolderAsInverse(ExtDocModel.Folder value) {
			    
			    Object oldValue = this.folder;
			    
			    if(value == null && oldValue == null)
			    	return;
			    	
			    if(value != null && value.equals(oldValue))
			    	return;
			    	
			    
			    
			    	       	if(this.folder != null && value == null) {
			    	       		resetContainmentSilently();
			    	       	}
			    	        this.folder = value;
			    	        
			    
			    
			            	sendNotification(SmartEMFNotification.createSetNotification(this, ExtDocModelPackage.Literals.DOC__FOLDER, oldValue, value, -1));
			            	
    }
    
    @Override
    public LinkedSmartESet<ExtDocModel.Entry> getEntries() {
    	return this.entries;
    }
    
    @Override
    public void setEntries(LinkedSmartESet<ExtDocModel.Entry> value) {
    	throw new UnsupportedOperationException("Set methods for SmartEMF collections are not supported.");
    }
    
    private void addEntriesAsInverse(ExtDocModel.Entry value) {
    	if(this.entries.addInternal(value, false) == NotifyStatus.SUCCESS_NO_NOTIFICATION) {
    sendNotification(SmartEMFNotification.createAddNotification(this, ExtDocModelPackage.Literals.DOC__ENTRIES, value, -1));
    	} 
    }
    
    private void removeEntriesAsInverse(ExtDocModel.Entry value) {
    	entries.removeInternal(value, false, true);
    }
    
    @Override
    public LinkedSmartESet<ExtDocModel.Doc> getSubDocs() {
    	return this.subDocs;
    }
    
    @Override
    public void setSubDocs(LinkedSmartESet<ExtDocModel.Doc> value) {
    	throw new UnsupportedOperationException("Set methods for SmartEMF collections are not supported.");
    }
    
    private void addSubDocsAsInverse(ExtDocModel.Doc value) {
    	if(this.subDocs.addInternal(value, false) == NotifyStatus.SUCCESS_NO_NOTIFICATION) {
    sendNotification(SmartEMFNotification.createAddNotification(this, ExtDocModelPackage.Literals.DOC__SUB_DOCS, value, -1));
    	} 
    }
    
    private void removeSubDocsAsInverse(ExtDocModel.Doc value) {
    	subDocs.removeInternal(value, false, true);
    }
    
    @Override
    public LinkedSmartESet<ExtDocModel.Doc> getSuperDocs() {
    	return this.superDocs;
    }
    
    @Override
    public void setSuperDocs(LinkedSmartESet<ExtDocModel.Doc> value) {
    	throw new UnsupportedOperationException("Set methods for SmartEMF collections are not supported.");
    }
    
    private void addSuperDocsAsInverse(ExtDocModel.Doc value) {
    	if(this.superDocs.addInternal(value, false) == NotifyStatus.SUCCESS_NO_NOTIFICATION) {
    sendNotification(SmartEMFNotification.createAddNotification(this, ExtDocModelPackage.Literals.DOC__SUPER_DOCS, value, -1));
    	} 
    }
    
    private void removeSuperDocsAsInverse(ExtDocModel.Doc value) {
    	superDocs.removeInternal(value, false, true);
    }

    @Override
    public void eSet(EStructuralFeature eFeature, Object newValue){
    	if (ExtDocModelPackage.Literals.NAMED_ELEMENT__NAME.equals(eFeature)) {
    		setName((java.lang.String) newValue); 
    		return;
    	}
    	if (ExtDocModelPackage.Literals.DOC__FOLDER.equals(eFeature)) {
    		setFolder((ExtDocModel.Folder) newValue); 
    		return;
    	}
    	if (ExtDocModelPackage.Literals.DOC__ENTRIES.equals(eFeature)) {
    		setEntries((LinkedSmartESet<ExtDocModel.Entry>) newValue); 
    		return;
    	}
    	if (ExtDocModelPackage.Literals.DOC__SUB_DOCS.equals(eFeature)) {
    		setSubDocs((LinkedSmartESet<ExtDocModel.Doc>) newValue); 
    		return;
    	}
    	if (ExtDocModelPackage.Literals.DOC__SUPER_DOCS.equals(eFeature)) {
    		setSuperDocs((LinkedSmartESet<ExtDocModel.Doc>) newValue); 
    		return;
    	}
    	eDynamicSet(eFeature, newValue);
    }
    
    @Override
    public void eUnset(EStructuralFeature eFeature){
    	if (ExtDocModelPackage.Literals.NAMED_ELEMENT__NAME.equals(eFeature)) {
    		setName((java.lang.String)null); 
    		return;
    	}
    	if (ExtDocModelPackage.Literals.DOC__FOLDER.equals(eFeature)) {
    		setFolder((ExtDocModel.Folder)null); 
    		return;
    	}
    	if (ExtDocModelPackage.Literals.DOC__ENTRIES.equals(eFeature)) {
    		getEntries().clear(); 
    		return;
    	}
    	if (ExtDocModelPackage.Literals.DOC__SUB_DOCS.equals(eFeature)) {
    		getSubDocs().clear(); 
    		return;
    	}
    	if (ExtDocModelPackage.Literals.DOC__SUPER_DOCS.equals(eFeature)) {
    		getSuperDocs().clear(); 
    		return;
    	}
    	eDynamicUnset(eFeature);
    }

    @Override
    public String toString(){
		StringBuilder b = new StringBuilder();
		b.append(super.toString());
		b.append(" (");
		if (SmartEMFConfig.simpleStringRepresentations()) {
			b.append(getName());
		} else {
			b.append("name: ");
			b.append(getName());
		}
		b.append(")");
		return b.toString();
    }

 	@Override
    public Object eGet(EStructuralFeature eFeature){
    	if (ExtDocModelPackage.Literals.NAMED_ELEMENT__NAME.equals(eFeature))
    		return getName();
    	if (ExtDocModelPackage.Literals.DOC__FOLDER.equals(eFeature))
    		return getFolder();
    	if (ExtDocModelPackage.Literals.DOC__ENTRIES.equals(eFeature))
    		return getEntries();
    	if (ExtDocModelPackage.Literals.DOC__SUB_DOCS.equals(eFeature))
    		return getSubDocs();
    	if (ExtDocModelPackage.Literals.DOC__SUPER_DOCS.equals(eFeature))
    		return getSuperDocs();
    	return eDynamicGet(eFeature);
    }

    @Override
    public Object eGet(int featureID, boolean resolve, boolean coreType){
    	throw new UnsupportedOperationException("This method has been deactivated since it is not always safe to use.");
    }
    
    @Override
    public void eInverseAdd(Object otherEnd, EStructuralFeature feature) {
if (ExtDocModelPackage.Literals.DOC__FOLDER.equals(feature)) {
setFolderAsInverse((ExtDocModel.Folder) otherEnd); 
 	return;
			        }	
if (ExtDocModelPackage.Literals.DOC__ENTRIES.equals(feature)) {
	addEntriesAsInverse((ExtDocModel.Entry) otherEnd);
 	return;
			        }	
if (ExtDocModelPackage.Literals.DOC__SUB_DOCS.equals(feature)) {
	addSubDocsAsInverse((ExtDocModel.Doc) otherEnd);
 	return;
			        }	
if (ExtDocModelPackage.Literals.DOC__SUPER_DOCS.equals(feature)) {
	addSuperDocsAsInverse((ExtDocModel.Doc) otherEnd);
 	return;
			        }	
	    if(feature == null)
	    	return;
	    	
    	eDynamicInverseAdd(otherEnd, feature);
	    	}
    	
    @Override
	    	public void eInverseRemove(Object otherEnd, EStructuralFeature feature) {
if (ExtDocModelPackage.Literals.DOC__FOLDER.equals(feature)) {
setFolderAsInverse(null); 
 	return;
			        }
if (ExtDocModelPackage.Literals.DOC__ENTRIES.equals(feature)) {
	removeEntriesAsInverse((ExtDocModel.Entry) otherEnd);
 	return;
			        }
if (ExtDocModelPackage.Literals.DOC__SUB_DOCS.equals(feature)) {
	removeSubDocsAsInverse((ExtDocModel.Doc) otherEnd);
 	return;
			        }
if (ExtDocModelPackage.Literals.DOC__SUPER_DOCS.equals(feature)) {
	removeSuperDocsAsInverse((ExtDocModel.Doc) otherEnd);
 	return;
			        }
	    if(feature == null)
	    	return;
	    		    		
    	eDynamicInverseRemove(otherEnd, feature);
	    	}
    
    @Override
    /**
    * This method sets the resource and generates REMOVING_ADAPTER and ADD notifications
    */
    protected void setResourceOfContainments(Consumer<SmartObject> setResourceCall) {
    	for(Object obj : getEntries()) {
    		setResourceCall.accept(((SmartObject) obj));
	    		}
	    	}
	    	
	    	@Override
	    	/**
	    	* This method sets the resource and only generates REMOVING_ADAPTER notifications (no ADD messages)
	    	*/
    protected void setResourceOfContainmentsSilently(Resource r) { 		
    	for(Object obj : getEntries()) {
    		((SmartObject) obj).setResourceSilently(r);
	    		}
	    	}
}
