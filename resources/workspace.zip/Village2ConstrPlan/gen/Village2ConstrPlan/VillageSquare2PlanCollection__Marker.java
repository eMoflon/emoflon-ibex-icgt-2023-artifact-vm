package Village2ConstrPlan;

import runtime.RuntimePackage;
import Village2ConstrPlan.Village2ConstrPlanPackage;

import org.emoflon.smartemf.runtime.notification.SmartEMFNotification;
import org.emoflon.smartemf.runtime.SmartObject;
import org.emoflon.smartemf.runtime.collections.*;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EStructuralFeature;

public interface VillageSquare2PlanCollection__Marker extends EObject, runtime.TGGRuleApplication {
	
    public runtime.Protocol getProtocol();
    
    public void setProtocol(runtime.Protocol value);
    
    public Village.VillageSquare getCREATE__SRC__vs();
    
    public void setCREATE__SRC__vs(Village.VillageSquare value);
    
    public ConstructionPlan.PlanCollection getCREATE__TRG__pc();
    
    public void setCREATE__TRG__pc(ConstructionPlan.PlanCollection value);
    
    public Village2ConstrPlan.VillageSquare2PlanCollection getCREATE__CORR__vs2pl();
    
    public void setCREATE__CORR__vs2pl(Village2ConstrPlan.VillageSquare2PlanCollection value);
    

}
