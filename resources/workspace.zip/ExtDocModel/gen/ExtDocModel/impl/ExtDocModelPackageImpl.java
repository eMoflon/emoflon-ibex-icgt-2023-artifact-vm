package ExtDocModel.impl;

import ExtDocModel.NamedElement;
import ExtDocModel.Folder;
import ExtDocModel.Doc;
import ExtDocModel.Entry;
import ExtDocModel.Annotation;
import ExtDocModel.Glossary;
import ExtDocModel.GlossaryEntry;
import ExtDocModel.DocContainer;

import ExtDocModel.EntryType;

import ExtDocModel.ExtDocModelFactory;
import ExtDocModel.ExtDocModelPackage;


import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.ecore.EcorePackage;

import org.eclipse.emf.ecore.impl.EPackageImpl;

import org.emoflon.smartemf.runtime.SmartPackageImpl;

public class ExtDocModelPackageImpl extends SmartPackageImpl
		implements ExtDocModelPackage {
			
	private EClass namedElementEClass = null;
	private EAttribute namedElement_nameEAttribute = null;
	private EClass folderEClass = null;
	private EReference folder_docsEReference = null;
	private EReference folder_containerEReference = null;
	private EReference folder_subFolderEReference = null;
	private EReference folder_superFolderEReference = null;
	private EClass docEClass = null;
	private EReference doc_folderEReference = null;
	private EReference doc_entriesEReference = null;
	private EReference doc_subDocsEReference = null;
	private EReference doc_superDocsEReference = null;
	private EClass entryEClass = null;
	private EReference entry_docEReference = null;
	private EReference entry_annotationsEReference = null;
	private EReference entry_glossaryEntriesEReference = null;
	private EAttribute entry_typeEAttribute = null;
	private EClass annotationEClass = null;
	private EReference annotation_entryEReference = null;
	private EAttribute annotation_valueEAttribute = null;
	private EClass glossaryEClass = null;
	private EReference glossary_entriesEReference = null;
	private EReference glossary_containerEReference = null;
	private EClass glossaryEntryEClass = null;
	private EReference glossaryEntry_glossaryEReference = null;
	private EReference glossaryEntry_entriesEReference = null;
	private EClass docContainerEClass = null;
	private EReference docContainer_foldersEReference = null;
	private EReference docContainer_glossaryEReference = null;
	
	private EEnum entryTypeEEnum = null;
	

	private ExtDocModelPackageImpl() {
		super(eNS_URI, ExtDocModel.ExtDocModelFactory.eINSTANCE);
	}

	private static boolean isRegistered = false;
	private boolean isCreated = false;
	private boolean isInitialized = false;

	public static ExtDocModelPackage init() {
		if (isRegistered)
			return (ExtDocModelPackage) EPackage.Registry.INSTANCE
					.getEPackage(ExtDocModelPackage.eNS_URI);

		// Obtain or create and register package
		Object registeredExtDocModelPackage = EPackage.Registry.INSTANCE.get(eNS_URI);
		ExtDocModelPackageImpl theExtDocModelPackage = registeredExtDocModelPackage instanceof ExtDocModelPackageImpl
				? (ExtDocModelPackageImpl) registeredExtDocModelPackage
				: new ExtDocModelPackageImpl();

		isRegistered = true;

		// Create package meta-data objects
		theExtDocModelPackage.createPackageContents();

		// Initialize created meta-data
		theExtDocModelPackage.initializePackageContents();
		
		// Inject internal eOpposites to unidirectional references
		theExtDocModelPackage.injectDynamicOpposites();
		
		// Inject external references into foreign packages
		theExtDocModelPackage.injectExternalReferences();

		// Mark meta-data to indicate it can't be changed
		theExtDocModelPackage.freeze();

		// Update the registry and return the package
		EPackage.Registry.INSTANCE.put(ExtDocModelPackage.eNS_URI,
				theExtDocModelPackage);
				
		theExtDocModelPackage.fetchDynamicEStructuralFeaturesOfSuperTypes();
		return theExtDocModelPackage;
	}

	@Override
	public EClass getNamedElement() {
		return namedElementEClass;
	}
	@Override
	public EAttribute getNamedElement_Name() {
		return namedElement_nameEAttribute;	
	}
	@Override
	public EClass getFolder() {
		return folderEClass;
	}
	@Override
	public EReference getFolder_Docs() {
		return folder_docsEReference;	
	}
	@Override
	public EReference getFolder_Container() {
		return folder_containerEReference;	
	}
	@Override
	public EReference getFolder_SubFolder() {
		return folder_subFolderEReference;	
	}
	@Override
	public EReference getFolder_SuperFolder() {
		return folder_superFolderEReference;	
	}
	@Override
	public EClass getDoc() {
		return docEClass;
	}
	@Override
	public EReference getDoc_Folder() {
		return doc_folderEReference;	
	}
	@Override
	public EReference getDoc_Entries() {
		return doc_entriesEReference;	
	}
	@Override
	public EReference getDoc_SubDocs() {
		return doc_subDocsEReference;	
	}
	@Override
	public EReference getDoc_SuperDocs() {
		return doc_superDocsEReference;	
	}
	@Override
	public EClass getEntry() {
		return entryEClass;
	}
	@Override
	public EReference getEntry_Doc() {
		return entry_docEReference;	
	}
	@Override
	public EReference getEntry_Annotations() {
		return entry_annotationsEReference;	
	}
	@Override
	public EReference getEntry_GlossaryEntries() {
		return entry_glossaryEntriesEReference;	
	}
	@Override
	public EAttribute getEntry_Type() {
		return entry_typeEAttribute;	
	}
	@Override
	public EClass getAnnotation() {
		return annotationEClass;
	}
	@Override
	public EReference getAnnotation_Entry() {
		return annotation_entryEReference;	
	}
	@Override
	public EAttribute getAnnotation_Value() {
		return annotation_valueEAttribute;	
	}
	@Override
	public EClass getGlossary() {
		return glossaryEClass;
	}
	@Override
	public EReference getGlossary_Entries() {
		return glossary_entriesEReference;	
	}
	@Override
	public EReference getGlossary_Container() {
		return glossary_containerEReference;	
	}
	@Override
	public EClass getGlossaryEntry() {
		return glossaryEntryEClass;
	}
	@Override
	public EReference getGlossaryEntry_Glossary() {
		return glossaryEntry_glossaryEReference;	
	}
	@Override
	public EReference getGlossaryEntry_Entries() {
		return glossaryEntry_entriesEReference;	
	}
	@Override
	public EClass getDocContainer() {
		return docContainerEClass;
	}
	@Override
	public EReference getDocContainer_Folders() {
		return docContainer_foldersEReference;	
	}
	@Override
	public EReference getDocContainer_Glossary() {
		return docContainer_glossaryEReference;	
	}
	
	@Override
	public EEnum getEntryType() {
		return entryTypeEEnum;
	}
	

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ExtDocModel.ExtDocModelFactory getExtDocModelFactory() {
		return (ExtDocModel.ExtDocModelFactory) getEFactoryInstance();
	}

	public void createPackageContents() {
		if (isCreated)
			return;
		isCreated = true;

		// Create classes and their features
		namedElementEClass = createEClass(NAMED_ELEMENT);
		createEAttribute(namedElementEClass, NAMED_ELEMENT__NAME);
		namedElement_nameEAttribute = (EAttribute) namedElementEClass.getEStructuralFeatures().get(0);
		
		folderEClass = createEClass(FOLDER);
		createEReference(folderEClass, FOLDER__DOCS);
		folder_docsEReference = (EReference) folderEClass.getEStructuralFeatures().get(0);
		createEReference(folderEClass, FOLDER__CONTAINER);
		folder_containerEReference = (EReference) folderEClass.getEStructuralFeatures().get(1);
		createEReference(folderEClass, FOLDER__SUB_FOLDER);
		folder_subFolderEReference = (EReference) folderEClass.getEStructuralFeatures().get(2);
		createEReference(folderEClass, FOLDER__SUPER_FOLDER);
		folder_superFolderEReference = (EReference) folderEClass.getEStructuralFeatures().get(3);
		
		docEClass = createEClass(DOC);
		createEReference(docEClass, DOC__FOLDER);
		doc_folderEReference = (EReference) docEClass.getEStructuralFeatures().get(0);
		createEReference(docEClass, DOC__ENTRIES);
		doc_entriesEReference = (EReference) docEClass.getEStructuralFeatures().get(1);
		createEReference(docEClass, DOC__SUB_DOCS);
		doc_subDocsEReference = (EReference) docEClass.getEStructuralFeatures().get(2);
		createEReference(docEClass, DOC__SUPER_DOCS);
		doc_superDocsEReference = (EReference) docEClass.getEStructuralFeatures().get(3);
		
		entryEClass = createEClass(ENTRY);
		createEReference(entryEClass, ENTRY__DOC);
		entry_docEReference = (EReference) entryEClass.getEStructuralFeatures().get(0);
		createEReference(entryEClass, ENTRY__ANNOTATIONS);
		entry_annotationsEReference = (EReference) entryEClass.getEStructuralFeatures().get(1);
		createEReference(entryEClass, ENTRY__GLOSSARY_ENTRIES);
		entry_glossaryEntriesEReference = (EReference) entryEClass.getEStructuralFeatures().get(2);
		createEAttribute(entryEClass, ENTRY__TYPE);
		entry_typeEAttribute = (EAttribute) entryEClass.getEStructuralFeatures().get(3);
		
		annotationEClass = createEClass(ANNOTATION);
		createEReference(annotationEClass, ANNOTATION__ENTRY);
		annotation_entryEReference = (EReference) annotationEClass.getEStructuralFeatures().get(0);
		createEAttribute(annotationEClass, ANNOTATION__VALUE);
		annotation_valueEAttribute = (EAttribute) annotationEClass.getEStructuralFeatures().get(1);
		
		glossaryEClass = createEClass(GLOSSARY);
		createEReference(glossaryEClass, GLOSSARY__ENTRIES);
		glossary_entriesEReference = (EReference) glossaryEClass.getEStructuralFeatures().get(0);
		createEReference(glossaryEClass, GLOSSARY__CONTAINER);
		glossary_containerEReference = (EReference) glossaryEClass.getEStructuralFeatures().get(1);
		
		glossaryEntryEClass = createEClass(GLOSSARY_ENTRY);
		createEReference(glossaryEntryEClass, GLOSSARY_ENTRY__GLOSSARY);
		glossaryEntry_glossaryEReference = (EReference) glossaryEntryEClass.getEStructuralFeatures().get(0);
		createEReference(glossaryEntryEClass, GLOSSARY_ENTRY__ENTRIES);
		glossaryEntry_entriesEReference = (EReference) glossaryEntryEClass.getEStructuralFeatures().get(1);
		
		docContainerEClass = createEClass(DOC_CONTAINER);
		createEReference(docContainerEClass, DOC_CONTAINER__FOLDERS);
		docContainer_foldersEReference = (EReference) docContainerEClass.getEStructuralFeatures().get(0);
		createEReference(docContainerEClass, DOC_CONTAINER__GLOSSARY);
		docContainer_glossaryEReference = (EReference) docContainerEClass.getEStructuralFeatures().get(1);
		
		// Create enums
		entryTypeEEnum = createEEnum(ENTRY_TYPE);
		
		// Create data types
	}

	public void initializePackageContents() {
		if (isInitialized)
			return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);
		
		// Obtain other dependent packages

		// Create type parameters

		// Set bounds for type parameters

		// Add supertypes to classes
		folderEClass.getESuperTypes().add(this.getNamedElement());
		docEClass.getESuperTypes().add(this.getNamedElement());
		entryEClass.getESuperTypes().add(this.getNamedElement());
		glossaryEntryEClass.getESuperTypes().add(this.getNamedElement());

		// Initialize classes, features, and operations; add parameters
		initEClass(namedElementEClass, NamedElement.class, "NamedElement", IS_ABSTRACT, !IS_INTERFACE,
			IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getNamedElement_Name(), ecorePackage.getEString(),
			"name", null, 0, 1, NamedElement.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, IS_ID, IS_UNIQUE,
			!IS_DERIVED, IS_ORDERED);
		
		initEClass(folderEClass, Folder.class, "Folder", !IS_ABSTRACT, !IS_INTERFACE,
			IS_GENERATED_INSTANCE_CLASS);
		initEReference(getFolder_Docs(), this.getDoc(), this.getDoc_Folder(), 
			"docs", null, 1, -1, Folder.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getFolder_Container(), this.getDocContainer(), this.getDocContainer_Folders(), 
			"container", null, 0, 1, Folder.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getFolder_SubFolder(), this.getFolder(), this.getFolder_SuperFolder(), 
			"subFolder", null, 0, -1, Folder.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getFolder_SuperFolder(), this.getFolder(), this.getFolder_SubFolder(), 
			"superFolder", null, 0, 1, Folder.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
				
		initEClass(docEClass, Doc.class, "Doc", !IS_ABSTRACT, !IS_INTERFACE,
			IS_GENERATED_INSTANCE_CLASS);
		initEReference(getDoc_Folder(), this.getFolder(), this.getFolder_Docs(), 
			"folder", null, 0, 1, Doc.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getDoc_Entries(), this.getEntry(), this.getEntry_Doc(), 
			"entries", null, 0, -1, Doc.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getDoc_SubDocs(), this.getDoc(), this.getDoc_SuperDocs(), 
			"subDocs", null, 0, -1, Doc.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getDoc_SuperDocs(), this.getDoc(), this.getDoc_SubDocs(), 
			"superDocs", null, 0, -1, Doc.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
				
		initEClass(entryEClass, Entry.class, "Entry", !IS_ABSTRACT, !IS_INTERFACE,
			IS_GENERATED_INSTANCE_CLASS);
		initEReference(getEntry_Doc(), this.getDoc(), this.getDoc_Entries(), 
			"doc", null, 0, 1, Entry.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getEntry_Annotations(), this.getAnnotation(), this.getAnnotation_Entry(), 
			"annotations", null, 0, 2, Entry.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getEntry_GlossaryEntries(), this.getGlossaryEntry(), this.getGlossaryEntry_Entries(), 
			"glossaryEntries", null, 0, -1, Entry.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getEntry_Type(), this.getEntryType(),
			"type", "FIELD", 0, 1, Entry.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, IS_ID, IS_UNIQUE,
			!IS_DERIVED, IS_ORDERED);
		
		initEClass(annotationEClass, Annotation.class, "Annotation", !IS_ABSTRACT, !IS_INTERFACE,
			IS_GENERATED_INSTANCE_CLASS);
		initEReference(getAnnotation_Entry(), this.getEntry(), this.getEntry_Annotations(), 
			"entry", null, 0, 1, Annotation.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getAnnotation_Value(), ecorePackage.getEString(),
			"value", null, 0, 1, Annotation.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, IS_ID, IS_UNIQUE,
			!IS_DERIVED, IS_ORDERED);
		
		initEClass(glossaryEClass, Glossary.class, "Glossary", !IS_ABSTRACT, !IS_INTERFACE,
			IS_GENERATED_INSTANCE_CLASS);
		initEReference(getGlossary_Entries(), this.getGlossaryEntry(), this.getGlossaryEntry_Glossary(), 
			"entries", null, 0, -1, Glossary.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getGlossary_Container(), this.getDocContainer(), this.getDocContainer_Glossary(), 
			"container", null, 0, 1, Glossary.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
				
		initEClass(glossaryEntryEClass, GlossaryEntry.class, "GlossaryEntry", !IS_ABSTRACT, !IS_INTERFACE,
			IS_GENERATED_INSTANCE_CLASS);
		initEReference(getGlossaryEntry_Glossary(), this.getGlossary(), this.getGlossary_Entries(), 
			"glossary", null, 0, 1, GlossaryEntry.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getGlossaryEntry_Entries(), this.getEntry(), this.getEntry_GlossaryEntries(), 
			"entries", null, 0, -1, GlossaryEntry.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
				
		initEClass(docContainerEClass, DocContainer.class, "DocContainer", !IS_ABSTRACT, !IS_INTERFACE,
			IS_GENERATED_INSTANCE_CLASS);
		initEReference(getDocContainer_Folders(), this.getFolder(), this.getFolder_Container(), 
			"folders", null, 0, -1, DocContainer.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getDocContainer_Glossary(), this.getGlossary(), this.getGlossary_Container(), 
			"glossary", null, 0, 1, DocContainer.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, IS_RESOLVE_PROXIES,
			!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
				
		
		// Initialize enums and add enum literals
		initEEnum(entryTypeEEnum, EntryType.class, "EntryType");
		addEEnumLiteral(entryTypeEEnum, ExtDocModel.EntryType.FIELD);
		addEEnumLiteral(entryTypeEEnum, ExtDocModel.EntryType.METHOD);
		
		// Initialize data types
		
		// Create resource
		createResource(eNS_URI);
	}

} 

