package ExtType2Doc_ConcSync;

import ExtType2Doc_ConcSync.Project2DocContainer;
import ExtType2Doc_ConcSync.Package2Folder;
import ExtType2Doc_ConcSync.Type2Doc;
import ExtType2Doc_ConcSync.Method2Entry;
import ExtType2Doc_ConcSync.Param2Entry;
import ExtType2Doc_ConcSync.Field2Entry;
import ExtType2Doc_ConcSync.JDoc2Annotation;
import ExtType2Doc_ConcSync.ExtendingType2Doc__Marker;
import ExtType2Doc_ConcSync.Field2Entry__Marker;
import ExtType2Doc_ConcSync.Glossary__Marker;
import ExtType2Doc_ConcSync.GlossaryEntry__Marker;
import ExtType2Doc_ConcSync.GlossaryLink__Marker;
import ExtType2Doc_ConcSync.JDoc2Annotation__Marker;
import ExtType2Doc_ConcSync.Method2Entry__Marker;
import ExtType2Doc_ConcSync.Package2Folder__Marker;
import ExtType2Doc_ConcSync.Param2Entry__Marker;
import ExtType2Doc_ConcSync.Project2DocCont__Marker;
import ExtType2Doc_ConcSync.Type2Doc__Marker;

import org.eclipse.emf.ecore.EFactory;

public interface ExtType2Doc_ConcSyncFactory extends EFactory {

	ExtType2Doc_ConcSyncFactory eINSTANCE = ExtType2Doc_ConcSync.impl.ExtType2Doc_ConcSyncFactoryImpl.init();
	
	Project2DocContainer createProject2DocContainer();
	
	Package2Folder createPackage2Folder();
	
	Type2Doc createType2Doc();
	
	Method2Entry createMethod2Entry();
	
	Param2Entry createParam2Entry();
	
	Field2Entry createField2Entry();
	
	JDoc2Annotation createJDoc2Annotation();
	
	ExtendingType2Doc__Marker createExtendingType2Doc__Marker();
	
	Field2Entry__Marker createField2Entry__Marker();
	
	Glossary__Marker createGlossary__Marker();
	
	GlossaryEntry__Marker createGlossaryEntry__Marker();
	
	GlossaryLink__Marker createGlossaryLink__Marker();
	
	JDoc2Annotation__Marker createJDoc2Annotation__Marker();
	
	Method2Entry__Marker createMethod2Entry__Marker();
	
	Package2Folder__Marker createPackage2Folder__Marker();
	
	Param2Entry__Marker createParam2Entry__Marker();
	
	Project2DocCont__Marker createProject2DocCont__Marker();
	
	Type2Doc__Marker createType2Doc__Marker();
	
	
	ExtType2Doc_ConcSyncPackage getExtType2Doc_ConcSyncPackage();

}
