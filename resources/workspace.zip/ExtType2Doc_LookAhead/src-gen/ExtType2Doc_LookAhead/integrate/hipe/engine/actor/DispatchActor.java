package ExtType2Doc_LookAhead.integrate.hipe.engine.actor;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EObject;

import java.text.DecimalFormat;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.time.Duration;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.function.Consumer;

import akka.actor.AbstractActor;
import akka.actor.ActorRef;
import akka.stream.ActorMaterializer;
import akka.stream.javadsl.*;
import static akka.pattern.Patterns.ask;

import hipe.engine.util.HiPEMultiUtil;
import hipe.engine.util.IncUtil;
import hipe.engine.message.NewInput;
import hipe.engine.message.NoMoreInput;
import hipe.engine.message.input.ObjectAdded;
import hipe.engine.message.input.ObjectDeleted;
import hipe.engine.message.input.ReferenceAdded;
import hipe.engine.message.input.ReferenceDeleted;		
import hipe.engine.message.input.AttributeChanged;
import hipe.engine.message.input.NotificationContainer;

import hipe.generic.actor.junction.util.HiPEConfig;

public class DispatchActor extends AbstractActor {
	
	private int counter = 0;
	public long time = 0;
				
	private Map<String, ActorRef> name2actor;
	
	private Map<Object, Consumer<Object>> type2addConsumer = HiPEMultiUtil.createMap();
	private Map<Object, Consumer<Notification>> feature2setConsumer = HiPEMultiUtil.createMap();
	private Map<Object, Consumer<Notification>> feature2addEdgeConsumer = HiPEMultiUtil.createMap();
	private Map<Object, Consumer<Notification>> feature2removeEdgeConsumer = HiPEMultiUtil.createMap();
	
	private IncUtil incUtil;
	
	private ActorMaterializer materializer;
	
	public DispatchActor(Map<String, ActorRef> name2actor, IncUtil incUtil) {
		this.name2actor = name2actor;
		this.incUtil = incUtil;
		
		initializeAdd();
		initializeSet();
		initializeAddEdge();
		initializeRemoveEdge();
	
		materializer = ActorMaterializer.create(getContext());
	}
	
	private void initializeAdd() {
		type2addConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getExtendingType2Doc__Marker(), obj -> {
			ExtType2Doc_LookAhead.ExtendingType2Doc__Marker _extendingtype2doc__marker = (ExtType2Doc_LookAhead.ExtendingType2Doc__Marker) obj;
			incUtil.newMessage();
			name2actor.get("ExtendingType2Doc__Marker_object").tell(new ObjectAdded<ExtType2Doc_LookAhead.ExtendingType2Doc__Marker>(incUtil, _extendingtype2doc__marker), getSelf());
		});
		type2addConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getPackage2Folder(), obj -> {
			ExtType2Doc_LookAhead.Package2Folder _package2folder = (ExtType2Doc_LookAhead.Package2Folder) obj;
			incUtil.newMessage();
			name2actor.get("Package2Folder_object_SP0").tell(new ObjectAdded<ExtType2Doc_LookAhead.Package2Folder>(incUtil, _package2folder), getSelf());
			incUtil.newMessage();
			name2actor.get("Package2Folder_object_SP1").tell(new ObjectAdded<ExtType2Doc_LookAhead.Package2Folder>(incUtil, _package2folder), getSelf());
		});
		type2addConsumer.put(ExtTypeModel.ExtTypeModelPackage.eINSTANCE.getPackage(), obj -> {
			ExtTypeModel.Package _package = (ExtTypeModel.Package) obj;
			incUtil.newMessage();
			name2actor.get("Package_object_SP0").tell(new ObjectAdded<ExtTypeModel.Package>(incUtil, _package), getSelf());
			incUtil.newMessage();
			name2actor.get("Package_object_SP1").tell(new ObjectAdded<ExtTypeModel.Package>(incUtil, _package), getSelf());
		});
		type2addConsumer.put(ExtTypeModel.ExtTypeModelPackage.eINSTANCE.getField(), obj -> {
			ExtTypeModel.Field _field = (ExtTypeModel.Field) obj;
			incUtil.newMessage();
			name2actor.get("Field_object").tell(new ObjectAdded<ExtTypeModel.Field>(incUtil, _field), getSelf());
		});
		type2addConsumer.put(ExtDocModel.ExtDocModelPackage.eINSTANCE.getEntry(), obj -> {
			ExtDocModel.Entry _entry = (ExtDocModel.Entry) obj;
			incUtil.newMessage();
			name2actor.get("Entry_object").tell(new ObjectAdded<ExtDocModel.Entry>(incUtil, _entry), getSelf());
		});
		type2addConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getField2Entry__Marker(), obj -> {
			ExtType2Doc_LookAhead.Field2Entry__Marker _field2entry__marker = (ExtType2Doc_LookAhead.Field2Entry__Marker) obj;
			incUtil.newMessage();
			name2actor.get("Field2Entry__Marker_object").tell(new ObjectAdded<ExtType2Doc_LookAhead.Field2Entry__Marker>(incUtil, _field2entry__marker), getSelf());
		});
		type2addConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getParam2Entry(), obj -> {
			ExtType2Doc_LookAhead.Param2Entry _param2entry = (ExtType2Doc_LookAhead.Param2Entry) obj;
			incUtil.newMessage();
			name2actor.get("Param2Entry_object").tell(new ObjectAdded<ExtType2Doc_LookAhead.Param2Entry>(incUtil, _param2entry), getSelf());
		});
		type2addConsumer.put(ExtDocModel.ExtDocModelPackage.eINSTANCE.getFolder(), obj -> {
			ExtDocModel.Folder _folder = (ExtDocModel.Folder) obj;
			incUtil.newMessage();
			name2actor.get("Folder_object_SP0").tell(new ObjectAdded<ExtDocModel.Folder>(incUtil, _folder), getSelf());
			incUtil.newMessage();
			name2actor.get("Folder_object_SP1").tell(new ObjectAdded<ExtDocModel.Folder>(incUtil, _folder), getSelf());
		});
		type2addConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getType2Doc__Marker(), obj -> {
			ExtType2Doc_LookAhead.Type2Doc__Marker _type2doc__marker = (ExtType2Doc_LookAhead.Type2Doc__Marker) obj;
			incUtil.newMessage();
			name2actor.get("Type2Doc__Marker_object").tell(new ObjectAdded<ExtType2Doc_LookAhead.Type2Doc__Marker>(incUtil, _type2doc__marker), getSelf());
		});
		type2addConsumer.put(ExtDocModel.ExtDocModelPackage.eINSTANCE.getDoc(), obj -> {
			ExtDocModel.Doc _doc = (ExtDocModel.Doc) obj;
			incUtil.newMessage();
			name2actor.get("Doc_object_SP0").tell(new ObjectAdded<ExtDocModel.Doc>(incUtil, _doc), getSelf());
			incUtil.newMessage();
			name2actor.get("Doc_object_SP1").tell(new ObjectAdded<ExtDocModel.Doc>(incUtil, _doc), getSelf());
			incUtil.newMessage();
			name2actor.get("Doc_object_SP2").tell(new ObjectAdded<ExtDocModel.Doc>(incUtil, _doc), getSelf());
		});
		type2addConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getSubPackage2Folder__Marker(), obj -> {
			ExtType2Doc_LookAhead.SubPackage2Folder__Marker _subpackage2folder__marker = (ExtType2Doc_LookAhead.SubPackage2Folder__Marker) obj;
			incUtil.newMessage();
			name2actor.get("SubPackage2Folder__Marker_object").tell(new ObjectAdded<ExtType2Doc_LookAhead.SubPackage2Folder__Marker>(incUtil, _subpackage2folder__marker), getSelf());
		});
		type2addConsumer.put(ExtTypeModel.ExtTypeModelPackage.eINSTANCE.getType(), obj -> {
			ExtTypeModel.Type _type = (ExtTypeModel.Type) obj;
			incUtil.newMessage();
			name2actor.get("Type_object_SP0").tell(new ObjectAdded<ExtTypeModel.Type>(incUtil, _type), getSelf());
			incUtil.newMessage();
			name2actor.get("Type_object_SP1").tell(new ObjectAdded<ExtTypeModel.Type>(incUtil, _type), getSelf());
			incUtil.newMessage();
			name2actor.get("Type_object_SP2").tell(new ObjectAdded<ExtTypeModel.Type>(incUtil, _type), getSelf());
		});
		type2addConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getMethod2Entry__Marker(), obj -> {
			ExtType2Doc_LookAhead.Method2Entry__Marker _method2entry__marker = (ExtType2Doc_LookAhead.Method2Entry__Marker) obj;
			incUtil.newMessage();
			name2actor.get("Method2Entry__Marker_object").tell(new ObjectAdded<ExtType2Doc_LookAhead.Method2Entry__Marker>(incUtil, _method2entry__marker), getSelf());
		});
		type2addConsumer.put(ExtTypeModel.ExtTypeModelPackage.eINSTANCE.getMethod(), obj -> {
			ExtTypeModel.Method _method = (ExtTypeModel.Method) obj;
			incUtil.newMessage();
			name2actor.get("Method_object").tell(new ObjectAdded<ExtTypeModel.Method>(incUtil, _method), getSelf());
		});
		type2addConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getMethod2Entry(), obj -> {
			ExtType2Doc_LookAhead.Method2Entry _method2entry = (ExtType2Doc_LookAhead.Method2Entry) obj;
			incUtil.newMessage();
			name2actor.get("Method2Entry_object").tell(new ObjectAdded<ExtType2Doc_LookAhead.Method2Entry>(incUtil, _method2entry), getSelf());
		});
		type2addConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getField2Entry(), obj -> {
			ExtType2Doc_LookAhead.Field2Entry _field2entry = (ExtType2Doc_LookAhead.Field2Entry) obj;
			incUtil.newMessage();
			name2actor.get("Field2Entry_object").tell(new ObjectAdded<ExtType2Doc_LookAhead.Field2Entry>(incUtil, _field2entry), getSelf());
		});
		type2addConsumer.put(ExtTypeModel.ExtTypeModelPackage.eINSTANCE.getParameter(), obj -> {
			ExtTypeModel.Parameter _parameter = (ExtTypeModel.Parameter) obj;
			incUtil.newMessage();
			name2actor.get("Parameter_object").tell(new ObjectAdded<ExtTypeModel.Parameter>(incUtil, _parameter), getSelf());
		});
		type2addConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getPackage2Folder__Marker(), obj -> {
			ExtType2Doc_LookAhead.Package2Folder__Marker _package2folder__marker = (ExtType2Doc_LookAhead.Package2Folder__Marker) obj;
			incUtil.newMessage();
			name2actor.get("Package2Folder__Marker_object").tell(new ObjectAdded<ExtType2Doc_LookAhead.Package2Folder__Marker>(incUtil, _package2folder__marker), getSelf());
		});
		type2addConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getImplementingType2Doc__Marker(), obj -> {
			ExtType2Doc_LookAhead.ImplementingType2Doc__Marker _implementingtype2doc__marker = (ExtType2Doc_LookAhead.ImplementingType2Doc__Marker) obj;
			incUtil.newMessage();
			name2actor.get("ImplementingType2Doc__Marker_object").tell(new ObjectAdded<ExtType2Doc_LookAhead.ImplementingType2Doc__Marker>(incUtil, _implementingtype2doc__marker), getSelf());
		});
		type2addConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getType2Doc(), obj -> {
			ExtType2Doc_LookAhead.Type2Doc _type2doc = (ExtType2Doc_LookAhead.Type2Doc) obj;
			incUtil.newMessage();
			name2actor.get("Type2Doc_object_SP0").tell(new ObjectAdded<ExtType2Doc_LookAhead.Type2Doc>(incUtil, _type2doc), getSelf());
			incUtil.newMessage();
			name2actor.get("Type2Doc_object_SP1").tell(new ObjectAdded<ExtType2Doc_LookAhead.Type2Doc>(incUtil, _type2doc), getSelf());
			incUtil.newMessage();
			name2actor.get("Type2Doc_object_SP2").tell(new ObjectAdded<ExtType2Doc_LookAhead.Type2Doc>(incUtil, _type2doc), getSelf());
		});
		type2addConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getParam2Entry__Marker(), obj -> {
			ExtType2Doc_LookAhead.Param2Entry__Marker _param2entry__marker = (ExtType2Doc_LookAhead.Param2Entry__Marker) obj;
			incUtil.newMessage();
			name2actor.get("Param2Entry__Marker_object").tell(new ObjectAdded<ExtType2Doc_LookAhead.Param2Entry__Marker>(incUtil, _param2entry__marker), getSelf());
		});
	}
	
	private void initializeSet() {
		feature2setConsumer.put(ExtTypeModel.ExtTypeModelPackage.eINSTANCE.getNamedElement_Name(), notification -> {
			if(notification.getNotifier() instanceof ExtTypeModel.Package) {
				incUtil.newMessage();
				name2actor.get("Package_object_SP0").tell(new AttributeChanged<ExtTypeModel.NamedElement>(incUtil, (ExtTypeModel.NamedElement) notification.getNotifier(), notification.getOldValue()), getSelf());
			}
			if(notification.getNotifier() instanceof ExtTypeModel.Type) {
				incUtil.newMessage();
				name2actor.get("Type_object_SP1").tell(new AttributeChanged<ExtTypeModel.NamedElement>(incUtil, (ExtTypeModel.NamedElement) notification.getNotifier(), notification.getOldValue()), getSelf());
			}
			if(notification.getNotifier() instanceof ExtTypeModel.Type) {
				incUtil.newMessage();
				name2actor.get("Type_object_SP0").tell(new AttributeChanged<ExtTypeModel.NamedElement>(incUtil, (ExtTypeModel.NamedElement) notification.getNotifier(), notification.getOldValue()), getSelf());
			}
			if(notification.getNotifier() instanceof ExtTypeModel.Method) {
				incUtil.newMessage();
				name2actor.get("Method_object").tell(new AttributeChanged<ExtTypeModel.NamedElement>(incUtil, (ExtTypeModel.NamedElement) notification.getNotifier(), notification.getOldValue()), getSelf());
			}
			if(notification.getNotifier() instanceof ExtTypeModel.Type) {
				incUtil.newMessage();
				name2actor.get("Type_object_SP2").tell(new AttributeChanged<ExtTypeModel.NamedElement>(incUtil, (ExtTypeModel.NamedElement) notification.getNotifier(), notification.getOldValue()), getSelf());
			}
			if(notification.getNotifier() instanceof ExtTypeModel.Parameter) {
				incUtil.newMessage();
				name2actor.get("Parameter_object").tell(new AttributeChanged<ExtTypeModel.NamedElement>(incUtil, (ExtTypeModel.NamedElement) notification.getNotifier(), notification.getOldValue()), getSelf());
			}
			if(notification.getNotifier() instanceof ExtTypeModel.Field) {
				incUtil.newMessage();
				name2actor.get("Field_object").tell(new AttributeChanged<ExtTypeModel.NamedElement>(incUtil, (ExtTypeModel.NamedElement) notification.getNotifier(), notification.getOldValue()), getSelf());
			}
			if(notification.getNotifier() instanceof ExtTypeModel.Package) {
				incUtil.newMessage();
				name2actor.get("Package_object_SP1").tell(new AttributeChanged<ExtTypeModel.NamedElement>(incUtil, (ExtTypeModel.NamedElement) notification.getNotifier(), notification.getOldValue()), getSelf());
			}
		});
		
		feature2setConsumer.put(ExtDocModel.ExtDocModelPackage.eINSTANCE.getNamedElement_Name(), notification -> {
			if(notification.getNotifier() instanceof ExtDocModel.Doc) {
				incUtil.newMessage();
				name2actor.get("Doc_object_SP0").tell(new AttributeChanged<ExtDocModel.NamedElement>(incUtil, (ExtDocModel.NamedElement) notification.getNotifier(), notification.getOldValue()), getSelf());
			}
			if(notification.getNotifier() instanceof ExtDocModel.Doc) {
				incUtil.newMessage();
				name2actor.get("Doc_object_SP1").tell(new AttributeChanged<ExtDocModel.NamedElement>(incUtil, (ExtDocModel.NamedElement) notification.getNotifier(), notification.getOldValue()), getSelf());
			}
			if(notification.getNotifier() instanceof ExtDocModel.Folder) {
				incUtil.newMessage();
				name2actor.get("Folder_object_SP1").tell(new AttributeChanged<ExtDocModel.NamedElement>(incUtil, (ExtDocModel.NamedElement) notification.getNotifier(), notification.getOldValue()), getSelf());
			}
			if(notification.getNotifier() instanceof ExtDocModel.Entry) {
				incUtil.newMessage();
				name2actor.get("Entry_object").tell(new AttributeChanged<ExtDocModel.NamedElement>(incUtil, (ExtDocModel.NamedElement) notification.getNotifier(), notification.getOldValue()), getSelf());
			}
			if(notification.getNotifier() instanceof ExtDocModel.Doc) {
				incUtil.newMessage();
				name2actor.get("Doc_object_SP2").tell(new AttributeChanged<ExtDocModel.NamedElement>(incUtil, (ExtDocModel.NamedElement) notification.getNotifier(), notification.getOldValue()), getSelf());
			}
			if(notification.getNotifier() instanceof ExtDocModel.Folder) {
				incUtil.newMessage();
				name2actor.get("Folder_object_SP0").tell(new AttributeChanged<ExtDocModel.NamedElement>(incUtil, (ExtDocModel.NamedElement) notification.getNotifier(), notification.getOldValue()), getSelf());
			}
		});
		
		feature2setConsumer.put(ExtTypeModel.ExtTypeModelPackage.eINSTANCE.getType_Interface(), notification -> {
			if(notification.getNotifier() instanceof ExtTypeModel.Type) {
				incUtil.newMessage();
				name2actor.get("Type_object_SP1").tell(new AttributeChanged<ExtTypeModel.Type>(incUtil, (ExtTypeModel.Type) notification.getNotifier(), notification.getOldValue()), getSelf());
			}
			if(notification.getNotifier() instanceof ExtTypeModel.Type) {
				incUtil.newMessage();
				name2actor.get("Type_object_SP0").tell(new AttributeChanged<ExtTypeModel.Type>(incUtil, (ExtTypeModel.Type) notification.getNotifier(), notification.getOldValue()), getSelf());
			}
			if(notification.getNotifier() instanceof ExtTypeModel.Type) {
				incUtil.newMessage();
				name2actor.get("Type_object_SP2").tell(new AttributeChanged<ExtTypeModel.Type>(incUtil, (ExtTypeModel.Type) notification.getNotifier(), notification.getOldValue()), getSelf());
			}
		});
		
		feature2setConsumer.put(ExtDocModel.ExtDocModelPackage.eINSTANCE.getEntry_Type(), notification -> {
			if(notification.getNotifier() instanceof ExtDocModel.Entry) {
				incUtil.newMessage();
				name2actor.get("Entry_object").tell(new AttributeChanged<ExtDocModel.Entry>(incUtil, (ExtDocModel.Entry) notification.getNotifier(), notification.getOldValue()), getSelf());
			}
		});
		
	}
	
	private void initializeAddEdge() {
		feature2addEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getParam2Entry__Marker_CONTEXT__SRC__m(), notification -> {
			incUtil.newMessage();
			name2actor.get("Param2Entry__CONSISTENCY_89_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.Param2Entry__Marker, ExtTypeModel.Method>(incUtil,(ExtType2Doc_LookAhead.Param2Entry__Marker) notification.getNotifier(), (ExtTypeModel.Method) notification.getNewValue(), "ExtType2Doc_LookAhead.Param2Entry__Marker_CONTEXT__SRC__m_Method"), getSelf());
		});
		feature2addEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getImplementingType2Doc__Marker_CONTEXT__TRG__d(), notification -> {
			incUtil.newMessage();
			name2actor.get("ImplementingType2Doc__CONSISTENCY_53_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.ImplementingType2Doc__Marker, ExtDocModel.Doc>(incUtil,(ExtType2Doc_LookAhead.ImplementingType2Doc__Marker) notification.getNotifier(), (ExtDocModel.Doc) notification.getNewValue(), "ExtType2Doc_LookAhead.ImplementingType2Doc__Marker_CONTEXT__TRG__d_Doc"), getSelf());
		});
		feature2addEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getType2Doc_Source(), notification -> {
			incUtil.newMessage();
			name2actor.get("ExtendingType2Doc__BWD_5_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.Type2Doc, ExtTypeModel.Type>(incUtil,(ExtType2Doc_LookAhead.Type2Doc) notification.getNotifier(), (ExtTypeModel.Type) notification.getNewValue(), "ExtType2Doc_LookAhead.Type2Doc_source_Type"), getSelf());
			incUtil.newMessage();
			name2actor.get("ExtendingType2Doc__FWD_14_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.Type2Doc, ExtTypeModel.Type>(incUtil,(ExtType2Doc_LookAhead.Type2Doc) notification.getNotifier(), (ExtTypeModel.Type) notification.getNewValue(), "ExtType2Doc_LookAhead.Type2Doc_source_Type"), getSelf());
			incUtil.newMessage();
			name2actor.get("ExtendingType2Doc__CONSISTENCY_19_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.Type2Doc, ExtTypeModel.Type>(incUtil,(ExtType2Doc_LookAhead.Type2Doc) notification.getNotifier(), (ExtTypeModel.Type) notification.getNewValue(), "ExtType2Doc_LookAhead.Type2Doc_source_Type"), getSelf());
			incUtil.newMessage();
			name2actor.get("Field2Entry__BWD_25_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.Type2Doc, ExtTypeModel.Type>(incUtil,(ExtType2Doc_LookAhead.Type2Doc) notification.getNotifier(), (ExtTypeModel.Type) notification.getNewValue(), "ExtType2Doc_LookAhead.Type2Doc_source_Type"), getSelf());
			incUtil.newMessage();
			name2actor.get("Field2Entry__FWD_31_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.Type2Doc, ExtTypeModel.Type>(incUtil,(ExtType2Doc_LookAhead.Type2Doc) notification.getNotifier(), (ExtTypeModel.Type) notification.getNewValue(), "ExtType2Doc_LookAhead.Type2Doc_source_Type"), getSelf());
			incUtil.newMessage();
			name2actor.get("ImplementingType2Doc__BWD_40_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.Type2Doc, ExtTypeModel.Type>(incUtil,(ExtType2Doc_LookAhead.Type2Doc) notification.getNotifier(), (ExtTypeModel.Type) notification.getNewValue(), "ExtType2Doc_LookAhead.Type2Doc_source_Type"), getSelf());
			incUtil.newMessage();
			name2actor.get("ImplementingType2Doc__BWD_40_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.Type2Doc, ExtTypeModel.Type>(incUtil,(ExtType2Doc_LookAhead.Type2Doc) notification.getNotifier(), (ExtTypeModel.Type) notification.getNewValue(), "ExtType2Doc_LookAhead.Type2Doc_source_Type"), getSelf());
			incUtil.newMessage();
			name2actor.get("ImplementingType2Doc__FWD_48_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.Type2Doc, ExtTypeModel.Type>(incUtil,(ExtType2Doc_LookAhead.Type2Doc) notification.getNotifier(), (ExtTypeModel.Type) notification.getNewValue(), "ExtType2Doc_LookAhead.Type2Doc_source_Type"), getSelf());
			incUtil.newMessage();
			name2actor.get("ImplementingType2Doc__FWD_48_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.Type2Doc, ExtTypeModel.Type>(incUtil,(ExtType2Doc_LookAhead.Type2Doc) notification.getNotifier(), (ExtTypeModel.Type) notification.getNewValue(), "ExtType2Doc_LookAhead.Type2Doc_source_Type"), getSelf());
			incUtil.newMessage();
			name2actor.get("Method2Entry__BWD_58_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.Type2Doc, ExtTypeModel.Type>(incUtil,(ExtType2Doc_LookAhead.Type2Doc) notification.getNotifier(), (ExtTypeModel.Type) notification.getNewValue(), "ExtType2Doc_LookAhead.Type2Doc_source_Type"), getSelf());
			incUtil.newMessage();
			name2actor.get("Method2Entry__FWD_64_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.Type2Doc, ExtTypeModel.Type>(incUtil,(ExtType2Doc_LookAhead.Type2Doc) notification.getNotifier(), (ExtTypeModel.Type) notification.getNewValue(), "ExtType2Doc_LookAhead.Type2Doc_source_Type"), getSelf());
			incUtil.newMessage();
			name2actor.get("Type2Doc__CONSISTENCY_119_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.Type2Doc, ExtTypeModel.Type>(incUtil,(ExtType2Doc_LookAhead.Type2Doc) notification.getNotifier(), (ExtTypeModel.Type) notification.getNewValue(), "ExtType2Doc_LookAhead.Type2Doc_source_Type"), getSelf());
		});
		feature2addEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getPackage2Folder__Marker_CREATE__TRG__f(), notification -> {
			incUtil.newMessage();
			name2actor.get("Package2Folder__CONSISTENCY_80_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.Package2Folder__Marker, ExtDocModel.Folder>(incUtil,(ExtType2Doc_LookAhead.Package2Folder__Marker) notification.getNotifier(), (ExtDocModel.Folder) notification.getNewValue(), "ExtType2Doc_LookAhead.Package2Folder__Marker_CREATE__TRG__f_Folder"), getSelf());
		});
		feature2addEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getPackage2Folder__Marker_CREATE__CORR__p2f(), notification -> {
			incUtil.newMessage();
			name2actor.get("Package2Folder__CONSISTENCY_80_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.Package2Folder__Marker, ExtType2Doc_LookAhead.Package2Folder>(incUtil,(ExtType2Doc_LookAhead.Package2Folder__Marker) notification.getNotifier(), (ExtType2Doc_LookAhead.Package2Folder) notification.getNewValue(), "ExtType2Doc_LookAhead.Package2Folder__Marker_CREATE__CORR__p2f_Package2Folder"), getSelf());
		});
		feature2addEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getImplementingType2Doc__Marker_CONTEXT__TRG__id(), notification -> {
			incUtil.newMessage();
			name2actor.get("ImplementingType2Doc__CONSISTENCY_53_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.ImplementingType2Doc__Marker, ExtDocModel.Doc>(incUtil,(ExtType2Doc_LookAhead.ImplementingType2Doc__Marker) notification.getNotifier(), (ExtDocModel.Doc) notification.getNewValue(), "ExtType2Doc_LookAhead.ImplementingType2Doc__Marker_CONTEXT__TRG__id_Doc"), getSelf());
		});
		feature2addEdgeConsumer.put(ExtDocModel.ExtDocModelPackage.eINSTANCE.getDoc_SuperDocs(), notification -> {
			incUtil.newMessage();
			name2actor.get("ExtendingType2Doc__TRG_1_localSearch").tell(new ReferenceAdded<ExtDocModel.Doc, ExtDocModel.Doc>(incUtil,(ExtDocModel.Doc) notification.getNotifier(), (ExtDocModel.Doc) notification.getNewValue(), "ExtDocModel.Doc_superDocs_Doc"), getSelf());
			incUtil.newMessage();
			name2actor.get("ImplementingType2Doc__TRG_37_localSearch").tell(new ReferenceAdded<ExtDocModel.Doc, ExtDocModel.Doc>(incUtil,(ExtDocModel.Doc) notification.getNotifier(), (ExtDocModel.Doc) notification.getNewValue(), "ExtDocModel.Doc_superDocs_Doc"), getSelf());
		});
		feature2addEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getPackage2Folder_Target(), notification -> {
			incUtil.newMessage();
			name2actor.get("ExtendingType2Doc__BWD_5_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.Package2Folder, ExtDocModel.Folder>(incUtil,(ExtType2Doc_LookAhead.Package2Folder) notification.getNotifier(), (ExtDocModel.Folder) notification.getNewValue(), "ExtType2Doc_LookAhead.Package2Folder_target_Folder"), getSelf());
			incUtil.newMessage();
			name2actor.get("ExtendingType2Doc__FWD_14_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.Package2Folder, ExtDocModel.Folder>(incUtil,(ExtType2Doc_LookAhead.Package2Folder) notification.getNotifier(), (ExtDocModel.Folder) notification.getNewValue(), "ExtType2Doc_LookAhead.Package2Folder_target_Folder"), getSelf());
			incUtil.newMessage();
			name2actor.get("Package2Folder__CONSISTENCY_80_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.Package2Folder, ExtDocModel.Folder>(incUtil,(ExtType2Doc_LookAhead.Package2Folder) notification.getNotifier(), (ExtDocModel.Folder) notification.getNewValue(), "ExtType2Doc_LookAhead.Package2Folder_target_Folder"), getSelf());
			incUtil.newMessage();
			name2actor.get("SubPackage2Folder__BWD_95_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.Package2Folder, ExtDocModel.Folder>(incUtil,(ExtType2Doc_LookAhead.Package2Folder) notification.getNotifier(), (ExtDocModel.Folder) notification.getNewValue(), "ExtType2Doc_LookAhead.Package2Folder_target_Folder"), getSelf());
			incUtil.newMessage();
			name2actor.get("SubPackage2Folder__FWD_101_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.Package2Folder, ExtDocModel.Folder>(incUtil,(ExtType2Doc_LookAhead.Package2Folder) notification.getNotifier(), (ExtDocModel.Folder) notification.getNewValue(), "ExtType2Doc_LookAhead.Package2Folder_target_Folder"), getSelf());
			incUtil.newMessage();
			name2actor.get("SubPackage2Folder__CONSISTENCY_104_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.Package2Folder, ExtDocModel.Folder>(incUtil,(ExtType2Doc_LookAhead.Package2Folder) notification.getNotifier(), (ExtDocModel.Folder) notification.getNewValue(), "ExtType2Doc_LookAhead.Package2Folder_target_Folder"), getSelf());
			incUtil.newMessage();
			name2actor.get("Type2Doc__BWD_110_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.Package2Folder, ExtDocModel.Folder>(incUtil,(ExtType2Doc_LookAhead.Package2Folder) notification.getNotifier(), (ExtDocModel.Folder) notification.getNewValue(), "ExtType2Doc_LookAhead.Package2Folder_target_Folder"), getSelf());
			incUtil.newMessage();
			name2actor.get("Type2Doc__FWD_116_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.Package2Folder, ExtDocModel.Folder>(incUtil,(ExtType2Doc_LookAhead.Package2Folder) notification.getNotifier(), (ExtDocModel.Folder) notification.getNewValue(), "ExtType2Doc_LookAhead.Package2Folder_target_Folder"), getSelf());
		});
		feature2addEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getImplementingType2Doc__Marker_CONTEXT__SRC__t(), notification -> {
			incUtil.newMessage();
			name2actor.get("ImplementingType2Doc__CONSISTENCY_53_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.ImplementingType2Doc__Marker, ExtTypeModel.Type>(incUtil,(ExtType2Doc_LookAhead.ImplementingType2Doc__Marker) notification.getNotifier(), (ExtTypeModel.Type) notification.getNewValue(), "ExtType2Doc_LookAhead.ImplementingType2Doc__Marker_CONTEXT__SRC__t_Type"), getSelf());
		});
		feature2addEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getType2Doc__Marker_CREATE__CORR__t2d(), notification -> {
			incUtil.newMessage();
			name2actor.get("Type2Doc__CONSISTENCY_119_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.Type2Doc__Marker, ExtType2Doc_LookAhead.Type2Doc>(incUtil,(ExtType2Doc_LookAhead.Type2Doc__Marker) notification.getNotifier(), (ExtType2Doc_LookAhead.Type2Doc) notification.getNewValue(), "ExtType2Doc_LookAhead.Type2Doc__Marker_CREATE__CORR__t2d_Type2Doc"), getSelf());
		});
		feature2addEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getField2Entry__Marker_CREATE__TRG__e(), notification -> {
			incUtil.newMessage();
			name2actor.get("Field2Entry__CONSISTENCY_34_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.Field2Entry__Marker, ExtDocModel.Entry>(incUtil,(ExtType2Doc_LookAhead.Field2Entry__Marker) notification.getNotifier(), (ExtDocModel.Entry) notification.getNewValue(), "ExtType2Doc_LookAhead.Field2Entry__Marker_CREATE__TRG__e_Entry"), getSelf());
		});
		feature2addEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getParam2Entry__Marker_CONTEXT__TRG__e(), notification -> {
			incUtil.newMessage();
			name2actor.get("Param2Entry__CONSISTENCY_89_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.Param2Entry__Marker, ExtDocModel.Entry>(incUtil,(ExtType2Doc_LookAhead.Param2Entry__Marker) notification.getNotifier(), (ExtDocModel.Entry) notification.getNewValue(), "ExtType2Doc_LookAhead.Param2Entry__Marker_CONTEXT__TRG__e_Entry"), getSelf());
		});
		feature2addEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getField2Entry__Marker_CREATE__SRC__f(), notification -> {
			incUtil.newMessage();
			name2actor.get("Field2Entry__CONSISTENCY_34_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.Field2Entry__Marker, ExtTypeModel.Field>(incUtil,(ExtType2Doc_LookAhead.Field2Entry__Marker) notification.getNotifier(), (ExtTypeModel.Field) notification.getNewValue(), "ExtType2Doc_LookAhead.Field2Entry__Marker_CREATE__SRC__f_Field"), getSelf());
		});
		feature2addEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getSubPackage2Folder__Marker_CONTEXT__SRC__p(), notification -> {
			incUtil.newMessage();
			name2actor.get("SubPackage2Folder__CONSISTENCY_104_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.SubPackage2Folder__Marker, ExtTypeModel.Package>(incUtil,(ExtType2Doc_LookAhead.SubPackage2Folder__Marker) notification.getNotifier(), (ExtTypeModel.Package) notification.getNewValue(), "ExtType2Doc_LookAhead.SubPackage2Folder__Marker_CONTEXT__SRC__p_Package"), getSelf());
		});
		feature2addEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getExtendingType2Doc__Marker_CONTEXT__SRC__t(), notification -> {
			incUtil.newMessage();
			name2actor.get("ExtendingType2Doc__CONSISTENCY_19_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.ExtendingType2Doc__Marker, ExtTypeModel.Type>(incUtil,(ExtType2Doc_LookAhead.ExtendingType2Doc__Marker) notification.getNotifier(), (ExtTypeModel.Type) notification.getNewValue(), "ExtType2Doc_LookAhead.ExtendingType2Doc__Marker_CONTEXT__SRC__t_Type"), getSelf());
		});
		feature2addEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getField2Entry_Target(), notification -> {
			incUtil.newMessage();
			name2actor.get("Field2Entry__CONSISTENCY_34_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.Field2Entry, ExtDocModel.Entry>(incUtil,(ExtType2Doc_LookAhead.Field2Entry) notification.getNotifier(), (ExtDocModel.Entry) notification.getNewValue(), "ExtType2Doc_LookAhead.Field2Entry_target_Entry"), getSelf());
		});
		feature2addEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getSubPackage2Folder__Marker_CREATE__CORR__sp2f(), notification -> {
			incUtil.newMessage();
			name2actor.get("SubPackage2Folder__CONSISTENCY_104_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.SubPackage2Folder__Marker, ExtType2Doc_LookAhead.Package2Folder>(incUtil,(ExtType2Doc_LookAhead.SubPackage2Folder__Marker) notification.getNotifier(), (ExtType2Doc_LookAhead.Package2Folder) notification.getNewValue(), "ExtType2Doc_LookAhead.SubPackage2Folder__Marker_CREATE__CORR__sp2f_Package2Folder"), getSelf());
		});
		feature2addEdgeConsumer.put(ExtTypeModel.ExtTypeModelPackage.eINSTANCE.getType_InheritsFrom(), notification -> {
			incUtil.newMessage();
			name2actor.get("ExtendingType2Doc__SRC_10_localSearch").tell(new ReferenceAdded<ExtTypeModel.Type, ExtTypeModel.Type>(incUtil,(ExtTypeModel.Type) notification.getNotifier(), (ExtTypeModel.Type) notification.getNewValue(), "ExtTypeModel.Type_inheritsFrom_Type"), getSelf());
			incUtil.newMessage();
			name2actor.get("ImplementingType2Doc__SRC_45_localSearch").tell(new ReferenceAdded<ExtTypeModel.Type, ExtTypeModel.Type>(incUtil,(ExtTypeModel.Type) notification.getNotifier(), (ExtTypeModel.Type) notification.getNewValue(), "ExtTypeModel.Type_inheritsFrom_Type"), getSelf());
		});
		feature2addEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getType2Doc_Target(), notification -> {
			incUtil.newMessage();
			name2actor.get("ExtendingType2Doc__BWD_5_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.Type2Doc, ExtDocModel.Doc>(incUtil,(ExtType2Doc_LookAhead.Type2Doc) notification.getNotifier(), (ExtDocModel.Doc) notification.getNewValue(), "ExtType2Doc_LookAhead.Type2Doc_target_Doc"), getSelf());
			incUtil.newMessage();
			name2actor.get("ExtendingType2Doc__FWD_14_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.Type2Doc, ExtDocModel.Doc>(incUtil,(ExtType2Doc_LookAhead.Type2Doc) notification.getNotifier(), (ExtDocModel.Doc) notification.getNewValue(), "ExtType2Doc_LookAhead.Type2Doc_target_Doc"), getSelf());
			incUtil.newMessage();
			name2actor.get("ExtendingType2Doc__CONSISTENCY_19_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.Type2Doc, ExtDocModel.Doc>(incUtil,(ExtType2Doc_LookAhead.Type2Doc) notification.getNotifier(), (ExtDocModel.Doc) notification.getNewValue(), "ExtType2Doc_LookAhead.Type2Doc_target_Doc"), getSelf());
			incUtil.newMessage();
			name2actor.get("Field2Entry__BWD_25_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.Type2Doc, ExtDocModel.Doc>(incUtil,(ExtType2Doc_LookAhead.Type2Doc) notification.getNotifier(), (ExtDocModel.Doc) notification.getNewValue(), "ExtType2Doc_LookAhead.Type2Doc_target_Doc"), getSelf());
			incUtil.newMessage();
			name2actor.get("Field2Entry__FWD_31_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.Type2Doc, ExtDocModel.Doc>(incUtil,(ExtType2Doc_LookAhead.Type2Doc) notification.getNotifier(), (ExtDocModel.Doc) notification.getNewValue(), "ExtType2Doc_LookAhead.Type2Doc_target_Doc"), getSelf());
			incUtil.newMessage();
			name2actor.get("ImplementingType2Doc__BWD_40_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.Type2Doc, ExtDocModel.Doc>(incUtil,(ExtType2Doc_LookAhead.Type2Doc) notification.getNotifier(), (ExtDocModel.Doc) notification.getNewValue(), "ExtType2Doc_LookAhead.Type2Doc_target_Doc"), getSelf());
			incUtil.newMessage();
			name2actor.get("ImplementingType2Doc__BWD_40_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.Type2Doc, ExtDocModel.Doc>(incUtil,(ExtType2Doc_LookAhead.Type2Doc) notification.getNotifier(), (ExtDocModel.Doc) notification.getNewValue(), "ExtType2Doc_LookAhead.Type2Doc_target_Doc"), getSelf());
			incUtil.newMessage();
			name2actor.get("ImplementingType2Doc__FWD_48_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.Type2Doc, ExtDocModel.Doc>(incUtil,(ExtType2Doc_LookAhead.Type2Doc) notification.getNotifier(), (ExtDocModel.Doc) notification.getNewValue(), "ExtType2Doc_LookAhead.Type2Doc_target_Doc"), getSelf());
			incUtil.newMessage();
			name2actor.get("ImplementingType2Doc__FWD_48_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.Type2Doc, ExtDocModel.Doc>(incUtil,(ExtType2Doc_LookAhead.Type2Doc) notification.getNotifier(), (ExtDocModel.Doc) notification.getNewValue(), "ExtType2Doc_LookAhead.Type2Doc_target_Doc"), getSelf());
			incUtil.newMessage();
			name2actor.get("Method2Entry__BWD_58_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.Type2Doc, ExtDocModel.Doc>(incUtil,(ExtType2Doc_LookAhead.Type2Doc) notification.getNotifier(), (ExtDocModel.Doc) notification.getNewValue(), "ExtType2Doc_LookAhead.Type2Doc_target_Doc"), getSelf());
			incUtil.newMessage();
			name2actor.get("Method2Entry__FWD_64_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.Type2Doc, ExtDocModel.Doc>(incUtil,(ExtType2Doc_LookAhead.Type2Doc) notification.getNotifier(), (ExtDocModel.Doc) notification.getNewValue(), "ExtType2Doc_LookAhead.Type2Doc_target_Doc"), getSelf());
			incUtil.newMessage();
			name2actor.get("Type2Doc__CONSISTENCY_119_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.Type2Doc, ExtDocModel.Doc>(incUtil,(ExtType2Doc_LookAhead.Type2Doc) notification.getNotifier(), (ExtDocModel.Doc) notification.getNewValue(), "ExtType2Doc_LookAhead.Type2Doc_target_Doc"), getSelf());
		});
		feature2addEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getSubPackage2Folder__Marker_CONTEXT__TRG__f(), notification -> {
			incUtil.newMessage();
			name2actor.get("SubPackage2Folder__CONSISTENCY_104_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.SubPackage2Folder__Marker, ExtDocModel.Folder>(incUtil,(ExtType2Doc_LookAhead.SubPackage2Folder__Marker) notification.getNotifier(), (ExtDocModel.Folder) notification.getNewValue(), "ExtType2Doc_LookAhead.SubPackage2Folder__Marker_CONTEXT__TRG__f_Folder"), getSelf());
		});
		feature2addEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getSubPackage2Folder__Marker_CREATE__TRG__sf(), notification -> {
			incUtil.newMessage();
			name2actor.get("SubPackage2Folder__CONSISTENCY_104_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.SubPackage2Folder__Marker, ExtDocModel.Folder>(incUtil,(ExtType2Doc_LookAhead.SubPackage2Folder__Marker) notification.getNotifier(), (ExtDocModel.Folder) notification.getNewValue(), "ExtType2Doc_LookAhead.SubPackage2Folder__Marker_CREATE__TRG__sf_Folder"), getSelf());
		});
		feature2addEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getImplementingType2Doc__Marker_CONTEXT__CORR__t2d(), notification -> {
			incUtil.newMessage();
			name2actor.get("ImplementingType2Doc__CONSISTENCY_53_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.ImplementingType2Doc__Marker, ExtType2Doc_LookAhead.Type2Doc>(incUtil,(ExtType2Doc_LookAhead.ImplementingType2Doc__Marker) notification.getNotifier(), (ExtType2Doc_LookAhead.Type2Doc) notification.getNewValue(), "ExtType2Doc_LookAhead.ImplementingType2Doc__Marker_CONTEXT__CORR__t2d_Type2Doc"), getSelf());
		});
		feature2addEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getParam2Entry__Marker_CREATE__SRC__p(), notification -> {
			incUtil.newMessage();
			name2actor.get("Param2Entry__CONSISTENCY_89_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.Param2Entry__Marker, ExtTypeModel.Parameter>(incUtil,(ExtType2Doc_LookAhead.Param2Entry__Marker) notification.getNotifier(), (ExtTypeModel.Parameter) notification.getNewValue(), "ExtType2Doc_LookAhead.Param2Entry__Marker_CREATE__SRC__p_Parameter"), getSelf());
		});
		feature2addEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getType2Doc__Marker_CREATE__TRG__d(), notification -> {
			incUtil.newMessage();
			name2actor.get("Type2Doc__CONSISTENCY_119_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.Type2Doc__Marker, ExtDocModel.Doc>(incUtil,(ExtType2Doc_LookAhead.Type2Doc__Marker) notification.getNotifier(), (ExtDocModel.Doc) notification.getNewValue(), "ExtType2Doc_LookAhead.Type2Doc__Marker_CREATE__TRG__d_Doc"), getSelf());
		});
		feature2addEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getMethod2Entry__Marker_CONTEXT__SRC__t(), notification -> {
			incUtil.newMessage();
			name2actor.get("Method2Entry__CONSISTENCY_67_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.Method2Entry__Marker, ExtTypeModel.Type>(incUtil,(ExtType2Doc_LookAhead.Method2Entry__Marker) notification.getNotifier(), (ExtTypeModel.Type) notification.getNewValue(), "ExtType2Doc_LookAhead.Method2Entry__Marker_CONTEXT__SRC__t_Type"), getSelf());
		});
		feature2addEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getParam2Entry_Source(), notification -> {
			incUtil.newMessage();
			name2actor.get("Param2Entry__CONSISTENCY_89_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.Param2Entry, ExtTypeModel.Parameter>(incUtil,(ExtType2Doc_LookAhead.Param2Entry) notification.getNotifier(), (ExtTypeModel.Parameter) notification.getNewValue(), "ExtType2Doc_LookAhead.Param2Entry_source_Parameter"), getSelf());
		});
		feature2addEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getField2Entry__Marker_CONTEXT__CORR__t2d(), notification -> {
			incUtil.newMessage();
			name2actor.get("Field2Entry__CONSISTENCY_34_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.Field2Entry__Marker, ExtType2Doc_LookAhead.Type2Doc>(incUtil,(ExtType2Doc_LookAhead.Field2Entry__Marker) notification.getNotifier(), (ExtType2Doc_LookAhead.Type2Doc) notification.getNewValue(), "ExtType2Doc_LookAhead.Field2Entry__Marker_CONTEXT__CORR__t2d_Type2Doc"), getSelf());
		});
		feature2addEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getMethod2Entry_Source(), notification -> {
			incUtil.newMessage();
			name2actor.get("Method2Entry__CONSISTENCY_67_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.Method2Entry, ExtTypeModel.Method>(incUtil,(ExtType2Doc_LookAhead.Method2Entry) notification.getNotifier(), (ExtTypeModel.Method) notification.getNewValue(), "ExtType2Doc_LookAhead.Method2Entry_source_Method"), getSelf());
			incUtil.newMessage();
			name2actor.get("Param2Entry__FWD_86_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.Method2Entry, ExtTypeModel.Method>(incUtil,(ExtType2Doc_LookAhead.Method2Entry) notification.getNotifier(), (ExtTypeModel.Method) notification.getNewValue(), "ExtType2Doc_LookAhead.Method2Entry_source_Method"), getSelf());
		});
		feature2addEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getType2Doc__Marker_CONTEXT__CORR__p2f(), notification -> {
			incUtil.newMessage();
			name2actor.get("Type2Doc__CONSISTENCY_119_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.Type2Doc__Marker, ExtType2Doc_LookAhead.Package2Folder>(incUtil,(ExtType2Doc_LookAhead.Type2Doc__Marker) notification.getNotifier(), (ExtType2Doc_LookAhead.Package2Folder) notification.getNewValue(), "ExtType2Doc_LookAhead.Type2Doc__Marker_CONTEXT__CORR__p2f_Package2Folder"), getSelf());
		});
		feature2addEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getPackage2Folder_Source(), notification -> {
			incUtil.newMessage();
			name2actor.get("ExtendingType2Doc__BWD_5_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.Package2Folder, ExtTypeModel.Package>(incUtil,(ExtType2Doc_LookAhead.Package2Folder) notification.getNotifier(), (ExtTypeModel.Package) notification.getNewValue(), "ExtType2Doc_LookAhead.Package2Folder_source_Package"), getSelf());
			incUtil.newMessage();
			name2actor.get("ExtendingType2Doc__FWD_14_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.Package2Folder, ExtTypeModel.Package>(incUtil,(ExtType2Doc_LookAhead.Package2Folder) notification.getNotifier(), (ExtTypeModel.Package) notification.getNewValue(), "ExtType2Doc_LookAhead.Package2Folder_source_Package"), getSelf());
			incUtil.newMessage();
			name2actor.get("Package2Folder__CONSISTENCY_80_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.Package2Folder, ExtTypeModel.Package>(incUtil,(ExtType2Doc_LookAhead.Package2Folder) notification.getNotifier(), (ExtTypeModel.Package) notification.getNewValue(), "ExtType2Doc_LookAhead.Package2Folder_source_Package"), getSelf());
			incUtil.newMessage();
			name2actor.get("SubPackage2Folder__BWD_95_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.Package2Folder, ExtTypeModel.Package>(incUtil,(ExtType2Doc_LookAhead.Package2Folder) notification.getNotifier(), (ExtTypeModel.Package) notification.getNewValue(), "ExtType2Doc_LookAhead.Package2Folder_source_Package"), getSelf());
			incUtil.newMessage();
			name2actor.get("SubPackage2Folder__FWD_101_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.Package2Folder, ExtTypeModel.Package>(incUtil,(ExtType2Doc_LookAhead.Package2Folder) notification.getNotifier(), (ExtTypeModel.Package) notification.getNewValue(), "ExtType2Doc_LookAhead.Package2Folder_source_Package"), getSelf());
			incUtil.newMessage();
			name2actor.get("SubPackage2Folder__CONSISTENCY_104_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.Package2Folder, ExtTypeModel.Package>(incUtil,(ExtType2Doc_LookAhead.Package2Folder) notification.getNotifier(), (ExtTypeModel.Package) notification.getNewValue(), "ExtType2Doc_LookAhead.Package2Folder_source_Package"), getSelf());
			incUtil.newMessage();
			name2actor.get("Type2Doc__BWD_110_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.Package2Folder, ExtTypeModel.Package>(incUtil,(ExtType2Doc_LookAhead.Package2Folder) notification.getNotifier(), (ExtTypeModel.Package) notification.getNewValue(), "ExtType2Doc_LookAhead.Package2Folder_source_Package"), getSelf());
			incUtil.newMessage();
			name2actor.get("Type2Doc__FWD_116_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.Package2Folder, ExtTypeModel.Package>(incUtil,(ExtType2Doc_LookAhead.Package2Folder) notification.getNotifier(), (ExtTypeModel.Package) notification.getNewValue(), "ExtType2Doc_LookAhead.Package2Folder_source_Package"), getSelf());
		});
		feature2addEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getMethod2Entry__Marker_CREATE__CORR__m2e(), notification -> {
			incUtil.newMessage();
			name2actor.get("Method2Entry__CONSISTENCY_67_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.Method2Entry__Marker, ExtType2Doc_LookAhead.Method2Entry>(incUtil,(ExtType2Doc_LookAhead.Method2Entry__Marker) notification.getNotifier(), (ExtType2Doc_LookAhead.Method2Entry) notification.getNewValue(), "ExtType2Doc_LookAhead.Method2Entry__Marker_CREATE__CORR__m2e_Method2Entry"), getSelf());
		});
		feature2addEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getType2Doc__Marker_CONTEXT__SRC__p(), notification -> {
			incUtil.newMessage();
			name2actor.get("Type2Doc__CONSISTENCY_119_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.Type2Doc__Marker, ExtTypeModel.Package>(incUtil,(ExtType2Doc_LookAhead.Type2Doc__Marker) notification.getNotifier(), (ExtTypeModel.Package) notification.getNewValue(), "ExtType2Doc_LookAhead.Type2Doc__Marker_CONTEXT__SRC__p_Package"), getSelf());
		});
		feature2addEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getMethod2Entry__Marker_CONTEXT__CORR__t2d(), notification -> {
			incUtil.newMessage();
			name2actor.get("Method2Entry__CONSISTENCY_67_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.Method2Entry__Marker, ExtType2Doc_LookAhead.Type2Doc>(incUtil,(ExtType2Doc_LookAhead.Method2Entry__Marker) notification.getNotifier(), (ExtType2Doc_LookAhead.Type2Doc) notification.getNewValue(), "ExtType2Doc_LookAhead.Method2Entry__Marker_CONTEXT__CORR__t2d_Type2Doc"), getSelf());
		});
		feature2addEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getExtendingType2Doc__Marker_CONTEXT__TRG__f(), notification -> {
			incUtil.newMessage();
			name2actor.get("ExtendingType2Doc__CONSISTENCY_19_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.ExtendingType2Doc__Marker, ExtDocModel.Folder>(incUtil,(ExtType2Doc_LookAhead.ExtendingType2Doc__Marker) notification.getNotifier(), (ExtDocModel.Folder) notification.getNewValue(), "ExtType2Doc_LookAhead.ExtendingType2Doc__Marker_CONTEXT__TRG__f_Folder"), getSelf());
		});
		feature2addEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getMethod2Entry_Target(), notification -> {
			incUtil.newMessage();
			name2actor.get("Method2Entry__CONSISTENCY_67_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.Method2Entry, ExtDocModel.Entry>(incUtil,(ExtType2Doc_LookAhead.Method2Entry) notification.getNotifier(), (ExtDocModel.Entry) notification.getNewValue(), "ExtType2Doc_LookAhead.Method2Entry_target_Entry"), getSelf());
			incUtil.newMessage();
			name2actor.get("Param2Entry__FWD_86_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.Method2Entry, ExtDocModel.Entry>(incUtil,(ExtType2Doc_LookAhead.Method2Entry) notification.getNotifier(), (ExtDocModel.Entry) notification.getNewValue(), "ExtType2Doc_LookAhead.Method2Entry_target_Entry"), getSelf());
		});
		feature2addEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getMethod2Entry__Marker_CONTEXT__TRG__d(), notification -> {
			incUtil.newMessage();
			name2actor.get("Method2Entry__CONSISTENCY_67_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.Method2Entry__Marker, ExtDocModel.Doc>(incUtil,(ExtType2Doc_LookAhead.Method2Entry__Marker) notification.getNotifier(), (ExtDocModel.Doc) notification.getNewValue(), "ExtType2Doc_LookAhead.Method2Entry__Marker_CONTEXT__TRG__d_Doc"), getSelf());
		});
		feature2addEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getType2Doc__Marker_CREATE__SRC__t(), notification -> {
			incUtil.newMessage();
			name2actor.get("Type2Doc__CONSISTENCY_119_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.Type2Doc__Marker, ExtTypeModel.Type>(incUtil,(ExtType2Doc_LookAhead.Type2Doc__Marker) notification.getNotifier(), (ExtTypeModel.Type) notification.getNewValue(), "ExtType2Doc_LookAhead.Type2Doc__Marker_CREATE__SRC__t_Type"), getSelf());
		});
		feature2addEdgeConsumer.put(ExtDocModel.ExtDocModelPackage.eINSTANCE.getDoc_Entries(), notification -> {
			incUtil.newMessage();
			name2actor.get("Field2Entry__TRG_22_localSearch").tell(new ReferenceAdded<ExtDocModel.Doc, ExtDocModel.Entry>(incUtil,(ExtDocModel.Doc) notification.getNotifier(), (ExtDocModel.Entry) notification.getNewValue(), "ExtDocModel.Doc_entries_Entry"), getSelf());
			incUtil.newMessage();
			name2actor.get("Method2Entry__TRG_55_localSearch").tell(new ReferenceAdded<ExtDocModel.Doc, ExtDocModel.Entry>(incUtil,(ExtDocModel.Doc) notification.getNotifier(), (ExtDocModel.Entry) notification.getNewValue(), "ExtDocModel.Doc_entries_Entry"), getSelf());
		});
		feature2addEdgeConsumer.put(ExtTypeModel.ExtTypeModelPackage.eINSTANCE.getMethod_Params(), notification -> {
			incUtil.newMessage();
			name2actor.get("Param2Entry__SRC_83_localSearch").tell(new ReferenceAdded<ExtTypeModel.Method, ExtTypeModel.Parameter>(incUtil,(ExtTypeModel.Method) notification.getNotifier(), (ExtTypeModel.Parameter) notification.getNewValue(), "ExtTypeModel.Method_params_Parameter"), getSelf());
		});
		feature2addEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getParam2Entry_Target(), notification -> {
			incUtil.newMessage();
			name2actor.get("Param2Entry__CONSISTENCY_89_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.Param2Entry, ExtDocModel.Entry>(incUtil,(ExtType2Doc_LookAhead.Param2Entry) notification.getNotifier(), (ExtDocModel.Entry) notification.getNewValue(), "ExtType2Doc_LookAhead.Param2Entry_target_Entry"), getSelf());
		});
		feature2addEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getExtendingType2Doc__Marker_CONTEXT__SRC__p(), notification -> {
			incUtil.newMessage();
			name2actor.get("ExtendingType2Doc__CONSISTENCY_19_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.ExtendingType2Doc__Marker, ExtTypeModel.Package>(incUtil,(ExtType2Doc_LookAhead.ExtendingType2Doc__Marker) notification.getNotifier(), (ExtTypeModel.Package) notification.getNewValue(), "ExtType2Doc_LookAhead.ExtendingType2Doc__Marker_CONTEXT__SRC__p_Package"), getSelf());
		});
		feature2addEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getExtendingType2Doc__Marker_CONTEXT__CORR__p2f(), notification -> {
			incUtil.newMessage();
			name2actor.get("ExtendingType2Doc__CONSISTENCY_19_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.ExtendingType2Doc__Marker, ExtType2Doc_LookAhead.Package2Folder>(incUtil,(ExtType2Doc_LookAhead.ExtendingType2Doc__Marker) notification.getNotifier(), (ExtType2Doc_LookAhead.Package2Folder) notification.getNewValue(), "ExtType2Doc_LookAhead.ExtendingType2Doc__Marker_CONTEXT__CORR__p2f_Package2Folder"), getSelf());
		});
		feature2addEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getField2Entry_Source(), notification -> {
			incUtil.newMessage();
			name2actor.get("Field2Entry__CONSISTENCY_34_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.Field2Entry, ExtTypeModel.Field>(incUtil,(ExtType2Doc_LookAhead.Field2Entry) notification.getNotifier(), (ExtTypeModel.Field) notification.getNewValue(), "ExtType2Doc_LookAhead.Field2Entry_source_Field"), getSelf());
		});
		feature2addEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getMethod2Entry__Marker_CREATE__SRC__m(), notification -> {
			incUtil.newMessage();
			name2actor.get("Method2Entry__CONSISTENCY_67_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.Method2Entry__Marker, ExtTypeModel.Method>(incUtil,(ExtType2Doc_LookAhead.Method2Entry__Marker) notification.getNotifier(), (ExtTypeModel.Method) notification.getNewValue(), "ExtType2Doc_LookAhead.Method2Entry__Marker_CREATE__SRC__m_Method"), getSelf());
		});
		feature2addEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getExtendingType2Doc__Marker_CREATE__SRC__nt(), notification -> {
			incUtil.newMessage();
			name2actor.get("ExtendingType2Doc__CONSISTENCY_19_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.ExtendingType2Doc__Marker, ExtTypeModel.Type>(incUtil,(ExtType2Doc_LookAhead.ExtendingType2Doc__Marker) notification.getNotifier(), (ExtTypeModel.Type) notification.getNewValue(), "ExtType2Doc_LookAhead.ExtendingType2Doc__Marker_CREATE__SRC__nt_Type"), getSelf());
		});
		feature2addEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getField2Entry__Marker_CONTEXT__SRC__t(), notification -> {
			incUtil.newMessage();
			name2actor.get("Field2Entry__CONSISTENCY_34_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.Field2Entry__Marker, ExtTypeModel.Type>(incUtil,(ExtType2Doc_LookAhead.Field2Entry__Marker) notification.getNotifier(), (ExtTypeModel.Type) notification.getNewValue(), "ExtType2Doc_LookAhead.Field2Entry__Marker_CONTEXT__SRC__t_Type"), getSelf());
		});
		feature2addEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getExtendingType2Doc__Marker_CREATE__TRG__nd(), notification -> {
			incUtil.newMessage();
			name2actor.get("ExtendingType2Doc__CONSISTENCY_19_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.ExtendingType2Doc__Marker, ExtDocModel.Doc>(incUtil,(ExtType2Doc_LookAhead.ExtendingType2Doc__Marker) notification.getNotifier(), (ExtDocModel.Doc) notification.getNewValue(), "ExtType2Doc_LookAhead.ExtendingType2Doc__Marker_CREATE__TRG__nd_Doc"), getSelf());
		});
		feature2addEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getSubPackage2Folder__Marker_CREATE__SRC__sp(), notification -> {
			incUtil.newMessage();
			name2actor.get("SubPackage2Folder__CONSISTENCY_104_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.SubPackage2Folder__Marker, ExtTypeModel.Package>(incUtil,(ExtType2Doc_LookAhead.SubPackage2Folder__Marker) notification.getNotifier(), (ExtTypeModel.Package) notification.getNewValue(), "ExtType2Doc_LookAhead.SubPackage2Folder__Marker_CREATE__SRC__sp_Package"), getSelf());
		});
		feature2addEdgeConsumer.put(ExtTypeModel.ExtTypeModelPackage.eINSTANCE.getField_Type(), notification -> {
			incUtil.newMessage();
			name2actor.get("Field2Entry__SRC_28_localSearch").tell(new ReferenceAdded<ExtTypeModel.Field, ExtTypeModel.Type>(incUtil,(ExtTypeModel.Field) notification.getNotifier(), (ExtTypeModel.Type) notification.getNewValue(), "ExtTypeModel.Field_type_Type"), getSelf());
		});
		feature2addEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getField2Entry__Marker_CREATE__CORR__f2e(), notification -> {
			incUtil.newMessage();
			name2actor.get("Field2Entry__CONSISTENCY_34_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.Field2Entry__Marker, ExtType2Doc_LookAhead.Field2Entry>(incUtil,(ExtType2Doc_LookAhead.Field2Entry__Marker) notification.getNotifier(), (ExtType2Doc_LookAhead.Field2Entry) notification.getNewValue(), "ExtType2Doc_LookAhead.Field2Entry__Marker_CREATE__CORR__f2e_Field2Entry"), getSelf());
		});
		feature2addEdgeConsumer.put(ExtDocModel.ExtDocModelPackage.eINSTANCE.getDoc_Folder(), notification -> {
			incUtil.newMessage();
			name2actor.get("ExtendingType2Doc__TRG_1_localSearch").tell(new ReferenceAdded<ExtDocModel.Doc, ExtDocModel.Folder>(incUtil,(ExtDocModel.Doc) notification.getNotifier(), (ExtDocModel.Folder) notification.getNewValue(), "ExtDocModel.Doc_folder_Folder"), getSelf());
			incUtil.newMessage();
			name2actor.get("ExtendingType2Doc__TRG_1_localSearch").tell(new ReferenceAdded<ExtDocModel.Doc, ExtDocModel.Folder>(incUtil,(ExtDocModel.Doc) notification.getNotifier(), (ExtDocModel.Folder) notification.getNewValue(), "ExtDocModel.Doc_folder_Folder"), getSelf());
			incUtil.newMessage();
			name2actor.get("ExtendingType2Doc__FWD_14_localSearch").tell(new ReferenceAdded<ExtDocModel.Doc, ExtDocModel.Folder>(incUtil,(ExtDocModel.Doc) notification.getNotifier(), (ExtDocModel.Folder) notification.getNewValue(), "ExtDocModel.Doc_folder_Folder"), getSelf());
			incUtil.newMessage();
			name2actor.get("Type2Doc__TRG_107_localSearch").tell(new ReferenceAdded<ExtDocModel.Doc, ExtDocModel.Folder>(incUtil,(ExtDocModel.Doc) notification.getNotifier(), (ExtDocModel.Folder) notification.getNewValue(), "ExtDocModel.Doc_folder_Folder"), getSelf());
		});
		feature2addEdgeConsumer.put(ExtTypeModel.ExtTypeModelPackage.eINSTANCE.getPackage_Types(), notification -> {
			incUtil.newMessage();
			name2actor.get("ExtendingType2Doc__BWD_5_localSearch").tell(new ReferenceAdded<ExtTypeModel.Package, ExtTypeModel.Type>(incUtil,(ExtTypeModel.Package) notification.getNotifier(), (ExtTypeModel.Type) notification.getNewValue(), "ExtTypeModel.Package_types_Type"), getSelf());
			incUtil.newMessage();
			name2actor.get("ExtendingType2Doc__SRC_10_localSearch").tell(new ReferenceAdded<ExtTypeModel.Package, ExtTypeModel.Type>(incUtil,(ExtTypeModel.Package) notification.getNotifier(), (ExtTypeModel.Type) notification.getNewValue(), "ExtTypeModel.Package_types_Type"), getSelf());
			incUtil.newMessage();
			name2actor.get("ExtendingType2Doc__SRC_10_localSearch").tell(new ReferenceAdded<ExtTypeModel.Package, ExtTypeModel.Type>(incUtil,(ExtTypeModel.Package) notification.getNotifier(), (ExtTypeModel.Type) notification.getNewValue(), "ExtTypeModel.Package_types_Type"), getSelf());
			incUtil.newMessage();
			name2actor.get("Type2Doc__SRC_113_localSearch").tell(new ReferenceAdded<ExtTypeModel.Package, ExtTypeModel.Type>(incUtil,(ExtTypeModel.Package) notification.getNotifier(), (ExtTypeModel.Type) notification.getNewValue(), "ExtTypeModel.Package_types_Type"), getSelf());
		});
		feature2addEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getType2Doc__Marker_CONTEXT__TRG__f(), notification -> {
			incUtil.newMessage();
			name2actor.get("Type2Doc__CONSISTENCY_119_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.Type2Doc__Marker, ExtDocModel.Folder>(incUtil,(ExtType2Doc_LookAhead.Type2Doc__Marker) notification.getNotifier(), (ExtDocModel.Folder) notification.getNewValue(), "ExtType2Doc_LookAhead.Type2Doc__Marker_CONTEXT__TRG__f_Folder"), getSelf());
		});
		feature2addEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getExtendingType2Doc__Marker_CONTEXT__CORR__t2d(), notification -> {
			incUtil.newMessage();
			name2actor.get("ExtendingType2Doc__CONSISTENCY_19_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.ExtendingType2Doc__Marker, ExtType2Doc_LookAhead.Type2Doc>(incUtil,(ExtType2Doc_LookAhead.ExtendingType2Doc__Marker) notification.getNotifier(), (ExtType2Doc_LookAhead.Type2Doc) notification.getNewValue(), "ExtType2Doc_LookAhead.ExtendingType2Doc__Marker_CONTEXT__CORR__t2d_Type2Doc"), getSelf());
		});
		feature2addEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getExtendingType2Doc__Marker_CONTEXT__TRG__d(), notification -> {
			incUtil.newMessage();
			name2actor.get("ExtendingType2Doc__CONSISTENCY_19_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.ExtendingType2Doc__Marker, ExtDocModel.Doc>(incUtil,(ExtType2Doc_LookAhead.ExtendingType2Doc__Marker) notification.getNotifier(), (ExtDocModel.Doc) notification.getNewValue(), "ExtType2Doc_LookAhead.ExtendingType2Doc__Marker_CONTEXT__TRG__d_Doc"), getSelf());
		});
		feature2addEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getParam2Entry__Marker_CREATE__CORR__p2e(), notification -> {
			incUtil.newMessage();
			name2actor.get("Param2Entry__CONSISTENCY_89_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.Param2Entry__Marker, ExtType2Doc_LookAhead.Param2Entry>(incUtil,(ExtType2Doc_LookAhead.Param2Entry__Marker) notification.getNotifier(), (ExtType2Doc_LookAhead.Param2Entry) notification.getNewValue(), "ExtType2Doc_LookAhead.Param2Entry__Marker_CREATE__CORR__p2e_Param2Entry"), getSelf());
		});
		feature2addEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getImplementingType2Doc__Marker_CONTEXT__SRC__it(), notification -> {
			incUtil.newMessage();
			name2actor.get("ImplementingType2Doc__CONSISTENCY_53_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.ImplementingType2Doc__Marker, ExtTypeModel.Type>(incUtil,(ExtType2Doc_LookAhead.ImplementingType2Doc__Marker) notification.getNotifier(), (ExtTypeModel.Type) notification.getNewValue(), "ExtType2Doc_LookAhead.ImplementingType2Doc__Marker_CONTEXT__SRC__it_Type"), getSelf());
		});
		feature2addEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getField2Entry__Marker_CONTEXT__TRG__d(), notification -> {
			incUtil.newMessage();
			name2actor.get("Field2Entry__CONSISTENCY_34_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.Field2Entry__Marker, ExtDocModel.Doc>(incUtil,(ExtType2Doc_LookAhead.Field2Entry__Marker) notification.getNotifier(), (ExtDocModel.Doc) notification.getNewValue(), "ExtType2Doc_LookAhead.Field2Entry__Marker_CONTEXT__TRG__d_Doc"), getSelf());
		});
		feature2addEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getExtendingType2Doc__Marker_CREATE__CORR__nt2nd(), notification -> {
			incUtil.newMessage();
			name2actor.get("ExtendingType2Doc__CONSISTENCY_19_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.ExtendingType2Doc__Marker, ExtType2Doc_LookAhead.Type2Doc>(incUtil,(ExtType2Doc_LookAhead.ExtendingType2Doc__Marker) notification.getNotifier(), (ExtType2Doc_LookAhead.Type2Doc) notification.getNewValue(), "ExtType2Doc_LookAhead.ExtendingType2Doc__Marker_CREATE__CORR__nt2nd_Type2Doc"), getSelf());
		});
		feature2addEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getImplementingType2Doc__Marker_CONTEXT__CORR__it2id(), notification -> {
			incUtil.newMessage();
			name2actor.get("ImplementingType2Doc__CONSISTENCY_53_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.ImplementingType2Doc__Marker, ExtType2Doc_LookAhead.Type2Doc>(incUtil,(ExtType2Doc_LookAhead.ImplementingType2Doc__Marker) notification.getNotifier(), (ExtType2Doc_LookAhead.Type2Doc) notification.getNewValue(), "ExtType2Doc_LookAhead.ImplementingType2Doc__Marker_CONTEXT__CORR__it2id_Type2Doc"), getSelf());
		});
		feature2addEdgeConsumer.put(ExtTypeModel.ExtTypeModelPackage.eINSTANCE.getMethod_Type(), notification -> {
			incUtil.newMessage();
			name2actor.get("Method2Entry__SRC_61_localSearch").tell(new ReferenceAdded<ExtTypeModel.Method, ExtTypeModel.Type>(incUtil,(ExtTypeModel.Method) notification.getNotifier(), (ExtTypeModel.Type) notification.getNewValue(), "ExtTypeModel.Method_type_Type"), getSelf());
		});
		feature2addEdgeConsumer.put(ExtTypeModel.ExtTypeModelPackage.eINSTANCE.getPackage_SuperPackage(), notification -> {
			incUtil.newMessage();
			name2actor.get("Package2Folder_p_superPackage_outgoing_SRC__FILTER_NAC_SRC_75_localSearch").tell(new ReferenceAdded<ExtTypeModel.Package, ExtTypeModel.Package>(incUtil,(ExtTypeModel.Package) notification.getNotifier(), (ExtTypeModel.Package) notification.getNewValue(), "ExtTypeModel.Package_superPackage_Package"), getSelf());
			incUtil.newMessage();
			name2actor.get("SubPackage2Folder__SRC_98_localSearch").tell(new ReferenceAdded<ExtTypeModel.Package, ExtTypeModel.Package>(incUtil,(ExtTypeModel.Package) notification.getNotifier(), (ExtTypeModel.Package) notification.getNewValue(), "ExtTypeModel.Package_superPackage_Package"), getSelf());
		});
		feature2addEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getParam2Entry__Marker_CONTEXT__CORR__m2e(), notification -> {
			incUtil.newMessage();
			name2actor.get("Param2Entry__CONSISTENCY_89_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.Param2Entry__Marker, ExtType2Doc_LookAhead.Method2Entry>(incUtil,(ExtType2Doc_LookAhead.Param2Entry__Marker) notification.getNotifier(), (ExtType2Doc_LookAhead.Method2Entry) notification.getNewValue(), "ExtType2Doc_LookAhead.Param2Entry__Marker_CONTEXT__CORR__m2e_Method2Entry"), getSelf());
		});
		feature2addEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getSubPackage2Folder__Marker_CONTEXT__CORR__p2f(), notification -> {
			incUtil.newMessage();
			name2actor.get("SubPackage2Folder__CONSISTENCY_104_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.SubPackage2Folder__Marker, ExtType2Doc_LookAhead.Package2Folder>(incUtil,(ExtType2Doc_LookAhead.SubPackage2Folder__Marker) notification.getNotifier(), (ExtType2Doc_LookAhead.Package2Folder) notification.getNewValue(), "ExtType2Doc_LookAhead.SubPackage2Folder__Marker_CONTEXT__CORR__p2f_Package2Folder"), getSelf());
		});
		feature2addEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getMethod2Entry__Marker_CREATE__TRG__e(), notification -> {
			incUtil.newMessage();
			name2actor.get("Method2Entry__CONSISTENCY_67_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.Method2Entry__Marker, ExtDocModel.Entry>(incUtil,(ExtType2Doc_LookAhead.Method2Entry__Marker) notification.getNotifier(), (ExtDocModel.Entry) notification.getNewValue(), "ExtType2Doc_LookAhead.Method2Entry__Marker_CREATE__TRG__e_Entry"), getSelf());
		});
		feature2addEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getPackage2Folder__Marker_CREATE__SRC__p(), notification -> {
			incUtil.newMessage();
			name2actor.get("Package2Folder__CONSISTENCY_80_localSearch").tell(new ReferenceAdded<ExtType2Doc_LookAhead.Package2Folder__Marker, ExtTypeModel.Package>(incUtil,(ExtType2Doc_LookAhead.Package2Folder__Marker) notification.getNotifier(), (ExtTypeModel.Package) notification.getNewValue(), "ExtType2Doc_LookAhead.Package2Folder__Marker_CREATE__SRC__p_Package"), getSelf());
		});
		feature2addEdgeConsumer.put(ExtDocModel.ExtDocModelPackage.eINSTANCE.getFolder_SuperFolder(), notification -> {
			incUtil.newMessage();
			name2actor.get("Package2Folder_f_superFolder_outgoing_TRG__FILTER_NAC_TRG_70_localSearch").tell(new ReferenceAdded<ExtDocModel.Folder, ExtDocModel.Folder>(incUtil,(ExtDocModel.Folder) notification.getNotifier(), (ExtDocModel.Folder) notification.getNewValue(), "ExtDocModel.Folder_superFolder_Folder"), getSelf());
			incUtil.newMessage();
			name2actor.get("SubPackage2Folder__TRG_92_localSearch").tell(new ReferenceAdded<ExtDocModel.Folder, ExtDocModel.Folder>(incUtil,(ExtDocModel.Folder) notification.getNotifier(), (ExtDocModel.Folder) notification.getNewValue(), "ExtDocModel.Folder_superFolder_Folder"), getSelf());
		});
	}
	
	private void initializeRemoveEdge() {
		feature2removeEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getParam2Entry__Marker_CONTEXT__SRC__m(), notification -> {
			incUtil.newMessage();
			name2actor.get("Param2Entry__CONSISTENCY_89_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.Param2Entry__Marker, ExtTypeModel.Method>(incUtil, (ExtType2Doc_LookAhead.Param2Entry__Marker) notification.getNotifier(), (ExtTypeModel.Method) notification.getOldValue(), "ExtType2Doc_LookAhead.Param2Entry__Marker_CONTEXT__SRC__m_Method"), getSelf());
		});
		feature2removeEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getImplementingType2Doc__Marker_CONTEXT__TRG__d(), notification -> {
			incUtil.newMessage();
			name2actor.get("ImplementingType2Doc__CONSISTENCY_53_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.ImplementingType2Doc__Marker, ExtDocModel.Doc>(incUtil, (ExtType2Doc_LookAhead.ImplementingType2Doc__Marker) notification.getNotifier(), (ExtDocModel.Doc) notification.getOldValue(), "ExtType2Doc_LookAhead.ImplementingType2Doc__Marker_CONTEXT__TRG__d_Doc"), getSelf());
		});
		feature2removeEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getType2Doc_Source(), notification -> {
			incUtil.newMessage();
			name2actor.get("ExtendingType2Doc__BWD_5_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.Type2Doc, ExtTypeModel.Type>(incUtil, (ExtType2Doc_LookAhead.Type2Doc) notification.getNotifier(), (ExtTypeModel.Type) notification.getOldValue(), "ExtType2Doc_LookAhead.Type2Doc_source_Type"), getSelf());
			incUtil.newMessage();
			name2actor.get("ExtendingType2Doc__FWD_14_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.Type2Doc, ExtTypeModel.Type>(incUtil, (ExtType2Doc_LookAhead.Type2Doc) notification.getNotifier(), (ExtTypeModel.Type) notification.getOldValue(), "ExtType2Doc_LookAhead.Type2Doc_source_Type"), getSelf());
			incUtil.newMessage();
			name2actor.get("ExtendingType2Doc__CONSISTENCY_19_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.Type2Doc, ExtTypeModel.Type>(incUtil, (ExtType2Doc_LookAhead.Type2Doc) notification.getNotifier(), (ExtTypeModel.Type) notification.getOldValue(), "ExtType2Doc_LookAhead.Type2Doc_source_Type"), getSelf());
			incUtil.newMessage();
			name2actor.get("Field2Entry__BWD_25_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.Type2Doc, ExtTypeModel.Type>(incUtil, (ExtType2Doc_LookAhead.Type2Doc) notification.getNotifier(), (ExtTypeModel.Type) notification.getOldValue(), "ExtType2Doc_LookAhead.Type2Doc_source_Type"), getSelf());
			incUtil.newMessage();
			name2actor.get("Field2Entry__FWD_31_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.Type2Doc, ExtTypeModel.Type>(incUtil, (ExtType2Doc_LookAhead.Type2Doc) notification.getNotifier(), (ExtTypeModel.Type) notification.getOldValue(), "ExtType2Doc_LookAhead.Type2Doc_source_Type"), getSelf());
			incUtil.newMessage();
			name2actor.get("ImplementingType2Doc__BWD_40_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.Type2Doc, ExtTypeModel.Type>(incUtil, (ExtType2Doc_LookAhead.Type2Doc) notification.getNotifier(), (ExtTypeModel.Type) notification.getOldValue(), "ExtType2Doc_LookAhead.Type2Doc_source_Type"), getSelf());
			incUtil.newMessage();
			name2actor.get("ImplementingType2Doc__BWD_40_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.Type2Doc, ExtTypeModel.Type>(incUtil, (ExtType2Doc_LookAhead.Type2Doc) notification.getNotifier(), (ExtTypeModel.Type) notification.getOldValue(), "ExtType2Doc_LookAhead.Type2Doc_source_Type"), getSelf());
			incUtil.newMessage();
			name2actor.get("ImplementingType2Doc__FWD_48_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.Type2Doc, ExtTypeModel.Type>(incUtil, (ExtType2Doc_LookAhead.Type2Doc) notification.getNotifier(), (ExtTypeModel.Type) notification.getOldValue(), "ExtType2Doc_LookAhead.Type2Doc_source_Type"), getSelf());
			incUtil.newMessage();
			name2actor.get("ImplementingType2Doc__FWD_48_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.Type2Doc, ExtTypeModel.Type>(incUtil, (ExtType2Doc_LookAhead.Type2Doc) notification.getNotifier(), (ExtTypeModel.Type) notification.getOldValue(), "ExtType2Doc_LookAhead.Type2Doc_source_Type"), getSelf());
			incUtil.newMessage();
			name2actor.get("Method2Entry__BWD_58_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.Type2Doc, ExtTypeModel.Type>(incUtil, (ExtType2Doc_LookAhead.Type2Doc) notification.getNotifier(), (ExtTypeModel.Type) notification.getOldValue(), "ExtType2Doc_LookAhead.Type2Doc_source_Type"), getSelf());
			incUtil.newMessage();
			name2actor.get("Method2Entry__FWD_64_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.Type2Doc, ExtTypeModel.Type>(incUtil, (ExtType2Doc_LookAhead.Type2Doc) notification.getNotifier(), (ExtTypeModel.Type) notification.getOldValue(), "ExtType2Doc_LookAhead.Type2Doc_source_Type"), getSelf());
			incUtil.newMessage();
			name2actor.get("Type2Doc__CONSISTENCY_119_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.Type2Doc, ExtTypeModel.Type>(incUtil, (ExtType2Doc_LookAhead.Type2Doc) notification.getNotifier(), (ExtTypeModel.Type) notification.getOldValue(), "ExtType2Doc_LookAhead.Type2Doc_source_Type"), getSelf());
		});
		feature2removeEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getPackage2Folder__Marker_CREATE__TRG__f(), notification -> {
			incUtil.newMessage();
			name2actor.get("Package2Folder__CONSISTENCY_80_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.Package2Folder__Marker, ExtDocModel.Folder>(incUtil, (ExtType2Doc_LookAhead.Package2Folder__Marker) notification.getNotifier(), (ExtDocModel.Folder) notification.getOldValue(), "ExtType2Doc_LookAhead.Package2Folder__Marker_CREATE__TRG__f_Folder"), getSelf());
		});
		feature2removeEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getPackage2Folder__Marker_CREATE__CORR__p2f(), notification -> {
			incUtil.newMessage();
			name2actor.get("Package2Folder__CONSISTENCY_80_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.Package2Folder__Marker, ExtType2Doc_LookAhead.Package2Folder>(incUtil, (ExtType2Doc_LookAhead.Package2Folder__Marker) notification.getNotifier(), (ExtType2Doc_LookAhead.Package2Folder) notification.getOldValue(), "ExtType2Doc_LookAhead.Package2Folder__Marker_CREATE__CORR__p2f_Package2Folder"), getSelf());
		});
		feature2removeEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getImplementingType2Doc__Marker_CONTEXT__TRG__id(), notification -> {
			incUtil.newMessage();
			name2actor.get("ImplementingType2Doc__CONSISTENCY_53_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.ImplementingType2Doc__Marker, ExtDocModel.Doc>(incUtil, (ExtType2Doc_LookAhead.ImplementingType2Doc__Marker) notification.getNotifier(), (ExtDocModel.Doc) notification.getOldValue(), "ExtType2Doc_LookAhead.ImplementingType2Doc__Marker_CONTEXT__TRG__id_Doc"), getSelf());
		});
		feature2removeEdgeConsumer.put(ExtDocModel.ExtDocModelPackage.eINSTANCE.getDoc_SuperDocs(), notification -> {
			incUtil.newMessage();
			name2actor.get("ExtendingType2Doc__TRG_1_localSearch").tell(new ReferenceDeleted<ExtDocModel.Doc, ExtDocModel.Doc>(incUtil, (ExtDocModel.Doc) notification.getNotifier(), (ExtDocModel.Doc) notification.getOldValue(), "ExtDocModel.Doc_superDocs_Doc"), getSelf());
			incUtil.newMessage();
			name2actor.get("ImplementingType2Doc__TRG_37_localSearch").tell(new ReferenceDeleted<ExtDocModel.Doc, ExtDocModel.Doc>(incUtil, (ExtDocModel.Doc) notification.getNotifier(), (ExtDocModel.Doc) notification.getOldValue(), "ExtDocModel.Doc_superDocs_Doc"), getSelf());
		});
		feature2removeEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getPackage2Folder_Target(), notification -> {
			incUtil.newMessage();
			name2actor.get("ExtendingType2Doc__BWD_5_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.Package2Folder, ExtDocModel.Folder>(incUtil, (ExtType2Doc_LookAhead.Package2Folder) notification.getNotifier(), (ExtDocModel.Folder) notification.getOldValue(), "ExtType2Doc_LookAhead.Package2Folder_target_Folder"), getSelf());
			incUtil.newMessage();
			name2actor.get("ExtendingType2Doc__FWD_14_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.Package2Folder, ExtDocModel.Folder>(incUtil, (ExtType2Doc_LookAhead.Package2Folder) notification.getNotifier(), (ExtDocModel.Folder) notification.getOldValue(), "ExtType2Doc_LookAhead.Package2Folder_target_Folder"), getSelf());
			incUtil.newMessage();
			name2actor.get("Package2Folder__CONSISTENCY_80_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.Package2Folder, ExtDocModel.Folder>(incUtil, (ExtType2Doc_LookAhead.Package2Folder) notification.getNotifier(), (ExtDocModel.Folder) notification.getOldValue(), "ExtType2Doc_LookAhead.Package2Folder_target_Folder"), getSelf());
			incUtil.newMessage();
			name2actor.get("SubPackage2Folder__BWD_95_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.Package2Folder, ExtDocModel.Folder>(incUtil, (ExtType2Doc_LookAhead.Package2Folder) notification.getNotifier(), (ExtDocModel.Folder) notification.getOldValue(), "ExtType2Doc_LookAhead.Package2Folder_target_Folder"), getSelf());
			incUtil.newMessage();
			name2actor.get("SubPackage2Folder__FWD_101_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.Package2Folder, ExtDocModel.Folder>(incUtil, (ExtType2Doc_LookAhead.Package2Folder) notification.getNotifier(), (ExtDocModel.Folder) notification.getOldValue(), "ExtType2Doc_LookAhead.Package2Folder_target_Folder"), getSelf());
			incUtil.newMessage();
			name2actor.get("SubPackage2Folder__CONSISTENCY_104_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.Package2Folder, ExtDocModel.Folder>(incUtil, (ExtType2Doc_LookAhead.Package2Folder) notification.getNotifier(), (ExtDocModel.Folder) notification.getOldValue(), "ExtType2Doc_LookAhead.Package2Folder_target_Folder"), getSelf());
			incUtil.newMessage();
			name2actor.get("Type2Doc__BWD_110_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.Package2Folder, ExtDocModel.Folder>(incUtil, (ExtType2Doc_LookAhead.Package2Folder) notification.getNotifier(), (ExtDocModel.Folder) notification.getOldValue(), "ExtType2Doc_LookAhead.Package2Folder_target_Folder"), getSelf());
			incUtil.newMessage();
			name2actor.get("Type2Doc__FWD_116_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.Package2Folder, ExtDocModel.Folder>(incUtil, (ExtType2Doc_LookAhead.Package2Folder) notification.getNotifier(), (ExtDocModel.Folder) notification.getOldValue(), "ExtType2Doc_LookAhead.Package2Folder_target_Folder"), getSelf());
		});
		feature2removeEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getImplementingType2Doc__Marker_CONTEXT__SRC__t(), notification -> {
			incUtil.newMessage();
			name2actor.get("ImplementingType2Doc__CONSISTENCY_53_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.ImplementingType2Doc__Marker, ExtTypeModel.Type>(incUtil, (ExtType2Doc_LookAhead.ImplementingType2Doc__Marker) notification.getNotifier(), (ExtTypeModel.Type) notification.getOldValue(), "ExtType2Doc_LookAhead.ImplementingType2Doc__Marker_CONTEXT__SRC__t_Type"), getSelf());
		});
		feature2removeEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getType2Doc__Marker_CREATE__CORR__t2d(), notification -> {
			incUtil.newMessage();
			name2actor.get("Type2Doc__CONSISTENCY_119_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.Type2Doc__Marker, ExtType2Doc_LookAhead.Type2Doc>(incUtil, (ExtType2Doc_LookAhead.Type2Doc__Marker) notification.getNotifier(), (ExtType2Doc_LookAhead.Type2Doc) notification.getOldValue(), "ExtType2Doc_LookAhead.Type2Doc__Marker_CREATE__CORR__t2d_Type2Doc"), getSelf());
		});
		feature2removeEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getField2Entry__Marker_CREATE__TRG__e(), notification -> {
			incUtil.newMessage();
			name2actor.get("Field2Entry__CONSISTENCY_34_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.Field2Entry__Marker, ExtDocModel.Entry>(incUtil, (ExtType2Doc_LookAhead.Field2Entry__Marker) notification.getNotifier(), (ExtDocModel.Entry) notification.getOldValue(), "ExtType2Doc_LookAhead.Field2Entry__Marker_CREATE__TRG__e_Entry"), getSelf());
		});
		feature2removeEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getParam2Entry__Marker_CONTEXT__TRG__e(), notification -> {
			incUtil.newMessage();
			name2actor.get("Param2Entry__CONSISTENCY_89_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.Param2Entry__Marker, ExtDocModel.Entry>(incUtil, (ExtType2Doc_LookAhead.Param2Entry__Marker) notification.getNotifier(), (ExtDocModel.Entry) notification.getOldValue(), "ExtType2Doc_LookAhead.Param2Entry__Marker_CONTEXT__TRG__e_Entry"), getSelf());
		});
		feature2removeEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getField2Entry__Marker_CREATE__SRC__f(), notification -> {
			incUtil.newMessage();
			name2actor.get("Field2Entry__CONSISTENCY_34_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.Field2Entry__Marker, ExtTypeModel.Field>(incUtil, (ExtType2Doc_LookAhead.Field2Entry__Marker) notification.getNotifier(), (ExtTypeModel.Field) notification.getOldValue(), "ExtType2Doc_LookAhead.Field2Entry__Marker_CREATE__SRC__f_Field"), getSelf());
		});
		feature2removeEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getSubPackage2Folder__Marker_CONTEXT__SRC__p(), notification -> {
			incUtil.newMessage();
			name2actor.get("SubPackage2Folder__CONSISTENCY_104_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.SubPackage2Folder__Marker, ExtTypeModel.Package>(incUtil, (ExtType2Doc_LookAhead.SubPackage2Folder__Marker) notification.getNotifier(), (ExtTypeModel.Package) notification.getOldValue(), "ExtType2Doc_LookAhead.SubPackage2Folder__Marker_CONTEXT__SRC__p_Package"), getSelf());
		});
		feature2removeEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getExtendingType2Doc__Marker_CONTEXT__SRC__t(), notification -> {
			incUtil.newMessage();
			name2actor.get("ExtendingType2Doc__CONSISTENCY_19_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.ExtendingType2Doc__Marker, ExtTypeModel.Type>(incUtil, (ExtType2Doc_LookAhead.ExtendingType2Doc__Marker) notification.getNotifier(), (ExtTypeModel.Type) notification.getOldValue(), "ExtType2Doc_LookAhead.ExtendingType2Doc__Marker_CONTEXT__SRC__t_Type"), getSelf());
		});
		feature2removeEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getField2Entry_Target(), notification -> {
			incUtil.newMessage();
			name2actor.get("Field2Entry__CONSISTENCY_34_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.Field2Entry, ExtDocModel.Entry>(incUtil, (ExtType2Doc_LookAhead.Field2Entry) notification.getNotifier(), (ExtDocModel.Entry) notification.getOldValue(), "ExtType2Doc_LookAhead.Field2Entry_target_Entry"), getSelf());
		});
		feature2removeEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getSubPackage2Folder__Marker_CREATE__CORR__sp2f(), notification -> {
			incUtil.newMessage();
			name2actor.get("SubPackage2Folder__CONSISTENCY_104_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.SubPackage2Folder__Marker, ExtType2Doc_LookAhead.Package2Folder>(incUtil, (ExtType2Doc_LookAhead.SubPackage2Folder__Marker) notification.getNotifier(), (ExtType2Doc_LookAhead.Package2Folder) notification.getOldValue(), "ExtType2Doc_LookAhead.SubPackage2Folder__Marker_CREATE__CORR__sp2f_Package2Folder"), getSelf());
		});
		feature2removeEdgeConsumer.put(ExtTypeModel.ExtTypeModelPackage.eINSTANCE.getType_InheritsFrom(), notification -> {
			incUtil.newMessage();
			name2actor.get("ExtendingType2Doc__SRC_10_localSearch").tell(new ReferenceDeleted<ExtTypeModel.Type, ExtTypeModel.Type>(incUtil, (ExtTypeModel.Type) notification.getNotifier(), (ExtTypeModel.Type) notification.getOldValue(), "ExtTypeModel.Type_inheritsFrom_Type"), getSelf());
			incUtil.newMessage();
			name2actor.get("ImplementingType2Doc__SRC_45_localSearch").tell(new ReferenceDeleted<ExtTypeModel.Type, ExtTypeModel.Type>(incUtil, (ExtTypeModel.Type) notification.getNotifier(), (ExtTypeModel.Type) notification.getOldValue(), "ExtTypeModel.Type_inheritsFrom_Type"), getSelf());
		});
		feature2removeEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getType2Doc_Target(), notification -> {
			incUtil.newMessage();
			name2actor.get("ExtendingType2Doc__BWD_5_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.Type2Doc, ExtDocModel.Doc>(incUtil, (ExtType2Doc_LookAhead.Type2Doc) notification.getNotifier(), (ExtDocModel.Doc) notification.getOldValue(), "ExtType2Doc_LookAhead.Type2Doc_target_Doc"), getSelf());
			incUtil.newMessage();
			name2actor.get("ExtendingType2Doc__FWD_14_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.Type2Doc, ExtDocModel.Doc>(incUtil, (ExtType2Doc_LookAhead.Type2Doc) notification.getNotifier(), (ExtDocModel.Doc) notification.getOldValue(), "ExtType2Doc_LookAhead.Type2Doc_target_Doc"), getSelf());
			incUtil.newMessage();
			name2actor.get("ExtendingType2Doc__CONSISTENCY_19_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.Type2Doc, ExtDocModel.Doc>(incUtil, (ExtType2Doc_LookAhead.Type2Doc) notification.getNotifier(), (ExtDocModel.Doc) notification.getOldValue(), "ExtType2Doc_LookAhead.Type2Doc_target_Doc"), getSelf());
			incUtil.newMessage();
			name2actor.get("Field2Entry__BWD_25_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.Type2Doc, ExtDocModel.Doc>(incUtil, (ExtType2Doc_LookAhead.Type2Doc) notification.getNotifier(), (ExtDocModel.Doc) notification.getOldValue(), "ExtType2Doc_LookAhead.Type2Doc_target_Doc"), getSelf());
			incUtil.newMessage();
			name2actor.get("Field2Entry__FWD_31_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.Type2Doc, ExtDocModel.Doc>(incUtil, (ExtType2Doc_LookAhead.Type2Doc) notification.getNotifier(), (ExtDocModel.Doc) notification.getOldValue(), "ExtType2Doc_LookAhead.Type2Doc_target_Doc"), getSelf());
			incUtil.newMessage();
			name2actor.get("ImplementingType2Doc__BWD_40_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.Type2Doc, ExtDocModel.Doc>(incUtil, (ExtType2Doc_LookAhead.Type2Doc) notification.getNotifier(), (ExtDocModel.Doc) notification.getOldValue(), "ExtType2Doc_LookAhead.Type2Doc_target_Doc"), getSelf());
			incUtil.newMessage();
			name2actor.get("ImplementingType2Doc__BWD_40_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.Type2Doc, ExtDocModel.Doc>(incUtil, (ExtType2Doc_LookAhead.Type2Doc) notification.getNotifier(), (ExtDocModel.Doc) notification.getOldValue(), "ExtType2Doc_LookAhead.Type2Doc_target_Doc"), getSelf());
			incUtil.newMessage();
			name2actor.get("ImplementingType2Doc__FWD_48_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.Type2Doc, ExtDocModel.Doc>(incUtil, (ExtType2Doc_LookAhead.Type2Doc) notification.getNotifier(), (ExtDocModel.Doc) notification.getOldValue(), "ExtType2Doc_LookAhead.Type2Doc_target_Doc"), getSelf());
			incUtil.newMessage();
			name2actor.get("ImplementingType2Doc__FWD_48_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.Type2Doc, ExtDocModel.Doc>(incUtil, (ExtType2Doc_LookAhead.Type2Doc) notification.getNotifier(), (ExtDocModel.Doc) notification.getOldValue(), "ExtType2Doc_LookAhead.Type2Doc_target_Doc"), getSelf());
			incUtil.newMessage();
			name2actor.get("Method2Entry__BWD_58_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.Type2Doc, ExtDocModel.Doc>(incUtil, (ExtType2Doc_LookAhead.Type2Doc) notification.getNotifier(), (ExtDocModel.Doc) notification.getOldValue(), "ExtType2Doc_LookAhead.Type2Doc_target_Doc"), getSelf());
			incUtil.newMessage();
			name2actor.get("Method2Entry__FWD_64_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.Type2Doc, ExtDocModel.Doc>(incUtil, (ExtType2Doc_LookAhead.Type2Doc) notification.getNotifier(), (ExtDocModel.Doc) notification.getOldValue(), "ExtType2Doc_LookAhead.Type2Doc_target_Doc"), getSelf());
			incUtil.newMessage();
			name2actor.get("Type2Doc__CONSISTENCY_119_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.Type2Doc, ExtDocModel.Doc>(incUtil, (ExtType2Doc_LookAhead.Type2Doc) notification.getNotifier(), (ExtDocModel.Doc) notification.getOldValue(), "ExtType2Doc_LookAhead.Type2Doc_target_Doc"), getSelf());
		});
		feature2removeEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getSubPackage2Folder__Marker_CONTEXT__TRG__f(), notification -> {
			incUtil.newMessage();
			name2actor.get("SubPackage2Folder__CONSISTENCY_104_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.SubPackage2Folder__Marker, ExtDocModel.Folder>(incUtil, (ExtType2Doc_LookAhead.SubPackage2Folder__Marker) notification.getNotifier(), (ExtDocModel.Folder) notification.getOldValue(), "ExtType2Doc_LookAhead.SubPackage2Folder__Marker_CONTEXT__TRG__f_Folder"), getSelf());
		});
		feature2removeEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getSubPackage2Folder__Marker_CREATE__TRG__sf(), notification -> {
			incUtil.newMessage();
			name2actor.get("SubPackage2Folder__CONSISTENCY_104_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.SubPackage2Folder__Marker, ExtDocModel.Folder>(incUtil, (ExtType2Doc_LookAhead.SubPackage2Folder__Marker) notification.getNotifier(), (ExtDocModel.Folder) notification.getOldValue(), "ExtType2Doc_LookAhead.SubPackage2Folder__Marker_CREATE__TRG__sf_Folder"), getSelf());
		});
		feature2removeEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getImplementingType2Doc__Marker_CONTEXT__CORR__t2d(), notification -> {
			incUtil.newMessage();
			name2actor.get("ImplementingType2Doc__CONSISTENCY_53_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.ImplementingType2Doc__Marker, ExtType2Doc_LookAhead.Type2Doc>(incUtil, (ExtType2Doc_LookAhead.ImplementingType2Doc__Marker) notification.getNotifier(), (ExtType2Doc_LookAhead.Type2Doc) notification.getOldValue(), "ExtType2Doc_LookAhead.ImplementingType2Doc__Marker_CONTEXT__CORR__t2d_Type2Doc"), getSelf());
		});
		feature2removeEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getParam2Entry__Marker_CREATE__SRC__p(), notification -> {
			incUtil.newMessage();
			name2actor.get("Param2Entry__CONSISTENCY_89_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.Param2Entry__Marker, ExtTypeModel.Parameter>(incUtil, (ExtType2Doc_LookAhead.Param2Entry__Marker) notification.getNotifier(), (ExtTypeModel.Parameter) notification.getOldValue(), "ExtType2Doc_LookAhead.Param2Entry__Marker_CREATE__SRC__p_Parameter"), getSelf());
		});
		feature2removeEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getType2Doc__Marker_CREATE__TRG__d(), notification -> {
			incUtil.newMessage();
			name2actor.get("Type2Doc__CONSISTENCY_119_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.Type2Doc__Marker, ExtDocModel.Doc>(incUtil, (ExtType2Doc_LookAhead.Type2Doc__Marker) notification.getNotifier(), (ExtDocModel.Doc) notification.getOldValue(), "ExtType2Doc_LookAhead.Type2Doc__Marker_CREATE__TRG__d_Doc"), getSelf());
		});
		feature2removeEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getMethod2Entry__Marker_CONTEXT__SRC__t(), notification -> {
			incUtil.newMessage();
			name2actor.get("Method2Entry__CONSISTENCY_67_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.Method2Entry__Marker, ExtTypeModel.Type>(incUtil, (ExtType2Doc_LookAhead.Method2Entry__Marker) notification.getNotifier(), (ExtTypeModel.Type) notification.getOldValue(), "ExtType2Doc_LookAhead.Method2Entry__Marker_CONTEXT__SRC__t_Type"), getSelf());
		});
		feature2removeEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getParam2Entry_Source(), notification -> {
			incUtil.newMessage();
			name2actor.get("Param2Entry__CONSISTENCY_89_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.Param2Entry, ExtTypeModel.Parameter>(incUtil, (ExtType2Doc_LookAhead.Param2Entry) notification.getNotifier(), (ExtTypeModel.Parameter) notification.getOldValue(), "ExtType2Doc_LookAhead.Param2Entry_source_Parameter"), getSelf());
		});
		feature2removeEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getField2Entry__Marker_CONTEXT__CORR__t2d(), notification -> {
			incUtil.newMessage();
			name2actor.get("Field2Entry__CONSISTENCY_34_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.Field2Entry__Marker, ExtType2Doc_LookAhead.Type2Doc>(incUtil, (ExtType2Doc_LookAhead.Field2Entry__Marker) notification.getNotifier(), (ExtType2Doc_LookAhead.Type2Doc) notification.getOldValue(), "ExtType2Doc_LookAhead.Field2Entry__Marker_CONTEXT__CORR__t2d_Type2Doc"), getSelf());
		});
		feature2removeEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getMethod2Entry_Source(), notification -> {
			incUtil.newMessage();
			name2actor.get("Method2Entry__CONSISTENCY_67_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.Method2Entry, ExtTypeModel.Method>(incUtil, (ExtType2Doc_LookAhead.Method2Entry) notification.getNotifier(), (ExtTypeModel.Method) notification.getOldValue(), "ExtType2Doc_LookAhead.Method2Entry_source_Method"), getSelf());
			incUtil.newMessage();
			name2actor.get("Param2Entry__FWD_86_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.Method2Entry, ExtTypeModel.Method>(incUtil, (ExtType2Doc_LookAhead.Method2Entry) notification.getNotifier(), (ExtTypeModel.Method) notification.getOldValue(), "ExtType2Doc_LookAhead.Method2Entry_source_Method"), getSelf());
		});
		feature2removeEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getType2Doc__Marker_CONTEXT__CORR__p2f(), notification -> {
			incUtil.newMessage();
			name2actor.get("Type2Doc__CONSISTENCY_119_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.Type2Doc__Marker, ExtType2Doc_LookAhead.Package2Folder>(incUtil, (ExtType2Doc_LookAhead.Type2Doc__Marker) notification.getNotifier(), (ExtType2Doc_LookAhead.Package2Folder) notification.getOldValue(), "ExtType2Doc_LookAhead.Type2Doc__Marker_CONTEXT__CORR__p2f_Package2Folder"), getSelf());
		});
		feature2removeEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getPackage2Folder_Source(), notification -> {
			incUtil.newMessage();
			name2actor.get("ExtendingType2Doc__BWD_5_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.Package2Folder, ExtTypeModel.Package>(incUtil, (ExtType2Doc_LookAhead.Package2Folder) notification.getNotifier(), (ExtTypeModel.Package) notification.getOldValue(), "ExtType2Doc_LookAhead.Package2Folder_source_Package"), getSelf());
			incUtil.newMessage();
			name2actor.get("ExtendingType2Doc__FWD_14_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.Package2Folder, ExtTypeModel.Package>(incUtil, (ExtType2Doc_LookAhead.Package2Folder) notification.getNotifier(), (ExtTypeModel.Package) notification.getOldValue(), "ExtType2Doc_LookAhead.Package2Folder_source_Package"), getSelf());
			incUtil.newMessage();
			name2actor.get("Package2Folder__CONSISTENCY_80_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.Package2Folder, ExtTypeModel.Package>(incUtil, (ExtType2Doc_LookAhead.Package2Folder) notification.getNotifier(), (ExtTypeModel.Package) notification.getOldValue(), "ExtType2Doc_LookAhead.Package2Folder_source_Package"), getSelf());
			incUtil.newMessage();
			name2actor.get("SubPackage2Folder__BWD_95_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.Package2Folder, ExtTypeModel.Package>(incUtil, (ExtType2Doc_LookAhead.Package2Folder) notification.getNotifier(), (ExtTypeModel.Package) notification.getOldValue(), "ExtType2Doc_LookAhead.Package2Folder_source_Package"), getSelf());
			incUtil.newMessage();
			name2actor.get("SubPackage2Folder__FWD_101_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.Package2Folder, ExtTypeModel.Package>(incUtil, (ExtType2Doc_LookAhead.Package2Folder) notification.getNotifier(), (ExtTypeModel.Package) notification.getOldValue(), "ExtType2Doc_LookAhead.Package2Folder_source_Package"), getSelf());
			incUtil.newMessage();
			name2actor.get("SubPackage2Folder__CONSISTENCY_104_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.Package2Folder, ExtTypeModel.Package>(incUtil, (ExtType2Doc_LookAhead.Package2Folder) notification.getNotifier(), (ExtTypeModel.Package) notification.getOldValue(), "ExtType2Doc_LookAhead.Package2Folder_source_Package"), getSelf());
			incUtil.newMessage();
			name2actor.get("Type2Doc__BWD_110_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.Package2Folder, ExtTypeModel.Package>(incUtil, (ExtType2Doc_LookAhead.Package2Folder) notification.getNotifier(), (ExtTypeModel.Package) notification.getOldValue(), "ExtType2Doc_LookAhead.Package2Folder_source_Package"), getSelf());
			incUtil.newMessage();
			name2actor.get("Type2Doc__FWD_116_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.Package2Folder, ExtTypeModel.Package>(incUtil, (ExtType2Doc_LookAhead.Package2Folder) notification.getNotifier(), (ExtTypeModel.Package) notification.getOldValue(), "ExtType2Doc_LookAhead.Package2Folder_source_Package"), getSelf());
		});
		feature2removeEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getMethod2Entry__Marker_CREATE__CORR__m2e(), notification -> {
			incUtil.newMessage();
			name2actor.get("Method2Entry__CONSISTENCY_67_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.Method2Entry__Marker, ExtType2Doc_LookAhead.Method2Entry>(incUtil, (ExtType2Doc_LookAhead.Method2Entry__Marker) notification.getNotifier(), (ExtType2Doc_LookAhead.Method2Entry) notification.getOldValue(), "ExtType2Doc_LookAhead.Method2Entry__Marker_CREATE__CORR__m2e_Method2Entry"), getSelf());
		});
		feature2removeEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getType2Doc__Marker_CONTEXT__SRC__p(), notification -> {
			incUtil.newMessage();
			name2actor.get("Type2Doc__CONSISTENCY_119_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.Type2Doc__Marker, ExtTypeModel.Package>(incUtil, (ExtType2Doc_LookAhead.Type2Doc__Marker) notification.getNotifier(), (ExtTypeModel.Package) notification.getOldValue(), "ExtType2Doc_LookAhead.Type2Doc__Marker_CONTEXT__SRC__p_Package"), getSelf());
		});
		feature2removeEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getMethod2Entry__Marker_CONTEXT__CORR__t2d(), notification -> {
			incUtil.newMessage();
			name2actor.get("Method2Entry__CONSISTENCY_67_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.Method2Entry__Marker, ExtType2Doc_LookAhead.Type2Doc>(incUtil, (ExtType2Doc_LookAhead.Method2Entry__Marker) notification.getNotifier(), (ExtType2Doc_LookAhead.Type2Doc) notification.getOldValue(), "ExtType2Doc_LookAhead.Method2Entry__Marker_CONTEXT__CORR__t2d_Type2Doc"), getSelf());
		});
		feature2removeEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getExtendingType2Doc__Marker_CONTEXT__TRG__f(), notification -> {
			incUtil.newMessage();
			name2actor.get("ExtendingType2Doc__CONSISTENCY_19_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.ExtendingType2Doc__Marker, ExtDocModel.Folder>(incUtil, (ExtType2Doc_LookAhead.ExtendingType2Doc__Marker) notification.getNotifier(), (ExtDocModel.Folder) notification.getOldValue(), "ExtType2Doc_LookAhead.ExtendingType2Doc__Marker_CONTEXT__TRG__f_Folder"), getSelf());
		});
		feature2removeEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getMethod2Entry_Target(), notification -> {
			incUtil.newMessage();
			name2actor.get("Method2Entry__CONSISTENCY_67_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.Method2Entry, ExtDocModel.Entry>(incUtil, (ExtType2Doc_LookAhead.Method2Entry) notification.getNotifier(), (ExtDocModel.Entry) notification.getOldValue(), "ExtType2Doc_LookAhead.Method2Entry_target_Entry"), getSelf());
			incUtil.newMessage();
			name2actor.get("Param2Entry__FWD_86_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.Method2Entry, ExtDocModel.Entry>(incUtil, (ExtType2Doc_LookAhead.Method2Entry) notification.getNotifier(), (ExtDocModel.Entry) notification.getOldValue(), "ExtType2Doc_LookAhead.Method2Entry_target_Entry"), getSelf());
		});
		feature2removeEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getMethod2Entry__Marker_CONTEXT__TRG__d(), notification -> {
			incUtil.newMessage();
			name2actor.get("Method2Entry__CONSISTENCY_67_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.Method2Entry__Marker, ExtDocModel.Doc>(incUtil, (ExtType2Doc_LookAhead.Method2Entry__Marker) notification.getNotifier(), (ExtDocModel.Doc) notification.getOldValue(), "ExtType2Doc_LookAhead.Method2Entry__Marker_CONTEXT__TRG__d_Doc"), getSelf());
		});
		feature2removeEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getType2Doc__Marker_CREATE__SRC__t(), notification -> {
			incUtil.newMessage();
			name2actor.get("Type2Doc__CONSISTENCY_119_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.Type2Doc__Marker, ExtTypeModel.Type>(incUtil, (ExtType2Doc_LookAhead.Type2Doc__Marker) notification.getNotifier(), (ExtTypeModel.Type) notification.getOldValue(), "ExtType2Doc_LookAhead.Type2Doc__Marker_CREATE__SRC__t_Type"), getSelf());
		});
		feature2removeEdgeConsumer.put(ExtDocModel.ExtDocModelPackage.eINSTANCE.getDoc_Entries(), notification -> {
			incUtil.newMessage();
			name2actor.get("Field2Entry__TRG_22_localSearch").tell(new ReferenceDeleted<ExtDocModel.Doc, ExtDocModel.Entry>(incUtil, (ExtDocModel.Doc) notification.getNotifier(), (ExtDocModel.Entry) notification.getOldValue(), "ExtDocModel.Doc_entries_Entry"), getSelf());
			incUtil.newMessage();
			name2actor.get("Method2Entry__TRG_55_localSearch").tell(new ReferenceDeleted<ExtDocModel.Doc, ExtDocModel.Entry>(incUtil, (ExtDocModel.Doc) notification.getNotifier(), (ExtDocModel.Entry) notification.getOldValue(), "ExtDocModel.Doc_entries_Entry"), getSelf());
		});
		feature2removeEdgeConsumer.put(ExtTypeModel.ExtTypeModelPackage.eINSTANCE.getMethod_Params(), notification -> {
			incUtil.newMessage();
			name2actor.get("Param2Entry__SRC_83_localSearch").tell(new ReferenceDeleted<ExtTypeModel.Method, ExtTypeModel.Parameter>(incUtil, (ExtTypeModel.Method) notification.getNotifier(), (ExtTypeModel.Parameter) notification.getOldValue(), "ExtTypeModel.Method_params_Parameter"), getSelf());
		});
		feature2removeEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getParam2Entry_Target(), notification -> {
			incUtil.newMessage();
			name2actor.get("Param2Entry__CONSISTENCY_89_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.Param2Entry, ExtDocModel.Entry>(incUtil, (ExtType2Doc_LookAhead.Param2Entry) notification.getNotifier(), (ExtDocModel.Entry) notification.getOldValue(), "ExtType2Doc_LookAhead.Param2Entry_target_Entry"), getSelf());
		});
		feature2removeEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getExtendingType2Doc__Marker_CONTEXT__SRC__p(), notification -> {
			incUtil.newMessage();
			name2actor.get("ExtendingType2Doc__CONSISTENCY_19_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.ExtendingType2Doc__Marker, ExtTypeModel.Package>(incUtil, (ExtType2Doc_LookAhead.ExtendingType2Doc__Marker) notification.getNotifier(), (ExtTypeModel.Package) notification.getOldValue(), "ExtType2Doc_LookAhead.ExtendingType2Doc__Marker_CONTEXT__SRC__p_Package"), getSelf());
		});
		feature2removeEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getExtendingType2Doc__Marker_CONTEXT__CORR__p2f(), notification -> {
			incUtil.newMessage();
			name2actor.get("ExtendingType2Doc__CONSISTENCY_19_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.ExtendingType2Doc__Marker, ExtType2Doc_LookAhead.Package2Folder>(incUtil, (ExtType2Doc_LookAhead.ExtendingType2Doc__Marker) notification.getNotifier(), (ExtType2Doc_LookAhead.Package2Folder) notification.getOldValue(), "ExtType2Doc_LookAhead.ExtendingType2Doc__Marker_CONTEXT__CORR__p2f_Package2Folder"), getSelf());
		});
		feature2removeEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getField2Entry_Source(), notification -> {
			incUtil.newMessage();
			name2actor.get("Field2Entry__CONSISTENCY_34_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.Field2Entry, ExtTypeModel.Field>(incUtil, (ExtType2Doc_LookAhead.Field2Entry) notification.getNotifier(), (ExtTypeModel.Field) notification.getOldValue(), "ExtType2Doc_LookAhead.Field2Entry_source_Field"), getSelf());
		});
		feature2removeEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getMethod2Entry__Marker_CREATE__SRC__m(), notification -> {
			incUtil.newMessage();
			name2actor.get("Method2Entry__CONSISTENCY_67_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.Method2Entry__Marker, ExtTypeModel.Method>(incUtil, (ExtType2Doc_LookAhead.Method2Entry__Marker) notification.getNotifier(), (ExtTypeModel.Method) notification.getOldValue(), "ExtType2Doc_LookAhead.Method2Entry__Marker_CREATE__SRC__m_Method"), getSelf());
		});
		feature2removeEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getExtendingType2Doc__Marker_CREATE__SRC__nt(), notification -> {
			incUtil.newMessage();
			name2actor.get("ExtendingType2Doc__CONSISTENCY_19_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.ExtendingType2Doc__Marker, ExtTypeModel.Type>(incUtil, (ExtType2Doc_LookAhead.ExtendingType2Doc__Marker) notification.getNotifier(), (ExtTypeModel.Type) notification.getOldValue(), "ExtType2Doc_LookAhead.ExtendingType2Doc__Marker_CREATE__SRC__nt_Type"), getSelf());
		});
		feature2removeEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getField2Entry__Marker_CONTEXT__SRC__t(), notification -> {
			incUtil.newMessage();
			name2actor.get("Field2Entry__CONSISTENCY_34_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.Field2Entry__Marker, ExtTypeModel.Type>(incUtil, (ExtType2Doc_LookAhead.Field2Entry__Marker) notification.getNotifier(), (ExtTypeModel.Type) notification.getOldValue(), "ExtType2Doc_LookAhead.Field2Entry__Marker_CONTEXT__SRC__t_Type"), getSelf());
		});
		feature2removeEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getExtendingType2Doc__Marker_CREATE__TRG__nd(), notification -> {
			incUtil.newMessage();
			name2actor.get("ExtendingType2Doc__CONSISTENCY_19_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.ExtendingType2Doc__Marker, ExtDocModel.Doc>(incUtil, (ExtType2Doc_LookAhead.ExtendingType2Doc__Marker) notification.getNotifier(), (ExtDocModel.Doc) notification.getOldValue(), "ExtType2Doc_LookAhead.ExtendingType2Doc__Marker_CREATE__TRG__nd_Doc"), getSelf());
		});
		feature2removeEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getSubPackage2Folder__Marker_CREATE__SRC__sp(), notification -> {
			incUtil.newMessage();
			name2actor.get("SubPackage2Folder__CONSISTENCY_104_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.SubPackage2Folder__Marker, ExtTypeModel.Package>(incUtil, (ExtType2Doc_LookAhead.SubPackage2Folder__Marker) notification.getNotifier(), (ExtTypeModel.Package) notification.getOldValue(), "ExtType2Doc_LookAhead.SubPackage2Folder__Marker_CREATE__SRC__sp_Package"), getSelf());
		});
		feature2removeEdgeConsumer.put(ExtTypeModel.ExtTypeModelPackage.eINSTANCE.getField_Type(), notification -> {
			incUtil.newMessage();
			name2actor.get("Field2Entry__SRC_28_localSearch").tell(new ReferenceDeleted<ExtTypeModel.Field, ExtTypeModel.Type>(incUtil, (ExtTypeModel.Field) notification.getNotifier(), (ExtTypeModel.Type) notification.getOldValue(), "ExtTypeModel.Field_type_Type"), getSelf());
		});
		feature2removeEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getField2Entry__Marker_CREATE__CORR__f2e(), notification -> {
			incUtil.newMessage();
			name2actor.get("Field2Entry__CONSISTENCY_34_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.Field2Entry__Marker, ExtType2Doc_LookAhead.Field2Entry>(incUtil, (ExtType2Doc_LookAhead.Field2Entry__Marker) notification.getNotifier(), (ExtType2Doc_LookAhead.Field2Entry) notification.getOldValue(), "ExtType2Doc_LookAhead.Field2Entry__Marker_CREATE__CORR__f2e_Field2Entry"), getSelf());
		});
		feature2removeEdgeConsumer.put(ExtDocModel.ExtDocModelPackage.eINSTANCE.getDoc_Folder(), notification -> {
			incUtil.newMessage();
			name2actor.get("ExtendingType2Doc__TRG_1_localSearch").tell(new ReferenceDeleted<ExtDocModel.Doc, ExtDocModel.Folder>(incUtil, (ExtDocModel.Doc) notification.getNotifier(), (ExtDocModel.Folder) notification.getOldValue(), "ExtDocModel.Doc_folder_Folder"), getSelf());
			incUtil.newMessage();
			name2actor.get("ExtendingType2Doc__TRG_1_localSearch").tell(new ReferenceDeleted<ExtDocModel.Doc, ExtDocModel.Folder>(incUtil, (ExtDocModel.Doc) notification.getNotifier(), (ExtDocModel.Folder) notification.getOldValue(), "ExtDocModel.Doc_folder_Folder"), getSelf());
			incUtil.newMessage();
			name2actor.get("ExtendingType2Doc__FWD_14_localSearch").tell(new ReferenceDeleted<ExtDocModel.Doc, ExtDocModel.Folder>(incUtil, (ExtDocModel.Doc) notification.getNotifier(), (ExtDocModel.Folder) notification.getOldValue(), "ExtDocModel.Doc_folder_Folder"), getSelf());
			incUtil.newMessage();
			name2actor.get("Type2Doc__TRG_107_localSearch").tell(new ReferenceDeleted<ExtDocModel.Doc, ExtDocModel.Folder>(incUtil, (ExtDocModel.Doc) notification.getNotifier(), (ExtDocModel.Folder) notification.getOldValue(), "ExtDocModel.Doc_folder_Folder"), getSelf());
		});
		feature2removeEdgeConsumer.put(ExtTypeModel.ExtTypeModelPackage.eINSTANCE.getPackage_Types(), notification -> {
			incUtil.newMessage();
			name2actor.get("ExtendingType2Doc__BWD_5_localSearch").tell(new ReferenceDeleted<ExtTypeModel.Package, ExtTypeModel.Type>(incUtil, (ExtTypeModel.Package) notification.getNotifier(), (ExtTypeModel.Type) notification.getOldValue(), "ExtTypeModel.Package_types_Type"), getSelf());
			incUtil.newMessage();
			name2actor.get("ExtendingType2Doc__SRC_10_localSearch").tell(new ReferenceDeleted<ExtTypeModel.Package, ExtTypeModel.Type>(incUtil, (ExtTypeModel.Package) notification.getNotifier(), (ExtTypeModel.Type) notification.getOldValue(), "ExtTypeModel.Package_types_Type"), getSelf());
			incUtil.newMessage();
			name2actor.get("ExtendingType2Doc__SRC_10_localSearch").tell(new ReferenceDeleted<ExtTypeModel.Package, ExtTypeModel.Type>(incUtil, (ExtTypeModel.Package) notification.getNotifier(), (ExtTypeModel.Type) notification.getOldValue(), "ExtTypeModel.Package_types_Type"), getSelf());
			incUtil.newMessage();
			name2actor.get("Type2Doc__SRC_113_localSearch").tell(new ReferenceDeleted<ExtTypeModel.Package, ExtTypeModel.Type>(incUtil, (ExtTypeModel.Package) notification.getNotifier(), (ExtTypeModel.Type) notification.getOldValue(), "ExtTypeModel.Package_types_Type"), getSelf());
		});
		feature2removeEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getType2Doc__Marker_CONTEXT__TRG__f(), notification -> {
			incUtil.newMessage();
			name2actor.get("Type2Doc__CONSISTENCY_119_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.Type2Doc__Marker, ExtDocModel.Folder>(incUtil, (ExtType2Doc_LookAhead.Type2Doc__Marker) notification.getNotifier(), (ExtDocModel.Folder) notification.getOldValue(), "ExtType2Doc_LookAhead.Type2Doc__Marker_CONTEXT__TRG__f_Folder"), getSelf());
		});
		feature2removeEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getExtendingType2Doc__Marker_CONTEXT__CORR__t2d(), notification -> {
			incUtil.newMessage();
			name2actor.get("ExtendingType2Doc__CONSISTENCY_19_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.ExtendingType2Doc__Marker, ExtType2Doc_LookAhead.Type2Doc>(incUtil, (ExtType2Doc_LookAhead.ExtendingType2Doc__Marker) notification.getNotifier(), (ExtType2Doc_LookAhead.Type2Doc) notification.getOldValue(), "ExtType2Doc_LookAhead.ExtendingType2Doc__Marker_CONTEXT__CORR__t2d_Type2Doc"), getSelf());
		});
		feature2removeEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getExtendingType2Doc__Marker_CONTEXT__TRG__d(), notification -> {
			incUtil.newMessage();
			name2actor.get("ExtendingType2Doc__CONSISTENCY_19_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.ExtendingType2Doc__Marker, ExtDocModel.Doc>(incUtil, (ExtType2Doc_LookAhead.ExtendingType2Doc__Marker) notification.getNotifier(), (ExtDocModel.Doc) notification.getOldValue(), "ExtType2Doc_LookAhead.ExtendingType2Doc__Marker_CONTEXT__TRG__d_Doc"), getSelf());
		});
		feature2removeEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getParam2Entry__Marker_CREATE__CORR__p2e(), notification -> {
			incUtil.newMessage();
			name2actor.get("Param2Entry__CONSISTENCY_89_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.Param2Entry__Marker, ExtType2Doc_LookAhead.Param2Entry>(incUtil, (ExtType2Doc_LookAhead.Param2Entry__Marker) notification.getNotifier(), (ExtType2Doc_LookAhead.Param2Entry) notification.getOldValue(), "ExtType2Doc_LookAhead.Param2Entry__Marker_CREATE__CORR__p2e_Param2Entry"), getSelf());
		});
		feature2removeEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getImplementingType2Doc__Marker_CONTEXT__SRC__it(), notification -> {
			incUtil.newMessage();
			name2actor.get("ImplementingType2Doc__CONSISTENCY_53_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.ImplementingType2Doc__Marker, ExtTypeModel.Type>(incUtil, (ExtType2Doc_LookAhead.ImplementingType2Doc__Marker) notification.getNotifier(), (ExtTypeModel.Type) notification.getOldValue(), "ExtType2Doc_LookAhead.ImplementingType2Doc__Marker_CONTEXT__SRC__it_Type"), getSelf());
		});
		feature2removeEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getField2Entry__Marker_CONTEXT__TRG__d(), notification -> {
			incUtil.newMessage();
			name2actor.get("Field2Entry__CONSISTENCY_34_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.Field2Entry__Marker, ExtDocModel.Doc>(incUtil, (ExtType2Doc_LookAhead.Field2Entry__Marker) notification.getNotifier(), (ExtDocModel.Doc) notification.getOldValue(), "ExtType2Doc_LookAhead.Field2Entry__Marker_CONTEXT__TRG__d_Doc"), getSelf());
		});
		feature2removeEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getExtendingType2Doc__Marker_CREATE__CORR__nt2nd(), notification -> {
			incUtil.newMessage();
			name2actor.get("ExtendingType2Doc__CONSISTENCY_19_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.ExtendingType2Doc__Marker, ExtType2Doc_LookAhead.Type2Doc>(incUtil, (ExtType2Doc_LookAhead.ExtendingType2Doc__Marker) notification.getNotifier(), (ExtType2Doc_LookAhead.Type2Doc) notification.getOldValue(), "ExtType2Doc_LookAhead.ExtendingType2Doc__Marker_CREATE__CORR__nt2nd_Type2Doc"), getSelf());
		});
		feature2removeEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getImplementingType2Doc__Marker_CONTEXT__CORR__it2id(), notification -> {
			incUtil.newMessage();
			name2actor.get("ImplementingType2Doc__CONSISTENCY_53_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.ImplementingType2Doc__Marker, ExtType2Doc_LookAhead.Type2Doc>(incUtil, (ExtType2Doc_LookAhead.ImplementingType2Doc__Marker) notification.getNotifier(), (ExtType2Doc_LookAhead.Type2Doc) notification.getOldValue(), "ExtType2Doc_LookAhead.ImplementingType2Doc__Marker_CONTEXT__CORR__it2id_Type2Doc"), getSelf());
		});
		feature2removeEdgeConsumer.put(ExtTypeModel.ExtTypeModelPackage.eINSTANCE.getMethod_Type(), notification -> {
			incUtil.newMessage();
			name2actor.get("Method2Entry__SRC_61_localSearch").tell(new ReferenceDeleted<ExtTypeModel.Method, ExtTypeModel.Type>(incUtil, (ExtTypeModel.Method) notification.getNotifier(), (ExtTypeModel.Type) notification.getOldValue(), "ExtTypeModel.Method_type_Type"), getSelf());
		});
		feature2removeEdgeConsumer.put(ExtTypeModel.ExtTypeModelPackage.eINSTANCE.getPackage_SuperPackage(), notification -> {
			incUtil.newMessage();
			name2actor.get("Package2Folder_p_superPackage_outgoing_SRC__FILTER_NAC_SRC_75_localSearch").tell(new ReferenceDeleted<ExtTypeModel.Package, ExtTypeModel.Package>(incUtil, (ExtTypeModel.Package) notification.getNotifier(), (ExtTypeModel.Package) notification.getOldValue(), "ExtTypeModel.Package_superPackage_Package"), getSelf());
			incUtil.newMessage();
			name2actor.get("SubPackage2Folder__SRC_98_localSearch").tell(new ReferenceDeleted<ExtTypeModel.Package, ExtTypeModel.Package>(incUtil, (ExtTypeModel.Package) notification.getNotifier(), (ExtTypeModel.Package) notification.getOldValue(), "ExtTypeModel.Package_superPackage_Package"), getSelf());
		});
		feature2removeEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getParam2Entry__Marker_CONTEXT__CORR__m2e(), notification -> {
			incUtil.newMessage();
			name2actor.get("Param2Entry__CONSISTENCY_89_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.Param2Entry__Marker, ExtType2Doc_LookAhead.Method2Entry>(incUtil, (ExtType2Doc_LookAhead.Param2Entry__Marker) notification.getNotifier(), (ExtType2Doc_LookAhead.Method2Entry) notification.getOldValue(), "ExtType2Doc_LookAhead.Param2Entry__Marker_CONTEXT__CORR__m2e_Method2Entry"), getSelf());
		});
		feature2removeEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getSubPackage2Folder__Marker_CONTEXT__CORR__p2f(), notification -> {
			incUtil.newMessage();
			name2actor.get("SubPackage2Folder__CONSISTENCY_104_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.SubPackage2Folder__Marker, ExtType2Doc_LookAhead.Package2Folder>(incUtil, (ExtType2Doc_LookAhead.SubPackage2Folder__Marker) notification.getNotifier(), (ExtType2Doc_LookAhead.Package2Folder) notification.getOldValue(), "ExtType2Doc_LookAhead.SubPackage2Folder__Marker_CONTEXT__CORR__p2f_Package2Folder"), getSelf());
		});
		feature2removeEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getMethod2Entry__Marker_CREATE__TRG__e(), notification -> {
			incUtil.newMessage();
			name2actor.get("Method2Entry__CONSISTENCY_67_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.Method2Entry__Marker, ExtDocModel.Entry>(incUtil, (ExtType2Doc_LookAhead.Method2Entry__Marker) notification.getNotifier(), (ExtDocModel.Entry) notification.getOldValue(), "ExtType2Doc_LookAhead.Method2Entry__Marker_CREATE__TRG__e_Entry"), getSelf());
		});
		feature2removeEdgeConsumer.put(ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage.eINSTANCE.getPackage2Folder__Marker_CREATE__SRC__p(), notification -> {
			incUtil.newMessage();
			name2actor.get("Package2Folder__CONSISTENCY_80_localSearch").tell(new ReferenceDeleted<ExtType2Doc_LookAhead.Package2Folder__Marker, ExtTypeModel.Package>(incUtil, (ExtType2Doc_LookAhead.Package2Folder__Marker) notification.getNotifier(), (ExtTypeModel.Package) notification.getOldValue(), "ExtType2Doc_LookAhead.Package2Folder__Marker_CREATE__SRC__p_Package"), getSelf());
		});
		feature2removeEdgeConsumer.put(ExtDocModel.ExtDocModelPackage.eINSTANCE.getFolder_SuperFolder(), notification -> {
			incUtil.newMessage();
			name2actor.get("Package2Folder_f_superFolder_outgoing_TRG__FILTER_NAC_TRG_70_localSearch").tell(new ReferenceDeleted<ExtDocModel.Folder, ExtDocModel.Folder>(incUtil, (ExtDocModel.Folder) notification.getNotifier(), (ExtDocModel.Folder) notification.getOldValue(), "ExtDocModel.Folder_superFolder_Folder"), getSelf());
			incUtil.newMessage();
			name2actor.get("SubPackage2Folder__TRG_92_localSearch").tell(new ReferenceDeleted<ExtDocModel.Folder, ExtDocModel.Folder>(incUtil, (ExtDocModel.Folder) notification.getNotifier(), (ExtDocModel.Folder) notification.getOldValue(), "ExtDocModel.Folder_superFolder_Folder"), getSelf());
		});
	}

	@Override
	public void preStart() throws Exception {
		super.preStart();
	}

	@Override
	public void postStop() throws Exception {
		if(HiPEConfig.logWorkloadActivated) {
			DecimalFormat df = new DecimalFormat("0.#####");
	        df.setMaximumFractionDigits(5);
			System.err.println("DispatchNode" + ";"  + counter + ";" + df.format((double) time / (double) (1000 * 1000 * 1000)));
		}
	}

	@Override
	public Receive createReceive() {
		return receiveBuilder() //
				.match(NotificationContainer.class, this::handleNotificationContainer)
				.match(NoMoreInput.class, this::sendFinished) //
				.build();
	}

	private void sendFinished(NoMoreInput m) {
		incUtil.allMessagesInserted();
	}
	
	private void handleNotificationContainer(NotificationContainer nc) {
		counter++;
		long tic = System.nanoTime();
		nc.notifications.parallelStream().forEach(this::handleNotification);
		time += System.nanoTime() - tic;
	}
	
	private void handleNotification(Notification notification) {
		switch (notification.getEventType()) {
		case Notification.ADD:
			handleAdd(notification);
			break;
		case Notification.REMOVE:
			handleRemove(notification);
			break;
		case Notification.REMOVING_ADAPTER:
			handleRemoveAdapter(notification);
			break;	
		case Notification.SET:
			handleSet(notification);
			break;
		}
	}

	private void handleAdd(Notification notification) {
		if(notification.getFeature() == null) 
			handleAddedNode(notification.getNewValue());
		else
			handleAddedEdge(notification);
	}

	private void handleAddedNode(Object node) {
		if(node == null) 
			return;
			
		EObject obj = (EObject) node;
		if(type2addConsumer.containsKey(obj.eClass())) {
			type2addConsumer.get(obj.eClass()).accept(node);
		}
	}
	
	private void handleSet(Notification notification) {
		Object feature = notification.getFeature();
		if(feature2setConsumer.containsKey(feature)) {
			feature2setConsumer.get(feature).accept(notification);
		}
	}

	private void handleAddedEdge(Notification notification) {
		//check for self-edges
		if(notification.getNotifier().equals(notification.getNewValue()))
			handleAddedNode(notification.getNewValue());
					
		Object feature = notification.getFeature();
		if(feature2addEdgeConsumer.containsKey(feature)) {
			feature2addEdgeConsumer.get(feature).accept(notification);
		}
	}

	private void handleRemove(Notification notification) {
		Object feature = notification.getFeature();
		if(feature2removeEdgeConsumer.containsKey(feature)) {
			feature2removeEdgeConsumer.get(feature).accept(notification);
		}
	}
	
	private void handleRemoveAdapter(Notification notification) {
		Object node = notification.getNotifier();
		if (node instanceof ExtDocModel.Entry) {
			incUtil.newMessage();
			name2actor.get("Entry_object").tell(new ObjectDeleted<ExtDocModel.Entry>(incUtil, (ExtDocModel.Entry) node), getSelf());
		}
		if (node instanceof ExtDocModel.Doc) {
			incUtil.newMessage();
			name2actor.get("Doc_object_SP0").tell(new ObjectDeleted<ExtDocModel.Doc>(incUtil, (ExtDocModel.Doc) node), getSelf());
		}
		if (node instanceof ExtDocModel.Doc) {
			incUtil.newMessage();
			name2actor.get("Doc_object_SP1").tell(new ObjectDeleted<ExtDocModel.Doc>(incUtil, (ExtDocModel.Doc) node), getSelf());
		}
		if (node instanceof ExtDocModel.Doc) {
			incUtil.newMessage();
			name2actor.get("Doc_object_SP2").tell(new ObjectDeleted<ExtDocModel.Doc>(incUtil, (ExtDocModel.Doc) node), getSelf());
		}
		if (node instanceof ExtDocModel.Folder) {
			incUtil.newMessage();
			name2actor.get("Folder_object_SP0").tell(new ObjectDeleted<ExtDocModel.Folder>(incUtil, (ExtDocModel.Folder) node), getSelf());
		}
		if (node instanceof ExtDocModel.Folder) {
			incUtil.newMessage();
			name2actor.get("Folder_object_SP1").tell(new ObjectDeleted<ExtDocModel.Folder>(incUtil, (ExtDocModel.Folder) node), getSelf());
		}
		if (node instanceof ExtType2Doc_LookAhead.ExtendingType2Doc__Marker) {
			incUtil.newMessage();
			name2actor.get("ExtendingType2Doc__Marker_object").tell(new ObjectDeleted<ExtType2Doc_LookAhead.ExtendingType2Doc__Marker>(incUtil, (ExtType2Doc_LookAhead.ExtendingType2Doc__Marker) node), getSelf());
		}
		if (node instanceof ExtType2Doc_LookAhead.Field2Entry) {
			incUtil.newMessage();
			name2actor.get("Field2Entry_object").tell(new ObjectDeleted<ExtType2Doc_LookAhead.Field2Entry>(incUtil, (ExtType2Doc_LookAhead.Field2Entry) node), getSelf());
		}
		if (node instanceof ExtType2Doc_LookAhead.Field2Entry__Marker) {
			incUtil.newMessage();
			name2actor.get("Field2Entry__Marker_object").tell(new ObjectDeleted<ExtType2Doc_LookAhead.Field2Entry__Marker>(incUtil, (ExtType2Doc_LookAhead.Field2Entry__Marker) node), getSelf());
		}
		if (node instanceof ExtType2Doc_LookAhead.ImplementingType2Doc__Marker) {
			incUtil.newMessage();
			name2actor.get("ImplementingType2Doc__Marker_object").tell(new ObjectDeleted<ExtType2Doc_LookAhead.ImplementingType2Doc__Marker>(incUtil, (ExtType2Doc_LookAhead.ImplementingType2Doc__Marker) node), getSelf());
		}
		if (node instanceof ExtType2Doc_LookAhead.Method2Entry) {
			incUtil.newMessage();
			name2actor.get("Method2Entry_object").tell(new ObjectDeleted<ExtType2Doc_LookAhead.Method2Entry>(incUtil, (ExtType2Doc_LookAhead.Method2Entry) node), getSelf());
		}
		if (node instanceof ExtType2Doc_LookAhead.Method2Entry__Marker) {
			incUtil.newMessage();
			name2actor.get("Method2Entry__Marker_object").tell(new ObjectDeleted<ExtType2Doc_LookAhead.Method2Entry__Marker>(incUtil, (ExtType2Doc_LookAhead.Method2Entry__Marker) node), getSelf());
		}
		if (node instanceof ExtType2Doc_LookAhead.Package2Folder__Marker) {
			incUtil.newMessage();
			name2actor.get("Package2Folder__Marker_object").tell(new ObjectDeleted<ExtType2Doc_LookAhead.Package2Folder__Marker>(incUtil, (ExtType2Doc_LookAhead.Package2Folder__Marker) node), getSelf());
		}
		if (node instanceof ExtType2Doc_LookAhead.Param2Entry) {
			incUtil.newMessage();
			name2actor.get("Param2Entry_object").tell(new ObjectDeleted<ExtType2Doc_LookAhead.Param2Entry>(incUtil, (ExtType2Doc_LookAhead.Param2Entry) node), getSelf());
		}
		if (node instanceof ExtType2Doc_LookAhead.Param2Entry__Marker) {
			incUtil.newMessage();
			name2actor.get("Param2Entry__Marker_object").tell(new ObjectDeleted<ExtType2Doc_LookAhead.Param2Entry__Marker>(incUtil, (ExtType2Doc_LookAhead.Param2Entry__Marker) node), getSelf());
		}
		if (node instanceof ExtType2Doc_LookAhead.SubPackage2Folder__Marker) {
			incUtil.newMessage();
			name2actor.get("SubPackage2Folder__Marker_object").tell(new ObjectDeleted<ExtType2Doc_LookAhead.SubPackage2Folder__Marker>(incUtil, (ExtType2Doc_LookAhead.SubPackage2Folder__Marker) node), getSelf());
		}
		if (node instanceof ExtType2Doc_LookAhead.Type2Doc__Marker) {
			incUtil.newMessage();
			name2actor.get("Type2Doc__Marker_object").tell(new ObjectDeleted<ExtType2Doc_LookAhead.Type2Doc__Marker>(incUtil, (ExtType2Doc_LookAhead.Type2Doc__Marker) node), getSelf());
		}
		if (node instanceof ExtType2Doc_LookAhead.Package2Folder) {
			incUtil.newMessage();
			name2actor.get("Package2Folder_object_SP0").tell(new ObjectDeleted<ExtType2Doc_LookAhead.Package2Folder>(incUtil, (ExtType2Doc_LookAhead.Package2Folder) node), getSelf());
		}
		if (node instanceof ExtType2Doc_LookAhead.Package2Folder) {
			incUtil.newMessage();
			name2actor.get("Package2Folder_object_SP1").tell(new ObjectDeleted<ExtType2Doc_LookAhead.Package2Folder>(incUtil, (ExtType2Doc_LookAhead.Package2Folder) node), getSelf());
		}
		if (node instanceof ExtType2Doc_LookAhead.Type2Doc) {
			incUtil.newMessage();
			name2actor.get("Type2Doc_object_SP0").tell(new ObjectDeleted<ExtType2Doc_LookAhead.Type2Doc>(incUtil, (ExtType2Doc_LookAhead.Type2Doc) node), getSelf());
		}
		if (node instanceof ExtType2Doc_LookAhead.Type2Doc) {
			incUtil.newMessage();
			name2actor.get("Type2Doc_object_SP1").tell(new ObjectDeleted<ExtType2Doc_LookAhead.Type2Doc>(incUtil, (ExtType2Doc_LookAhead.Type2Doc) node), getSelf());
		}
		if (node instanceof ExtType2Doc_LookAhead.Type2Doc) {
			incUtil.newMessage();
			name2actor.get("Type2Doc_object_SP2").tell(new ObjectDeleted<ExtType2Doc_LookAhead.Type2Doc>(incUtil, (ExtType2Doc_LookAhead.Type2Doc) node), getSelf());
		}
		if (node instanceof ExtTypeModel.Field) {
			incUtil.newMessage();
			name2actor.get("Field_object").tell(new ObjectDeleted<ExtTypeModel.Field>(incUtil, (ExtTypeModel.Field) node), getSelf());
		}
		if (node instanceof ExtTypeModel.Method) {
			incUtil.newMessage();
			name2actor.get("Method_object").tell(new ObjectDeleted<ExtTypeModel.Method>(incUtil, (ExtTypeModel.Method) node), getSelf());
		}
		if (node instanceof ExtTypeModel.Parameter) {
			incUtil.newMessage();
			name2actor.get("Parameter_object").tell(new ObjectDeleted<ExtTypeModel.Parameter>(incUtil, (ExtTypeModel.Parameter) node), getSelf());
		}
		if (node instanceof ExtTypeModel.Package) {
			incUtil.newMessage();
			name2actor.get("Package_object_SP0").tell(new ObjectDeleted<ExtTypeModel.Package>(incUtil, (ExtTypeModel.Package) node), getSelf());
		}
		if (node instanceof ExtTypeModel.Package) {
			incUtil.newMessage();
			name2actor.get("Package_object_SP1").tell(new ObjectDeleted<ExtTypeModel.Package>(incUtil, (ExtTypeModel.Package) node), getSelf());
		}
		if (node instanceof ExtTypeModel.Type) {
			incUtil.newMessage();
			name2actor.get("Type_object_SP0").tell(new ObjectDeleted<ExtTypeModel.Type>(incUtil, (ExtTypeModel.Type) node), getSelf());
		}
		if (node instanceof ExtTypeModel.Type) {
			incUtil.newMessage();
			name2actor.get("Type_object_SP1").tell(new ObjectDeleted<ExtTypeModel.Type>(incUtil, (ExtTypeModel.Type) node), getSelf());
		}
		if (node instanceof ExtTypeModel.Type) {
			incUtil.newMessage();
			name2actor.get("Type_object_SP2").tell(new ObjectDeleted<ExtTypeModel.Type>(incUtil, (ExtTypeModel.Type) node), getSelf());
		}
	}
}

