package org.emoflon.ibex.neo.benchmark.village2constrplan;

public enum DeltaType {
	
	ADD_ROOT, REMOVE_ROOT, MOVE_ROW, CHANGE_TYPE
	
}
