package ConstructionPlan;

import java.lang.String;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.ecore.EEnum;


import org.emoflon.smartemf.runtime.SmartPackage;

public interface ConstructionPlanPackage extends SmartPackage {

	String eNAME = "ConstructionPlan";
	String eNS_URI = "platform:/resource/ConstructionPlan/model/ConstructionPlan.ecore";
	String eNS_PREFIX = "ConstructionPlan";

	ConstructionPlanPackage eINSTANCE = ConstructionPlan.impl.ConstructionPlanPackageImpl.init();

	int PLAN_COLLECTION = 0;
	int PLAN_COLLECTION__PLANS = 0;
	int PLAN_COLLECTION_FEATURE_COUNT = 1;
	int PLAN_COLLECTION_OPERATION_COUNT = 0;
	
	int PLAN = 1;
	int PLAN__CONSTRUCTIONS = 1;
	int PLAN__NAME = 2;
	int PLAN_FEATURE_COUNT = 2;
	int PLAN_OPERATION_COUNT = 0;
	
	int CONSTRUCTION = 2;
	int CONSTRUCTION__FIRST_STEP = 3;
	int CONSTRUCTION__NAME = 4;
	int CONSTRUCTION__NEXT = 5;
	int CONSTRUCTION_FEATURE_COUNT = 3;
	int CONSTRUCTION_OPERATION_COUNT = 0;
	
	int COMPONENT = 3;
	int COMPONENT__NEXT_STEP = 6;
	int COMPONENT__DESCRIPTION = 7;
	int COMPONENT_FEATURE_COUNT = 2;
	int COMPONENT_OPERATION_COUNT = 0;
	
	int CELLAR = 4;
	int CELLAR_FEATURE_COUNT = 2;
	int CELLAR_OPERATION_COUNT = 0;
	
	int BASEMENT = 5;
	int BASEMENT_FEATURE_COUNT = 2;
	int BASEMENT_OPERATION_COUNT = 0;
	
	int SADDLE_ROOF = 6;
	int SADDLE_ROOF_FEATURE_COUNT = 2;
	int SADDLE_ROOF_OPERATION_COUNT = 0;
	
	

	EClass getPlanCollection();
	EReference getPlanCollection_Plans();
	
	EClass getPlan();
	EReference getPlan_Constructions();
	EAttribute getPlan_Name();
	
	EClass getConstruction();
	EReference getConstruction_FirstStep();
	EAttribute getConstruction_Name();
	EReference getConstruction_Next();
	
	EClass getComponent();
	EReference getComponent_NextStep();
	EAttribute getComponent_Description();
	
	EClass getCellar();
	
	EClass getBasement();
	
	EClass getSaddleRoof();
	
	
	ConstructionPlan.ConstructionPlanFactory getConstructionPlanFactory();

	interface Literals {
		
		EClass PLAN_COLLECTION = eINSTANCE.getPlanCollection();
		
		EReference PLAN_COLLECTION__PLANS = eINSTANCE.getPlanCollection_Plans();
		
		EClass PLAN = eINSTANCE.getPlan();
		
		EReference PLAN__CONSTRUCTIONS = eINSTANCE.getPlan_Constructions();
		
		EAttribute PLAN__NAME = eINSTANCE.getPlan_Name();
		
		EClass CONSTRUCTION = eINSTANCE.getConstruction();
		
		EReference CONSTRUCTION__FIRST_STEP = eINSTANCE.getConstruction_FirstStep();
		
		EAttribute CONSTRUCTION__NAME = eINSTANCE.getConstruction_Name();
		
		EReference CONSTRUCTION__NEXT = eINSTANCE.getConstruction_Next();
		
		EClass COMPONENT = eINSTANCE.getComponent();
		
		EReference COMPONENT__NEXT_STEP = eINSTANCE.getComponent_NextStep();
		
		EAttribute COMPONENT__DESCRIPTION = eINSTANCE.getComponent_Description();
		
		EClass CELLAR = eINSTANCE.getCellar();
		
		EClass BASEMENT = eINSTANCE.getBasement();
		
		EClass SADDLE_ROOF = eINSTANCE.getSaddleRoof();
		
		
		
		
	}

} 
