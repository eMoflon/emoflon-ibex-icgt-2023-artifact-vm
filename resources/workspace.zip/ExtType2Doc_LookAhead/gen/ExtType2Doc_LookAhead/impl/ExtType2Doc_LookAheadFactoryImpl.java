package ExtType2Doc_LookAhead.impl;

import ExtType2Doc_LookAhead.Package2Folder;
import ExtType2Doc_LookAhead.Type2Doc;
import ExtType2Doc_LookAhead.Method2Entry;
import ExtType2Doc_LookAhead.Param2Entry;
import ExtType2Doc_LookAhead.Field2Entry;
import ExtType2Doc_LookAhead.ExtendingType2Doc__Marker;
import ExtType2Doc_LookAhead.Field2Entry__Marker;
import ExtType2Doc_LookAhead.ImplementingType2Doc__Marker;
import ExtType2Doc_LookAhead.Method2Entry__Marker;
import ExtType2Doc_LookAhead.Package2Folder__Marker;
import ExtType2Doc_LookAhead.Param2Entry__Marker;
import ExtType2Doc_LookAhead.SubPackage2Folder__Marker;
import ExtType2Doc_LookAhead.Type2Doc__Marker;


import ExtType2Doc_LookAhead.ExtType2Doc_LookAheadFactory;
import ExtType2Doc_LookAhead.ExtType2Doc_LookAheadPackage;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

public class ExtType2Doc_LookAheadFactoryImpl extends EFactoryImpl implements ExtType2Doc_LookAhead.ExtType2Doc_LookAheadFactory {

	public static ExtType2Doc_LookAhead.ExtType2Doc_LookAheadFactory init() {
		try {
			ExtType2Doc_LookAheadFactory theExtType2Doc_LookAheadFactory = (ExtType2Doc_LookAheadFactory) EPackage.Registry.INSTANCE
					.getEFactory(ExtType2Doc_LookAheadPackage.eNS_URI);
			if (theExtType2Doc_LookAheadFactory != null) {
				return theExtType2Doc_LookAheadFactory;
			}
		} catch (java.lang.Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new ExtType2Doc_LookAheadFactoryImpl();
	}

	public ExtType2Doc_LookAheadFactoryImpl() {
		super();
	}

	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
		case ExtType2Doc_LookAheadPackage.PACKAGE2_FOLDER:
			return createPackage2Folder();
		case ExtType2Doc_LookAheadPackage.TYPE2_DOC:
			return createType2Doc();
		case ExtType2Doc_LookAheadPackage.METHOD2_ENTRY:
			return createMethod2Entry();
		case ExtType2Doc_LookAheadPackage.PARAM2_ENTRY:
			return createParam2Entry();
		case ExtType2Doc_LookAheadPackage.FIELD2_ENTRY:
			return createField2Entry();
		case ExtType2Doc_LookAheadPackage.EXTENDING_TYPE2_DOC___MARKER:
			return createExtendingType2Doc__Marker();
		case ExtType2Doc_LookAheadPackage.FIELD2_ENTRY___MARKER:
			return createField2Entry__Marker();
		case ExtType2Doc_LookAheadPackage.IMPLEMENTING_TYPE2_DOC___MARKER:
			return createImplementingType2Doc__Marker();
		case ExtType2Doc_LookAheadPackage.METHOD2_ENTRY___MARKER:
			return createMethod2Entry__Marker();
		case ExtType2Doc_LookAheadPackage.PACKAGE2_FOLDER___MARKER:
			return createPackage2Folder__Marker();
		case ExtType2Doc_LookAheadPackage.PARAM2_ENTRY___MARKER:
			return createParam2Entry__Marker();
		case ExtType2Doc_LookAheadPackage.SUB_PACKAGE2_FOLDER___MARKER:
			return createSubPackage2Folder__Marker();
		case ExtType2Doc_LookAheadPackage.TYPE2_DOC___MARKER:
			return createType2Doc__Marker();
		default:
			throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}
	
	
	@Override
	public ExtType2Doc_LookAhead.Package2Folder createPackage2Folder() {
		Package2FolderImpl package2Folder = new Package2FolderImpl();
		return package2Folder;
	}
	@Override
	public ExtType2Doc_LookAhead.Type2Doc createType2Doc() {
		Type2DocImpl type2Doc = new Type2DocImpl();
		return type2Doc;
	}
	@Override
	public ExtType2Doc_LookAhead.Method2Entry createMethod2Entry() {
		Method2EntryImpl method2Entry = new Method2EntryImpl();
		return method2Entry;
	}
	@Override
	public ExtType2Doc_LookAhead.Param2Entry createParam2Entry() {
		Param2EntryImpl param2Entry = new Param2EntryImpl();
		return param2Entry;
	}
	@Override
	public ExtType2Doc_LookAhead.Field2Entry createField2Entry() {
		Field2EntryImpl field2Entry = new Field2EntryImpl();
		return field2Entry;
	}
	@Override
	public ExtType2Doc_LookAhead.ExtendingType2Doc__Marker createExtendingType2Doc__Marker() {
		ExtendingType2Doc__MarkerImpl extendingType2Doc__Marker = new ExtendingType2Doc__MarkerImpl();
		return extendingType2Doc__Marker;
	}
	@Override
	public ExtType2Doc_LookAhead.Field2Entry__Marker createField2Entry__Marker() {
		Field2Entry__MarkerImpl field2Entry__Marker = new Field2Entry__MarkerImpl();
		return field2Entry__Marker;
	}
	@Override
	public ExtType2Doc_LookAhead.ImplementingType2Doc__Marker createImplementingType2Doc__Marker() {
		ImplementingType2Doc__MarkerImpl implementingType2Doc__Marker = new ImplementingType2Doc__MarkerImpl();
		return implementingType2Doc__Marker;
	}
	@Override
	public ExtType2Doc_LookAhead.Method2Entry__Marker createMethod2Entry__Marker() {
		Method2Entry__MarkerImpl method2Entry__Marker = new Method2Entry__MarkerImpl();
		return method2Entry__Marker;
	}
	@Override
	public ExtType2Doc_LookAhead.Package2Folder__Marker createPackage2Folder__Marker() {
		Package2Folder__MarkerImpl package2Folder__Marker = new Package2Folder__MarkerImpl();
		return package2Folder__Marker;
	}
	@Override
	public ExtType2Doc_LookAhead.Param2Entry__Marker createParam2Entry__Marker() {
		Param2Entry__MarkerImpl param2Entry__Marker = new Param2Entry__MarkerImpl();
		return param2Entry__Marker;
	}
	@Override
	public ExtType2Doc_LookAhead.SubPackage2Folder__Marker createSubPackage2Folder__Marker() {
		SubPackage2Folder__MarkerImpl subPackage2Folder__Marker = new SubPackage2Folder__MarkerImpl();
		return subPackage2Folder__Marker;
	}
	@Override
	public ExtType2Doc_LookAhead.Type2Doc__Marker createType2Doc__Marker() {
		Type2Doc__MarkerImpl type2Doc__Marker = new Type2Doc__MarkerImpl();
		return type2Doc__Marker;
	}
	

	@Override
	public ExtType2Doc_LookAheadPackage getExtType2Doc_LookAheadPackage() {
	return (ExtType2Doc_LookAheadPackage) getEPackage();
	}
} 
