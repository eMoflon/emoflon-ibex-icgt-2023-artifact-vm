package ExtDocModel.impl;

import ExtDocModel.NamedElement;
import ExtDocModel.Folder;
import ExtDocModel.Doc;
import ExtDocModel.Entry;
import ExtDocModel.Annotation;
import ExtDocModel.Glossary;
import ExtDocModel.GlossaryEntry;
import ExtDocModel.DocContainer;

import ExtDocModel.EntryType;

import ExtDocModel.ExtDocModelFactory;
import ExtDocModel.ExtDocModelPackage;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

public class ExtDocModelFactoryImpl extends EFactoryImpl implements ExtDocModel.ExtDocModelFactory {

	public static ExtDocModel.ExtDocModelFactory init() {
		try {
			ExtDocModelFactory theExtDocModelFactory = (ExtDocModelFactory) EPackage.Registry.INSTANCE
					.getEFactory(ExtDocModelPackage.eNS_URI);
			if (theExtDocModelFactory != null) {
				return theExtDocModelFactory;
			}
		} catch (java.lang.Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new ExtDocModelFactoryImpl();
	}

	public ExtDocModelFactoryImpl() {
		super();
	}

	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
		case ExtDocModelPackage.FOLDER:
			return createFolder();
		case ExtDocModelPackage.DOC:
			return createDoc();
		case ExtDocModelPackage.ENTRY:
			return createEntry();
		case ExtDocModelPackage.ANNOTATION:
			return createAnnotation();
		case ExtDocModelPackage.GLOSSARY:
			return createGlossary();
		case ExtDocModelPackage.GLOSSARY_ENTRY:
			return createGlossaryEntry();
		case ExtDocModelPackage.DOC_CONTAINER:
			return createDocContainer();
		default:
			throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}
	
		@Override
		public Object createFromString(EDataType eDataType, String initialValue) {
			switch (eDataType.getClassifierID()) {
			case ExtDocModelPackage.ENTRY_TYPE:
				return createEntryTypeFromString(eDataType, initialValue);
			default:
				throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
			}
		}

	@Override
	public String convertToString(EDataType eDataType, Object instanceValue) {
		switch (eDataType.getClassifierID()) {
		case ExtDocModelPackage.ENTRY_TYPE:
			return convertEntryTypeToString(eDataType, instanceValue);
		default:
			throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}
	
	@Override
	public ExtDocModel.Folder createFolder() {
		FolderImpl folder = new FolderImpl();
		return folder;
	}
	@Override
	public ExtDocModel.Doc createDoc() {
		DocImpl doc = new DocImpl();
		return doc;
	}
	@Override
	public ExtDocModel.Entry createEntry() {
		EntryImpl entry = new EntryImpl();
		return entry;
	}
	@Override
	public ExtDocModel.Annotation createAnnotation() {
		AnnotationImpl annotation = new AnnotationImpl();
		return annotation;
	}
	@Override
	public ExtDocModel.Glossary createGlossary() {
		GlossaryImpl glossary = new GlossaryImpl();
		return glossary;
	}
	@Override
	public ExtDocModel.GlossaryEntry createGlossaryEntry() {
		GlossaryEntryImpl glossaryEntry = new GlossaryEntryImpl();
		return glossaryEntry;
	}
	@Override
	public ExtDocModel.DocContainer createDocContainer() {
		DocContainerImpl docContainer = new DocContainerImpl();
		return docContainer;
	}
	
	public EntryType createEntryTypeFromString(EDataType eDataType, String initialValue) {
		EntryType result = EntryType.get(initialValue);
		if (result == null)
			throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
				
		return result;
	}
	
	public String convertEntryTypeToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	@Override
	public ExtDocModelPackage getExtDocModelPackage() {
	return (ExtDocModelPackage) getEPackage();
	}
} 
