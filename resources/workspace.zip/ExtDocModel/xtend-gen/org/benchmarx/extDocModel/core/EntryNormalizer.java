package org.benchmarx.extDocModel.core;

import ExtDocModel.Entry;
import org.benchmarx.util.Normalizer;

@SuppressWarnings("all")
public class EntryNormalizer extends Normalizer<Entry> {
  @Override
  public int compare(final Entry o1, final Entry o2) {
    return o1.getName().compareTo(o2.getName());
  }
}
