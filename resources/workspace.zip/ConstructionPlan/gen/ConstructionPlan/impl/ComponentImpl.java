package ConstructionPlan.impl;

import ConstructionPlan.ConstructionPlanPackage;
import ConstructionPlan.ConstructionPlanPackage;

import org.emoflon.smartemf.runtime.*;
import org.emoflon.smartemf.runtime.collections.*;
import org.emoflon.smartemf.persistence.SmartEMFResource;
import org.emoflon.smartemf.runtime.notification.SmartEMFNotification;
import org.emoflon.smartemf.runtime.notification.NotifyStatus;

import java.util.function.Consumer;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EcoreFactory;
import org.eclipse.emf.ecore.EcorePackage;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.resource.Resource;

public class ComponentImpl extends SmartObject implements ConstructionPlan.Component {

    protected ConstructionPlan.Component nextStep = null;
    protected java.lang.String description = null;
	
	protected ComponentImpl() {
		super(ConstructionPlanPackage.Literals.COMPONENT);
	}
	
    
    @Override
    public ConstructionPlan.Component getNextStep() {
    	return this.nextStep;
    }
    
    @Override
    public void setNextStep(ConstructionPlan.Component value) {
    	
    	Object oldValue = this.nextStep;
    	
    	if(value == null && oldValue == null)
    		return;
    		
    	if(value != null && value.equals(oldValue))
    		return;
    		
    	
    	Resource.Internal resource = (Resource.Internal) eResource();
    		        if(oldValue != null && value != null) {
    		        	setResourceWithoutChecks(null);
    		        }
    		        
    		        NotifyStatus status = NotifyStatus.SUCCESS_NO_NOTIFICATION;
    	if(oldValue != null) {
    	        		status = ((MinimalSObjectContainer) oldValue).resetContainment();
    	}	
    	
    		        this.nextStep = value;
    		        
    	
    	
    			 	if(oldValue != null && value != null) {
    		        	setResourceWithoutChecks(resource);
    		        }
    	
    	if(value != null)
    		status = ((MinimalSObjectContainer) this.nextStep).setContainment(this, ConstructionPlanPackage.Literals.COMPONENT__NEXT_STEP);
    	
    	
    	if(status == NotifyStatus.SUCCESS_NO_NOTIFICATION || oldValue != null && value != null)
    	        	sendNotification(SmartEMFNotification.createSetNotification(this, ConstructionPlanPackage.Literals.COMPONENT__NEXT_STEP, oldValue, value, -1));
    	        	
    	        	if(ConstructionPlanPackage.Literals.COMPONENT__NEXT_STEP.getEOpposite() != null) {
    	        		if(oldValue != null) {
    	        			((SmartObject) oldValue).eInverseRemove(this, ConstructionPlanPackage.Literals.COMPONENT__NEXT_STEP.getEOpposite());
    	        		}
    	        		if(value != null) {
    	        		    ((SmartObject) value).eInverseAdd(this, ConstructionPlanPackage.Literals.COMPONENT__NEXT_STEP.getEOpposite());
    	        		}
    	        	}
    }
    
    
    @Override
    public java.lang.String getDescription() {
    	return this.description;
    }
    
    @Override
    public void setDescription(java.lang.String value) {
    	Object oldValue = this.description;
    	this.description = value;
    	
    	        	sendNotification(SmartEMFNotification.createSetNotification(this, ConstructionPlanPackage.Literals.COMPONENT__DESCRIPTION, oldValue, value, -1));
    }
    

    @Override
    public void eSet(EStructuralFeature eFeature, Object newValue){
    	if (ConstructionPlanPackage.Literals.COMPONENT__NEXT_STEP.equals(eFeature)) {
    		setNextStep((ConstructionPlan.Component) newValue); 
    		return;
    	}
    	if (ConstructionPlanPackage.Literals.COMPONENT__DESCRIPTION.equals(eFeature)) {
    		setDescription((java.lang.String) newValue); 
    		return;
    	}
    	eDynamicSet(eFeature, newValue);
    }
    
    @Override
    public void eUnset(EStructuralFeature eFeature){
    	if (ConstructionPlanPackage.Literals.COMPONENT__NEXT_STEP.equals(eFeature)) {
    		setNextStep((ConstructionPlan.Component)null); 
    		return;
    	}
    	if (ConstructionPlanPackage.Literals.COMPONENT__DESCRIPTION.equals(eFeature)) {
    		setDescription((java.lang.String)null); 
    		return;
    	}
    	eDynamicUnset(eFeature);
    }

    @Override
    public String toString(){
		StringBuilder b = new StringBuilder();
		b.append(super.toString());
		b.append(" (");
		if (SmartEMFConfig.simpleStringRepresentations()) {
			b.append("description: ");
			b.append(getDescription());
		} else {
			b.append("description: ");
			b.append(getDescription());
		}
		b.append(")");
		return b.toString();
    }

 	@Override
    public Object eGet(EStructuralFeature eFeature){
    	if (ConstructionPlanPackage.Literals.COMPONENT__NEXT_STEP.equals(eFeature))
    		return getNextStep();
    	if (ConstructionPlanPackage.Literals.COMPONENT__DESCRIPTION.equals(eFeature))
    		return getDescription();
    	return eDynamicGet(eFeature);
    }

    @Override
    public Object eGet(int featureID, boolean resolve, boolean coreType){
    	throw new UnsupportedOperationException("This method has been deactivated since it is not always safe to use.");
    }
    
    @Override
    public void eInverseAdd(Object otherEnd, EStructuralFeature feature) {
	    if(feature == null)
	    	return;
	    	
    	eDynamicInverseAdd(otherEnd, feature);
	    	}
    	
    @Override
	    	public void eInverseRemove(Object otherEnd, EStructuralFeature feature) {
	    if(feature == null)
	    	return;
	    		    		
    	eDynamicInverseRemove(otherEnd, feature);
	    	}
    
    @Override
    /**
    * This method sets the resource and generates REMOVING_ADAPTER and ADD notifications
    */
    protected void setResourceOfContainments(Consumer<SmartObject> setResourceCall) {
if(getNextStep() != null)
	setResourceCall.accept((SmartObject) getNextStep());
	    	}
	    	
	    	@Override
	    	/**
	    	* This method sets the resource and only generates REMOVING_ADAPTER notifications (no ADD messages)
	    	*/
    protected void setResourceOfContainmentsSilently(Resource r) { 		
if(getNextStep() != null)
    ((SmartObject) getNextStep()).setResourceSilently(r);
	    	}
}
