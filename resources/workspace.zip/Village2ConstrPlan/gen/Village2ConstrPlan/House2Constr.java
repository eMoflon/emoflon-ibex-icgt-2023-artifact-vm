package Village2ConstrPlan;

import runtime.RuntimePackage;
import Village2ConstrPlan.Village2ConstrPlanPackage;

import org.emoflon.smartemf.runtime.notification.SmartEMFNotification;
import org.emoflon.smartemf.runtime.SmartObject;
import org.emoflon.smartemf.runtime.collections.*;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EStructuralFeature;

public interface House2Constr extends EObject, runtime.CorrespondenceNode {
	
    public Village.House getSource();
    
    public void setSource(Village.House value);
    
    public ConstructionPlan.Construction getTarget();
    
    public void setTarget(ConstructionPlan.Construction value);
    

}
