package Village2ConstrPlan;

import java.lang.String;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.ecore.EEnum;


import org.emoflon.smartemf.runtime.SmartPackage;

public interface Village2ConstrPlanPackage extends SmartPackage {

	String eNAME = "Village2ConstrPlan";
	String eNS_URI = "platform:/resource/Village2ConstrPlan/model/Village2ConstrPlan.ecore";
	String eNS_PREFIX = "Village2ConstrPlan";

	Village2ConstrPlanPackage eINSTANCE = Village2ConstrPlan.impl.Village2ConstrPlanPackageImpl.init();

	int VILLAGE_SQUARE2_PLAN_COLLECTION = 0;
	int VILLAGE_SQUARE2_PLAN_COLLECTION__SOURCE = 0;
	int VILLAGE_SQUARE2_PLAN_COLLECTION__TARGET = 1;
	int VILLAGE_SQUARE2_PLAN_COLLECTION_FEATURE_COUNT = 2;
	int VILLAGE_SQUARE2_PLAN_COLLECTION_OPERATION_COUNT = 0;
	
	int HOUSE2_CONSTR = 1;
	int HOUSE2_CONSTR__SOURCE = 2;
	int HOUSE2_CONSTR__TARGET = 3;
	int HOUSE2_CONSTR_FEATURE_COUNT = 2;
	int HOUSE2_CONSTR_OPERATION_COUNT = 0;
	
	int CORNER2_CONSTR___MARKER = 2;
	int CORNER2_CONSTR___MARKER__CREAT_E__SR_C__H = 4;
	int CORNER2_CONSTR___MARKER__CONTEX_T__SR_C__VS = 5;
	int CORNER2_CONSTR___MARKER__CREAT_E__TR_G__BT = 6;
	int CORNER2_CONSTR___MARKER__CREAT_E__TR_G__CST = 7;
	int CORNER2_CONSTR___MARKER__CREAT_E__TR_G__P = 8;
	int CORNER2_CONSTR___MARKER__CONTEX_T__TR_G__PC = 9;
	int CORNER2_CONSTR___MARKER__CREAT_E__COR_R__H2CST = 10;
	int CORNER2_CONSTR___MARKER__CONTEX_T__COR_R__VS2PC = 11;
	int CORNER2_CONSTR___MARKER_FEATURE_COUNT = 9;
	int CORNER2_CONSTR___MARKER_OPERATION_COUNT = 0;
	
	int CUBE2_CONSTR___MARKER = 3;
	int CUBE2_CONSTR___MARKER__CONTEX_T__SR_C__H = 12;
	int CUBE2_CONSTR___MARKER__CREAT_E__SR_C__NH = 13;
	int CUBE2_CONSTR___MARKER__CREAT_E__TR_G__BT = 14;
	int CUBE2_CONSTR___MARKER__CREAT_E__TR_G__CL = 15;
	int CUBE2_CONSTR___MARKER__CONTEX_T__TR_G__CST = 16;
	int CUBE2_CONSTR___MARKER__CREAT_E__TR_G__NCST = 17;
	int CUBE2_CONSTR___MARKER__CONTEX_T__TR_G__P = 18;
	int CUBE2_CONSTR___MARKER__CONTEX_T__COR_R__H2CST = 19;
	int CUBE2_CONSTR___MARKER__CREAT_E__COR_R__NH2NCST = 20;
	int CUBE2_CONSTR___MARKER_FEATURE_COUNT = 10;
	int CUBE2_CONSTR___MARKER_OPERATION_COUNT = 0;
	
	int VILLA2_CONSTR___MARKER = 4;
	int VILLA2_CONSTR___MARKER__CONTEX_T__SR_C__H = 21;
	int VILLA2_CONSTR___MARKER__CREAT_E__SR_C__NH = 22;
	int VILLA2_CONSTR___MARKER__CREAT_E__TR_G__BT = 23;
	int VILLA2_CONSTR___MARKER__CONTEX_T__TR_G__CST = 24;
	int VILLA2_CONSTR___MARKER__CREAT_E__TR_G__NCST = 25;
	int VILLA2_CONSTR___MARKER__CONTEX_T__TR_G__P = 26;
	int VILLA2_CONSTR___MARKER__CREAT_E__TR_G__SR = 27;
	int VILLA2_CONSTR___MARKER__CONTEX_T__COR_R__H2CST = 28;
	int VILLA2_CONSTR___MARKER__CREAT_E__COR_R__NH2NCST = 29;
	int VILLA2_CONSTR___MARKER_FEATURE_COUNT = 10;
	int VILLA2_CONSTR___MARKER_OPERATION_COUNT = 0;
	
	int VILLAGE_SQUARE2_PLAN_COLLECTION___MARKER = 5;
	int VILLAGE_SQUARE2_PLAN_COLLECTION___MARKER__CREAT_E__SR_C__VS = 30;
	int VILLAGE_SQUARE2_PLAN_COLLECTION___MARKER__CREAT_E__TR_G__PC = 31;
	int VILLAGE_SQUARE2_PLAN_COLLECTION___MARKER__CREAT_E__COR_R__VS2PL = 32;
	int VILLAGE_SQUARE2_PLAN_COLLECTION___MARKER_FEATURE_COUNT = 4;
	int VILLAGE_SQUARE2_PLAN_COLLECTION___MARKER_OPERATION_COUNT = 0;
	
	

	EClass getVillageSquare2PlanCollection();
	EReference getVillageSquare2PlanCollection_Source();
	EReference getVillageSquare2PlanCollection_Target();
	
	EClass getHouse2Constr();
	EReference getHouse2Constr_Source();
	EReference getHouse2Constr_Target();
	
	EClass getCorner2Constr__Marker();
	EReference getCorner2Constr__Marker_CREATE__SRC__h();
	EReference getCorner2Constr__Marker_CONTEXT__SRC__vs();
	EReference getCorner2Constr__Marker_CREATE__TRG__bt();
	EReference getCorner2Constr__Marker_CREATE__TRG__cst();
	EReference getCorner2Constr__Marker_CREATE__TRG__p();
	EReference getCorner2Constr__Marker_CONTEXT__TRG__pc();
	EReference getCorner2Constr__Marker_CREATE__CORR__h2cst();
	EReference getCorner2Constr__Marker_CONTEXT__CORR__vs2pc();
	
	EClass getCube2Constr__Marker();
	EReference getCube2Constr__Marker_CONTEXT__SRC__h();
	EReference getCube2Constr__Marker_CREATE__SRC__nh();
	EReference getCube2Constr__Marker_CREATE__TRG__bt();
	EReference getCube2Constr__Marker_CREATE__TRG__cl();
	EReference getCube2Constr__Marker_CONTEXT__TRG__cst();
	EReference getCube2Constr__Marker_CREATE__TRG__ncst();
	EReference getCube2Constr__Marker_CONTEXT__TRG__p();
	EReference getCube2Constr__Marker_CONTEXT__CORR__h2cst();
	EReference getCube2Constr__Marker_CREATE__CORR__nh2ncst();
	
	EClass getVilla2Constr__Marker();
	EReference getVilla2Constr__Marker_CONTEXT__SRC__h();
	EReference getVilla2Constr__Marker_CREATE__SRC__nh();
	EReference getVilla2Constr__Marker_CREATE__TRG__bt();
	EReference getVilla2Constr__Marker_CONTEXT__TRG__cst();
	EReference getVilla2Constr__Marker_CREATE__TRG__ncst();
	EReference getVilla2Constr__Marker_CONTEXT__TRG__p();
	EReference getVilla2Constr__Marker_CREATE__TRG__sr();
	EReference getVilla2Constr__Marker_CONTEXT__CORR__h2cst();
	EReference getVilla2Constr__Marker_CREATE__CORR__nh2ncst();
	
	EClass getVillageSquare2PlanCollection__Marker();
	EReference getVillageSquare2PlanCollection__Marker_CREATE__SRC__vs();
	EReference getVillageSquare2PlanCollection__Marker_CREATE__TRG__pc();
	EReference getVillageSquare2PlanCollection__Marker_CREATE__CORR__vs2pl();
	
	
	Village2ConstrPlan.Village2ConstrPlanFactory getVillage2ConstrPlanFactory();

	interface Literals {
		
		EClass VILLAGE_SQUARE2_PLAN_COLLECTION = eINSTANCE.getVillageSquare2PlanCollection();
		
		EReference VILLAGE_SQUARE2_PLAN_COLLECTION__SOURCE = eINSTANCE.getVillageSquare2PlanCollection_Source();
		
		EReference VILLAGE_SQUARE2_PLAN_COLLECTION__TARGET = eINSTANCE.getVillageSquare2PlanCollection_Target();
		
		EClass HOUSE2_CONSTR = eINSTANCE.getHouse2Constr();
		
		EReference HOUSE2_CONSTR__SOURCE = eINSTANCE.getHouse2Constr_Source();
		
		EReference HOUSE2_CONSTR__TARGET = eINSTANCE.getHouse2Constr_Target();
		
		EClass CORNER2_CONSTR___MARKER = eINSTANCE.getCorner2Constr__Marker();
		
		EReference CORNER2_CONSTR___MARKER__CREAT_E__SR_C__H = eINSTANCE.getCorner2Constr__Marker_CREATE__SRC__h();
		
		EReference CORNER2_CONSTR___MARKER__CONTEX_T__SR_C__VS = eINSTANCE.getCorner2Constr__Marker_CONTEXT__SRC__vs();
		
		EReference CORNER2_CONSTR___MARKER__CREAT_E__TR_G__BT = eINSTANCE.getCorner2Constr__Marker_CREATE__TRG__bt();
		
		EReference CORNER2_CONSTR___MARKER__CREAT_E__TR_G__CST = eINSTANCE.getCorner2Constr__Marker_CREATE__TRG__cst();
		
		EReference CORNER2_CONSTR___MARKER__CREAT_E__TR_G__P = eINSTANCE.getCorner2Constr__Marker_CREATE__TRG__p();
		
		EReference CORNER2_CONSTR___MARKER__CONTEX_T__TR_G__PC = eINSTANCE.getCorner2Constr__Marker_CONTEXT__TRG__pc();
		
		EReference CORNER2_CONSTR___MARKER__CREAT_E__COR_R__H2CST = eINSTANCE.getCorner2Constr__Marker_CREATE__CORR__h2cst();
		
		EReference CORNER2_CONSTR___MARKER__CONTEX_T__COR_R__VS2PC = eINSTANCE.getCorner2Constr__Marker_CONTEXT__CORR__vs2pc();
		
		EClass CUBE2_CONSTR___MARKER = eINSTANCE.getCube2Constr__Marker();
		
		EReference CUBE2_CONSTR___MARKER__CONTEX_T__SR_C__H = eINSTANCE.getCube2Constr__Marker_CONTEXT__SRC__h();
		
		EReference CUBE2_CONSTR___MARKER__CREAT_E__SR_C__NH = eINSTANCE.getCube2Constr__Marker_CREATE__SRC__nh();
		
		EReference CUBE2_CONSTR___MARKER__CREAT_E__TR_G__BT = eINSTANCE.getCube2Constr__Marker_CREATE__TRG__bt();
		
		EReference CUBE2_CONSTR___MARKER__CREAT_E__TR_G__CL = eINSTANCE.getCube2Constr__Marker_CREATE__TRG__cl();
		
		EReference CUBE2_CONSTR___MARKER__CONTEX_T__TR_G__CST = eINSTANCE.getCube2Constr__Marker_CONTEXT__TRG__cst();
		
		EReference CUBE2_CONSTR___MARKER__CREAT_E__TR_G__NCST = eINSTANCE.getCube2Constr__Marker_CREATE__TRG__ncst();
		
		EReference CUBE2_CONSTR___MARKER__CONTEX_T__TR_G__P = eINSTANCE.getCube2Constr__Marker_CONTEXT__TRG__p();
		
		EReference CUBE2_CONSTR___MARKER__CONTEX_T__COR_R__H2CST = eINSTANCE.getCube2Constr__Marker_CONTEXT__CORR__h2cst();
		
		EReference CUBE2_CONSTR___MARKER__CREAT_E__COR_R__NH2NCST = eINSTANCE.getCube2Constr__Marker_CREATE__CORR__nh2ncst();
		
		EClass VILLA2_CONSTR___MARKER = eINSTANCE.getVilla2Constr__Marker();
		
		EReference VILLA2_CONSTR___MARKER__CONTEX_T__SR_C__H = eINSTANCE.getVilla2Constr__Marker_CONTEXT__SRC__h();
		
		EReference VILLA2_CONSTR___MARKER__CREAT_E__SR_C__NH = eINSTANCE.getVilla2Constr__Marker_CREATE__SRC__nh();
		
		EReference VILLA2_CONSTR___MARKER__CREAT_E__TR_G__BT = eINSTANCE.getVilla2Constr__Marker_CREATE__TRG__bt();
		
		EReference VILLA2_CONSTR___MARKER__CONTEX_T__TR_G__CST = eINSTANCE.getVilla2Constr__Marker_CONTEXT__TRG__cst();
		
		EReference VILLA2_CONSTR___MARKER__CREAT_E__TR_G__NCST = eINSTANCE.getVilla2Constr__Marker_CREATE__TRG__ncst();
		
		EReference VILLA2_CONSTR___MARKER__CONTEX_T__TR_G__P = eINSTANCE.getVilla2Constr__Marker_CONTEXT__TRG__p();
		
		EReference VILLA2_CONSTR___MARKER__CREAT_E__TR_G__SR = eINSTANCE.getVilla2Constr__Marker_CREATE__TRG__sr();
		
		EReference VILLA2_CONSTR___MARKER__CONTEX_T__COR_R__H2CST = eINSTANCE.getVilla2Constr__Marker_CONTEXT__CORR__h2cst();
		
		EReference VILLA2_CONSTR___MARKER__CREAT_E__COR_R__NH2NCST = eINSTANCE.getVilla2Constr__Marker_CREATE__CORR__nh2ncst();
		
		EClass VILLAGE_SQUARE2_PLAN_COLLECTION___MARKER = eINSTANCE.getVillageSquare2PlanCollection__Marker();
		
		EReference VILLAGE_SQUARE2_PLAN_COLLECTION___MARKER__CREAT_E__SR_C__VS = eINSTANCE.getVillageSquare2PlanCollection__Marker_CREATE__SRC__vs();
		
		EReference VILLAGE_SQUARE2_PLAN_COLLECTION___MARKER__CREAT_E__TR_G__PC = eINSTANCE.getVillageSquare2PlanCollection__Marker_CREATE__TRG__pc();
		
		EReference VILLAGE_SQUARE2_PLAN_COLLECTION___MARKER__CREAT_E__COR_R__VS2PL = eINSTANCE.getVillageSquare2PlanCollection__Marker_CREATE__CORR__vs2pl();
		
		
		
		
	}

} 
