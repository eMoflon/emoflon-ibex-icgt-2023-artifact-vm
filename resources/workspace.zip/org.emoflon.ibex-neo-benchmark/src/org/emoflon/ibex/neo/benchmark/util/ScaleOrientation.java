package org.emoflon.ibex.neo.benchmark.util;

public enum ScaleOrientation {
	
	VERTICAL,
	HORIZONTAL;
	
}
