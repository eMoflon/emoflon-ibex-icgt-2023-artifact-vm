package ExtDocModel;

import ExtDocModel.ExtDocModelPackage;

import org.emoflon.smartemf.runtime.notification.SmartEMFNotification;
import org.emoflon.smartemf.runtime.SmartObject;
import org.emoflon.smartemf.runtime.collections.*;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EStructuralFeature;

public interface Entry extends EObject, ExtDocModel.NamedElement {
	
    public java.lang.String getName();
    
    public void setName(java.lang.String value);
    
    public ExtDocModel.Doc getDoc();
    
    public void setDoc(ExtDocModel.Doc value);
    
    public LinkedSmartESet<ExtDocModel.Annotation> getAnnotations();
    
    public void setAnnotations(LinkedSmartESet<ExtDocModel.Annotation> value);
    
    public LinkedSmartESet<ExtDocModel.GlossaryEntry> getGlossaryEntries();
    
    public void setGlossaryEntries(LinkedSmartESet<ExtDocModel.GlossaryEntry> value);
    
    public ExtDocModel.EntryType getType();
    
    public void setType(ExtDocModel.EntryType value);
    

}
