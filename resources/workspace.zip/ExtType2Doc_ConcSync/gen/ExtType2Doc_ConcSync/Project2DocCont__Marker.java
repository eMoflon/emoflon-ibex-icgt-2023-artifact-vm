package ExtType2Doc_ConcSync;

import runtime.RuntimePackage;
import ExtType2Doc_ConcSync.ExtType2Doc_ConcSyncPackage;

import org.emoflon.smartemf.runtime.notification.SmartEMFNotification;
import org.emoflon.smartemf.runtime.SmartObject;
import org.emoflon.smartemf.runtime.collections.*;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EStructuralFeature;

public interface Project2DocCont__Marker extends EObject, runtime.TGGRuleApplication {
	
    public runtime.Protocol getProtocol();
    
    public void setProtocol(runtime.Protocol value);
    
    public ExtTypeModel.Project getCREATE__SRC__pr();
    
    public void setCREATE__SRC__pr(ExtTypeModel.Project value);
    
    public ExtDocModel.DocContainer getCREATE__TRG__dc();
    
    public void setCREATE__TRG__dc(ExtDocModel.DocContainer value);
    
    public ExtType2Doc_ConcSync.Project2DocContainer getCREATE__CORR__pr2dc();
    
    public void setCREATE__CORR__pr2dc(ExtType2Doc_ConcSync.Project2DocContainer value);
    

}
