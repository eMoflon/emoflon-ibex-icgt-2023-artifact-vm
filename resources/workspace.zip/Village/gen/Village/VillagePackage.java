package Village;

import java.lang.String;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.ecore.EEnum;


import org.emoflon.smartemf.runtime.SmartPackage;

public interface VillagePackage extends SmartPackage {

	String eNAME = "Village";
	String eNS_URI = "platform:/resource/Village/model/Village.ecore";
	String eNS_PREFIX = "Village";

	VillagePackage eINSTANCE = Village.impl.VillagePackageImpl.init();

	int VILLAGE_SQUARE = 0;
	int VILLAGE_SQUARE__STREET_CORNER = 0;
	int VILLAGE_SQUARE_FEATURE_COUNT = 1;
	int VILLAGE_SQUARE_OPERATION_COUNT = 0;
	
	int HOUSE = 1;
	int HOUSE__NEXT_HOUSE = 1;
	int HOUSE__NAME = 2;
	int HOUSE__TYPE = 3;
	int HOUSE__ADDRESS = 4;
	int HOUSE_FEATURE_COUNT = 4;
	int HOUSE_OPERATION_COUNT = 0;
	
	int HOUSE_TYPE = 2;
	

	EClass getVillageSquare();
	EReference getVillageSquare_StreetCorner();
	
	EClass getHouse();
	EReference getHouse_NextHouse();
	EAttribute getHouse_Name();
	EAttribute getHouse_Type();
	EAttribute getHouse_Address();
	
	EEnum getHouseType();
	
	Village.VillageFactory getVillageFactory();

	interface Literals {
		
		EClass VILLAGE_SQUARE = eINSTANCE.getVillageSquare();
		
		EReference VILLAGE_SQUARE__STREET_CORNER = eINSTANCE.getVillageSquare_StreetCorner();
		
		EClass HOUSE = eINSTANCE.getHouse();
		
		EReference HOUSE__NEXT_HOUSE = eINSTANCE.getHouse_NextHouse();
		
		EAttribute HOUSE__NAME = eINSTANCE.getHouse_Name();
		
		EAttribute HOUSE__TYPE = eINSTANCE.getHouse_Type();
		
		EAttribute HOUSE__ADDRESS = eINSTANCE.getHouse_Address();
		
		
		EEnum HOUSE_TYPE = eINSTANCE.getHouseType();
		
		
	}

} 
