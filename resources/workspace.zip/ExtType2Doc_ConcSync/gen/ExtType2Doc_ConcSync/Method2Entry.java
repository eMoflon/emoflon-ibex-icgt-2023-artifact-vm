package ExtType2Doc_ConcSync;

import runtime.RuntimePackage;
import ExtType2Doc_ConcSync.ExtType2Doc_ConcSyncPackage;

import org.emoflon.smartemf.runtime.notification.SmartEMFNotification;
import org.emoflon.smartemf.runtime.SmartObject;
import org.emoflon.smartemf.runtime.collections.*;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EStructuralFeature;

public interface Method2Entry extends EObject, runtime.CorrespondenceNode {
	
    public ExtTypeModel.Method getSource();
    
    public void setSource(ExtTypeModel.Method value);
    
    public ExtDocModel.Entry getTarget();
    
    public void setTarget(ExtDocModel.Entry value);
    

}
