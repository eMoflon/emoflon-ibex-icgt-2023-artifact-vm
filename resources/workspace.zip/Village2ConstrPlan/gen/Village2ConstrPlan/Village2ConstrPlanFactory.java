package Village2ConstrPlan;

import Village2ConstrPlan.VillageSquare2PlanCollection;
import Village2ConstrPlan.House2Constr;
import Village2ConstrPlan.Corner2Constr__Marker;
import Village2ConstrPlan.Cube2Constr__Marker;
import Village2ConstrPlan.Villa2Constr__Marker;
import Village2ConstrPlan.VillageSquare2PlanCollection__Marker;

import org.eclipse.emf.ecore.EFactory;

public interface Village2ConstrPlanFactory extends EFactory {

	Village2ConstrPlanFactory eINSTANCE = Village2ConstrPlan.impl.Village2ConstrPlanFactoryImpl.init();
	
	VillageSquare2PlanCollection createVillageSquare2PlanCollection();
	
	House2Constr createHouse2Constr();
	
	Corner2Constr__Marker createCorner2Constr__Marker();
	
	Cube2Constr__Marker createCube2Constr__Marker();
	
	Villa2Constr__Marker createVilla2Constr__Marker();
	
	VillageSquare2PlanCollection__Marker createVillageSquare2PlanCollection__Marker();
	
	
	Village2ConstrPlanPackage getVillage2ConstrPlanPackage();

}
