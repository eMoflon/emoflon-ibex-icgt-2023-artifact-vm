package ExtDocModel;

import java.lang.String;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.ecore.EEnum;


import org.emoflon.smartemf.runtime.SmartPackage;

public interface ExtDocModelPackage extends SmartPackage {

	String eNAME = "ExtDocModel";
	String eNS_URI = "platform:/resource/ExtDocModel/model/ExtDocModel.ecore";
	String eNS_PREFIX = "ExtDocModel";

	ExtDocModelPackage eINSTANCE = ExtDocModel.impl.ExtDocModelPackageImpl.init();

	int NAMED_ELEMENT = 0;
	int NAMED_ELEMENT__NAME = 0;
	int NAMED_ELEMENT_FEATURE_COUNT = 1;
	int NAMED_ELEMENT_OPERATION_COUNT = 0;
	
	int FOLDER = 1;
	int FOLDER__DOCS = 1;
	int FOLDER__CONTAINER = 2;
	int FOLDER__SUB_FOLDER = 3;
	int FOLDER__SUPER_FOLDER = 4;
	int FOLDER_FEATURE_COUNT = 5;
	int FOLDER_OPERATION_COUNT = 0;
	
	int DOC = 2;
	int DOC__FOLDER = 5;
	int DOC__ENTRIES = 6;
	int DOC__SUB_DOCS = 7;
	int DOC__SUPER_DOCS = 8;
	int DOC_FEATURE_COUNT = 5;
	int DOC_OPERATION_COUNT = 0;
	
	int ENTRY = 3;
	int ENTRY__DOC = 9;
	int ENTRY__ANNOTATIONS = 10;
	int ENTRY__GLOSSARY_ENTRIES = 11;
	int ENTRY__TYPE = 12;
	int ENTRY_FEATURE_COUNT = 5;
	int ENTRY_OPERATION_COUNT = 0;
	
	int ANNOTATION = 4;
	int ANNOTATION__ENTRY = 13;
	int ANNOTATION__VALUE = 14;
	int ANNOTATION_FEATURE_COUNT = 2;
	int ANNOTATION_OPERATION_COUNT = 0;
	
	int GLOSSARY = 5;
	int GLOSSARY__ENTRIES = 15;
	int GLOSSARY__CONTAINER = 16;
	int GLOSSARY_FEATURE_COUNT = 2;
	int GLOSSARY_OPERATION_COUNT = 0;
	
	int GLOSSARY_ENTRY = 6;
	int GLOSSARY_ENTRY__GLOSSARY = 17;
	int GLOSSARY_ENTRY__ENTRIES = 18;
	int GLOSSARY_ENTRY_FEATURE_COUNT = 3;
	int GLOSSARY_ENTRY_OPERATION_COUNT = 0;
	
	int DOC_CONTAINER = 8;
	int DOC_CONTAINER__FOLDERS = 19;
	int DOC_CONTAINER__GLOSSARY = 20;
	int DOC_CONTAINER_FEATURE_COUNT = 2;
	int DOC_CONTAINER_OPERATION_COUNT = 0;
	
	int ENTRY_TYPE = 7;
	

	EClass getNamedElement();
	EAttribute getNamedElement_Name();
	
	EClass getFolder();
	EReference getFolder_Docs();
	EReference getFolder_Container();
	EReference getFolder_SubFolder();
	EReference getFolder_SuperFolder();
	
	EClass getDoc();
	EReference getDoc_Folder();
	EReference getDoc_Entries();
	EReference getDoc_SubDocs();
	EReference getDoc_SuperDocs();
	
	EClass getEntry();
	EReference getEntry_Doc();
	EReference getEntry_Annotations();
	EReference getEntry_GlossaryEntries();
	EAttribute getEntry_Type();
	
	EClass getAnnotation();
	EReference getAnnotation_Entry();
	EAttribute getAnnotation_Value();
	
	EClass getGlossary();
	EReference getGlossary_Entries();
	EReference getGlossary_Container();
	
	EClass getGlossaryEntry();
	EReference getGlossaryEntry_Glossary();
	EReference getGlossaryEntry_Entries();
	
	EClass getDocContainer();
	EReference getDocContainer_Folders();
	EReference getDocContainer_Glossary();
	
	EEnum getEntryType();
	
	ExtDocModel.ExtDocModelFactory getExtDocModelFactory();

	interface Literals {
		
		EClass NAMED_ELEMENT = eINSTANCE.getNamedElement();
		
		EAttribute NAMED_ELEMENT__NAME = eINSTANCE.getNamedElement_Name();
		
		EClass FOLDER = eINSTANCE.getFolder();
		
		EReference FOLDER__DOCS = eINSTANCE.getFolder_Docs();
		
		EReference FOLDER__CONTAINER = eINSTANCE.getFolder_Container();
		
		EReference FOLDER__SUB_FOLDER = eINSTANCE.getFolder_SubFolder();
		
		EReference FOLDER__SUPER_FOLDER = eINSTANCE.getFolder_SuperFolder();
		
		EClass DOC = eINSTANCE.getDoc();
		
		EReference DOC__FOLDER = eINSTANCE.getDoc_Folder();
		
		EReference DOC__ENTRIES = eINSTANCE.getDoc_Entries();
		
		EReference DOC__SUB_DOCS = eINSTANCE.getDoc_SubDocs();
		
		EReference DOC__SUPER_DOCS = eINSTANCE.getDoc_SuperDocs();
		
		EClass ENTRY = eINSTANCE.getEntry();
		
		EReference ENTRY__DOC = eINSTANCE.getEntry_Doc();
		
		EReference ENTRY__ANNOTATIONS = eINSTANCE.getEntry_Annotations();
		
		EReference ENTRY__GLOSSARY_ENTRIES = eINSTANCE.getEntry_GlossaryEntries();
		
		EAttribute ENTRY__TYPE = eINSTANCE.getEntry_Type();
		
		EClass ANNOTATION = eINSTANCE.getAnnotation();
		
		EReference ANNOTATION__ENTRY = eINSTANCE.getAnnotation_Entry();
		
		EAttribute ANNOTATION__VALUE = eINSTANCE.getAnnotation_Value();
		
		EClass GLOSSARY = eINSTANCE.getGlossary();
		
		EReference GLOSSARY__ENTRIES = eINSTANCE.getGlossary_Entries();
		
		EReference GLOSSARY__CONTAINER = eINSTANCE.getGlossary_Container();
		
		EClass GLOSSARY_ENTRY = eINSTANCE.getGlossaryEntry();
		
		EReference GLOSSARY_ENTRY__GLOSSARY = eINSTANCE.getGlossaryEntry_Glossary();
		
		EReference GLOSSARY_ENTRY__ENTRIES = eINSTANCE.getGlossaryEntry_Entries();
		
		EClass DOC_CONTAINER = eINSTANCE.getDocContainer();
		
		EReference DOC_CONTAINER__FOLDERS = eINSTANCE.getDocContainer_Folders();
		
		EReference DOC_CONTAINER__GLOSSARY = eINSTANCE.getDocContainer_Glossary();
		
		
		EEnum ENTRY_TYPE = eINSTANCE.getEntryType();
		
		
	}

} 
